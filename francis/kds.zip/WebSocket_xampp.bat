cd backend\scripts
:before
c:\xampp\php\php.exe WebSocket.php
timeout 5
goto before
PAUSE

