cd backend\scripts
:before
..\..\..\apache\php72\php.exe WebSocket.php
timeout 5
goto before
PAUSE