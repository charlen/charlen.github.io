cd backend\scripts
:before
c:\xampp\php\php.exe checkForUpdate.php
timeout 5
goto before
PAUSE