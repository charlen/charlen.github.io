projectScripts = {};
projectScripts.filesToUpdate = ['mobile/config.json'];
projectScripts.environmentExtraParams = ['wsport', 'endPointPushNotification', 'endPointPagerNotification'];
projectScripts.services = [
    {"fileName": 'KDSWebSocket_serviceInstaller.bat', 'name': 'KDSWebSocket'},
    {"fileName": 'KDSCheckForUpdate_serviceInstaller.bat', 'name': 'KDSCheckForUpdate'}
];


exports = projectScripts;