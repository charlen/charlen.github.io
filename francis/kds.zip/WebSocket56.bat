cd backend\scripts
:before
..\..\..\apache\php56\php.exe WebSocket.php
timeout 5
goto before
PAUSE