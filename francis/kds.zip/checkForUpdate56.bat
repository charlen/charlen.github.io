cd backend\scripts
:before
..\..\..\apache\php56\php.exe checkForUpdate.php
timeout 5
goto before
PAUSE