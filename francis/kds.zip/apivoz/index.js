var express = require('express');
var app = express();
var request = require('request');

var bodyParser = require('body-parser');

// create application/json parser
var jsonParser = bodyParser.json()

// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.get('/', jsonParser, function (req, res) {
  res.send('OK');
});

app.post('/apivoz/', jsonParser, function (req, res) {
    console.log(req.body.text);
    res.send('OK');
});

app.get('/pager/*', jsonParser, function (req, res) {
    console.log('Notificado');
    res.send('OK');
});  

app.listen(3000, jsonParser, function () {
  console.log('Running on 3000!');
});
