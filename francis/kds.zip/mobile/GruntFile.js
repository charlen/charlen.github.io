module.exports = function(grunt) {
    var utilitiesPath   = 'js/util/*.js';
    var directivesPath  = 'js/directives/*.js';
    var repositoryPath  = 'js/model/**/*.js';
    var servicePath     = 'js/services/**/*.js';
    var controllerPath  = 'js/controllers/*.js';

    var assetsPath = [
        utilitiesPath,
        repositoryPath,
        'js/services/Environment.js',
        'js/services/SummaryItemsService.js',
        'js/services/SoundService.js',
        'js/services/ScreenMessagesService.js',
        'js/services/NavigatorService.js',
        'js/services/SocketService.js',
        'js/services/ConcludeQueue.js',
        'js/services/OrderActionService.js',
        servicePath,
        directivesPath,
        controllerPath
    ];

    grunt.initConfig({
        concat: {
            none: {},
            zh: {
                options: {
                    process: function(src, filepath) {
                        return '\n' + '// FILE: ' + filepath + '\n' + src;
                    }
                },
                src: assetsPath,
                dest: 'dist/kds_main.js'
            }
        },
        jshint: {
            all: ['Gruntfile.js', assetsPath],
            options: {
            	esversion: 6
            }
        },
        uglify: {
            options: {
                mangle: false,
                compress: false,
                report: 'min',
                // the banner is inserted at the top of the output
                banner: '/*! <%= grunt.template.today("dd-mm-yyyy") %> */\n'
            },
            dist: {
                files: {
                    'dist/kds.min.js': assetsPath
                }
            }
        },
        watch: {
            pivotal: {
                files: assetsPath,
                tasks: ['concat', 'jshint']
            }
        }
    });

    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-watch');


    // Default task.
    grunt.registerTask('default', ['jshint', 'concat']);
};