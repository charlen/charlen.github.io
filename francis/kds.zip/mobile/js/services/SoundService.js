function SoundService(environment) {

	var audioArray = {};
	var beepPath;
	var self = this;
	var initialInfo = environment.getLocalEnvironment();
	var continuosBeepArray = {};

	this.configureBeep = function() {
		var audio;
		if (initialInfo && initialInfo.SOMBEEP) {
			var SOMBEEP = initialInfo.SOMBEEP.substr(initialInfo.SOMBEEP.indexOf('kds'));
			beepPath = "http://" + window.location.hostname + ':' + window.location.port + '/' + SOMBEEP;
		} else {
			beepPath = "assets/beep.mp3";
		}
		audio =  new Audio(beepPath);
		audioArray[beepPath] = audio;
	};

	this.beep = function(continuosBeep) {
		var audio = audioArray[beepPath];
		var widget = environment.getKDSWidget();
		if(!widget.beeping && continuosBeep) {
			widget.beeping = setInterval(function() {
				if(isSomeOrderBeeping(widget)) {
					try{
						audio.play();
					}catch(error){
						console.log(error);
					}
				}
			}, 1000);
		} else if(!continuosBeep) {
			try{
				audio.play();
			}catch(error){
				console.log(error);
			}
		}
	};

	function isSomeOrderBeeping(widget) {
		var orders = widget.dataSource.data;
		return orders.some(function(order) {
			return order.isOrderBeeping;
		});
	}

	this.playSound = function(audioLink, continuosBeepName){
		var soundPath;
		if (audioLink) {
			audioLink = audioLink.substr(audioLink.indexOf('kds'));
			soundPath = "http://" + window.location.hostname + ':' + window.location.port + '/' + audioLink;
		} else {
			soundPath = "assets/beep.mp3";
		}
		if (!audioArray[soundPath]) {
			var audio =  new Audio(soundPath);
			audioArray[soundPath] = audio;
		}
		try{
			if(continuosBeepName && !continuosBeepArray[continuosBeepName]){
				audioArray[soundPath].play();
				continuosBeepArray[continuosBeepName] = setInterval(function() {
					if(someOrderStillBeeping(continuosBeepName)){
						try{
							audioArray[soundPath].play();
						}catch(error){
							console.log(error);
						}
					}else{
						clearInterval(continuosBeepArray[continuosBeepName]);
						continuosBeepArray[continuosBeepName] = null;
					}
				}, 1000);
			}
		}catch(error){
			console.log(error);
		}

		function someOrderStillBeeping(continuosBeepName) {
			var orders = environment.getKDSWidget().dataSource.data;
			return orders.some(function(order) {
				return order[continuosBeepName];
			});
		}
	};

}

Configuration(function(ContextRegister) {
	ContextRegister.register('SoundService', SoundService);
});