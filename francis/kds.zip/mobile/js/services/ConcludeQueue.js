function ConcludeQueue(environment, SocketServiceKDS, $timeout, $interval, SummaryItemsService) {

	var self = this;

    this.queue = [];

    this.insert = function(order, isZoom) {
        var rollbackLimitTime = environment.getLocalEnvironment().NRROLLBTIME;
        order.keepOrderColor = true;
        if (environment.getLocalEnvironment().IDTIPOSETOR === 'E'){
            order.expeditionDelayBeep = false;
        }
        var toConcludeOrder = {
            order: order,
            isZoom: isZoom,
            timer : $timeout(timeoutConclusionQueue, rollbackLimitTime, true)
        };
        self.queue.push(toConcludeOrder);
    };

    this.pop = function() {
        return self.queue.pop();
    };

    this.isQueueEmpty = function() {
        return self.queue.length === 0;
    };

    this.get = function() {
        return self.queue;
    };

    this.checkItemExistence = function(orderKey) {
        return self.queue.some(function(item) {
            return orderKey && item.order.orderKey == orderKey;
        });
    };

    function timeoutConclusionQueue() {
        var localConclusionOrder = self.queue.shift();
        handleConcludeOrder(localConclusionOrder.order, localConclusionOrder.isZoom);
    }

    function handleConcludeOrder(order, isZoom) {
        var widget = environment.getKDSWidget();
        var localEnvironment = environment.getLocalEnvironment();
        var sectorType  = localEnvironment.IDTIPOSETOR;
        var CDFILIAL    = localEnvironment.CDFILIAL;
        var NRPEDIDOFOS = order.NRPEDIDOFOS;
        var orderKey    = order.orderKey;
        var CDSETOR     = localEnvironment.CDSETOR;
        var clientKey   = CDFILIAL + '-' + CDSETOR;

        if (sectorType === 'E' || sectorType === 'M') {
            order.CDFILIAL = CDFILIAL;
            var itemsArray  = order.items ? order.items : [order];
            SocketServiceKDS.concludeExpedition(CDFILIAL, itemsArray, orderKey, clientKey, CDSETOR);
            if(order.items){
                if(order.orderCode){
                    //se for uma ordem
                    clearOrderTimeControl(order);
                    widget.dataSource.data.splice(widget.dataSource.data.indexOf(order), 1);
                } else {
                    //se for um grupo
                    widget.dataSource.data.forEach(function(dataOrder){
                        dataOrder.items.forEach(function(dataItem, index, items){
                            if(dataItem.orderKey == order.orderKey){
                                items.splice(index);
                            }
                        });
                    });
                }
            }
        } else if(sectorType === 'P'){
            var NRITPEDIDOFOS = order.items[0].NRITPEDIDOFOS;
            SocketServiceKDS.concludeRequest(CDFILIAL, NRPEDIDOFOS, NRITPEDIDOFOS, orderKey, clientKey, CDSETOR);
            widget.dataSource.data.splice(widget.dataSource.data.indexOf(order), 1);
            SummaryItemsService.updateSummaryItems();
        }
    }

    function clearOrderTimeControl(order) {
        if(order.timerInterval) {
            $interval.cancel(order.timerInterval);
            delete order.timerInterval;
        }
        if(order.colorTimeout) {
			$timeout.cancel(order.colorTimeout);
			delete order.colorTimeout;
		}
    }

}

Configuration(function(ContextRegister) {
	ContextRegister.register('ConcludeQueue', ConcludeQueue);
});