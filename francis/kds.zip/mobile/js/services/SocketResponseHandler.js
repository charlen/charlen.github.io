function SocketResponseHandler(eventAggregator){

	function publishEvent(eventName, params) {
		eventAggregator.publish(eventName, params);
	}

	this.sendChanges = function(data) {
		publishEvent("onProductionResponse", data.orders);
	};

	this.sendConclusions = function(data) {
		publishEvent("onProductionConclude", data);
	};

	this.sendStatistics= function(data){
		publishEvent("onStatisticsUpdate", data);
	};

	this.deleteOrders = function(data) {
		publishEvent("onDeleteOrders", data);
	};

	this.freezeUpdates = function(data) {
		publishEvent("onFreezeUpdates", data);
	};

	this.unfreezeUpdates = function(data) {
		publishEvent("onUnfreezeUpdates", data);
	};

	this.newMessage = function(data) {
		publishEvent("onNewMessage", data);
	};

	this.deleteMessage = function(data) {
		publishEvent("onDeleteMessage", data);
	};

    this.pong = function(data) {
		publishEvent("onPong", data);
    };
}