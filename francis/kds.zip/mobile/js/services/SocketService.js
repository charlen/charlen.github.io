function SocketService(ZhSocketFactory, ScreenService, ApplicationContext, environment, eventAggregator, ScreenMessagesService) {
	var self = this;
	// var host = 'ws://odh-pdt014:8080';
	var host = 'ws://' + window.location.hostname + ':';
	var webSocket = null;
	var securityKey = null;
	var socketEvents = {
		LOGIN_BROWSER      : 'loginBrowser',
		DELETE_ORDERS      : 'deleteOrders',
		LOGOFF_BROWSER     : 'logoffBrowser',
		PLAY_REQUEST       : 'playRequest',
		CONCLUDE_REQUEST   : 'concludeRequest',
		EXPEDITION_REQUEST : 'expeditionRequest',
		CLEAR_SCREEN       : 'clearScreen',
		GET_DATA           : 'getData',
		PING_EVENT         : 'ping',
		FREEZE             : 'freezeUpdates',
		UNFREEZE           : 'unfreezeUpdates'
	};

    var mutex = true;
    var intervalPing;
    var pingTime = 10000;
    var NUMBER_OF_PINGS_TO_RESYNCRONIZE = 2;
    var inLogoff = false;
    self.lastPong = null;
    var isConnected = false;

	this.startWebSocket = function() {
		var text = null;
		var port = null;
		var xhr = new XMLHttpRequest();
		xhr.open("GET", "http://" + window.location.hostname + ':' + window.location.port + "/kds/backend/environment.xml");
		xhr.responseType = "text";//force the HTTP response, response-type header to be blob
		xhr.onload = function()
		{
		    text = xhr.response;//xhr.response is now a blob object
	     	if (~text.indexOf('wsport')) {
		     	port = text.substr(text.indexOf('wsport') + 8);//+ 'wsport">'.length
		     	port = port.substr(0, port.indexOf('</'));
	     	} else {
	     		port = '8080';
			}
			host = 'ws://' + window.location.hostname + ':' + port;
			createWebSocket();
			addWebSocketListeners();
		};
		xhr.send();

		/*if (intervalPing == undefined) {
			intervalPing = setInterval(self.ping, pingTime);
		}*/
	};

	function createWebSocket() {
		webSocket = ZhSocketFactory.create(socketClientFactory, host, ApplicationContext);
	}

	function socketClientFactory() {
		return new SocketResponseHandler(eventAggregator);
	}

	function addWebSocketListeners() {
		webSocket.addListener({
			connectionLost : function(){
				if (!inLogoff) {
					ScreenService.notificationMessage("Sem conexão com o servidor.", 'error', 4000);
				} else {
					inLogoff = !inLogoff;
				}
				self.lastPong = null;
				isConnected = false;
			},
			onOpen :  function(){
				isConnected = true;
				var environmentParams = environment.getLocalEnvironment();
				if(environmentParams && environmentParams.CDFILIAL && environmentParams.CDSETOR){
					self.loginBrowser(environmentParams.CDFILIAL, environmentParams.CDSETOR);
					ScreenMessagesService.clearMessages();
					if(!environmentParams.cleanRequestsOnLogin){
						setTimeout(function(){self.getData(environmentParams.CDFILIAL, environmentParams.CDSETOR);}, 1000);
					}
				}
			}
		});
	}

	this.isConnected = function() {
		return isConnected;
	};

	this.isOpen = function() {
		return webSocket.isOpen();
	};

	this.loginBrowser = function(CDFILIAL, CDSETOR) {
		var date = new Date();
		securityKey = CDFILIAL + '-' + CDSETOR + '-' + date.getMilliseconds() + Math.floor((Math.random() * 100) + 1);
		this.send({
			event: socketEvents.LOGIN_BROWSER,
			data: {
				'CDFILIAL': CDFILIAL,
				'CDSETOR': CDSETOR
			}
		});
	};

	this.send = function send(parameters){
		try {
			parameters.data.SECURITYKEY = securityKey;
			webSocket.send(JSON.stringify(parameters));
		} catch(erro){
			setTimeout(function(){self.send(parameters);console.log(erro);}, 1000);
		}
	};

	this.logoffBrowser = function() {
		var environmentParams = environment.getLocalEnvironment();
		this.send({
			event: socketEvents.LOGOFF_BROWSER,
			data: {
				'CDFILIAL': environmentParams.CDFILIAL,
				'CDSETOR': environmentParams.CDSETOR
			}
		});
		webSocket.close();
		/*clearInterval(intervalPing);
		intervalPing = null;*/
		inLogoff = true;
	};

	this.playRequest = function(CDFILIAL, NRPEDIDOFOS, NRITPEDIDOFOS, CDSETOR){
		this.send({
			event: socketEvents.PLAY_REQUEST,
			data: {
				'CDFILIAL': CDFILIAL,
				'NRPEDIDOFOS': NRPEDIDOFOS,
				'NRITPEDIDOFOS': NRITPEDIDOFOS,
				'CDSETOR': CDSETOR
			}
		});
	};

	this.concludeRequest = function(CDFILIAL, NRPEDIDOFOS, NRITPEDIDOFOS, orderKey, clientKey, CDSETOR){
		this.send({
			event: socketEvents.CONCLUDE_REQUEST,
			data: {
				'CDFILIAL': CDFILIAL,
				'NRPEDIDOFOS': NRPEDIDOFOS,
				'NRITPEDIDOFOS': NRITPEDIDOFOS,
				'orderKey' :orderKey,
				'clientKey' :clientKey,
				'CDSETOR': CDSETOR
			}
		});
	};

	this.concludeExpedition = function(CDFILIAL, itemsArray, orderKey, clientKey, CDSETOR){
		this.send({
			event: socketEvents.EXPEDITION_REQUEST,
			data: {
				'CDFILIAL': CDFILIAL,
				'CDSETOR': CDSETOR,
				'itemsArray': JSON.stringify(itemsArray),
				'orderKey': orderKey,
				'clientKey': clientKey
			}
		});
	};

	this.clearScreen = function(CDFILIAL, CDSETOR, hoursNumber = 0){
		this.send({
			event: socketEvents.CLEAR_SCREEN,
			data: {
				'CDFILIAL': CDFILIAL,
				'CDSETOR': CDSETOR,
				'clearScreen': true,
				'hoursNumber': hoursNumber
			}
		});
	};

	this.freezeUpdates = function(){
		this.send({
			event: socketEvents.FREEZE,
			data: {}
		});
	};

	this.unfreezeUpdates = function(){
		this.send({
			event: socketEvents.UNFREEZE,
			data: {}
		});
	};

	this.getData = function(CDFILIAL, CDSETOR){
		this.send({
			event: socketEvents.GET_DATA,
			data: {
				'CDFILIAL': CDFILIAL,
				'CDSETOR': CDSETOR,
				'clearScreen': true
			}
		});
	};

    this.ping = function() {
        var environmentParams = environment.getLocalEnvironment();
        if (mutex) {
            try {
                mutex = false;
                if (isConnected) {
                    webSocket.send({
                        event: socketEvents.PING_EVENT,
                        data: {
                            'CDFILIAL': environmentParams.CDFILIAL,
                            'CDSETOR': environmentParams.CDSETOR
                        }
                    });
                    if (self.isServerNotResponding()) {
                        webSocket.close();
                    }
                }
                mutex = true;
            } catch(err) {
                console.log('SocketService - ping error:');
                console.log(err);
                mutex = true;
            }
        } else {
            console.log('SocketService - mutex false');
        }
    };

    this.onPong = function() {
        self.lastPong = new Date();
    };

    this.isServerNotResponding = function() {
        var now = new Date();
        return self.lastPong && (now - self.lastPong) > (NUMBER_OF_PINGS_TO_RESYNCRONIZE * pingTime);
    };
}

Configuration(function(ContextRegister) {
	ContextRegister.register('SocketServiceKDS', SocketService);
});