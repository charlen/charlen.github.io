function ScreenMessagesService(environment, SoundService, $timeout) {

    var self = this;
    self.messages = [];
    self.waitingMessages = [];
    self.deletedMessages = [];
    self.messageOnScreen = null;
    self.timeoutFunction = null;

    // NOW THE TIMEOUTS WALK TOGETHER
    this.getTimeUntilNextMinute = function (time){
        var timeUntilNextMinute = 0;
        if(time > 0){
            timeUntilNextMinute = moment();
            time = time * 60 * 1000;
            timeUntilNextMinute = (time - ((timeUntilNextMinute.seconds() * 1000) + timeUntilNextMinute.milliseconds()));
        }
        return timeUntilNextMinute;
    };
    this.clearMessages = function(){
        self.waitingMessages.forEach(function(message){
            message.timeoutFunction.cancel();
        });
        self.messages = [];
        self.waitingMessages = [];
    };

    this.onNewMessage = function(messageData) {
        if(messageData){
            messageData.forEach(function(currentMessage){
                $timeout(function(){
                    if(currentMessage.DSMENSAGEM){
                        var messageToUpdate = self.messages.filter(function(filtered){
                            return currentMessage.CDMENSAGEM == filtered.CDMENSAGEM;
                        }).shift();
                        if(messageToUpdate){
                            messageToUpdate = currentMessage;

                            messageToUpdate = self.waitingMessages.filter(function(filtered){
                                return currentMessage.CDMENSAGEM == filtered.CDMENSAGEM;
                            }).shift();
                            if(messageToUpdate){
                                messageToUpdate.timeoutFunction.cancel();
                                self.waitingMessages.splice(self.waitingMessages.indexOf(messageToUpdate), 1);
                                self.doomOrSaveMessage(currentMessage, currentMessage.DSMENSAGEM.length/3 > 30 ? currentMessage.DSMENSAGEM.length/3 : 30);
                            }
                        }else{
                            self.doomOrSaveMessage(currentMessage, currentMessage.DSMENSAGEM.length/3 > 30 ? currentMessage.DSMENSAGEM.length/3 : 30);
                            self.messages.push(currentMessage);
                        }
                        if(!self.messagePlayed){
                            self.playNextMessage();
                        }
                    }
                }, self.getTimeUntilNextMinute(currentMessage.timeout), true);
            });
        }
    };

    this.onDeleteMessage = function(messageData) {
        self.deletedMessages = messageData;
        if(messageData){
            messageData.forEach(function(currentMessage){
                var messageToDelete = self.messages.filter(function(filtered){
                        return currentMessage == filtered.CDMENSAGEM;
                    }).shift();
                if(messageToDelete){
                    this._eraseMessage(messageToDelete);
                }
                messageToDelete = self.waitingMessages.filter(function(filtered){
                        return currentMessage == filtered.CDMENSAGEM;
                    }).shift();
                if(messageToDelete){
                    self.waitingMessages.splice(self.waitingMessages.indexOf(messageToDelete), 1);
                }
                deletedMessages.splice(self.deletedMessages.indexOf(messageToDelete.CDMENSAGEM), 1);
            });
        }
    };
    this.getMessage = function(){
        return self.messageOnScreen != null ? [self.messageOnScreen] : [];
    };

    this.playNextMessage = function(){
        self.messageOnScreen = null;
        var kdsWidget = environment.getKDSWidget();
        if(!kdsWidget.frozen){
            self.messagePlayed = true;
            if(self.messages.length > 0){
                var temp = null;
                if(self.messages[0].timeoutFunction){
                    temp = self.messages[0].timeoutFunction;
                    delete self.messages[0].timeoutFunction;
                }
                var beforeClone = self.messages.shift();
                self.messageOnScreen = Util.clone(beforeClone);
                beforeClone.timeoutFunction = temp;
                var now = moment();
                self.messageOnScreen.DSMENSAGEM = self.messageOnScreen.DSMENSAGEM + ' ' + String('00'+now.hours()).slice(-2) +":"+ String('00'+now.minutes()).slice(-2);
                //timeout que roda a fila
                var time = self.messageOnScreen.DSMENSAGEM.length/3 > 30 ? self.messageOnScreen.DSMENSAGEM.length/3 : 30;
                if(self.messageOnScreen.sound){
                    SoundService.playSound(self.messageOnScreen.sound);
                }
                self.timeoutFunction = $timeout(function(){
                    self.playNextMessage();
                }, time*1000, true);
            }else{
                self.messagePlayed = false;
            }
        }
    };

    this._eraseMessage = function(message){
        if(self.messages.indexOf(message) > -1){
            self.messages.splice(self.messages.indexOf(message), 1);
        }
    };


    this.doomOrSaveMessage = function(message, animationTime){
        if(message.NRREPTINTERV && (message.NRQTDREPTINTERV > 0)){
            //uma delicia campo varchar pra int
            if(typeof message.NRQTDREPTINTERV == "number" || (typeof message.NRQTDREPTINTERV == "string" && parseInt(message.NRQTDREPTINTERV)!= "NaN")){
                message.NRQTDREPTINTERV = parseInt(message.NRQTDREPTINTERV);
            }else{
                message.NRQTDREPTINTERV = 1;
            }
            if(typeof message.NRREPTINTERV == "number" || (typeof message.NRREPTINTERV == "string" && parseInt(message.NRREPTINTERV)!= "NaN")){
                message.NRREPTINTERV = parseInt(message.NRREPTINTERV);
            }else{
                message.NRREPTINTERV = animationTime/60;
            }
            message.NRQTDREPTINTERV--;
            //timeout de repetição
            message.timeoutFunction = $timeout(function() {
                self.messages.push(message);
                self.doomOrSaveMessage(message, message.DSMENSAGEM.length/3 > 30 ? message.DSMENSAGEM.length/3 : 30);

                if(!self.messagePlayed){
                    self.playNextMessage();
                }
            }.bind(message), (message.NRREPTINTERV*60) * 1000, true);

            var messageToUpdate = self.waitingMessages.filter(function(filtered){
                return message.CDMENSAGEM == filtered.CDMENSAGEM;
            }).shift();
            if(!messageToUpdate){
                self.waitingMessages.push(message);
            }
        }else{
            if(~self.waitingMessages.indexOf(message)){
                self.waitingMessages.splice(self.waitingMessages.indexOf(message), 1);
            }
        }
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register('ScreenMessagesService', ScreenMessagesService);
});