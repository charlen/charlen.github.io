function ShortcutKeyService(environment, KeyboardEventsHandler, Utilities) {

	var self = this;
	var keysMap = {};

	var defaultKeysMap = {
		'down'      : ['2'        ],
		'left'      : ['4'        ],
		'zoom'      : ['YmFuYW5pbmhh','space'],
		'right'     : ['6'        ],
		'up'        : ['8'        ],
		'del'       : [','        ],
		'dot'       : ['-'        ],
		'reload'    : ['**'       ],
		'backspace' : ['backspace'],
		'enter'     : ['enter'    ]
	};

	this.bindShortcutsOrderPanel = function() {
		var localEnvironment = environment.getLocalEnvironment();
		var localKeyMap = localEnvironment.keyMapping;
		var mappedKeys = {};
		bindNumlockTurnedOffConvertion();

		// merge the backend keys whit the defalt keys and save in the front for future uses
		keysMap = Util.clone(defaultKeysMap);
		localKeyMap.forEach(function(shortcutKey) {
			if(keysMap[shortcutKey.name]){
				if(keysMap[shortcutKey.name].indexOf(shortcutKey.keyCode) == -1){
					keysMap[shortcutKey.name].push(shortcutKey.keyCode);
				}
			}else{
				keysMap[shortcutKey.name] = [shortcutKey.keyCode];
			}
		});

		bindMappedKeys(keysMap);
	};

	function bindMappedKeys() {
		unbindMappedKeys();
		Object.keys(keysMap).forEach(function(eventName) {
			var callbackName = 'execute' + Utilities.capitalizeFirstLetter(eventName) + 'Event';
			if(KeyboardEventsHandler[callbackName]) {
				Mousetrap.bind(keysMap[eventName], Util.buildDebounceMethod(KeyboardEventsHandler[callbackName]), 'keyup');
			}
		});
	}

	this.bindZoomMappedKeys = function() {
		unbindMappedKeys();
		Object.keys(keysMap).forEach(function(eventName) {
			var callbackName = 'executeZoom' + Utilities.capitalizeFirstLetter(eventName) + 'Event';
			if(KeyboardEventsHandler[callbackName]) {
				Mousetrap.bind(keysMap[eventName], Util.buildDebounceMethod(KeyboardEventsHandler[callbackName]), 'keyup');
			}
		});
	};

	function unbindMappedKeys() {
		Object.keys(keysMap).forEach(function(shortcutKey) {
			Mousetrap.unbind(keysMap[shortcutKey], 'keyup');
		});
	}

	function bindNumlockTurnedOffConvertion() {
		Mousetrap.addKeycodes({
			'111' : '/'	   ,
			'109' : '-'    ,
			'36'  : '7'    ,
			'38'  : '8'    ,
			'33'  : '9'    ,
			'37'  : '4'    ,
			'12'  : '5'    ,
			'39'  : '6'    ,
			'194' : '.'    ,
			'35'  : '1'    ,
			'40'  : '2'    ,
			'34'  : '3'    ,
			'13'  : 'enter',
			'45'  : '0'    ,
			'46'  : ','    ,
			'110' : ',',
			//o + e o * não binda no keyup sabe se lá o porque, mas com apelido funciona
			'107' : 'YmFuYW5pbmhh',
			'106' : '**'
		});
	}

}

Configuration(function(ContextRegister) {
	ContextRegister.register('ShortcutKeyService', ShortcutKeyService);
});