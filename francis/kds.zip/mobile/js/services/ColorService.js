function ColorService(RestEngine, localStorageEngine) {

	var self = this;
	var colors = null;

	this.setControlColors = function(controlColors) {
		colors = controlColors;
    };
    
	this.getControlColors = function() {
		return colors;
	};

    this.unsetControlColors = function() {
    	colors = null;
    };

    this.getColors = function(){
        var params = {
            requestType: "Empty"
        };
        var getColorsRoute = '/colors/get';
        return RestEngine.post(getColorsRoute, params).then(function(response) {
            return response.dataset.getColorsReponse;
        });
    };

    self.getColors().then(fillColorsOnBegin);

    function fillColorsOnBegin(response) {
    	if(response.success) {
    		self.setControlColors(response.colors);
    	}
    }
}

Configuration(function(ContextRegister) {
	ContextRegister.register('ColorService', ColorService);
});