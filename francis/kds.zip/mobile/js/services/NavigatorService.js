function NavigatorService(environment) {

	var self = this;

	this.setOrderAsSelected = function(orderIndex, keepOrMove, upDownFlag) {
        var widget = environment.getKDSWidget();
        self.unSelectAllOrders();
        if(~orderIndex) {
        	var isOrderTheLastOfDataSource = orderIndex == widget.dataSource.data.length - 1;
        	if(upDownFlag){
    			if(upDownFlag == 'down'){
	        		if (isOrderTheLastOfDataSource){
	        			self.setFirstOrderAsSelected();
	        			orderIndex = -1;
	        		}else{
		        		orderIndex++;
	        		}
        		}else{
        			if(orderIndex === 0){
        				self.setLastOrderAsSelected();
	        			orderIndex = -1;
        			}else{
	        			orderIndex--;
        			}
	        	}
        	}else{
        		if (isOrderTheLastOfDataSource){
	        		if(keepOrMove =='move'){
		        		orderIndex--;
		        		upDownFlag = 'up';
	        		}
	        	}else{
	        		orderIndex++;
	        		upDownFlag = 'down';        	
	        	}
        	}
        	
            while(~orderIndex && widget.dataSource.data[orderIndex].isInConclusionQueue) {
            	isOrderTheLastOfDataSource = orderIndex == widget.dataSource.data.length - 1;
            	if(isOrderTheLastOfDataSource) {
        			upDownFlag = 'up';
        			orderIndex--;
            	} else {
					if(upDownFlag == 'up') {
						orderIndex--;
					} else {
						orderIndex++;
					}
            	}
            }
        }
        if(~orderIndex){
        	widget.dataSource.data[orderIndex].isSelected = true;
        }
        widget.updateKDSTemplate();
        self.scrollAfterSelectOtherOrder();
    };

    this.setPreviousOrderAsSelected = function() {
		var currentOrder = self.getSelectedOrder();
		var currentOrderIndex = self.getOrderIndex(currentOrder);
		var widget = environment.getKDSWidget();
		if(~currentOrderIndex) {
			self.setOrderAsSelected(currentOrderIndex, 'keep', 'up');
		} else {
			self.setFirstOrderAsSelected();
		}
	};

	this.setLastOrderAsSelected = function() {
		var widget = environment.getKDSWidget();
		self.setOrderAsSelected(widget.dataSource.data.length - 1, 'keep');
	};

	this.setFirstOrderAsSelected = function() {
		var widget = environment.getKDSWidget();
		if(widget.dataSource.data[0]){
			if(widget.dataSource.data[0].isInConclusionQueue){
				self.setOrderAsSelected(0, 'keep');
			} else {
				widget.dataSource.data[0].isSelected = true;
			}
		}
		
	};

	this.setNextOrderAsSelected = function() {
		var currentOrder = self.getSelectedOrder();
		var currentOrderIndex = self.getOrderIndex(currentOrder);
		var widget = environment.getKDSWidget();
		if(~currentOrderIndex) {
			self.setOrderAsSelected(currentOrderIndex, 'keep', 'down');
		} else {
			self.setFirstOrderAsSelected();
		}
	};

	this.unSelectAllOrders = function() {
		var widget = environment.getKDSWidget();
		widget.dataSource.data.forEach(function(order) {
			self.unSelectOrder(order);
		});
	};

	this.unSelectOrder = function(order) {
		order.isSelected = false;
	};

	this.hasSelectOrder = function() {
		var widget = environment.getKDSWidget();
		return widget.dataSource.data.some(function(order){
			return order.isSelected;
		});
	};

	this.getSelectedOrder = function() {
		var widget = environment.getKDSWidget();
		return widget.dataSource.data.filter(function(order){
			return order.isSelected;
		}).shift();
	};

	this.getOrderIndex = function(order) {
		var widget = environment.getKDSWidget();
		return widget.dataSource.data.indexOf(order);
	};

	this.scrollAfterSelectOtherOrder = function(){
		var kdsContainer = $('#kds-container');
		var selectedOrder = kdsContainer.find('.selected');
		if(selectedOrder.length > 0) {
			var leftOrderOffset = selectedOrder.offset().left;
			var orderWidth = selectedOrder.outerWidth();		
			var rigthOrderOffset = leftOrderOffset + orderWidth;
			var containerWidth = kdsContainer.outerWidth();

			var gapBetweenOrders = 10;
			var containerLeftPadding = 12;
			var toScrollValue;

			// Rules to check when the scroll should move to the right
			if (rigthOrderOffset > containerWidth || selectedOrder.find('.kds-item').last().offset().left + selectedOrder.outerWidth() > containerWidth) {
				toScrollValue = rigthOrderOffset - containerWidth + gapBetweenOrders;
				// If the order haves items on the other side the size of the box is added to the scroll distante
				if (selectedOrder.find('.kds-item-group').last().offset().left + selectedOrder.outerWidth() > containerWidth) {
					toScrollValue = selectedOrder.find('.kds-item').last().offset().left + selectedOrder.outerWidth() - containerWidth + gapBetweenOrders;
				}

			} else if(leftOrderOffset < containerLeftPadding || selectedOrder.offset().top < 0) {
				toScrollValue =  leftOrderOffset - gapBetweenOrders;
				if (selectedOrder.offset().top < 0) {
					toScrollValue -= selectedOrder.width() - gapBetweenOrders;
				}
			}

			if(toScrollValue) {
				kdsContainer.animate({
					scrollLeft: '+=' + toScrollValue
				}, 100);
			}
		}
	};

	//------------------------------------------Zoom navigation

	this.setFirstItemAsSelected = function(order) {
		var widget = environment.getKDSWidget();
		unSelectAllSelectedItems(widget.zoomItem);
		widget.zoomItem[0][0].isZoomSelected = true;
		widget.zoomSelectedOrderKey = widget.zoomItem[0][0].orderKey;
	};

	this.getSelectedOrderItem = function(order) {
		var widget = environment.getKDSWidget();
		var selectedItem;
		if(order && Util.isArray(order)) {
			order.forEach(function(position) {
				position.forEach(function(item) {
					if(item.isZoomSelected) {
						selectedItem = item;
					}else{
						if(item.items) {
							item.items.forEach(function(comboItem) {
								if(comboItem.isZoomSelected) {
									if(item.items.length == 1){
										selectedItem = item;
									}else{
										selectedItem = comboItem;
									}
								}
							});
						}
					}
				});
			});
		}
		return selectedItem;
	};

	this.setInConclusionOnDataSource = function (item){
		var widget = environment.getKDSWidget();
		var currentOrder = self.getSelectedOrder();
		var CDPRODPROMOKDS;
		if(item.items){
			CDPRODPROMOKDS = item.CDPRODPROMOKDS;
		}
		currentOrder.items.forEach(function(dataItem){
			if(item.orderKey == dataItem.orderKey || (CDPRODPROMOKDS && CDPRODPROMOKDS == dataItem.CDPRODPROMOKDS)){
				dataItem.isInConclusionQueue = true;
			}
		});
	};

	function unSelectAllSelectedItems(order) {
		if(order) {
			order.forEach(function(position) {
				position.forEach(function(item) {
					item.isZoomSelected = false;
					if(item.items) {
						item.items.forEach(function(comboItem) {
							comboItem.isZoomSelected = false;
						});
					}
				});
			});
		}
	}

	function setZoomItemAsSelected(subZoomItem, zoomItem, orderKey, next){
		subZoomItem.isZoomSelected = true;
		if(!subZoomItem.isInConclusionQueue){
			var widget = environment.getKDSWidget();
			widget.zoomSelectedOrderKey = subZoomItem.orderKey;
		}else{
			self.setSelectedByOrderKeyZoom(zoomItem, subZoomItem.orderKey, next);
		}
	}

	this.setSelectedByOrderKeyZoom = function(zoomItem, orderKey, next){
		//next is true if is the next, false if is the prev
		zoomItem.forEach(function(position, positionIndex, positions){
			position.forEach(function(item, itemIndex, positionItems){
				//pra baixo
				if(next){
					if(orderKey == item.orderKey && item.isZoomSelected){
						item.isZoomSelected = false;
						if(item.items){
							setZoomItemAsSelected(item.items[0], zoomItem, orderKey, next);
						}else{
							if(positionItems[itemIndex + 1]){
								setZoomItemAsSelected(positionItems[itemIndex + 1], zoomItem, orderKey, next);
							}else if(!positions[positionIndex + 1]){
								setZoomItemAsSelected(positions[0][0], zoomItem, orderKey, next);
							}else{
								setZoomItemAsSelected(positions[positionIndex + 1][0], zoomItem, orderKey, next);
							}
						}
					}else{
						if(item.items) {
							item.items.forEach(function(compItem, compItemIndex, items){
								if(orderKey == compItem.orderKey && compItem.isZoomSelected){
									compItem.isZoomSelected = false;
									if(items[compItemIndex+1]){
										setZoomItemAsSelected(items[compItemIndex+1], zoomItem, orderKey, next);
									}else{
										if(positionItems[itemIndex + 1]){
											setZoomItemAsSelected(positionItems[itemIndex + 1], zoomItem, orderKey, next);
										}else if(!positions[positionIndex + 1]){
											setZoomItemAsSelected(positions[0][0], zoomItem, orderKey, next);
										}else{
											setZoomItemAsSelected(positions[positionIndex + 1][0], zoomItem, orderKey, next);
										}
									}
								}
							});
						}
					}
				}else{
				//pra cima
					if(orderKey == item.orderKey && item.isZoomSelected){
						item.isZoomSelected = false;
						var prevItem = positionItems[itemIndex - 1];
						if(prevItem){
							if(prevItem.items){
								setZoomItemAsSelected(prevItem.items[prevItem.items.length-1], zoomItem, orderKey, next);
							}else{
								setZoomItemAsSelected(prevItem, zoomItem, orderKey, next);
							}
						}else if(!positions[positionIndex - 1]){
							prevItem = positions[positions.length - 1][positions[positions.length - 1].length - 1];
							if(prevItem.items){
								setZoomItemAsSelected(prevItem.items[prevItem.items.length-1], zoomItem, orderKey, next);
							}else{
								setZoomItemAsSelected(prevItem, zoomItem, orderKey, next);
							}
						}else{
							prevItem = positions[positionIndex - 1][positions[positionIndex - 1].length -1];
							if(prevItem.items){
								setZoomItemAsSelected(prevItem.items[prevItem.items.length-1], zoomItem, orderKey, next);
							}else{
								setZoomItemAsSelected(prevItem, zoomItem, orderKey, next);
							}
						}
					}else{
						if(item.items){
							item.items.forEach(function(compItem, compItemIndex, items){
								if(orderKey == compItem.orderKey && compItem.isZoomSelected){
									compItem.isZoomSelected = false;
									if(items[compItemIndex - 1]){
										setZoomItemAsSelected(items[compItemIndex - 1], zoomItem, orderKey, next);
									}else{
										setZoomItemAsSelected(item, zoomItem, orderKey, next);
									}
								}
							});
						}
					}
				}
			});
		});
	
	};


	this.unselectAllOrdersItems = function(order) {
		var widget = environment.getKDSWidget();
		order = widget.zoomItem;
		order.forEach(function(position){
			self.unselectItemOrder(position, false);
		});
	};

	this.unselectItemOrder = function(item, selectNext) {
		if(selectNext) {
			item.isZoomSelected = true;
		} else {
			if(item.isZoomSelected) {
				item.isZoomSelected = false;
				self.this.unselectItemOrder(comboItem, item.isZoomSelected);
			}
			if(item.items) {
				item.items.forEach(function(comboItem) {
					self.this.unselectItemOrder(comboItem, comboItem.isZoomSelected);
				});
			} else {
				item.isZoomSelected = false;
			}
		}
	};

	this.handleScrollbarOnZoomDown = function () {
		var zoomContainer = $('.kds-zoom');
		var zoomContainerBottomOffset = zoomContainer.offset().top + zoomContainer.outerHeight(true);
		var selectedElement = zoomContainer.find('.selected');
		if (selectedElement[0]) {
			var selectedElementBottomOffset = selectedElement.offset().top + selectedElement.outerHeight(true);
			if (selectedElementBottomOffset > zoomContainerBottomOffset) {
				zoomContainer.scrollTop(zoomContainer.scrollTop() + selectedElementBottomOffset - zoomContainerBottomOffset);
			}
			if (selectedElement.offset().top - zoomContainer.offset().top < 0) {
				zoomContainer.scrollTop(0);
			}
		}
	};

	this.handleScrollbarOnZoomUp = function () {
		var zoomContainer = $('.kds-zoom');
		var zoomContainerTopOffset = zoomContainer.offset().top;
		var selectedElement = zoomContainer.find('.selected');
		if (selectedElement[0]) {
			var selectedElementTopOffset = selectedElement.offset().top;
			if (selectedElementTopOffset < zoomContainerTopOffset) {
				zoomContainer.scrollTop(zoomContainer.scrollTop() - (zoomContainerTopOffset - selectedElementTopOffset));
			} 
			if (selectedElementTopOffset + selectedElement.outerHeight(true) >= $('.kds-zoom').outerHeight(true) + zoomContainerTopOffset) {
				zoomContainer.scrollTop(selectedElementTopOffset + selectedElement.outerHeight(true));
			}
		}
	};

}

Configuration(function(ContextRegister) {
	ContextRegister.register('NavigatorService', NavigatorService);
});