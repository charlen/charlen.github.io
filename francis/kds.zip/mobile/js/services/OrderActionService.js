function OrderActionService($interval, $timeout, environment, NavigatorService, SocketServiceKDS, ConcludeQueue, SoundService, ScreenService) {

	this.startOrderProduction = function(order) {
		var widget = environment.getKDSWidget();
		if (SocketServiceKDS.isOpen() && SocketServiceKDS.isConnected()){
			var index = widget.dataSource.data.indexOf(order);
			SocketServiceKDS.playRequest(order.CDFILIAL, order.NRPEDIDOFOS, order.items[0].NRITPEDIDOFOS, order.CDSETOR);
			NavigatorService.setOrderAsSelected(index, 'keep');
		} else {
			ScreenService.notificationMessage("Não foi possível iniciar o item, falha de conexão com o servidor.", 'error', 4000);
		}
	};

	this.concludeOrderProduction = function(order) {
		var widget = environment.getKDSWidget();
		if (SocketServiceKDS.isOpen() && SocketServiceKDS.isConnected()){
				ConcludeQueue.insert(order, false);
				var indexOfSelectedOrder = widget.dataSource.data.indexOf(order);
				widget.dataSource.data[indexOfSelectedOrder].isInConclusionQueue = true;
				//widget.redrawKDSContainer();
				NavigatorService.setOrderAsSelected(indexOfSelectedOrder, 'move');
		} else {
			ScreenService.notificationMessage("Sem conexão no momento, tente novamente mais tarde!", 'error', 3000);
		}
	};

	this.expediteOrder = function(order) {
		var widget = environment.getKDSWidget();
		if (SocketServiceKDS.isOpen() && SocketServiceKDS.isConnected()) {
			ConcludeQueue.insert(order, widget.isZoom);
			var indexOfSelectedOrder = widget.dataSource.data.indexOf(order);
			widget.dataSource.data[indexOfSelectedOrder].isInConclusionQueue = true;
			//widget.redrawKDSContainer();
			NavigatorService.setOrderAsSelected(indexOfSelectedOrder, 'move');

		} else {
			ScreenService.notificationMessage("Sem conexão no momento, tente novamente mais tarde!", 'error', 3000);
		}
	};

	this.continueOrder = function(order) {
		order.isPausedByInterval = false;
		order.updateAvailableAction();
		order.startOrderTimer();
	};

	this.orderOnClick = function(order) {
		var widget = environment.getKDSWidget();
		if(order) {
			order.clearBeeps();
			if(order.availableAction) {
				if(order.IDSITITPEDFOS == 'E'){
					clearOrderTimer(order);
					// if (order.isCallClientAvailable() && order.status == 'expedite') {
					// 	order.dot = false;
					// 	ClientNotificationService.notifyClient(order);
					// }
				}
				order.availableAction.actionCallback(order);
			}
		}
		widget.updateKDSTemplate();
	};

	function clearOrderTimer(order) {
		if(order.timerInterval) {
			$interval.cancel(order.timerInterval);
			delete order.timerInterval;
		}
	}

}

Configuration(function(ContextRegister) {
	ContextRegister.register('OrderActionService', OrderActionService);
});

