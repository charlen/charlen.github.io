function KeyboardEventsHandler($timeout, environment, NavigatorService, OrderActionService, ClientNotificationService,  ConcludeQueue, ScreenService) {

	var self = this;

	this.executeDownEvent = function(event, key) {
		NavigatorService.setNextOrderAsSelected();
	};

	this.tempList = [];

	this.executeUpEvent = function(event, key) {
		NavigatorService.setPreviousOrderAsSelected();
	};

	this.executeLeftEvent = function(event, key) {
		var jumps = 1, NRMULTIPULO = environment.getLocalEnvironment().NRMULTIPULO;
		if(NRMULTIPULO && NRMULTIPULO > 1){
			jumps = NRMULTIPULO;
		}

		for (jumps; jumps > 0; jumps--) {
			self.executeUpEvent();
		}
	};

	this.executeRightEvent = function(event, key) {
		var jumps = 1, NRMULTIPULO = environment.getLocalEnvironment().NRMULTIPULO;
		if(NRMULTIPULO && NRMULTIPULO > 1){
			jumps = NRMULTIPULO;
		}
		
		for (jumps; jumps > 0; jumps--) {
			self.executeDownEvent();
		}
	};

	this.executeZoomEvent = function(event, key) {
		var widget = environment.getKDSWidget();
		var projectConfig = environment.getProjectConfig();
		if(widget.kdsType == "expedition" && projectConfig.partialRelease){
			var currentOrder = NavigatorService.getSelectedOrder();
			var tempOrder = widget.getItemsArray(currentOrder);
			if (currentOrder && hasItemOnOrder(tempOrder, 1)) {
				widget.zoomItem = tempOrder;
				NavigatorService.setFirstItemAsSelected(widget.zoomItem);
			}else{
				ScreenService.notificationMessage('Não há itens para serem expedidos separadamente', 'alert', 5200);
			}
			widget.updateKDSTemplate();
		}
	};

	this.executeBackspaceEvent = function() {
		var widget = environment.getKDSWidget();
		if (environment.getLocalEnvironment().IDHABROLLBKDS == 'S') {
			if (!ConcludeQueue.isQueueEmpty()) {
				var conclusionOrder = ConcludeQueue.pop();
				$timeout.cancel(conclusionOrder.timer);
				conclusionOrder.order.isInConclusionQueue = false;
				conclusionOrder.order.isNewOrder = true;
				if(widget.zoomItem){
					NavigatorService.handleScrollbarOnZoomUp();
				}
				if(!NavigatorService.getSelectedOrder()){
					NavigatorService.setFirstOrderAsSelected();
				}
				widget.updateKDSTemplate();
				conclusionOrder.order.keepOrderColor = false;
			} else {
				ScreenService.alertNotification('Não há pedidos na fila de conclusão!');
			}
		}
	};

	this.executeEnterEvent = function (event, key) {

		var currentOrder = NavigatorService.getSelectedOrder();
		if (currentOrder != undefined) {
			if (currentOrder.isCallClientAvailable() && currentOrder.status == 'expedite') {
				currentOrder.dot = false;
				ClientNotificationService.notifyClient(currentOrder);
			}
		}
		OrderActionService.orderOnClick(currentOrder);
	};

	this.executeDotEvent = function () {
		var currentOrder = NavigatorService.getSelectedOrder();
		if (currentOrder != undefined) {
			if (currentOrder.isCallClientAvailable() && currentOrder.status == 'expedite') {
				currentOrder.dot = true;
				ClientNotificationService.notifyClient(currentOrder);
			}
		}
	};

	this.executeReloadEvent = function() {
		location.reload();
	};

	//--------------------Zoom Events
	this.executeZoomBackspaceEvent = function() {
		self.executeBackspaceEvent();
	};

	//This will call expedite function for choosen items on zoom
	function applyExpeditionToTempList(listToConclude){
		listToConclude.forEach( item => {
			ConcludeQueue.insert(item, true);
		});
	}

	this.executeZoomEnterEvent = function (){
		var widget = environment.getKDSWidget();
		var orderItem = NavigatorService.getSelectedOrderItem(widget.zoomItem);
		//anda com o selected do zoom
		if(orderItem.IDSITITPEDFOS == 'F'){
			//Muda o foco
			NavigatorService.setSelectedByOrderKeyZoom(widget.zoomItem, widget.zoomSelectedOrderKey, true);
			//Se tiver subitens ? subitens  [do contrário] item
			orderItem = orderItem.items ? orderItem.items : [orderItem];
			//Coloca na fila de conclusão
			orderItem.isInConclusionQueue = true;
			//Trata cada item de ordemItem, seja um ou vários
			orderItem.forEach(function(item){
				
				NavigatorService.setInConclusionOnDataSource(item);
				if(item.IDSITITPEDFOS == 'F'){
					if(!hasItemOnOrder(widget.zoomItem, 1)){
						if(!hasItemOnOrder(widget.zoomItem, 0)){
							var toDeleteOrder = NavigatorService.getSelectedOrder();
							var index = widget.dataSource.data.indexOf(toDeleteOrder);
							widget.dataSource.data[index].isInConclusionQueue = true;
							NavigatorService.setOrderAsSelected(index, 'move', 'down');
						}
						widget.zoomItem = null;
						widget.bindPanelShortcutKeys();
						widget.updateKDSTemplate();
						//não sei se pode fazer isso mas ta ai
					}else{
						NavigatorService.handleScrollbarOnZoomDown();
					}
					if(item) {
						if(widget) {
							if(widget.zoomItem){
								if (!widget.zoomItem.listToConclude){
									widget.zoomItem.listToConclude = [];
								}
								widget.zoomItem.listToConclude.push(item);
							}							
						} else {
							ConcludeQueue.insert(item, true);
						}
					}
				}
			});
		}
	};

	function hasItemOnOrder(order, qtty) {
		var itemQtty = 0, compItemQtty = 0, groupQtty = 0;
		return order && order.some(function(position){
			return position && position.some(function(item){
				if (!item.isInConclusionQueue) {
					if(item.items){
						groupQtty++;
					}else{
						itemQtty++;
					}
				}
				return (itemQtty > qtty && !item.items) || (item.items && item.items.some(function(compItem){
					if (!compItem.isInConclusionQueue) {
						compItemQtty++;
					}
					return compItemQtty > qtty || ((groupQtty + itemQtty) > qtty) ;
				}));
			});
		});
	}

	this.executeZoomZoomEvent = function(event, key) {
		var widget = environment.getKDSWidget();
		if(widget.zoomItem) {
			if(widget.zoomItem.listToConclude){
				applyExpeditionToTempList(widget.zoomItem.listToConclude);
			}
			widget.zoomItem = null;
			widget.bindPanelShortcutKeys();			
			widget.updateKDSTemplate();
		}
	};

	this.executeZoomUpEvent =  function(){
		var widget = environment.getKDSWidget();
		NavigatorService.setSelectedByOrderKeyZoom(widget.zoomItem, widget.zoomSelectedOrderKey, false);
		widget.updateKDSTemplate();
		NavigatorService.handleScrollbarOnZoomUp();
	};

	this.executeZoomDownEvent = function() {
		var widget = environment.getKDSWidget();
		NavigatorService.setSelectedByOrderKeyZoom(widget.zoomItem, widget.zoomSelectedOrderKey, true);
		widget.updateKDSTemplate();
		NavigatorService.handleScrollbarOnZoomDown();
	};


}

Configuration(function(ContextRegister) {
	ContextRegister.register('KeyboardEventsHandler', KeyboardEventsHandler);
});