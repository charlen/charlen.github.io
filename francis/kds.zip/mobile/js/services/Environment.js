function Environment(localStorageEngine, RestEngine) {
    
    var self = this;    
    var ENVIRONMENT_KDS_FLAG = 'ENVIRONMENT_KDS';

    self.projectConfig = null;
    self.kdsWidget = null;

    this.setKDSWidgetOnEnvironment = function(widget) {
        self.kdsWidget = widget;
    };

    this.getKDSWidget = function() {
        return self.kdsWidget;
    };
	
    this.setLocalEnvironment = function(localEnvironment) {
    	localEnvironment = JSON.stringify(localEnvironment);
        localStorageEngine.setLocalVar(ENVIRONMENT_KDS_FLAG, localEnvironment);
    };
    
	this.getLocalEnvironment = function() {
		var localEnvironment = localStorageEngine.getLocalVar(ENVIRONMENT_KDS_FLAG);
		if(localEnvironment) {
	    	return JSON.parse(localEnvironment);
		}
	};

    this.setProjectConfig = function() {
        return RestEngine.requestMetaData('config.json').then(function(configJSONData) {
            self.projectConfig = configJSONData.data;
            return configJSONData.data;
        });
    };

    this.getProjectConfig = function() {
        return self.projectConfig;
    };

    this.unsetLocalEnvironment = function() {
        localStorage.removeItem(ENVIRONMENT_KDS_FLAG);
    };

	this.getBranch = function(){
        var params = {
            requestType: "DataSet",
            dataset: {}
        };
        var getBranchRoute = '/branch/get';
        return RestEngine.post(getBranchRoute, params).then(function(response) {
            return response.dataset.branch;
        });
    };

    this.getBranchSectors = function(){
        var params = {
            requestType: "DataSet",
            dataset: {}
        };
        var getBranchSectorsRoute = '/sector/get';
        return RestEngine.post(getBranchSectorsRoute, params).then(function(response) {
            return response.dataset.sectors;
        });
    };

    this.getRegisterControlParams = function(CDSETOR){
        var params = {
            requestType: "Row",
            row: {
                'CDSETOR': CDSETOR
            }
        };
        var getControlParametersRoute = '/register/getControlParameters';
        return RestEngine.post(getControlParametersRoute, params).then(function(response) {
            return response.dataset.productionControlParams;
        });
    };
}

Configuration(function(ContextRegister) {
	ContextRegister.register('environment', Environment);
});