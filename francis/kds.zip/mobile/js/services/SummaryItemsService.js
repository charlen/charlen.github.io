function SummaryItemsService(environment, RestEngine, ZHPromise) {

	var self = this;
	var summaryItems = [];
	var fixedItems = null;

	this.setFixedItems = function(fixedItemsValue) {
		fixedItems = fixedItemsValue;
	};

	this.setSummaryItems = function(summaryItemsValue){
		summaryItems = summaryItemsValue;
	};

	this.getSummaryItems = function(){
		return summaryItems;
	};

	this.sortOrders = function(order){
		if(order && order.IDRESUMOPRODKDS){
			return (order.IDRESUMOPRODKDS == 'FIXED' ? 0 : 1);
		} else {
			return -1;
		}
	};

	this.updateSummaryItems = function() {
		let widget = environment.getKDSWidget();
		getFixedItems().then( fixedItemsTreated =>{
			summaryItems = angular.copy(fixedItemsTreated);
			widget.dataSource.data.forEach(order => {
				if(order[widget.orderTimeField] !== 'wait'){
					if(order[widget.orderStatusField] !== 'C'){
						order[widget.orderItemsField].forEach(function(item) {
							let newSumItem = getSummaryItem(item, widget);
							if (!newSumItem) {
								newSumItem = {};
								newSumItem.DSAPELIDORESUMO = item.DSAPELIDORESUMO;
								newSumItem.CDPRODUTO = item.CDPRODUTO;
								newSumItem.IDRESUMOPRODKDS = item.IDRESUMOPRODKDS;
								newSumItem.QTDESPERA = 0;
								newSumItem.QTDPRODUCAO = 0;
								summaryItems.push(newSumItem);
							}
							if (item[widget.orderItemStatusField] === widget.itemNotStartedStatus) {
								newSumItem.QTDESPERA += parseFloat(item[widget.orderItemQttyField]);
							} else {
								newSumItem.QTDPRODUCAO += parseFloat(item[widget.orderItemQttyField]);
							}
						});
					}
				}
			});
		});
	};

	function getSummaryItem (item, widget) {
		return summaryItems.filter(sumItem => {
			return sumItem.CDPRODUTO == item.CDPRODUTO;
		}).shift();
	}

	function _getFixedItems(CDFILIAL, CDSETOR){
		var params = {
			requestType: "Row",
			row: {
					'CDSETOR': CDSETOR,
					'CDFILIAL': CDFILIAL
			}
		};
		var getSummaryRoute = '/getFixedSummaryItems';
		return RestEngine.post(getSummaryRoute, params).then(function(response) {
			return response.dataset.summary.fixedItems;
		});
	}

	function getFixedItems() {
		var deferred = ZHPromise.defer();
		let localEnvironment = environment.getLocalEnvironment();
		if(fixedItems === null && localEnvironment){
			self.setFixedItems(_getFixedItems(localEnvironment.CDFILIAL, localEnvironment.CDSETOR));
		}
 		deferred.resolve(fixedItems);
 		return deferred.promise;
	}

}

Configuration(function(ContextRegister) {
	ContextRegister.register('SummaryItemsService', SummaryItemsService);
});