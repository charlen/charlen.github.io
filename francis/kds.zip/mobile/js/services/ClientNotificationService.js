function ClientNotificationService(ScreenService, RestEngine) {

    var self = this;

    this.notifyClient = function (currentOrder) {
        if (currentOrder && currentOrder.items.length > 0) {         

            dispatchClientNotification(currentOrder.CDFILIAL, currentOrder.items[0].NRVENDAREST, currentOrder.items[0].NRCOMANDA, currentOrder.CDSENHAPED,
                currentOrder.CDSETOR, currentOrder.NRPEDIDOFOS, currentOrder.items[0].NRSEQVENDA, currentOrder.items[0].CDCAIXA, currentOrder.dot, currentOrder.items[0].NRPRODCOMVEN).then(function (response) {
                    if (!response.error) {
                        if(response.pager != undefined){
                            sweetNotify(response.pager);
                        }
                        if(response.voz != undefined){
                            sweetNotify(response.voz);
                        }
                        if(response.painel != undefined){
                            sweetNotify(response.painel);
                        }
                        if(response.error === false){
                            ScreenService.notificationMessage(response.message, 'error', 5000);
                        }
                        
                    } else {
                        currentOrder.DTHRPRIEXPED = null;
                        ScreenService.notificationMessage('Falha ao notificar consumidor.', 'error', 5000);
                    }
                });
        }
    };

    function sweetNotify(notifyType){
        if(notifyType.error){
            ScreenService.notificationMessage(notifyType.message, 'error', 5000);
        } else {
            ScreenService.notificationMessage(notifyType.message, 'success', 3000);
        }
    }

    function dispatchClientNotification(CDFILIAL, NRVENDAREST, NRCOMANDA, CDSENHAPED, CDSETOR, NRPEDIDOFOS, NRSEQVENDA, CDCAIXA, DOT, NRPRODCOMVEN) {
        var params = {
            requestType: "Row",
            row: {
                'CDFILIAL': CDFILIAL || null,
                'NRVENDAREST': NRVENDAREST || null,
                'NRCOMANDA': NRCOMANDA || null,
                'CDSENHAPED': CDSENHAPED || null,
                'CDSETOR': CDSETOR || null,
                'NRPEDIDOFOS': NRPEDIDOFOS || null,
                'NRSEQVENDA': NRSEQVENDA || null,
                'CDCAIXA': CDCAIXA || null,
                'DOT': DOT || null,
                'NRPRODCOMVEN': NRPRODCOMVEN || null
            }
        };
        var notifyClientRoute = '/notification/client';
        return RestEngine.post(notifyClientRoute, params).then(function (response) {
            return response.dataset.notifyClient;
        });
    }

}

Configuration(function (ContextRegister) {
    ContextRegister.register('ClientNotificationService', ClientNotificationService);
});