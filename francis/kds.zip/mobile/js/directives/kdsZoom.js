var app = angular.module("ZeedhiDirectives");

app.directive('kdsZoom', function (ApplicationContext){
	return {
		restrict: 'E',
		templateUrl: 'templates/widget/kds_zoom.html',
		link: function($scope, element, attrs){
			ApplicationContext.ShortcutKeyService.bindZoomMappedKeys();
		}
	};
});