var KDSModule = angular.module("ZeedhiDirectives");

KDSModule.directive('kdsSummary', function() {
	return {
		restrict: 'E',
		templateUrl: 'templates/widget/kds-summary.html',
		link: function($scope, element, attrs) {

        }
	};
});