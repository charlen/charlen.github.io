var KDSModule = angular.module("ZeedhiDirectives");

KDSModule.directive('kdsMessagePanel', function(ApplicationContext) {
	return {
		restrict: 'E',
		templateUrl: 'templates/widget/kds_message_panel.html',
		link: function($scope, element, attrs) {
            $scope.getMessages = function() {
                return ApplicationContext.ScreenMessagesService.getMessage();
            };
        }
	};
});