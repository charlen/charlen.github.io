var KDSModule = angular.module("ZeedhiDirectives");

KDSModule.directive('kdsResumePanel', function() {
	return {
		restrict: 'E',
		templateUrl: 'templates/widget/kds_resume_panel.html',
		link: function($scope, element, attrs) {

        }
	};
});