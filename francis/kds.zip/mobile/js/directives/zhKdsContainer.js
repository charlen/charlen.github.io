var KDSModule = angular.module("ZeedhiDirectives");

KDSModule.directive('zhKdsContainer', function($interval, ApplicationContext) {
	return {
		restrict: 'A',
		link: function($scope, element, attrs) {
			"use strict";

			var widget = $scope.widget;

			$interval(updateOrdersTimers, 1000, 0, false);

			function updateOrdersTimers () {
				widget.dataSource.data.forEach(function(order) {
					if(order.updateOrderTimer) {
						order.updateOrderTimer();
					}
				});
			}

			widget.bindPanelShortcutKeys = function() {
				ApplicationContext.ShortcutKeyService.bindShortcutsOrderPanel();
			};

			widget.orderDataSouce = function() {
				widget.dataSource.data.sort(sortDataSource);
			};


			function sortDataSource(a, b) {
				var orderDateA,orderDateB;
				orderDateA = chooseOrdenationTime(a, orderDateA);
				orderDateB = chooseOrdenationTime(b, orderDateB);

				if(orderDateA.isSame(orderDateB, 'second')){
					if(a.NRPEDIDOFOS == b.NRPEDIDOFOS){
						if(moment(a.DTHREXIBICAOPROD).isSame(moment(b.DTHREXIBICAOPROD), 'second')) {
							return a.orderKey > b.orderKey? 1:-1;
						} else {
							if(moment(a.DTHREXIBICAOPROD).isBefore(moment(b.DTHREXIBICAOPROD))) {
								return -1;
							} else {
								return 1;
							}
						}
					} else {
						return a.NRPEDIDOFOS > b.NRPEDIDOFOS? 1:-1;
					}
				} else {
					return orderDateA.isBefore(orderDateB, 'second') ? -1 : 1;
				}

			}

			function chooseOrdenationTime(order, orderDate) {
				if (order.NRSEQLIBERADO || order.items[0] && (order.items[0].NRATRAPRODITPE && order.items[0].NRATRAPRODITPE !== 0)) {
					var NRMAIORTEMPO = order.NRMAIORTEMPO && widget.IDTIPOSETOR == 'P' ? order.NRMAIORTEMPO: 0;
					return moment(order.DTHREXIBICAOPROD).subtract(NRMAIORTEMPO, 'seconds');
				} else {
					return moment(order.DTPEDIDOFOS);
				}
			}

			widget.updateKDSTemplate = function() {
				if(!$scope.$$phase) {
					$scope.$digest();
				}
			};

			widget.getItemsArray = function(order){
				//TA VENDO ISSO AQUI? É UM CACHE NA MÃO
				if (order.LASTUPDATE != order.cacheLastUpdate) {
					order.cacheLastUpdate = order.LASTUPDATE;
					var processedItens = buildOrderItemsArray(order);
					order.processedItens = processedItens;
				}
				order.processedItens.forEach(function(items){
					items.sort(function (a, b) {
						var comparadorA = a[widget.orderItemGroupDescField] || a[widget.orderItemDescField];
						var comparadorB = b[widget.orderItemGroupDescField] || b[widget.orderItemDescField];
						if (comparadorA > comparadorB) {
							return 1;
						}
						if (comparadorA < comparadorB) {
							return -1;
						}
						if(a.NRITPEDIDOFOS > b.NRITPEDIDOFOS){
							return 1;
						}else{
							return -1;
						}
						// a must be equal to b
						return 0;
					});
				});
				return order.processedItens;
			};

			function buildOrderItemsArray(order) {
				var orderGroupedByTablePosition = groupOrderByTablePosition(order);
				return Object.keys(orderGroupedByTablePosition).map(function(tablePosition) {
					var groups = buildItemsGroups(orderGroupedByTablePosition[tablePosition]);
					var items = buildLonelyItems(orderGroupedByTablePosition[tablePosition]);
					return items.concat(groups);
				});
			}

			function groupOrderByTablePosition(order) {
				var orderItems = order[widget.orderItemsField];
				return ApplicationContext.Utilities.groupArrayByProperty(orderItems, widget.orderItemPositionField);
			}

			function buildLonelyItems(orders) {
				var items = [];
				if(orders) {
					items = orders.filter(function(item) {
						return !item[widget.orderItemGroupField];
					});
				}
				return items;
			}

			function buildItemsGroups(orders) {
				var groups = [], IDSITITPEDFOS = 'E', qtty= 0;
				if(orders) {
					var groupFathers = ApplicationContext.Utilities.groupArrayByProperty(orders, 'NRSEQPRODCOMKDS');
					if(groupFathers){
						Object.keys(groupFathers).forEach(function(father) {
							var fatherObj = null;
							if(father !== 'null'){
								fatherObj = {};
								var groupItems = groupFathers[father];
								groupItems.forEach(function(groupItem) {
									groupItem.items = null;
									if(IDSITITPEDFOS == 'E' && groupItem.IDSITITPEDFOS == 'P'){
										IDSITITPEDFOS = 'P';
									}else if(IDSITITPEDFOS == 'E' && groupItem.IDSITITPEDFOS == 'F'){
										qtty++;
									}
									if(qtty == groupItems.length){
										IDSITITPEDFOS = 'F';
									}
								});
								fatherObj = Util.extend(fatherObj, groupItems[0], true);
								fatherObj.items = groupItems;
								fatherObj.isGroup = true;
								fatherObj.IDSITITPEDFOS = IDSITITPEDFOS;
								groups.push(fatherObj);
							}
						});
					}
				}
				return groups;
			}

			widget.bindPanelShortcutKeys();

		}
	};
});