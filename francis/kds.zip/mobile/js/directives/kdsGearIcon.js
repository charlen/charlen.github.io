var KDSModule = angular.module("ZeedhiDirectives");

KDSModule.directive('kdsGearIcon', function() {

	return {
		restrict: 'E',
		templateUrl: 'templates/widget/kds_gear_icon.html', 
		link: function($scope, element, attrs) {}
	};
});