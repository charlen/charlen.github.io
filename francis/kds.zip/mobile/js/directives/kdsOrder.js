var app = angular.module("ZeedhiDirectives");

app.directive('kdsOrder', function (ApplicationContext){
	return {
		restrict: 'E',
		templateUrl: 'templates/widget/kds_order.html',
		link: function($scope, element, attrs){

			$scope.isNotConcludedItem = function(orderKey) {
				return !ApplicationContext.ConcludeQueue.checkItemExistence(orderKey);
			};

			$scope.putColorOnObservations = function(observation) {
				return {
					'background' : '#'+observation.NRCORSINAL,
					'color' : ApplicationContext.Utilities.idealTextColor(observation.NRCORSINAL)
				};
			};

			$scope.isGroupTotallyProducted = function(items) {
				items.every(function(item) {
					return item[widget.orderItemStatusField] == widget.itemDoneStatus || item[widget.orderItemStatusField] == widget.itemCancelledStatus;
				});
			};

			$scope.checkPositionIsOnHeader = function(positionIndex, position){
				return (positionIndex > 0 || position.length > 1);
			};

			$scope.checkItemsIsOnHeader = function(itemIndex, positionIndex){
				return (itemIndex > 0 && positionIndex === 0)|| (positionIndex > 0);
			};

			$scope.positionHasItemsOutOfConclusionQueue = function(position) {
				return position.some(function(item) {
					if(!item.isInConclusionQueue) {
						return true;
					} else if(item.items){
						item.items.some(function(compItem) {
							return !compItem.isInConclusionQueue;
						});
					} else {
						return false;
					}
				});
			};

			$scope.groupHasItemsOutOfConclusionQueue = function(group) {
				if(group.items){
					return group.items.some(function(item) {
						return !item.isInConclusionQueue;
					});
				} else {
					return !group.isInConclusionQueue;
				}
			};

			$scope.isOrderVisisble = function(order) {
				if(!order.isInConclusionQueue){
					if(order && order.items) {
						return order.items.some(function(item) {
							return !item.isInConclusionQueue;
						});
					}
				} else {
					return false;
				}
			};

			$scope.isOrderItemCancelled = function(order) {
				if(order && order.items && order.items.length > 0) {
					return order.items.every(checkIfItemIsCancelled);
				} else {
					return checkIfItemIsCancelled(order);
				}
			};

			function checkIfItemIsCancelled(item) {
				return item.IDSITITPEDFOS == 'C';
			}
		}
	};
});