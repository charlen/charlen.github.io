var KDSModule = angular.module("ZeedhiDirectives");

KDSModule.directive('kdsMessage', function(ApplicationContext) {
	return {
        restrict: 'E',
		templateUrl: 'templates/widget/kds_message.html',
		compile: function(element, attributes){
         return {
                pre: function($scope, element, attributes, controller, transcludeFn){
                    $scope.configureAndPlayMessage = function(){
                        if($scope.message){
                            var animationTime = ($scope.message.DSMENSAGEM.length/3);
                            animationTime = animationTime > 30 ? animationTime : 30;
                            element.css({"-moz-animation": "scroll-left "+ animationTime +"s linear infinite",
                                         "-webkit-animation": "scroll-left "+ animationTime +"s linear infinite",
                                         "animation": "scroll-left "+ animationTime +"s linear infinite"});
                            $('.kds-message').css({"-moz-animation": "shrink "+ animationTime +"s linear infinite",
                                         "-webkit-animation": "shrink "+ animationTime +"s linear infinite",
                                         "animation": "shrink "+ animationTime +"s linear infinite"});
                        }
                    };

                    $scope.configureAndPlayMessage();
                },
                post: function($scope, element, attributes, controller, transcludeFn){
                }
            };
        }
	};
});