var app = angular.module("ZeedhiDirectives");

app.directive('kdsOrderHeader', function ($interval, $timeout,  ApplicationContext){
	return {
		restrict: 'E',
		templateUrl: 'templates/widget/kds_order_header.html',
		link: function($scope, element, attrs){

			var widget = $scope.widget;
			var order = $scope.order;
			var orderActionService = ApplicationContext.OrderActionService;
			var colorService = ApplicationContext.ColorService;
			var environment = ApplicationContext.environment;
			var SoundService = ApplicationContext.SoundService;
			var Utilities = ApplicationContext.Utilities;
			var SummaryItemsService = ApplicationContext.SummaryItemsService;
			var ClientNotificationService = ApplicationContext.ClientNotificationService;
			var localEnvironment = environment.getLocalEnvironment();
			$scope.localEnvironment = environment.getLocalEnvironment();

			var orderStatus = {
				'start' : {
					'actionLabel': 'INICIAR',
					'actionIconPath': widget.imgSrc + 'start.svg',
					'actionCallback': orderActionService.startOrderProduction,
					'actionCondition': orderCanStart
				},
				'cancel' : {
					'actionLabel': 'CANCELAR',
					'actionIconPath': widget.imgSrc + 'cancel.svg',
					'actionCallback': orderActionService.expediteOrder,
					'actionCondition': orderCanCancel
				},
				'conclude': {
					'actionLabel': 'CONCLUIR',
					'actionIconPath': widget.imgSrc + 'conclude.svg',
					'actionCallback': orderActionService.concludeOrderProduction,
					'actionCondition': orderCanConclude
				},
				'expedite' :  {
					'actionLabel': 'LIBERAR',
					'actionIconPath': widget.imgSrc + 'expedite.svg',
					'actionCallback': orderActionService.expediteOrder,
					'actionCondition': orderCanExpedite
				},
				'continue': {
					'actionLabel': 'CONTINUAR',
					'actionIconPath': widget.imgSrc + 'start.svg',
					'actionCallback': orderActionService.continueOrder,
					'actionCondition': orderCanContinue
				},
				'waiting_payment' : {
					'actionLabel': 'AGUARD. PGTO.',
					'actionCondition': orderWaitingPg,
					'actionCallback': _ => null,
				}
			};

			$scope.onOrderClick = function(order) {

				orderActionService.orderOnClick(order);
				if (order.isCallClientAvailable() && order.status == 'expedite') {
					ClientNotificationService.notifyClient(order);
				}

			};

			order.updateAvailableAction = function() {
				order.availableAction = null;
				Object.keys(orderStatus).forEach(function(action) {
					if(orderStatus[action].actionCondition()) {
						order.availableAction = orderStatus[action];
						order.status = action;
					}
				});
				if(!$scope.$$phase) {
					$scope.$apply();
				}
			};

			function orderCanStart() {
				var orderCurrentTime = moment(order[widget.orderCurrentTime]);
				var orderShowTime = moment(order[widget.orderShowTime]);
				return !localEnvironment.PLAYANDCONCLUDE && order[widget.orderTimeField] !== 'wait' &&
					widget.kdsType === 'production' &&
					order[widget.orderStatusField] !== widget.itemCancelledStatus &&
					orderCurrentTime.isAfter(orderShowTime) &&
					order.items.every(function(item) {
						return item[widget.orderItemStatusField] !== widget.itemProductionStatus;
					});
			}

			function orderCanExpedite() {
				return	widget.kdsType === 'expedition' &&
					!orderCanCancel() &&
					order.items.every(function(item) {
						return item[widget.orderItemSelectField];
					});
			}

			function orderCanContinue() {
				return order.isPausedByInterval;
			}

			function orderCanConclude() {
				var concludeDisabled = localEnvironment.concludeDisabled;
				var canConclude = (localEnvironment.PLAYANDCONCLUDE && localEnvironment.IDTIPOSETOR == 'P') || order.isProducted || (!concludeDisabled && widget.kdsType ===  'production' &&
					!order.isPausedByInterval &&
					order[widget.orderStatusField] !== widget.orderCancelledStatus &&
					order.items.some(function(item) {
						return item[widget.orderItemStatusField] === widget.itemProductionStatus;
					}));

					if(canConclude){
						if(localEnvironment.IDCONCAUT === 'S'){
							orderActionService.concludeOrderProduction(order);
						}
						return true;	
					}
			}

			function orderCanCancel() {
				return order.items.every(function(item) {
					return item[widget.orderItemStatusField] === widget.orderCancelledStatus || (order.items.every(function(item) {
						return item[widget.orderItemStatusField] === widget.orderCancelledStatus;
					}));
				});
			}

			function orderWaitingPg(){
				return ((orderCanExpedite()) && (localEnvironment.IDTIPOSETOR == 'E') && (order.DTVENDA == null && order.NRSEQMOVDLV == null && order.DSTIPOPEDFOS == 'COMANDA') && (localEnvironment.IDLIBCONDPG == 'S'));
			}

			function createDurationString(duration) {
				var durationString = '00:00:00';
				if(duration) {
					durationString = Utilities.zerofillNumberFormat(duration.hours(), 2) + ':' + Utilities.zerofillNumberFormat(duration.minutes(), 2) + ':' + Utilities.zerofillNumberFormat(duration.seconds(), 2);
				}
				return durationString;
			}

			$scope.showOrderOrigin = function () {
				return localEnvironment.IDMOSTRAORIGEM && order[widget.orderOrigin];
			};

			$scope.getOrderTimerString = function() {
				var productionTime;
				if(order && order.timerValue) {
					if(moment.isDuration(order.timerValue)) {
						productionTime = createDurationString(order.timerValue);

						if(productionTime == "00:00:00") {
							//this may fail, if for some reason the front time is walking diferent than the back
							order[widget.orderTimeField] = "0001/01/01 00:00:00";
							order.timerValue = null;
							order[widget.orderCurrentTime] = order.DTHREXIBICAOPRODISO;
							order[widget.orderShowTime] = order[widget.orderCurrentTime];
							order.prepareOrder();
							order.updateAvailableAction();
							order.startOrderTimer();
							order.getOrderColor();
						}
					} else {
						productionTime = order.timerValue.format('HH:mm:ss');
					}
				} else {
					productionTime = "00:00:00";
				}
				return productionTime;
			};

			$scope.getFreezedTime = function() {
				var currentDTHPRIEXPED;
				if(order.DTHRPRIEXPED){
					currentDTHPRIEXPED = moment(order.DTHRPRIEXPED).diff(moment(order.DTHREXIBICAOPROD));
					return moment.utc(currentDTHPRIEXPED).format('HH:mm:ss');
				} else {
					return null;
				}
			};

			order.updateOrderTimer = function() {
				if(moment.isDuration(order.timerValue)) {
					if(order.timerValue.asMilliseconds() !== 0) {
						order.timerValue.subtract(1, 'seconds');
					}
				} else {
					order.timerValue.add(1, 'seconds');
				}
				updateProductionTimer();
			};

			function updateProductionTimer() {
				if(!order.isInConclusionQueue){
					if(order.IDSITITPEDFOS == 'P' && widget.productionProgressBar){
						if(order.productionTimer.format('HH:mm:ss')!=='00:00:00' && !order.isPausedByInterval){
							order.productionTimer.subtract(1, 'seconds');
						} else {
							if(localEnvironment.IDHABSOMPROD!='N'){
								$timeout(function(){
									if(localEnvironment.IDHABCONTSOMPROD!='N'){
										SoundService.beep(true);
										order.isOrderBeeping = true;
									} else {
										SoundService.beep(false);
									}
								}, localEnvironment.NRATRASOSOMPROD*1000 || 0, false);
							}
						}
					}
				}
			}

			function startUpdateOrderInterval() {
				//order.timerInterval = $interval(updateOrderTimer, 1000, 0, false);
			}


			function calcuteWaitingTimeToStartProduction(order) {
				var exibitionTime = moment(order.DTHREXIBICAOPRODISO, 'YYYY/MM/DD HH:mm:ss');
				var now = moment(order.NOW, 'YYYY/MM/DD HH:mm:ss');
				var diffTime = exibitionTime.diff(now);
				return moment.duration(diffTime, 'milliseconds');
			}

			order.startOrderTimer = function() {
				//calcula o tempo do cabeçalho
				if(!order.timerValue) {
					var elapsedTime = order[widget.orderTimeField];//timer
					if (elapsedTime == 'wait') {
						order.timerValue = calcuteWaitingTimeToStartProduction(order);
						order.productionTimer = moment((Math.floor(order.NRTEMPOEXIB/60)).toString()+':'+(order.NRTEMPOEXIB%60).toString(), 'mm:ss');
					} else {
						elapsedTime = moment(elapsedTime, 'YYYY/MM/DD HH:mm:ss');
						elapsedTimeText = moment(elapsedTime);
						order[widget.orderTimeField] = elapsedTime.format('YYYY/MM/DD HH:mm:ss');
						order.timerValue = elapsedTime;
						//calcula o tempo de produção
						if(widget.productionProgressBar){
							var elapsedProductionTime = {};
							if(order.IDSITITPEDFOS == 'P'){
								elapsedProductionTime = moment(order.NOW).diff(order.DTHRINIPRODUCAO, 's');
								setOrderProductionItervals(order, elapsedProductionTime);
								elapsedProductionTime = order.NRTEMPOEXIB - elapsedProductionTime;
								elapsedProductionTime = elapsedProductionTime < 0 ? 0 : elapsedProductionTime;
							} else {
								elapsedProductionTime = order.NRTEMPOEXIB;
							}
							order.productionTimer = moment((Math.floor(elapsedProductionTime/60)).toString()+':'+(elapsedProductionTime%60).toString(), 'mm:ss');
						}
					}
					startUpdateOrderInterval();
				}
			};

			function setOrderProductionItervals(order, elapsedProductionTime) {
				if(Util.isArray(order.INTERVALS) && !Util.isEmptyOrBlank(order.INTERVALS)) {
					var productionInterval = parseInt(order.INTERVALS.shift().NRTEMPOINTER.toString());
					if(productionInterval < elapsedProductionTime) {
						setOrderProductionItervals(order, elapsedProductionTime);
					} else {
						var milisecondsToPause = (productionInterval - elapsedProductionTime) * 1000;
						order.productionIntervalTimeout = $timeout(function(){
							order.isPausedByInterval = true;
							order.updateAvailableAction();
						}, milisecondsToPause, false);
					}
				}
			}

			order.getProductionTimer = function(){
				if(!moment.isMoment(order.productionTimer)){
					order.productionTimer = moment(order.productionTimer);
				}
				return order.productionTimer.format('HH:mm:ss');
			};

			order.setOrderColor = function setOrderColor(orderColor, isOrderBlinking){
				order.colorParams = {
					color :  orderColor,
					blink : isOrderBlinking
				};
			};

			order.updateOrderColor = function(color) {
				order.setOrderColor(color.NRCORPEDIDO, color.IDPISCAPED === 'S');
				order.setNextChangeColorTimer();
			};
			//getorder color AND set delayed beep on expedition
			order.getOrderColor = function getOrderColor() {
				if(orderCanCancel()){
					order.setOrderColor('CCCCCC', false);
				}else{
					if(!order.keepOrderColor){
						order.setOrderColor('000000', false);
						if(order.colorTimeout && !order.keepOrderColor){
							$timeout.cancel(order.colorTimeout);
						}
						var elapsedTime = order[widget.orderTimeField];//timer
						var orderColor, isBlinking, delay = 0;
						if (elapsedTime == 'wait'){
							order.setOrderColor('ADADAD', false);
						} else {
							//se tiver cancelado não precisa preocupar com delaytime
							var exibitionTime = moment(order.DTHREXIBICAOPRODISO, 'YYYY/MM/DD HH:mm:ss');
							var now = moment(order.NOW, 'YYYY/MM/DD HH:mm:ss');
							var diffTime = now.diff(exibitionTime, 'seconds');
							delay = diffTime - order.NRTEMPOPROD;
							order.setDelayedBeepTimeout(delay);
							var colors = colorService.getControlColors();
							if (!Util.isEmptyOrBlank(colors)){
								order.setChangeColorTimers(delay, colors);
								order.setNextChangeColorTimer();
								if(delay < 0 && order.IDSITITPEDFOS === 'E' && !localEnvironment.PLAYANDCONCLUDE && localEnvironment.IDTIPOSETOR == 'P') {
									order.setOrderColor('0066ff', false);// azul baldi
								}
							} else { //caso não tenha cor parametrizada para este intervalo
								order.setOrderColor('000000', false);
							}
						}
					}
				}
			};

			order.setChangeColorTimers = function setChangeColorTimers (delay, colors){
				order.orderColorQueue = [];
				var lastDelay = 0;
				for(index = 0; index < colors.length; index++){
					color = colors[index];
					if(delay <= color.NRINICIOCOR){
						color.delayTime = color.NRINICIOCOR - delay - lastDelay;
						if(delay < 0 && color.NRINICIOCOR === 0){
							order.setOrderColor(color.NRCORPEDIDO, color.IDPISCAPED === 'S');
						}else{
							lastDelay = color.delayTime + lastDelay;
							order.orderColorQueue.push(color);
						}
					}else if(delay >= color.NRINICIOCOR && delay <= color.NRFINALCOR){
						order.setOrderColor(color.NRCORPEDIDO, color.IDPISCAPED === 'S');
					}
				}
			};

			order.setNextChangeColorTimer = function setNextChangeColorTimer() {
				if(order){
					var nextColor = order.orderColorQueue.shift();
					if(nextColor){
						order.colorTimeout = $timeout(function(){order.updateOrderColor(nextColor);}, nextColor.delayTime * 1000, 0, true);
					}
				}
			};

			order.setDelayedBeepTimeout = function setDelayedBeepTimeout(delay) {
				if(localEnvironment.IDTIPOSETOR == 'E' && localEnvironment.NRTEMPOATRASOEXP != null){
					order.expBeepTimeout = $timeout(function(){
						order.expeditionDelayBeep = true;
						SoundService.playSound(localEnvironment.SOMBEEPEXP, 'expeditionDelayBeep');
					}, (localEnvironment.NRTEMPOATRASOEXP - delay) * 1000, 0, true);
				}
			};

			$scope.getKDSTitleStyle = function() {
				if(order && order.colorParams) {
					var bgColor = order.colorParams.color;
					var toApplyClass = {
						'color' : order.colorParams.blink ? '#FFF': ApplicationContext.Utilities.idealTextColor(bgColor),
						'background-color' : '#' + bgColor,
						'background-size' : order.IDSITITPEDFOS === 'E' ? '10px 10px' : 'initial'
					};
					return toApplyClass;
				}
			};

			$scope.isCommandNumberVisible = function() {
				return order[widget.orderCommandNumberField] && order[widget.orderCommandNumberField].length && parseInt(order[widget.orderCommandNumberField]).toString() !== 'NaN';
			};

			$scope.getCommandNumber = function() {
				return parseInt(order[widget.orderCommandNumberField]).toString();
			};

			$scope.getKDSItemQtdStyle = function() {
				if(order && order.colorParams) {
					var toApplyClass = {
						'color' : '#' + order.colorParams.color
					};
					return toApplyClass;
				}
			};

			$scope.getKDSItemIconStyle = function() {
				if(order && order.colorParams) {
					var toApplyClass = {
						'stroke' : '#' + order.colorParams.color
					};
					return toApplyClass;
				}
			};

			$scope.getBorderStyle = function() {
				var toApplyClass = {
					'border-color':  order && order.colorParams && order.isSelected ? '#' + order.colorParams.color : '#dddddd',
					'-webkit-animation': order && order.colorParams && order.isSelected ? 'order-border-blink 0.5s linear infinite alternate' : 'initial'
				};
				return toApplyClass;
			};

			$scope.isOrderBlinking = function(){
				return order && order.colorParams && order.colorParams.blink;
			};

			$scope.getCallClientStyle = function() {
				var bgColor = order.colorParams.color;
				return {
					'fill':  ApplicationContext.Utilities.idealTextColor(bgColor)
				};
			};

			$scope.getProgressBarPercentage = function() {
				// porcentagem do tempo de produção (fiz regra de 3 mesmo)
				var productionTotalTime = order.NRTEMPOEXIB;
				var elapsedProductionTime = order.productionTimer;

				var productionPorc = ((((elapsedProductionTime.minutes() * 60) + elapsedProductionTime.seconds()) * 100) / (productionTotalTime));
				var width = 100 - productionPorc;
				if ((width < 0) || (width > 100)) {
					width = 100;
				}
				if(width > 80 && order.IDSITITPEDFOS == 'P' && !order.isProducted){
					order.isProducted = true;
					order.updateAvailableAction();
				}
				return {
					'width' : width + '%',
					'background-color' : tinycolor(order.colorParams.color).setAlpha(0.5).toRgbString()
				};
			};

			order.isCallClientAvailable = function () {
				var canExpedite = orderCanExpedite();
				var isExpeditionSector = localEnvironment.IDTIPOSETOR == 'E';
				var projectConfig = environment.getProjectConfig();
				return canExpedite && projectConfig.callClientIntegration && isExpeditionSector;
			};

			order.isCallPanelAvailable = function () {
				var canExpedite = orderCanExpedite();
				var isExpeditionSector = localEnvironment.IDTIPOSETOR == 'E';
				var projectConfig = environment.getProjectConfig();
				return canExpedite && projectConfig.callPanelIntegration && isExpeditionSector;
			};

			order.beepOnNewOrder = function() {
				var isTimeToBeep = localEnvironment.IDHABSOMKDS == 'S' && order.timer !== 'wait' && ((order.IDSITITPEDFOS == 'E' && widget.IDTIPOSETOR == 'P') || (order.isNewOrder && widget.IDTIPOSETOR != 'P') );
				if (isTimeToBeep) {
					if(localEnvironment.NRPRODATRAINISOM) {
						$timeout(function() {
							if(localEnvironment.IDCONTSOMKDS!='N'){
								SoundService.beep(true);
								order.isOrderBeeping = true;
								// order.beepUntilStart = $interval(SoundService.beep, 1000, 0, false);
							}
						}, localEnvironment.NRPRODATRAINISOM * 1000, true);
					}
					SoundService.beep(false);
				}
			};

			order.prepareOrder = function() {
				if(!order.isNewOrder) {
					order.timerValue = null;
				}
				order.items.forEach(function(item) {
					if (item.QTPRODPEFOS && (item.QTPRODPEFOS instanceof Number || item.QTPRODPEFOS.toString().indexOf('.') != -1)) {
						item.QTPRODPEFOS = item.QTPRODPEFOS.toFixed(3);
					}
					if (item[widget.orderItemObsField]) {
						try {
							if (typeof item[widget.orderItemObsField] === 'string') {
								item[widget.orderItemObsField] = JSON.parse(item[widget.orderItemObsField]);
							}
						} catch (e) {
							var obsArray = item[widget.orderItemObsField].split(';'),
								retArray = [];
							obsArray.forEach(function(observation, idx, obsArray) {
								if (observation) {
									var returnObs = {};
									returnObs.OBSERVACAO = observation;
									returnObs.NRCORSINAL = 'FFFFFF';
									retArray.push(returnObs);
								} else if (obsArray.length-1 == idx){
									item[widget.orderItemObsField] = retArray;
								}
							});
						}
					}
					if (item[widget.itemCanceledArray]) {
						if (typeof item[widget.itemCanceledArray] === 'string') {
							item[widget.itemCanceledArray] = JSON.parse(item[widget.itemCanceledArray]);
						}
					}
				});
			};

			order.clearBeeps = function() {
				order.isOrderBeeping = false;
			};

			$scope.$on('$destroy', function() {
				order.clearBeeps();
			});

			order.clearBeeps();
			order.prepareOrder();
			order.updateAvailableAction();
			order.startOrderTimer();
			order.getOrderColor();
			order.beepOnNewOrder();

		}
	};
});