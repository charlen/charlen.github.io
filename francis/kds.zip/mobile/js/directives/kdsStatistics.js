var app = angular.module("ZeedhiDirectives");

app.directive('kdsStatistics', function (){
	return {
		restrict: 'E',
		templateUrl: 'templates/widget/kds_statistics.html'
	};
});