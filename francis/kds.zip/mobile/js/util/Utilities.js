function Utilities() {

	var self = this;

	this.frontVersion = "1.0.0";

	this.zerofillNumberFormat = function(number, length) {
		if(typeof number == 'number') {
			number = number.toString(); 
		}
		var baseZeroFill = "0";
		var zeroFilledStringLength = self.stringRepeat(baseZeroFill, length);
		var concatenadBasePlusNumber =  zeroFilledStringLength + number;
		return concatenadBasePlusNumber.slice(-length);
	};

	this.stringRepeat = function(string, qtd) { //the same as str.repeat() ES6
		var finalString = [];
		while(finalString.length < qtd){
			finalString.push(string);
		}
		return finalString.join('');
	};

	this.clearAllTimeOutsAndIntervals = function() {
        var lastTimeOutId = window.setTimeout(function(){}, 0);
        while (lastTimeOutId > 0) {
            clearTimeout(lastTimeOutId);
            clearInterval(lastTimeOutId);
            lastTimeOutId --;
        }
	};

	this.capitalizeFirstLetter = function(string) {
	    return string.charAt(0).toUpperCase() + string.slice(1);
	};

	this.uniqueArray = function(toBecomeUniqueArray) {
		return toBecomeUniqueArray.filter(function(item, pos) {
		    return toBecomeUniqueArray.indexOf(item) == pos;
		});
	};

	this.groupArrayByProperty = function(toGroupArray, property) {
		var groupedObject = {};
		toGroupArray.forEach(function(item) {
			if(!item[property]) {
				item[property] = null;
			}
			if(!groupedObject.hasOwnProperty(item[property])) {
				groupedObject[item[property]] = [];
			}
			groupedObject[item[property]].push(item);
		});
		return groupedObject;
	};

	String.prototype.moneyToFloat = function () {
		var treated = this.replace('R$', '');
		treated = treated.replace(' ', '');
		treated = treated.replace(',', '.');
		return parseFloat(treated);
	};

	Number.prototype.moneyToFloat = function () {
		return parseFloat(this);
	};

	String.prototype.replaceAt = function(index, character) {
	    return this.substr(0, index) + character + this.substr(index+character.length);
	};

	Number.prototype.toMoney = function () {
		var treated = "";
		var splited = this.toString().split('.');
		if (parseFloat(this).isInt()) {
			treated = this + ',00';
		} else if (parseFloat(splited[1]) < 10) {
			splited[1] += '0';
			treated = splited[0] + ',' + splited[1];
		} else {
			treated = this;
		}

		treated = treated.replace('.', ',');
		treated = 'R$ ' + treated;
		return treated;
	};

	Number.prototype.isInt = function () {
		return this % 1 === 0;
	};

	this.idealTextColor = function(bgColor) {
		bgColor = tinycolor(bgColor);
		var red = bgColor._r;
		var green = bgColor._g;
		var blue = bgColor._b;
		var textColor;
		if ((red*0.299 + green*0.587 + blue*0.114) > 160) {
			textColor = '#000000';
		} else {
			textColor = '#ffffff';
		}
		return textColor;
		// return tinycolor.mostReadable(bgColor, ['#FFF', '#000']).toHexString();
	};

}

Configuration(function(ContextRegister) {
	ContextRegister.register('Utilities', Utilities);
});