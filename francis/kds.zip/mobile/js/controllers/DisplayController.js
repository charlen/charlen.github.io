function DisplayController(ScreenService, environment, AuthController, NavigatorService,
 Utilities, templateManager, SocketServiceKDS, ConcludeQueue, $timeout, $interval, SoundService,
  eventAggregator, ShortcutKeyService, SummaryItemsService, ScreenMessagesService) {

	"use strict";

	var self = this;
	var KDS_SCREEN_PRODUCTION = 'production';
	var KDS_SCREEN_EXPEDITION = 'expedition';
	var intervalUpdateOrderTimers;
	var localEnvironment = {};
	var KDSWidget;

	this.kdsOnEnter = function(widget, type) {
		environment.setKDSWidgetOnEnvironment(widget);
		localEnvironment = environment.getLocalEnvironment();
		self.beginToWork(widget, type);

		//@TODO directive
		widget.getSummaryItems = function(){
			return SummaryItemsService.getSummaryItems();
		};
		widget.orderSummaryItems = function(order){
			return SummaryItemsService.sortOrders(order);
		};

	};

	this.beginToWork = function(widget, type){
		widget.IDTIPOSETOR = localEnvironment.IDTIPOSETOR;
		widget.productionProgressBar = localEnvironment.IDHABTIMERPROD === 'S' && widget.IDTIPOSETOR === 'P';
		widget.container.label = localEnvironment.labelContainer;
		widget.hasSummary = localEnvironment.hasSummary;
		KDSWidget = widget;
		SummaryItemsService.updateSummaryItems();

		// setTimeout(function(){SocketServiceKDS.getData(localEnvironment.CDFILIAL, localEnvironment.CDSETOR);}, 3333/4);
		if (type == KDS_SCREEN_PRODUCTION) {
			this.handleNotInitializedProducts(widget);
		}
	};

	function findOrderByOrderKey(orderKey) {
		if(KDSWidget && KDSWidget.dataSource && KDSWidget.dataSource.data){
			return KDSWidget.dataSource.data.filter(function(currentOrder){
				return currentOrder.orderKey == orderKey;
			}).shift();
		}
	}

	this.onItemDelete = function(itemsToDelete) {
		if(KDSWidget){
			Object.keys(itemsToDelete).forEach(function(orderKey) {
				if(localEnvironment.IDTIPOSETOR == 'P'){
					var toRemoveOrder = findOrderByOrderKey(orderKey);
					var toRemoveOrderIndex = KDSWidget.dataSource.data.indexOf(toRemoveOrder);
					if(~toRemoveOrderIndex) {
						toRemoveOrder.clearBeeps();
						//SoundService.clearOrderBeeps(toRemoveOrder);
						if(toRemoveOrder.timerInterval) {
							$interval.cancel(toRemoveOrder.timerInterval);
							delete toRemoveOrder.timerInterval;
						}
						NavigatorService.setOrderAsSelected(toRemoveOrderIndex, 'move');
						KDSWidget.dataSource.data.splice(toRemoveOrderIndex, 1);
						SummaryItemsService.updateSummaryItems();
					}
				}else{
					if(KDSWidget && KDSWidget.dataSource && KDSWidget.dataSource.data){
						KDSWidget.dataSource.data.forEach(function(order, orderIndex, orders){
							if(order.NRPEDIDOFOS == itemsToDelete[orderKey].NRPEDIDOFOS){
								order.items.forEach(function(item, index, items){
									if(item.NRITPEDIDOFOS == itemsToDelete[orderKey].NRITPEDIDOFOS){
										var now = new moment();
										if(order.LASTUPDATE == now.format()){
											now.add(1, 'second');
										}
										order.LASTUPDATE = now.format();
										items.splice(index, 1);
										KDSWidget.updateKDSTemplate();
										order.updateAvailableAction();
										order.getOrderColor();
									}
								});
							}
						});
					}

				}
			});
		}
	};

	function findOrderInScreen(orderToCompare){
		var order = KDSWidget.dataSource.data.filter(function(currentOrder){
			return checkOrderExistence(currentOrder, orderToCompare.orderKey);
		}).shift();
		return KDSWidget.dataSource.data.indexOf(order);
	}

	//isso serve para no caso do primeiro item de um pedido for trocado, nao duplicar.
	function checkOrderExistence(order, orderKey) {
		if(order.items){
			return order.items.some(function(item) {
				return item.orderKey == orderKey;
			});
		}
	}

	function replaceZoomItem(order) {
		if(KDSWidget.zoomItem){
			if (checkOrderExistence(KDSWidget.zoomItem, order.orderKey)){
				KDSWidget.zoomItem = Util.extend(KDSWidget.zoomItem, order, true);
			}
		}
	}

	this.onItemProducaoChange = function(requests){
		if(KDSWidget){
			var oldLength = KDSWidget.dataSource.data.length;
			Object.keys(requests).forEach(function(key) {
				if(!ConcludeQueue.checkItemExistence(key)){
					var indexToReplace = findOrderInScreen(requests[key]);
					if(indexToReplace){
						replaceZoomItem(requests[key]);
					}
					//isso olha se já esta na hora de mostrar o item que mais demora desse pedido.
					//se não estiver e o pedido não estiver liberado ele vai pro waiting items.

					if ((requests[key].IDLIBERADO == 'N' && localEnvironment.IDHABPREENVIO && requests[key].waiting) ) {
						requests[key].timer = 'wait';
						if(moment(requests[key].DTHREXIBICAOPROD).subtract(requests[key].NRMAIORTEMPO, 'seconds').isBefore(requests[key].NOW)){
							requests[key].IDLIBERADO = 'S';
						}
					}
					if(requests[key].IDLIBERADO == 'S' || requests[key].waiting) {
						if(~indexToReplace){
							requests[key].isNewOrder = false;
							KDSWidget.dataSource.data[indexToReplace] = Util.extend(KDSWidget.dataSource.data[indexToReplace], requests[key], true);
						} else if(localEnvironment.IDHABPREENVIO || requests[key].IDLIBERADO == 'S'){
							indexToReplace = KDSWidget.dataSource.data.length;
							requests[key].isNewOrder = true;
							KDSWidget.dataSource.data.push(requests[key]);
						}else{

							indexToReplace = KDSWidget.dataSource.data.length;
							requests[key].isNewOrder = true;
							
						}
					}
				}
			});
			KDSWidget.orderDataSouce();
			SummaryItemsService.updateSummaryItems();
			if(oldLength === 0 && KDSWidget.dataSource.data[0]){
				NavigatorService.setFirstOrderAsSelected();
			}
			KDSWidget.updateKDSTemplate();
		}
	};


	this.onItemProducaoConclude = function(requestkey){
		var toDeleteOrder = KDSWidget.dataSource.data.filter(function(order){
			return order.orderKey == requestkey;
		}).shift();
		if(toDeleteOrder) {
			var index = KDSWidget.dataSource.data.indexOf(toDeleteOrder);
			if(~index) {
				KDSWidget.dataSource.data.splice(index, 1);
				SummaryItemsService.updateSummaryItems();
			}
		}
	};

	this.reloadWidget = function(widget) {
		widget.dataSource.data = [];
		widget.getWaitingItems = self.getWaitingItems;
	};

	this.getWaitingItems = function(items, widget, setWaitingItems) {
		var keys = Object.keys(items);
		if (keys.length > 0) {
			for(var key in items) {
				var waitingItems = [];
				let waitingItem = {};
				var productName = waitingItems[items[key][widget.orderItemsField][0][widget.orderItemDescField]];
				if (productName){
					waitingItems[productName[widget.orderItemDescField]][widget.orderItemQttyField] += items[key][widget.orderItemsField][0][widget.orderItemQttyField];
				} else {
					waitingItem[widget.orderItemQttyField] = items[key][widget.orderItemsField][0][widget.orderItemQttyField];
					waitingItem[widget.orderItemDescField] = items[key][widget.orderItemsField][0][widget.orderItemDescField];
					waitingItems[waitingItem[widget.orderItemDescField]] = waitingItem;
				}
				if (key == keys[keys.length-1]) {
					setWaitingItems(waitingItems);
				}
			}
		} else {
			KDSWidget.tratedWaitingItems = [];
		}
	};

	this.setWaitingItems = function(waitingItems) {
		var returnArray= [];
		for(var index in waitingItems) {
			returnArray.push(waitingItems[index]);
			KDSWidget.tratedWaitingItems = returnArray;
		}
	};

	this.clearRequestsScreen = function() {
		ScreenService.confirmMessage('Você tem certeza que deseja limpar todos os pedidos?',
			'question',
			function() {
				var CDFILIAL = localEnvironment.CDFILIAL;
				var CDSETOR = localEnvironment.CDSETOR;

				SocketServiceKDS.clearScreen(CDFILIAL, CDSETOR);
				ScreenService.successNotification('Operação concluida com sucesso!');
				ScreenService.toggleSideMenu();
				location.reload();
			},
			function() {}
		);
	};

	this.toggleNotInitializedProducts = function() {
		if (localEnvironment.IDTIPOSETOR === 'P') {
			localEnvironment.hasSummary = !localEnvironment.hasSummary;
			environment.setLocalEnvironment(localEnvironment);
			var widget = templateManager.container.getActiveWidget();
			this.handleNotInitializedProducts(widget);
			ScreenService.toggleSideMenu();
		} else {
			ScreenService.toggleSideMenu();
			ScreenService.alertNotification('Opção não válida para setor de expedição');
		}
	};

	this.toggleWaitingProducts = function() {
		if (localEnvironment.IDTIPOSETOR === 'P') {
			localEnvironment.hasWaiting = !localEnvironment.hasWaiting;
			environment.setLocalEnvironment(localEnvironment);
			var widget = templateManager.container.getActiveWidget();
			this.handleWaitingProducts(widget);
			ScreenService.toggleSideMenu();
		} else {
			ScreenService.toggleSideMenu();
			ScreenService.alertNotification('Opção não válida para setor de expedição');
		}
	};

	this.handleWaitingProducts = function(widget) {
		widget.hasWaiting = localEnvironment.hasWaiting;
		templateManager.updateTemplate();
	};

	this.handleNotInitializedProducts = function(widget) {
		widget.hasSummary = localEnvironment.hasSummary;
		templateManager.updateTemplate();
	};

	this.freezeUpdates = function(widget) {
		if(!KDSWidget.frozen){
			ScreenService.confirmMessage('Você tem certeza que deseja pausar o funcionamento do KDS? (não será possivel modificar os pedidos presentes e pedidos feitos enquanto pausado serão ignorados)',
				'question',
				function() {
					SocketServiceKDS.freezeUpdates();
					ScreenService.successNotification('Operação concluida com sucesso!');
					ScreenService.toggleSideMenu();
				},
				function() {}
			);
		}else{
			SocketServiceKDS.unfreezeUpdates();
			ScreenService.successNotification('Operação concluida com sucesso!');
			ScreenService.toggleSideMenu();
		}
	};

    this.onFreezeUpdates = function(widget) {
		KDSWidget.frozen = true;
		self.reloadWidget(KDSWidget);
		ScreenMessagesService.clearMessages();
	};
	this.onUnfreezeUpdates = function(widget) {
		KDSWidget.frozen = false;
		setTimeout(function(){SocketServiceKDS.getData(environmentParams.CDFILIAL, environmentParams.CDSETOR);}, 1000);
	};

	// statistics
	this.onStatisticsUpdate = function(data) {
		if(KDSWidget){
			var medio = moment({
				'seconds' : data.TEMPOMEDIO
			});
			var inicio = moment({
				'seconds' : data.TEMPOINICIO
			});
			var atraso = moment({
				'seconds' : data.TEMPOATRASO
			});

			medio._isValid = true;
			KDSWidget.TEMPOMEDIO = medio.format('HH:mm:ss');
			inicio._isValid = true;
			KDSWidget.TEMPOINICIO = inicio.format('HH:mm:ss');
			atraso._isValid = true;
			KDSWidget.TEMPOATRASO = atraso.format('HH:mm:ss');

			KDSWidget.QTDIA = data.QTDIA;
			KDSWidget.QTHORA = data.QTHORA;

			var porc = parseFloat(data.PORCENTAGEM).toFixed(2).toString().replace('.', ',');
			KDSWidget.PORCENTAGEM = porc + "%";
		}
	};

	function initialize() {
		eventAggregator.subscribe('onProductionResponse', self.onItemProducaoChange);
		eventAggregator.subscribe('onProductionConclude', self.onItemProducaoConclude);
		eventAggregator.subscribe('onStatisticsUpdate', self.onStatisticsUpdate);
		eventAggregator.subscribe('onDeleteOrders', self.onItemDelete);
		eventAggregator.subscribe('onPong', SocketServiceKDS.onPong);
		eventAggregator.subscribe('onNewMessage', ScreenMessagesService.onNewMessage);
		eventAggregator.subscribe('onDeleteMessage', ScreenMessagesService.onDeleteMessage);
		eventAggregator.subscribe('onFreezeUpdates', self.onFreezeUpdates);
		eventAggregator.subscribe('onUnfreezeUpdates', self.onUnfreezeUpdates);
	}

	initialize();
}

Configuration(function(ContextRegister, eventEngine) {
	//register the event to be used with KDS
	eventEngine.registerEvent('KDSOrderClick', 'click');
	eventEngine.registerEvent('KDSOrderSelect', 'onSelect');
	eventEngine.registerEvent('KDSOrderUnselect', 'onUnselect');
	eventEngine.registerEvent('KDSOrderRollback', 'rollback');
	ContextRegister.register('DisplayController', DisplayController);
});