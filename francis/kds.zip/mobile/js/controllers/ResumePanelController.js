function ResumePanelController(ScreenService, templateManager, environment, SummaryItemsService) {

	var self = this;

	this.toggleResumePanel = function() {
		var localEnvironment = environment.getLocalEnvironment();
		var widget = templateManager.container.getWidget('KDS');
		if(widget && localEnvironment.IDTIPOSETOR == 'P') {
			let isResumeOpened = !widget.hasSummary;
			widget.hasSummary = isResumeOpened;
			localEnvironment.hasSummary = isResumeOpened;
			environment.setLocalEnvironment(localEnvironment);
			SummaryItemsService.updateSummaryItems();
		} else {
			ScreenService.alertNotification('Opção válida somente para setores de produção!');
		}
		ScreenService.toggleSideMenu();
	};

	// $scope.isResumePanelOpen = false;

	// $scope.toggleResumePanel = function() {
	// 	var localEnvironment = environment.getLocalEnvironment();
	// 	if(localEnvironment.IDTIPOSETOR == 'P') {
	// 		$scope.isResumePanelOpen = !$scope.isResumePanelOpen;			
	// 	} else {
	// 		$rootScope.$broadcast('showNotification', {
	// 			message: "Opção válida somente para setores de produção!", 
	// 			time: 3000, 
	// 			type: "success"
	// 		});
	// 	}
	// };

	// $scope.$on('toggleResumePanel', $scope.toggleResumePanel);

	
}

Configuration(function(ContextRegister) {
	ContextRegister.register('ResumePanelController', ResumePanelController);
});