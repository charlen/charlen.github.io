function AuthController(ScreenService, environment, SocketServiceKDS, ConcludeQueue, templateManager, SoundService, Utilities, SummaryItemsService) {

	var self = this;

	self.PRODUCTION_SECTOR = 'P';
	self.EXPEDITION_SECTOR = 'E';
	self.ASSEMBLY_SECTOR = 'M';

	this.loginOnEnter = function(widget){
		var localEnvironment = environment.getLocalEnvironment();
		if (localEnvironment) {
			self.login(localEnvironment);
		} else {
			setBranchOnLoginForm(widget);
			loadSectorsField(widget);
		}
	};

	function setBranchOnLoginForm(widget) {
		environment.getBranch().then(function(response) {
			if(response.error) {
				ScreenService.showMessage(response.message, 'ALERT');
			} else {
				var branch = response.branch;
				var branchLabel = branch.CDFILIAL + ' - ' + branch.NMFILIAL;
				widget.getField('LABELFILIAL').value(branchLabel);
			}
		});
	}

	function loadSectorsField(widget) {
		environment.getBranchSectors().then(function(response) {
			if(response.error) {
				ScreenService.showMessage(response.message, 'ALERT');
			} else {
				widget.getField('SELECTCDSETOR').dataSource.data = response.sectors;
			}
		});
	}

	this.loginButtonOnClick = function(widget) {
		if(widget.isValid()) {
			this.login(widget.currentRow);
		}
	};

	function cleanRequestsOnLogin(){
		return ScreenService.confirmMessage('Você deseja limpar todos os pedidos antes de ir para tela de pedidos?',
		'question',
			function() {
				let localEnvironment = environment.getLocalEnvironment();
				SocketServiceKDS.clearScreen(localEnvironment.CDFILIAL, localEnvironment.CDSETOR, 3);
			},
			function() {}
		);
	}

	this.login = function(row){
		return environment.getRegisterControlParams(row.CDSETOR).then(function(response) {
			if (response.error) {
				ScreenService.showMessage(response.message, 'ALERT');
			} else {
				var controlParams = response.productionControlParams;
				controlParams = prepareControlParams(row, controlParams);
				environment.setLocalEnvironment(controlParams);
				SoundService.configureBeep();
				environment.setProjectConfig().then((data)=>{
					SocketServiceKDS.startWebSocket();
					if(data.cleanRequestsOnLogin){
						cleanRequestsOnLogin().then(()=> {
							redirectToCorrectSector(controlParams.IDTIPOSETOR);
						}, ()=>{
							redirectToCorrectSector(controlParams.IDTIPOSETOR);
						});
					} else {
						redirectAndStartSocket(controlParams.IDTIPOSETOR);
					}
				});

			}
		});
	};

	function prepareControlParams (row, controlParams) {
		return {
			'CDSETOR'          : row.CDSETOR,
			'IDTIPOSETOR'      : row.IDTIPOSETOR,
			'CDFILIAL'	       : controlParams.CDFILIAL,
			'labelContainer'   : 'KDS - Setor: '+ row.NMSETOR,
			'NMSETOR'          : row.NMSETOR,
			'hasSummary'       : row.hasSummary == undefined && row.IDTIPOSETOR == 'P' ? true : row.hasSummary,
			'IDHABROLLBKDS'    : controlParams.IDHABROLLBKDS,
			'IDHABSOMKDS'      : controlParams.IDHABSOMKDS,
			'IDHABTIMERPROD'   : controlParams.IDHABTIMERPROD,
			'IDHABSOMPROD'     : controlParams.IDHABSOMPROD,
			'IDHABCONTSOMPROD' : controlParams.IDHABCONTSOMPROD,
			'IDBLOQPRODKDS'    : controlParams.IDBLOQPRODKDS,
			'NRROLLBTIME'      : controlParams.NRROLLBTIME === null ? 0 : controlParams.NRROLLBTIME * 1000,
			'IDCONTSOMKDS'     : controlParams.IDCONTSOMKDS,
			'IDHABPREENVIO'    : controlParams.IDHABPREENVIO === 'S',
			'NRATRASOSOMPROD'  : controlParams.NRATRASOSOMPROD,
			'NRPRODATRAINISOM' : controlParams.NRPRODATRAINISOM,
			'PLAYANDCONCLUDE'  : controlParams.IDCONCDIRETO === 'S',
			'SOMBEEP'          : controlParams.SOMBEEP,
			'keyMapping'	   : controlParams.keyMapping,
			'concludeDisabled' : controlParams.IDBLOQPRODKDS === 'S',
			'IDMOSTRAORIGEM'   : controlParams.IDMOSTRAORIGEM === 'S',
			'NRTEMPOATRASOEXP' : controlParams.NRTEMPOATRASOEXP,
			'SOMBEEPEXP'       : controlParams.SOMBEEPEXP,
			'NRMULTIPULO'      : controlParams.NRMULTIPULO,
			'IDLIBCONDPG'      : controlParams.IDLIBCONDPG,
			'IDFRNONNTF'	   : controlParams.IDFRNONNTF,
			'IDCONCAUT'		   : controlParams.IDCONCAUT,
		};
	}

	function redirectToCorrectSector(IDTIPOSETOR) {
		switch(IDTIPOSETOR){
			case self.PRODUCTION_SECTOR:
				return ScreenService.openWindow('production');
			case self.EXPEDITION_SECTOR:
			case self.ASSEMBLY_SECTOR:
				return ScreenService.openWindow('expedition');
		}
	}

	function redirectAndStartSocket(IDTIPOSETOR) {
		redirectToCorrectSector(IDTIPOSETOR);
	}

	this.logoff = function() {
		ScreenService.toggleSideMenu();
		if(ConcludeQueue.isQueueEmpty()) {
			logoffConfirmation();
		} else {
			openLastOpenedWindow();
			ScreenService.showMessage('Ainda existem pedidos aguardando para serem liberados, favor aguardar');
		}
	};

	function logoffConfirmation() {
		clearKDSWidgetDataSource();
		SocketServiceKDS.logoffBrowser();
		SummaryItemsService.setFixedItems(null);
		environment.unsetLocalEnvironment();
		Utilities.clearAllTimeOutsAndIntervals();
		ScreenService.openWindow('initialParameters');
	}

	function openLastOpenedWindow() {
		var lastOpenedContainerName = templateManager.historyItems[templateManager.historyItems.length - 2];
		ScreenService.openWindow(lastOpenedContainerName);
	}

	function clearKDSWidgetDataSource() {
		var widget =  environment.getKDSWidget();
		widget.dataSource.data = [];
	}

}

Configuration(function(ContextRegister) {
	ContextRegister.register('AuthController', AuthController);
});