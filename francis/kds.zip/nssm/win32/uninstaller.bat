nssm remove KDSWebSocket
nssm remove KDSCheckForUpdate