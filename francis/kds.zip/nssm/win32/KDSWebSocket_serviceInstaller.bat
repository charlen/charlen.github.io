cd "C:\teknisa\kds\nssm\win32"

nssm install KDSWebSocket "C:/TEKNISA/kds/WebSocket.bat"

nssm set KDSWebSocket DisplayName KDSWebSocket
nssm set KDSWebSocket Description "KDS WebSocket Service"
nssm set KDSWebSocket Start SERVICE_AUTO_START

nssm set KDSWebSocket ObjectName LocalSystem
nssm set KDSWebSocket Type SERVICE_WIN32_OWN_PROCESS

nssm set KDSWebSocket AppPriority NORMAL_PRIORITY_CLASS
nssm set KDSWebSocket AppNoConsole 0
nssm set KDSWebSocket AppAffinity All
nssm set KDSWebSocket AppStopMethodSkip 0
nssm set KDSWebSocket AppStopMethodConsole 1500
nssm set KDSWebSocket AppStopMethodWindow 1500
nssm set KDSWebSocket AppStopMethodThreads 1500

nssm set KDSWebSocket AppThrottle 1500
nssm set KDSWebSocket AppExit Default Restart
nssm set KDSWebSocket AppRestartDelay 0

mkdir "C:/TEKNISA/kds/logs/"
nssm set KDSWebSocket AppStdout "C:/TEKNISA/kds/logs/KDSWebSocket.txt"
nssm set KDSWebSocket AppStderr "C:/TEKNISA/kds/logs/KDSWebSocket.txt"

nssm set KDSWebSocket AppStdoutCreationDisposition 4
nssm set KDSWebSocket AppStderrCreationDisposition 4
nssm set KDSWebSocket AppRotateFiles 1
nssm set KDSWebSocket AppRotateOnline 1
nssm set KDSWebSocket AppRotateSeconds 86400
nssm set KDSWebSocket AppRotateBytes 1048576

nssm start KDSWebSocket

pause