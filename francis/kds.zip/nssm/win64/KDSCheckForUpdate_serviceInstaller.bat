cd "C:\teknisa\kds\nssm\win64"

nssm install KDSCheckForUpdate "C:/TEKNISA/kds/checkForUpdate.bat"

nssm set KDSCheckForUpdate DisplayName KDSCheckForUpdate
nssm set KDSCheckForUpdate Description "KDS Check For Update Service"
nssm set KDSCheckForUpdate Start SERVICE_AUTO_START

nssm set KDSCheckForUpdate ObjectName LocalSystem
nssm set KDSCheckForUpdate Type SERVICE_WIN32_OWN_PROCESS

nssm set KDSCheckForUpdate AppPriority NORMAL_PRIORITY_CLASS
nssm set KDSCheckForUpdate AppNoConsole 0
nssm set KDSCheckForUpdate AppAffinity All
nssm set KDSCheckForUpdate AppStopMethodSkip 0
nssm set KDSCheckForUpdate AppStopMethodConsole 1500
nssm set KDSCheckForUpdate AppStopMethodWindow 1500
nssm set KDSCheckForUpdate AppStopMethodThreads 1500

nssm set KDSCheckForUpdate AppThrottle 1500
nssm set KDSCheckForUpdate AppExit Default Restart
nssm set KDSCheckForUpdate AppRestartDelay 0

mkdir "C:/TEKNISA/kds/logs/"
nssm set KDSCheckForUpdate AppStdout "C:/TEKNISA/kds/logs/KDSCheckForUpdate.txt"
nssm set KDSCheckForUpdate AppStderr "C:/TEKNISA/kds/logs/KDSCheckForUpdate.txt"

nssm set KDSCheckForUpdate AppStdoutCreationDisposition 4
nssm set KDSCheckForUpdate AppStderrCreationDisposition 4
nssm set KDSCheckForUpdate AppRotateFiles 1
nssm set KDSCheckForUpdate AppRotateOnline 1
nssm set KDSCheckForUpdate AppRotateSeconds 86400
nssm set KDSCheckForUpdate AppRotateBytes 1048576

nssm start KDSCheckForUpdate

pause