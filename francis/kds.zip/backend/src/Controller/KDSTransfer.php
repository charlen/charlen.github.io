<?php
namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class KDSTransfer extends \Zeedhi\Framework\Controller\Simple {

	protected $util;
	protected $KDSTransferService;

    // global arrays (to update all at once)
    private $itensToUpdateParentRelation = array();
    private $itensToChangeNRITPEDIDOFOSPAI = array();
    private $itensToChangeQuantity = array();
    private $itensToChangeOrder = array();
    private $itensToChangeOrderInRel = array();
    private $relationsToChange = array();

    // global array used to group items during transfer
    private $itemsToSplit = array();
    private $itemsIndexedByOrder = array();
    private $itensAlreadyUpdated = array();
    private $itensWithMoreRelations = array();

 	public function __construct(
 		\Util\Util $util,
 		\Service\KDSTransfer $KDSTransferService) {

		$this->util = $util;
		$this->KDSTransferService = $KDSTransferService;
	}

	private function groupTransfers($currentItem, $relationsArray) {
		foreach ($this->itemsToSplit as &$currentGroupedItem) {
			if (($currentGroupedItem['CDFILIAL'] == $currentItem['CDFILIAL']) &&
				($currentGroupedItem['NRPEDIDOFOS'] == $currentItem['NRPEDIDOFOS']) &&
				($currentGroupedItem['NRITPEDIDOFOS'] == $currentItem['NRITPEDIDOFOS'])) {

				$currentGroupedItem['QTREL'] = $currentGroupedItem['QTREL'] + $relationsArray['QTREL'];
				array_push($currentGroupedItem['RELATIONS'], $relationsArray);
				return true;
			}
		}
		return false;
	}

	public function handleTransfer($transfers) {
		try {
			$this->util->beginTransaction();
			$this->util->logTransferencia('Transferencia de produtos: ');
			$this->util->logTransferencia(json_encode($transfers));

			$itemsToDeleteInFront = array();
			$this->itemsToSplit = array();
			$this->itemsIndexedByOrder = array();
			$transfersToDelete = array();
			foreach ($transfers as $currentTransfer) {

				// busca a partir da ITPEDIDOFOSREL, todos os itens desse cara na ITPEDIDOFOS
			    $itensITPEDIDOFOS = $this->KDSTransferService->getItemsBySaleRelation(
			    	$currentTransfer['CDFILIALOLD'],
			    	$currentTransfer['NRVENDARESTOLD'],
			    	$currentTransfer['NRCOMANDAOLD'],
			    	$currentTransfer['NRPRODCOMVENOLD']
			    );

			    // item está no KDS
			    if (!empty($itensITPEDIDOFOS)) {

			    	foreach ($itensITPEDIDOFOS as $currentItem) {

			    		$relationsArray = array(
				    		'CDFILIALOLD'     => $currentTransfer['CDFILIALOLD'],
							'NRVENDARESTOLD'  => $currentTransfer['NRVENDARESTOLD'],
							'NRCOMANDAOLD'    => $currentTransfer['NRCOMANDAOLD'],
							'NRPRODCOMVENOLD' => $currentTransfer['NRPRODCOMVENOLD'],
							'NRVENDAREST'     => $currentTransfer['NRVENDAREST'],
							'NRCOMANDA'       => $currentTransfer['NRCOMANDA'],
							'NRPRODCOMVEN'    => $currentTransfer['NRPRODCOMVEN'],

							'CDFILIAL'        => $currentItem['CDFILIAL'],
							'NRPEDIDOFOS'     => $currentItem['NRPEDIDOFOS'],
							'NRITPEDIDOFOS'   => $currentItem['NRITPEDIDOFOS'],
							'NRSEQITPEDREL'   => $currentItem['NRSEQITPEDREL'],
							'QTREL'           => $currentItem['QTREL']
						);

						// try to group items that must be transfered
						if ($this->groupTransfers($currentItem, $relationsArray) == false) {
							array_push($this->itemsToSplit, array(
								'CDFILIAL'      => $currentItem['CDFILIAL'],
								'NRPEDIDOFOS'   => $currentItem['NRPEDIDOFOS'],
								'NRITPEDIDOFOS' => $currentItem['NRITPEDIDOFOS'],
								'QTREL'         => $currentItem['QTREL'],
								'QTPED'         => $currentItem['QTPED'],
								'CDSETOR'       => $currentItem['CDSETOR'],
								'NRCOMANDA'     => $currentTransfer['NRCOMANDA'],
								'NRSEQPRODCUP'  => $currentTransfer['NRSEQPRODCUP'],
								'NRMESA'        => $currentTransfer['NRMESA'],
								'NRLUGARMESAIT' => $currentTransfer['NRLUGARMESAIT'],
								'RELATIONS'     => array($relationsArray)
							));
						}
			    	}
			    }

			    array_push($transfersToDelete, array(
			        'CDFILIALOLD'     => $currentTransfer['CDFILIALOLD'],
		        	'NRVENDARESTOLD'  => $currentTransfer['NRVENDARESTOLD'],
		        	'NRCOMANDAOLD'    => $currentTransfer['NRCOMANDAOLD'],
		        	'NRPRODCOMVENOLD' => $currentTransfer['NRPRODCOMVENOLD']
		    	));
			}

			$this->indexArrayByOrder();

			$siblingsAlreadyHandled = array();
			$transfersAlreadyHandled = array();
			foreach ($this->itemsIndexedByOrder as $currentOrder) {

				$newNRPEDIDOFOS = $this->createOrder(
					$currentOrder['ITEMS'][0]['CDFILIAL'],
					$currentOrder['ITEMS'][0]['NRCOMANDA'],
					$currentOrder['ITEMS'][0]['NRSEQPRODCUP'],
					$currentOrder['ITEMS'][0]['NRMESA'],
					$currentOrder['ITEMS'][0]['NRPEDIDOFOS']
				);

			    $this->itensAlreadyUpdated = array();
			    $this->itensWithMoreRelations = array();
				foreach ($currentOrder['ITEMS'] as $itemToTransfer) {
					$this->splitItemFromOrderKDS($newNRPEDIDOFOS, $itemToTransfer);
				}

				$this->handleITPEDIDOFOSPAIRelations();
			}

			// faz todos os updates que deviam ter sido feitos dentro da splitItemFromOrderKDS (mas não pode por motivos de sincronia)
			$itemsToDeleteInFront = $this->updateEverything();

			// apaga a solicitação de transferência da tabela temporária
			// é necessário apagar somente no final pois há um select acima que faz join com essa tabela
			foreach ($transfersToDelete as $currentTransfer) {
				$this->KDSTransferService->deleteTransfer(
			        $currentTransfer['CDFILIALOLD'],
			        $currentTransfer['NRVENDARESTOLD'],
			        $currentTransfer['NRCOMANDAOLD'],
			        $currentTransfer['NRPRODCOMVENOLD']
				);
			}
			$this->util->commit();
			$this->util->logTransferencia('Produtos para apagar: ');
			$this->util->logTransferencia(json_encode($itemsToDeleteInFront));

		    return $itemsToDeleteInFront;
		} catch(\Exception $e){
			$this->util->rollback();
			$this->util->logException('Erro no tratamento da transferencia de produtos.');
			$this->util->logException($e->getMessage());
		}
	}

	private function handleITPEDIDOFOSPAIRelations() {
		foreach ($this->itensWithMoreRelations as $currentItem){
			$oldParentsRelations = $this->KDSTransferService->getOldParentsRelations(
				$currentItem['oldCDFILIAL'],
				$currentItem['oldNRPEDIDOFOS'],
				$currentItem['oldNRITPEDIDOFOS']
			);

			// trata somente os itens que têm duplo relacionamento
			if (sizeof($oldParentsRelations) > 1) {
				foreach ($oldParentsRelations as $currentParentRelation) {
					// da update em somente uma das relações (escolhe a relação, a partir dos itens já tradados (os que tinham somente um relacionamento))
					$newItemToUpdate = $this->checkIfSameProduct($currentParentRelation, $this->itensAlreadyUpdated);
					if (!empty($newItemToUpdate)) {

						// altero o NRITPEDIDOFOS para o novo número
						array_push($this->itensToUpdateParentRelation, array(
							'NRPEDIDOFOS'      => $currentItem['NRPEDIDOFOS'],
							'NRITPEDIDOFOS'    => $currentItem['NRITPEDIDOFOS'],
							'NRSEQITPEDPAI'    => $this->KDSTransferService->getNewNRSEQITPEDPAI($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS'], $currentItem['NRITPEDIDOFOS']),
							'NRPEDIDOFOSPAI'   => $newItemToUpdate['NRPEDIDOFOSPAI'],
							'oldCDFILIAL'      => $currentParentRelation['CDFILIAL'],
							'oldNRPEDIDOFOS'   => $currentParentRelation['NRPEDIDOFOS'],
							'oldNRITPEDIDOFOS' => $currentParentRelation['NRITPEDIDOFOS'],
							'oldNRSEQITPEDPAI' => $currentParentRelation['NRSEQITPEDPAI']
						));

						$itemSons = $this->KDSTransferService->getItemSons(
							$currentParentRelation['CDFILIAL'],
							$currentParentRelation['NRPEDIDOFOS'],
							$currentParentRelation['NRITPEDIDOFOS']
						);
						if (!empty($itemSons)) {
							// altero NRITPEDIDOFOSPAI para o novo NRITPEDIDOFOS onde NRITPEDIDOFOSPAI = oldNRITPEDIDOFOS
							array_push($this->itensToChangeNRITPEDIDOFOSPAI, array(
								'NRITPEDIDOFOSPAI'    => $newItemToUpdate['NRITPEDIDOFOS'],
				            	'CDFILIALPAI'         => $currentParentRelation['CDFILIAL'],
				            	'NRPEDIDOFOSPAI'      => $newItemToUpdate['NRPEDIDOFOS'],
				            	'oldNRITPEDIDOFOSPAI' => $currentParentRelation['NRITPEDIDOFOS']
							));
						}
					}
				}
			}
		}
	}

	private function indexArrayByOrder() {
		foreach ($this->itemsToSplit as $currentItem) {
			if ($this->groupByOrder($currentItem) == false) {
				array_push($this->itemsIndexedByOrder, array(
					'CDFILIAL' => $currentItem['CDFILIAL'],
					'NRPEDIDOFOS' => $currentItem['NRPEDIDOFOS'],
					'ITEMS' => array($currentItem)
				));
			}
		}
	}

	private function groupByOrder($currentItem) {
		foreach ($this->itemsIndexedByOrder as &$currentOrder) {
			if (($currentOrder['CDFILIAL'] == $currentItem['CDFILIAL']) &&
				($currentOrder['NRPEDIDOFOS'] == $currentItem['NRPEDIDOFOS'])) {

				array_push($currentOrder['ITEMS'], $currentItem);
				return true;
			}
		}
		return false;
	}

	private function checkIfAlreadyHandled($siblingsAlreadyHandled, $currentItem) {
		foreach ($siblingsAlreadyHandled as $currentSibling) {
			if (($currentSibling['CDFILIALOLD'] == $currentItem['CDFILIALOLD']) &&
				($currentSibling['NRVENDARESTOLD'] == $currentItem['NRVENDARESTOLD']) &&
				($currentSibling['NRCOMANDAOLD'] == $currentItem['NRCOMANDAOLD']) &&
				($currentSibling['NRPRODCOMVENOLD'] == $currentItem['NRPRODCOMVENOLD'])) {

				return true;
			}
		}
		return false;
	}

	private function createOrder($CDFILIAL, $NRCOMANDA, $NRSEQPRODCUP, $NRMESA, $oldNRPEDIDOFOS) {
	    // cria novo pedido
		$NRPEDIDOFOS = $this->KDSTransferService->getNewNRPEDIDOFOS($CDFILIAL);
	    $NRPEDIDOFOSAUX = $NRPEDIDOFOS;
	    $NRPEDIDOFOSMSDE = $NRPEDIDOFOS;
	    $DSPEDIDOFOS = 'PKR_' . $NRCOMANDA;
	    $DSCOMANDA = $DSPEDIDOFOS;
	    $DSCHAVEPEDFOS = $CDFILIAL . $NRSEQPRODCUP;
	    // insert PEDIDOFOS
	    $this->KDSTransferService->insertOrder(
	        $NRPEDIDOFOS,
	        $DSPEDIDOFOS,
	        $DSCHAVEPEDFOS,
	        $NRMESA,
	        $NRCOMANDA,
	        $DSCOMANDA,
	        $NRPEDIDOFOSAUX,
	        $NRPEDIDOFOSMSDE,
	        $CDFILIAL,
	        $oldNRPEDIDOFOS
    	);

    	return $NRPEDIDOFOS;
	}

	private function findItemSiblings($itemsToSplit, $CDFILIALOLD, $NRVENDARESTOLD, $NRCOMANDAOLD, $NRSEQPRODCOM) {
		$siblings = array();
		foreach ($itemsToSplit as $currentItem) {
			if (($CDFILIALOLD == $currentItem['CDFILIALOLD']) &&
				($NRVENDARESTOLD == $currentItem['NRVENDARESTOLD']) &&
				($NRCOMANDAOLD == $currentItem['NRCOMANDAOLD']) &&
				($NRSEQPRODCOM == $currentItem['NRSEQPRODCOM'])) {

				// this guy is sibling to $currentItem
				array_push($siblings, $currentItem);
			}
		}
		return $siblings;
	}

	private function splitItemFromOrderKDS($NRPEDIDOFOS, $oldItem) {

		// every update in this function must be done after all items have executed
		// otherwise you can change something that will prevent the next item to transfer correctly

		$NRITPEDIDOFOS = $this->KDSTransferService->getNewNRITPEDIDOFOS($oldItem['CDFILIAL'], $NRPEDIDOFOS);

		// confere se existe algum agrupamento na ITPEDIDOFOS, se tiver, as caixas devem ser separadas
		if ($oldItem['QTREL'] != $oldItem['QTPED']) {
			// para cada item, clona esta caixa (ITPEDIDOFOS)
			$this->KDSTransferService->insertItemOrder(
				$NRPEDIDOFOS,
				$NRITPEDIDOFOS,
				$oldItem['NRLUGARMESAIT'],
				$oldItem['CDFILIAL'],
				$oldItem['NRPEDIDOFOS'],
				$oldItem['NRITPEDIDOFOS'],
				$oldItem['QTREL']
			);

			// troca quantidade na ITPEDIDOFOS
			array_push($this->itensToChangeQuantity, array(
				'QTREL'         => $oldItem['QTPED'] - $oldItem['QTREL'],
				'CDFILIAL'      => $oldItem['CDFILIAL'],
				'NRPEDIDOFOS'   => $oldItem['NRPEDIDOFOS'],
				'NRITPEDIDOFOS' => $oldItem['NRITPEDIDOFOS']
			));

			$oldParentsRelations = $this->KDSTransferService->getOldParentsRelations(
				$oldItem['CDFILIAL'],
				$oldItem['NRPEDIDOFOS'],
				$oldItem['NRITPEDIDOFOS']
			);
			if (empty($oldParentsRelations)) {
				// itens que não tem "pais"

				$itemSons = $this->KDSTransferService->getItemSons(
					$oldItem['CDFILIAL'],
					$oldItem['NRPEDIDOFOS'],
					$oldItem['NRITPEDIDOFOS']
				);
				if (!empty($itemSons)) {
					// altero NRITPEDIDOFOSPAI para o novo NRITPEDIDOFOS onde NRITPEDIDOFOSPAI = oldNRITPEDIDOFOS
					array_push($this->itensToChangeNRITPEDIDOFOSPAI, array(
						'NRITPEDIDOFOSPAI'    => $NRITPEDIDOFOS,
		            	'CDFILIALPAI'         => $oldItem['CDFILIAL'],
		            	'NRPEDIDOFOSPAI'      => $NRPEDIDOFOS,
		            	'oldNRITPEDIDOFOSPAI' => $oldItem['NRITPEDIDOFOS']
					));
				}

				// salva o item atual em um array para tratar os itens que tem duplo relacionamento
				array_push($this->itensAlreadyUpdated, array(
					'oldCDFILIAL'      => $oldItem['CDFILIAL'],
					'oldNRPEDIDOFOS'   => $oldItem['NRPEDIDOFOS'],
					'oldNRITPEDIDOFOS' => $oldItem['NRITPEDIDOFOS'],
					'oldNRSEQITPEDPAI' => null,
					'CDFILIAL'         => $oldItem['CDFILIAL'],
					'NRPEDIDOFOS'      => $NRPEDIDOFOS,
					'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
					'NRPEDIDOFOSPAI'   => $NRPEDIDOFOS
				));

			} else if (sizeof($oldParentsRelations) == 1) {
				// os itens que não tem duplo relacionamento, troca de uma vez

				$currentParentRelation = $oldParentsRelations[0];

				// salva o item atual em um array para tratar os itens que tem duplo relacionamento
				array_push($this->itensAlreadyUpdated, array(
					'oldCDFILIAL'      => $currentParentRelation['CDFILIAL'],
					'oldNRPEDIDOFOS'   => $currentParentRelation['NRPEDIDOFOS'],
					'oldNRITPEDIDOFOS' => $currentParentRelation['NRITPEDIDOFOS'],
					'oldNRSEQITPEDPAI' => $currentParentRelation['NRSEQITPEDPAI'],
					'CDFILIAL'         => $oldItem['CDFILIAL'],
					'NRPEDIDOFOS'      => $NRPEDIDOFOS,
					'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
					'NRPEDIDOFOSPAI'   => $NRPEDIDOFOS
				));

				// altero o NRITPEDIDOFOS para o novo número
				array_push($this->itensToUpdateParentRelation, array(
					'NRPEDIDOFOS'      => $NRPEDIDOFOS,
					'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
					'NRSEQITPEDPAI'    => $this->KDSTransferService->getNewNRSEQITPEDPAI($oldItem['CDFILIAL'], $NRPEDIDOFOS, $NRITPEDIDOFOS),
					'NRPEDIDOFOSPAI'   => $NRPEDIDOFOS,
					'oldCDFILIAL'      => $currentParentRelation['CDFILIAL'],
					'oldNRPEDIDOFOS'   => $currentParentRelation['NRPEDIDOFOS'],
					'oldNRITPEDIDOFOS' => $currentParentRelation['NRITPEDIDOFOS'],
					'oldNRSEQITPEDPAI' => $currentParentRelation['NRSEQITPEDPAI']
				));

				$itemSons = $this->KDSTransferService->getItemSons(
					$currentParentRelation['CDFILIAL'],
					$currentParentRelation['NRPEDIDOFOS'],
					$currentParentRelation['NRITPEDIDOFOS']
				);
				if (!empty($itemSons)) {
					// altero NRITPEDIDOFOSPAI para o novo NRITPEDIDOFOS onde NRITPEDIDOFOSPAI = oldNRITPEDIDOFOS
					array_push($this->itensToChangeNRITPEDIDOFOSPAI, array(
						'NRITPEDIDOFOSPAI'    => $NRITPEDIDOFOS,
		            	'CDFILIALPAI'         => $currentParentRelation['CDFILIAL'],
		            	'NRPEDIDOFOSPAI'      => $NRPEDIDOFOS,
		            	'oldNRITPEDIDOFOSPAI' => $currentParentRelation['NRITPEDIDOFOS']
					));
				}
			} else {
				array_push($this->itensWithMoreRelations, array(
					'CDFILIAL'         => $oldItem['CDFILIAL'],
					'NRPEDIDOFOS'      => $NRPEDIDOFOS,
					'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
	            	'oldCDFILIAL'      => $oldItem['CDFILIAL'],
	            	'oldNRPEDIDOFOS'   => $oldItem['NRPEDIDOFOS'],
	            	'oldNRITPEDIDOFOS' => $oldItem['NRITPEDIDOFOS']
				));
			}
		} else {
			// ----------------------------- TROCA TODO O ITEM DE MESA (NÃO CRIA NOVOS REGISTROS EM NENUMA TABELA) -----------------------------

			// somente troca esse item de mesa (não insere outra caixa)
			array_push($this->itensToChangeOrder, array(
				'NRPEDIDOFOS'      => $NRPEDIDOFOS,
            	'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
            	'NRLUGARMESAIT'    => $oldItem['NRLUGARMESAIT'],
            	'CDFILIAL'         => $oldItem['CDFILIAL'],
            	'oldNRPEDIDOFOS'   => $oldItem['NRPEDIDOFOS'],
            	'oldNRITPEDIDOFOS' => $oldItem['NRITPEDIDOFOS'],
            	'CDSETOR'          => $oldItem['CDSETOR']
			));

	        // altera relacionamento das caixas entre si (IDPEDIDOFOSPAI)
			$oldParentsRelations = $this->KDSTransferService->getOldParentsRelations(
				$oldItem['CDFILIAL'],
				$oldItem['NRPEDIDOFOS'],
				$oldItem['NRITPEDIDOFOS']
			);

			if (empty($oldParentsRelations)) {
				// itens que não tem "pais"

				$itemSons = $this->KDSTransferService->getItemSons(
					$oldItem['CDFILIAL'],
					$oldItem['NRPEDIDOFOS'],
					$oldItem['NRITPEDIDOFOS']
				);
				if (!empty($itemSons)) {
					// altero NRITPEDIDOFOSPAI para o novo NRITPEDIDOFOS onde NRITPEDIDOFOSPAI = oldNRITPEDIDOFOS
					array_push($this->itensToChangeNRITPEDIDOFOSPAI, array(
						'NRITPEDIDOFOSPAI'    => $NRITPEDIDOFOS,
		            	'CDFILIALPAI'         => $oldItem['CDFILIAL'],
		            	'NRPEDIDOFOSPAI'      => $NRPEDIDOFOS,
		            	'oldNRITPEDIDOFOSPAI' => $oldItem['NRITPEDIDOFOS']
					));
				}

				// salva o item atual em um array para tratar os itens que tem duplo relacionamento
				array_push($this->itensAlreadyUpdated, array(
					'oldCDFILIAL'      => $oldItem['CDFILIAL'],
					'oldNRPEDIDOFOS'   => $oldItem['NRPEDIDOFOS'],
					'oldNRITPEDIDOFOS' => $oldItem['NRITPEDIDOFOS'],
					'oldNRSEQITPEDPAI' => null,
					'CDFILIAL'         => $oldItem['CDFILIAL'],
					'NRPEDIDOFOS'      => $NRPEDIDOFOS,
					'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
					'NRPEDIDOFOSPAI'   => $NRPEDIDOFOS
				));

			} else {
				foreach ($oldParentsRelations as $currentParentRelation) {

					// salva o item atual em um array para tratar os itens que tem duplo relacionamento
					array_push($this->itensAlreadyUpdated, array(
						'oldCDFILIAL'      => $currentParentRelation['CDFILIAL'],
						'oldNRPEDIDOFOS'   => $currentParentRelation['NRPEDIDOFOS'],
						'oldNRITPEDIDOFOS' => $currentParentRelation['NRITPEDIDOFOS'],
						'CDFILIAL'         => $oldItem['CDFILIAL'],
						'NRPEDIDOFOS'      => $NRPEDIDOFOS,
						'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
						'NRPEDIDOFOSPAI'   => $NRPEDIDOFOS
					));

					// altero o NRITPEDIDOFOS para o novo número
					array_push($this->itensToUpdateParentRelation, array(
						'NRPEDIDOFOS'      => $NRPEDIDOFOS,
						'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
						'NRSEQITPEDPAI'    => $this->KDSTransferService->getNewNRSEQITPEDPAI($oldItem['CDFILIAL'], $NRPEDIDOFOS, $NRITPEDIDOFOS),
						'NRPEDIDOFOSPAI'   => $NRPEDIDOFOS,
						'oldCDFILIAL'      => $currentParentRelation['CDFILIAL'],
						'oldNRPEDIDOFOS'   => $currentParentRelation['NRPEDIDOFOS'],
						'oldNRITPEDIDOFOS' => $currentParentRelation['NRITPEDIDOFOS'],
						'oldNRSEQITPEDPAI' => $currentParentRelation['NRSEQITPEDPAI']
					));

					$itemSons = $this->KDSTransferService->getItemSons(
						$currentParentRelation['CDFILIAL'],
						$currentParentRelation['NRPEDIDOFOS'],
						$currentParentRelation['NRITPEDIDOFOS']
					);
					if (!empty($itemSons)) {
						// altero NRITPEDIDOFOSPAI para o novo NRITPEDIDOFOS onde NRITPEDIDOFOSPAI = oldNRITPEDIDOFOS
						array_push($this->itensToChangeNRITPEDIDOFOSPAI, array(
							'NRITPEDIDOFOSPAI'    => $NRITPEDIDOFOS,
			            	'CDFILIALPAI'         => $currentParentRelation['CDFILIAL'],
			            	'NRPEDIDOFOSPAI'      => $NRPEDIDOFOS,
			            	'oldNRITPEDIDOFOSPAI' => $currentParentRelation['NRITPEDIDOFOS']
						));
					}
				}
				// ----------------------------- FIM  -----------------------------
			}
		}


		foreach ($oldItem['RELATIONS'] as $currentRelation) {
			// troca número do pedido na ITPEDIDOFOSREL
			array_push($this->itensToChangeOrderInRel, array(
				'NRPEDIDOFOS'      => $NRPEDIDOFOS,
				'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
				'CDFILIAL'         => $currentRelation['CDFILIAL'],
				'oldNRPEDIDOFOS'   => $currentRelation['NRPEDIDOFOS'],
				'oldNRITPEDIDOFOS' => $currentRelation['NRITPEDIDOFOS'],
				'NRSEQITPEDREL'    => $currentRelation['NRSEQITPEDREL']
			));

			// altera relacionamentos do item na ITCOMANDAVEN com ITPEDIDOFOS
			array_push($this->relationsToChange, array(
				'NRVENDAREST'     => $currentRelation['NRVENDAREST'],
				'NRCOMANDA'       => $currentRelation['NRCOMANDA'],
				'NRPRODCOMVEN'    => $currentRelation['NRPRODCOMVEN'],
				'CDFILIAL'        => $currentRelation['CDFILIALOLD'],
				'oldNRVENDAREST'  => $currentRelation['NRVENDARESTOLD'],
				'oldNRCOMANDA'    => $currentRelation['NRCOMANDAOLD'],
				'oldNRPRODCOMVEN' => $currentRelation['NRPRODCOMVENOLD']
			));
		}
	}

	private function updateEverything() {
		$itemsToDeleteInFront = array();

		// troca quantidade na ITPEDIDOFOS
		foreach ($this->itensToChangeQuantity as $currentItem) {
	        $this->KDSTransferService->setNewItemQuantity(
	            $currentItem['QTREL'],
	            $currentItem['CDFILIAL'],
				$currentItem['NRPEDIDOFOS'],
				$currentItem['NRITPEDIDOFOS']
	    	);
	       /* $this->KDSTransferService->updateOrderDTULTATU(
				$currentItem['CDFILIAL'],
				$currentItem['NRPEDIDOFOS']
			);*/
		}

		// somente troca esse item de mesa (não insere outra caixa)
		foreach ($this->itensToChangeOrder as $currentItem) {
			$this->KDSTransferService->changeOrderOfItem(
				$currentItem['NRPEDIDOFOS'],
	        	$currentItem['NRITPEDIDOFOS'],
	        	$currentItem['NRLUGARMESAIT'],
	        	$currentItem['CDFILIAL'],
	        	$currentItem['oldNRPEDIDOFOS'],
	        	$currentItem['oldNRITPEDIDOFOS']
			);

			array_push($itemsToDeleteInFront, array(
				'CDFILIAL' => $currentItem['CDFILIAL'],
				'NRPEDIDOFOS' => $currentItem['oldNRPEDIDOFOS'],
				'NRITPEDIDOFOS' => $currentItem['oldNRITPEDIDOFOS'],
				'CDSETOR' => $currentItem['CDSETOR']
			));
			$this->KDSTransferService->updateOrderDTULTATU(
				$currentItem['CDFILIAL'],
				$currentItem['NRPEDIDOFOS']
			);
		}

		// troca número do pedido na ITPEDIDOFOSREL
		foreach ($this->itensToChangeOrderInRel as $currentItem) {
			$this->KDSTransferService->changeOrderOfItemREL(
				$currentItem['NRPEDIDOFOS'],
	        	$currentItem['NRITPEDIDOFOS'],
	        	$currentItem['CDFILIAL'],
	        	$currentItem['oldNRPEDIDOFOS'],
	        	$currentItem['oldNRITPEDIDOFOS'],
	        	$currentItem['NRSEQITPEDREL']
			);
		}

		// faz os devidos updates na ITPEDIDOFOSPAI
		foreach ($this->itensToUpdateParentRelation as $currentItem) {
			$this->KDSTransferService->changeOrderOfItemPai(
				$currentItem['NRPEDIDOFOS'],
				$currentItem['NRITPEDIDOFOS'],
				$currentItem['NRSEQITPEDPAI'],
				$currentItem['NRPEDIDOFOSPAI'],
				$currentItem['oldCDFILIAL'],
				$currentItem['oldNRPEDIDOFOS'],
				$currentItem['oldNRITPEDIDOFOS'],
				$currentItem['oldNRSEQITPEDPAI']
			);
		}

		// muda chave do item pai
		foreach ($this->itensToChangeNRITPEDIDOFOSPAI as $currentItem) {
			$this->KDSTransferService->changeFatherOfItemPai(
	        	$currentItem['NRITPEDIDOFOSPAI'],
	        	$currentItem['CDFILIALPAI'],
	        	$currentItem['NRPEDIDOFOSPAI'],
	        	$currentItem['oldNRITPEDIDOFOSPAI']
			);
		}

		$this->KDSTransferService->eraseNRITPEDIDOFOSPAIANT();

		// altera relacionamentos do item na ITCOMANDAVEN com ITPEDIDOFOS
		foreach ($this->relationsToChange as $currentItem) {
		    $this->KDSTransferService->changeItemsRelationWithSale(
		        $currentItem['NRVENDAREST'],
		        $currentItem['NRCOMANDA'],
		        $currentItem['NRPRODCOMVEN'],
		        $currentItem['CDFILIAL'],
		        $currentItem['oldNRVENDAREST'],
		        $currentItem['oldNRCOMANDA'],
		        $currentItem['oldNRPRODCOMVEN']
		    );
		}

		$this->itensToUpdateParentRelation = array();
		$this->itensToChangeNRITPEDIDOFOSPAI = array();
		$this->itensToChangeQuantity = array();
		$this->itensToChangeOrder = array();
		$this->itensToChangeOrderInRel = array();
		$this->relationsToChange = array();

		return $itemsToDeleteInFront;
	}

	private function checkIfSameProduct($currentParentRelation, $itensAlreadyUpdated) {
		foreach ($itensAlreadyUpdated as $currentItem) {
			if (($currentItem['oldCDFILIAL'] == $currentParentRelation['CDFILIALPAI']) &&
				($currentItem['oldNRPEDIDOFOS'] == $currentParentRelation['NRPEDIDOFOSPAI']) &&
			    ($currentItem['oldNRITPEDIDOFOS'] == $currentParentRelation['NRITPEDIDOFOSPAI'])) {
				return $currentItem;
			}
		}
		return array();
	}

}