<?php
namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class Order {


	const REQUIRED_FIELDS = [
		'CHAVE', // Chave unica do pedido a ser gerado.  VE.CDFILIAL + VE.CDCAIXA + VE.NRSEQVENDA  se for venda, VE.CDFILIAL + IT.NRSEQPRODCUP se for pedido
		'VENDA', // Identificador de onde veio a venda. 'ODHENAPI' caso gerado pela api, VENDA caso balcão, COMANDA caso pedido
		'CDFILIAL', // Filial relacionada ao item
		'DATA', // Data do pedido. "agora" geralmente
		'NOW', // Agora, mesmo
		'CDPRODUTO', // Codigo do produto
		'QTDEPROD', // Quantidade
		'CDLOJA', // Codigo da loja do pedido
		'CDSENHAPED', // Codigo do pedido na tela do kds.
		'CHAVEITEM' // Chave unica do item a ser inserido. IT.CDFILIAL + IT.CDCAIXA + IT.NRSEQVENDA + IT.NRSEQUITVEND caso venda,IT.CDFILIAL + IT.NRVENDAREST + IT.NRCOMANDA + IT.NRPRODCOMVEN caso pedido

	];

	const TP_VENDA  = [
		'CDCAIXA',
		'NRSEQVENDA',
		'NRSEQUITVEND'];

	const TP_BALCAO = [
		'NRCOMANDA',
		'NRVENDAREST',
		'NRPRODCOMVEN'];

	private function validRequiredFields($fields, $requiredFields){
		for($i=0;count($requiredFields);$i++){
			$requiredField = $requiredFields[$i];
			if(!array_key_exists($requiredField , $fields) || !isset($fields[$requiredField])){
				throw new \Exception("O parametro {$requiredField} e obrigatorio.");
			}
		}
	}

    private function prepareOrder(){
		$dateTime = new \DateTime();
		for($i=0;$i<count($this->items);$i++){

			$item = $this->items[$i];

			if($item['VENDA'] == 'VENDA'){
				$requiredFields = array_merge(self::TP_BALCAO,self::REQUIRED_FIELDS);
				$this->validRequiredFields($item, $requiredFields);
			}else{
				$requiredFields = array_merge(self::TP_VENDA,self::REQUIRED_FIELDS);
				$this->validRequiredFields($item, $requiredFields);
			}


			$item['IDORIPED'] = 'K';
			$item['NRPEDIDOFOS'] = null;
			$item['NRITPEDIDOFOS'] = null;

			//
			$itemDate = $dateTime->createFromFormat('H:i:s d/m/Y', $item['DATA']);
			$item['DATA'] = $itemDate->format('c');
			$item['DATA'] = substr($item['DATA'], 0, -6);

			//
			$now = $data->createFromFormat('H:i:s d/m/Y', $item['NOW']);
			$item['NOW'] = $now->format('H:i:s m/d/Y');


			//var_dump(0);die;

			//to be continued
		}
    }

	/**
     * Respond 200 OK with an optional
     * This is used to return an acknowledgement response indicating that the request has been accepted and then the script can continue processing
     *
     * @param null $text
     */
    private function respondOK($text = null){
        if (is_callable('fastcgi_finish_request')){
            if ($text !== null) {
                echo $text;
            }
            session_write_close();
            fastcgi_finish_request();
            return;
        }
        ignore_user_abort(true);
        ob_start();
        if ($text !== null){
            echo $text;
        }
        $serverProtocol = filter_input(INPUT_SERVER, 'SERVER_PROTOCOL', FILTER_SANITIZE_STRING);
        header($serverProtocol . ' 200 OK');
        header('Content-Encoding: none');
        header('Content-Length: ' . ob_get_length());
        header('Connection: close');
        ob_end_flush();
        ob_flush();
        flush();
    }

	public function newOrder ($req, $res){
		try {
			//$this->respondOK();
			$this->items = array($req->getParameters());
			$this->prepareOrder();
		} catch(\Exception $e){
			$data = ["error" => "true", "message" => $e->getMessage()];
			//var_dump($data);
		}
	}

	public function transferOrder ($req, $res) {

		try {
			    $this->respondOK();
		} catch(\Exception $e){
			$data = ["error" => "true", "message" => $e->getMessage()];
			echo $data;
		}

	}

	public function cancelOrder ($req, $res) {

		try {
			    $this->respondOK();

		} catch(\Exception $e){
			$data = ["error" => "true", "message" => $e->getMessage()];
			echo $data;
		}

	}

}