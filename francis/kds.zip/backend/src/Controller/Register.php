<?php
namespace Controller;

use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource\DataSet;
use Zeedhi\Framework\DTO\Response\Message;

class Register extends \Zeedhi\Framework\Controller\Simple {

	protected $registerService;

	public function __construct(\Service\Register $registerService, \Service\Branch $branchService, \Service\Sector $sectorService, \Service\KDSManager $KDSManagerService, \Util\KDSMessage  $KDSMessage, \Util\Util $util) {
		$this->registerService = $registerService;
		$this->branchService = $branchService;
		$this->sectorService = $sectorService;
		$this->KDSManagerService = $KDSManagerService;
		$this->KDSMessage = $KDSMessage;
		$this->util = $util;
	}

	const DIRECTORY = __DIR__."\\..\\..\\sounds";

	public function getControlParameters(Request\Row $request, Response $response) {
		try {
			$row = $request->getRow();
			$caixa = $this->registerService->getControlRegister($row['CDSETOR']);
			$filial = $this->branchService->getBranch();

			if(!isset($caixa)){
				$response->addMessage(new Message($this->KDSMessage->getMessage(4)));
			} else {
				$parameters = $this->sectorService->getSetorParameters($filial['CDFILIAL'], $row['CDSETOR']);
				$parameters['CDFILIAL'] = $filial['CDFILIAL'];
				$parameters['CDCAIXA'] = $caixa['CDCAIXA'];

				//@TODO fazer uma função que de alguma forma faça isso e retorne o SOMBEEP
				// salvando o beep no servidor caso não exista
				//$soundDirectory = str_replace('\\', "\\", self::DIRECTORY);
				if (!empty($parameters["NMARQUIVO"])){
		            if(!file_exists(self::DIRECTORY)){
		                $this->util->directoryCheck(self::DIRECTORY);
		            }
					$soundDirectory = realpath(self::DIRECTORY);
		            $pathArquivo = $soundDirectory.'\\'.$parameters["CDARQUIVO"].$parameters["NMARQUIVO"];
		            if(!file_exists($pathArquivo)){
			            $SOMBEEP = array(
				            'b64File' => (string)$parameters["ARQUIVO"],
							'name' => $parameters["NMARQUIVO"],
							'size' => '1'
			            );
		            	$file = $this->util->factoryFromFileData($SOMBEEP, $soundDirectory, $parameters["CDARQUIVO"]);
		            }
		            $pathArquivo = str_replace('\\', "/", $pathArquivo);
		            $parameters['SOMBEEP'] = $pathArquivo;
				} else {
					$parameters['SOMBEEP'] = null;
				}
				if($parameters["IDTIPOSETOR"] == 'E'){
					if (!empty($parameters["NMARQUIVOEXP"])){
			            if(!file_exists(self::DIRECTORY)){
			                $this->util->directoryCheck(self::DIRECTORY);
			            }
						$soundDirectory = realpath(self::DIRECTORY);
			            $pathArquivo = $soundDirectory.'\\'.$parameters["CDARQUIVOBEEPEXP"].$parameters["NMARQUIVOEXP"];
			            if(!file_exists($pathArquivo)){
				            $SOMBEEP = array(
					            'b64File' => (string)$parameters["ARQUIVOEXP"],
								'name' => $parameters["NMARQUIVOEXP"],
								'size' => '1'
				            );
			            	$file = $this->util->factoryFromFileData($SOMBEEP, $soundDirectory, $parameters["CDARQUIVOBEEPEXP"]);
			            }
			            $pathArquivo = str_replace('\\', "/", $pathArquivo);
			            $parameters['SOMBEEPEXP'] = $pathArquivo;
					} else {
						$parameters['SOMBEEPEXP'] = null;
					}
				}

				// Insert key mapping here
				$mappedKeys = $this->KDSManagerService->getMappedKeys();
				$_mappedKeys = array();
				foreach ($mappedKeys as $index => $mappedKey) {
					switch ($mappedKey['IDFUNCAO']) {
						case '1':
							$_mappedKeys[$index]['name'] = "up";
							break;
						case '2':
							$_mappedKeys[$index]['name'] = "down";
							break;
						case '3':
							$_mappedKeys[$index]['name'] = "left";
							break;
						case '4':
							$_mappedKeys[$index]['name'] = "right";
							break;
						case '5':
							$_mappedKeys[$index]['name'] = "enter";
							break;
						case '6':
							$_mappedKeys[$index]['name'] = "backspace";
							break;
						case '7':
							$_mappedKeys[$index]['name'] = "zoom";
							break;
						case '8':
							$_mappedKeys[$index]['name'] = "reload";
							break;
					}
					$_mappedKeys[$index]['keyCode'] = $mappedKey['IDKEY'];
				}
				$parameters['keyMapping'] = $_mappedKeys;

				if (count($parameters) > 0){
					$response->addDataSet(new DataSet('productionControlParams', array('error' => false, 'productionControlParams'=> $parameters)));
				} else {
					$response->addDataSet(new DataSet('productionControlParams', array('error' => true, 'message'=> $this->KDSMessage->getMessage(6))));
				}
			}
		} catch (\Exception $e) {
			$this->util->logException($e->getMessage());
			$response->addDataSet(new DataSet('productionControlParams', array('error' => true, 'message'=> $e->getMessage())));
	    }
	}

}