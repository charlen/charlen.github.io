<?php
namespace Controller;

use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource\DataSet;

class Sector extends \Zeedhi\Framework\Controller\Simple {

	protected $sectorService;

	public function __construct(\Service\Sector $sectorService) {
		$this->sectorService = $sectorService;
	}	

	public function getSectors(Request $request, Response $response){
		try {
			$sectors = $this->sectorService->getSectors();
			if(empty($sectors)) {
				throw new \Exception('Não existem setores cadastrados.');
			} else {
			 	$response->addDataSet(new DataSet('sectors', array('success' => true, 'sectors'=> $sectors)));
			}
		} catch (\Exception $e) {
			$response->addDataSet(new DataSet('sectors', array('error' => true, 'message'=>$e->getMessage())));
		}
	}
	
}