<?php

namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\HTTP\Kernel;
use Zeedhi\Framework\DataSource\DataSet;
use Util\ElapsedTime;

class KDSManager extends \Zeedhi\Framework\Controller\Simple {
	const ERROR_MESSAGE = 'E';
	const SUCCESS_MESSAGE = 'S';


	protected $KDSMessage;
	protected $util;
	protected $KDSManagerService;
	protected $entityManager;
	protected $production;
	private $productionItemProcessed = Array();
	private $itemsForInsertion = array();
	private $itemsToHandleComposition = array();
	private $itemsRelations = array();
	private $itemsToFindMainParent = array();
	private $itemsToUpdateToReleased = array();

 	public function __construct(\Util\KDSMessage $KDSMessage,
 	                            \Util\Util $util,
 	                            \Service\KDSManager $KDSManagerService,
 	                            \Doctrine\ORM\EntityManager $entityManager,
 	                            \Controller\Production $production) {

		$this->KDSMessage        = $KDSMessage;
		$this->util              = $util;
		$this->KDSManagerService = $KDSManagerService;
		$this->entityManager 	 = $entityManager;
		$this->production        = $production;
	}

	public function handleProductsForDisplay($productsToDisplay) {
		// ordena array por CHAVEPEDIDO
		$orderedArray = $this->orderArrayByOrderKey($productsToDisplay);

		// para cada CHAVEPEDIDO, passar os itens desse pedido para outra funcao
		// separa os pedidos, chama a função uma vez por pedido
		$currentOrder = null;
		$lastOrder = null;
		$arrayForTimers = array();
		$idx = 0;
		while ($idx < sizeof($orderedArray)) {
			$item = $orderedArray[$idx];
			$currentOrder = $item['CHAVEPEDIDO'];
			if (($currentOrder != $lastOrder) && ($lastOrder != null)) {
				// trocou de pedido, define os timers do pedido atual

				$this->handleOrderTimers($arrayForTimers);
				$arrayForTimers = array();
			}
			array_push($arrayForTimers, $item);
			$lastOrder = $currentOrder;

			// trata último item
			if ($idx == sizeof($orderedArray) -1) {
				$this->handleOrderTimers($arrayForTimers);
			}

			$idx++;
		}
	}

	private function handleOrderTimers($arrayForInsertion) {
		// remove tempo de produção dos items da montagem e expedição
		$arrayForInsertion = $this->removeProductionTimeFromProducts($arrayForInsertion);
		// ordena array por tempo de produção
		$arrayForInsertion = $this->orderArrayByProductionTime($arrayForInsertion);
		// define os tempos de exibição de cada produto
		$arrayForInsertion = $this->defineOrderTimers($arrayForInsertion);
		// insere na ITPEDIDOFOS
		$this->handleProductsInsertion($arrayForInsertion);
	}

	private function removeProductionTimeFromProducts($arrayForInsertion) {
		foreach ($arrayForInsertion as &$currentItem) {
			if ($currentItem['IDTIPOSETOR'] != 'P') {
				$currentItem['NRTEMPOPROD'] = '0';
				$currentItem['NRTEMPOEXIB'] = '0';
			}
		}
		return $arrayForInsertion;
	}

	private function handleProductsInsertion($arrayForInsertion){
		foreach ($arrayForInsertion as $product) {
			$this->KDSManagerService->insertOrderItem(
				$product['CDFILIAL'],
				$product['NRPEDIDOFOS'],
				$product['NRITPEDIDOFOS'],
				$product['CDPRODUTO'],
				$product['QTPRODPEFOS'],
				$product['CDCAIXA'],
				$product['NRSEQVENDA'],
				$product['NRSEQUITVEND'],
				$product['NRVENDAREST'],
				$product['NRCOMANDA'],
				$product['NRPRODCOMVEN'],
				$product['TXPRODPED'],
				$product['IDSITITPEDFOS'],
				$product['CDSETOR'],
				$product['CDGRPOCOR'],
				$product['CDOCORR'],
				$product['DTHREXIBICAOPROD'],
				$product['DSCHAVEPEDPAI'],
				$product['CDPRODUTOPAI'],
				$product['CDPRODPROMOKDS'],
				$product['NRSEQPRODCOMKDS'],
				$product['NRTEMPOPROD'],
				$product['NRTEMPOEXIB'],
				$product['NRATRAPROD'],
				$product['NRLUGARMESAIT'],
				isset($product['IDLIBERADO']) ? $product['IDLIBERADO'] : 'N',
				$product['NRMAIORTEMPO'],
				$product['IDORIGEMVENDA']
			);
			// insere o relacionamento com a ITCOMANDAVEN (IDPEDIDOFOSREL)
			foreach ($product['RELITCOMANDAVEN'] as $currentRel) {
				$NRSEQITPEDREL = $this->generateNewNRSEQITPEDREL($product['CDFILIAL'], $product['NRPEDIDOFOS'], $product['NRITPEDIDOFOS']);
				$this->KDSManagerService->insertOrderRelation(
					$product['CDFILIAL'],
					$product['NRPEDIDOFOS'],
					$product['NRITPEDIDOFOS'],
					$NRSEQITPEDREL,
					$currentRel['NRVENDAREST'],
					$currentRel['NRCOMANDA'],
					$currentRel['NRPRODCOMVEN'],
					$currentRel['QTPRODPEFOS'],
					$currentRel['IDSITITPEDFOS']
				);
			}
		}
	}

	private function defineOrderTimers($products){
		$arrayForInsertion = array();
		$delayedItems = array();
		$biggestTime = 0;
		$interval = new \DateInterval('PT0S'); // cria intevalo de 0 segundos
		$delay = 'first';
		foreach ($products as $product) {
			if (empty($product['NRATRAPROD'])) {
				//coloca que já está liberado.
				$product['IDLIBERADO'] = 'S';

				if ($delay === 'first') {
					$delay = 0;
					$biggestTime = $product['NRTEMPOPROD'];
				} else {
					$delay = $biggestTime - $product['NRTEMPOPROD'];
					$interval = new \DateInterval('PT' . $delay . 'S'); // cria intevalo de $interval segundos
				}
				if ($product['NRTEMPOPROD'] == 0) {
					$product['NRTEMPOPROD'] = $biggestTime;
					$interval = new \DateInterval('PT0S');
				}
	    		$DTHREXIBICAOPROD = new \Datetime($product['DTPEDIDOFOS'], new \DateTimeZone(date_default_timezone_get()));
	    		$DTHREXIBICAOPROD = $DTHREXIBICAOPROD->add($interval);
				$DTHREXIBICAOPROD = $DTHREXIBICAOPROD->format('d/m/Y H:i:s');
				$product['DTHREXIBICAOPROD'] = $DTHREXIBICAOPROD;
				$product['NRMAIORTEMPO'] = null;

				// coloca no formato JSON pra mandar pro frontend
				if (!empty($product['TXPRODPED'])) {
					$product['TXPRODPED'] = json_encode($product['TXPRODPED']);
				}

				// expedição e montagem a hora de exibição é sempre a hora do pedido
				if ($product['IDTIPOSETOR'] != 'P') {
					$product['DTHREXIBICAOPROD'] = new \Datetime($product['DTPEDIDOFOS'], new \DateTimeZone(date_default_timezone_get()));
				}

				array_push($arrayForInsertion, $product);
			} else {
				array_push($delayedItems, $product);
			}
		}

		// ordena array por tempo de produção
		$delayedItems = $this->orderArrayByProductionTime($delayedItems);

		// variável auxiliar usada para armazenar o tempo do item mais demorado entre os itens com atraso
		$biggestTime = 0;
		$delay = 'first';
		foreach ($delayedItems as $currentItem) {

			if ($delay === 'first') {
				$delay = 0;
				$biggestTime = $currentItem['NRTEMPOPROD'];
				$interval = new \DateInterval('PT0S');
			} else {
				$delay = $biggestTime - $currentItem['NRTEMPOPROD'];
				$interval = new \DateInterval('PT' . $delay . 'S'); // cria intevalo de $interval segundos
			}
			if ($currentItem['NRTEMPOPROD'] == 0) {
				$currentItem['NRTEMPOPROD'] = $biggestTime;
				$interval = new \DateInterval('PT0S');
			}

			$currentItem['NRMAIORTEMPO'] = $delay;
			//Coloca que está em espera.
			$currentItem['IDLIBERADO'] = 'N';

			// calcula tempo de atraso do item
			// será: maior tempo + tempo de atraso - tempo de produção
			// para que o item fique pronto X minutos de atraso depois do maior item do pedido
			// exemplo: pedi dois itens, coloquei atraso de 5 minutos no segundo,
			// produto 1 fica pronto 18:00, produto 2 fica pronto 18:05
			//$delay = ($currentItem['NRATRAPROD'] * 60 - $biggestTime) + ($biggestTime - $currentItem['NRTEMPOPROD']);
			// trata observação do atraso
			$obsAtraso = 'SEGURA DE ' . (string)$currentItem['NRATRAPROD'] . ' MINUTO';
			if ($currentItem['NRATRAPROD'] > 1) {
				$obsAtraso = $obsAtraso . 'S';
			}
			if (empty($currentItem['TXPRODPED'])) {
				$currentItem['TXPRODPED'] = array();
			}
			array_push($currentItem['TXPRODPED'], array(
				'OBSERVACAO' => $obsAtraso,
				'NRCORSINAL' => 'FFFFFF',
				'TIPO' => 'ATRASO'
			));
			// coloca no formato JSON pra mandar pro frontend
			$currentItem['TXPRODPED'] = json_encode($currentItem['TXPRODPED']);

			$DTHREXIBICAOPROD = new \Datetime($currentItem['DTPEDIDOFOS'], new \DateTimeZone(date_default_timezone_get()));
    		$DTHREXIBICAOPROD = $DTHREXIBICAOPROD->add($interval);
    		$DTHREXIBICAOPROD = $DTHREXIBICAOPROD->add( new \DateInterval('PT'.$currentItem['NRATRAPROD'].'M'));
			$DTHREXIBICAOPROD = $DTHREXIBICAOPROD->format('d/m/Y H:i:s');

			$currentItem['DTHREXIBICAOPROD'] = $DTHREXIBICAOPROD;
			// if (($biggestTime != $currentItem['NRTEMPOPROD']) && ($currentItem['IDTIPOSETOR'] == 'P')) {
			// 	$currentItem['NRMAIORTEMPO'] = $biggestTime - $currentItem['NRTEMPOPROD'];
			// } else {
			// 	$currentItem['NRMAIORTEMPO'] = null;
			// }

			// expedição e montagem a hora de exibição é sempre a hora do pedido
			$currentItem['NRATRAPROD'] = $currentItem['NRATRAPROD'] * 60;

			array_push($arrayForInsertion, $currentItem);
		}

		return $arrayForInsertion;
	}

	private function compareProductionTime($a, $b) {
		return strnatcmp((string)$b['NRTEMPOPROD'], (string)$a['NRTEMPOPROD']);
	}

	private function orderArrayByProductionTime($order) {
		// sort alphabetically by name
		usort($order, array($this, 'compareProductionTime'));
		return $order;
	}

	private function compareOrderKey($a, $b) {
		return strnatcmp($a['CHAVEPEDIDO'], $b['CHAVEPEDIDO']);
	}

	private function orderArrayByOrderKey($arrayToOrder) {
		// sort alphabetically by name
		usort($arrayToOrder, array($this, 'compareOrderKey'));
		return $arrayToOrder;
	}

	private function validateProduct($CDPRODUTO) {
		$product = $this->KDSManagerService->getProductByCode($CDPRODUTO);
		if (empty($product)) {
			$retorno = false;
			$this->util->logException('Produto' . $CDPRODUTO . ' não encontrado na tabela de produtos.');
		} else {
			$retorno = true;
		}
		return $retorno;
	}

	public function pedidoFosGenerator($newOrders) {
		$this->itemsForInsertion = array();
		$this->itemsToHandleComposition = array();
		$this->itemsRelations = array();
		$this->productionItemProcessed = array();

		if (count($newOrders) > 0) {
	    	foreach ($newOrders as $item) {
	    		// pega o item atual, verifica se é promoção inteligente
				if ($item['VENDA'] == 'VENDA') {
					// venda balcão
					$productsPromotion = $this->KDSManagerService->getProductPromoVenda($item['CDFILIAL'], $item['CDCAIXA'], $item['NRSEQVENDA'], $item['NRSEQUITVEND']);
				} else {
					// venda mesa, comanda e delivery
					$productsPromotion = $this->KDSManagerService->getProductPromoComanda($item['CDFILIAL'], $item['NRCOMANDA'], $item['NRPRODCOMVEN'], $item['NRVENDAREST']);
				}

				if (!empty($productsPromotion)) {
					foreach ($productsPromotion as $currentProduct) {
						$newItem = $item;

						// parâmetros promoção inteligente
						$newItem['CDPRODPROMOKDS'] = $item['CDPRODUTO'];
						$newItem['NRSEQPRODCOMKDS'] = $item['NRSEQPRODCOM'];
						$newItem['NRATRAPROD'] = $item['NRATRAPROD'];

						$newItem['CDPRODUTO'] = $currentProduct['CDPRODUTO'];
						$newItem['QTDEPROD'] = $currentProduct['QUANTIDADE'];
						$newItem['OBSDIGITADA'] = $currentProduct['OBSDIGITADA'];
						$newItem['CHAVEITEM'] = $currentProduct['CHAVEITEM'];
						//CHAVEITEM será usada nas querys de buscar observação.
						//seria tolice checar qual chave esta sendo usada toda vez, pois tem 4 possibilidades e teria que passar todas no item.						
						$this->handleSector($newItem);
					}
				} else {
					$item['CDPRODPROMOKDS'] = $item['CDPRODPROMOCAO'];
					$item['NRSEQPRODCOMKDS'] = $item['NRSEQPRODCOM'];
					//CHAVEITEM será usada nas querys de buscar observação.
					//seria tolice checar qual chave esta sendo usada toda vez, pois tem 4 possibilidades e teria que passar todas no item.
					$this->handleSector($item);
				}
			}

			// inserindo os itens da composição do produto de venda no array de itens
    		$this->handleComposition($this->itemsToHandleComposition);

    		// insere no banco os itens da ITPEDIDOFOSPAI
    		$this->insertProductsRelations($this->itemsRelations);

	    	return $this->itemsForInsertion;
        }
    }

    private function insertProductsRelations($itemsRelations) {
    	foreach ($itemsRelations as $currentRelation) {
    		$this->KDSManagerService->insertRelation(
    			$currentRelation['CDFILIAL'],
    			$currentRelation['NRPEDIDOFOS'],
    			$currentRelation['NRITPEDIDOFOS'],
    			$currentRelation['NRSEQITPEDPAI'],
    			$currentRelation['CDFILIALPAI'],
    			$currentRelation['NRPEDIDOFOSPAI'],
    			$currentRelation['NRITPEDIDOFOSPAI']
    		);
    	}
    }

	private function handleSector($item) {
		// busca se item está no setor expedição (se estiver, deve ser pai do resto)
		$itemExpedition = $this->KDSManagerService->getProductSectorByType($item['CDPRODUTO'], $item['CDFILIAL'], $item['CDLOJA'], 'E');
		foreach ($itemExpedition as $currentSector) {
			$this->handleItem($item, $currentSector['CDSETOR'], $currentSector['IDTIPOSETOR'], null, $currentSector['NRTEMPOPROD'], 'EXPEDICAO', null, $currentSector['NRTEMPOEXIB'], $currentSector['NRCORVGM']);
		}

		if (empty($itemExpedition)) {
			// busca se item está no setor montagem (se estiver, deve ser pai do resto (junto com expedição))
			$itemMontagem = $this->KDSManagerService->getProductSectorByType($item['CDPRODUTO'], $item['CDFILIAL'], $item['CDLOJA'], 'M');
			foreach ($itemMontagem as $currentSector) {
				$this->handleItem($item, $currentSector['CDSETOR'], $currentSector['IDTIPOSETOR'], null, $currentSector['NRTEMPOPROD'], 'MONTAGEM', null, $currentSector['NRTEMPOEXIB'], $currentSector['NRCORVGM']);
			}

			if (empty($itemMontagem)) {
				if(!in_array($item['CHAVEITEM'], $this->productionItemProcessed)){
					array_push($this->productionItemProcessed, $item['CHAVEITEM']);

					// busca se produto está no setor produção se ainda não foi processado
					$itemProduction = $this->KDSManagerService->getProductSectorByType($item['CDPRODUTO'], $item['CDFILIAL'], $item['CDLOJA'], 'P');
					foreach ($itemProduction as $currentSector) {
						$this->handleItem($item, $currentSector['CDSETOR'], $currentSector['IDTIPOSETOR'], null, $currentSector['NRTEMPOPROD'], 'PRODUCAO', null, $currentSector['NRTEMPOEXIB'], $currentSector['NRCORVGM']);
					}
				}
			}
		}
		if(empty($itemExpedition) && empty($itemMontagem) && empty($itemProduction)){
			// da update no item na venda para avisar que já foi tratado pelo KDS
			$NRPEDIDOFOS = 'NPRODUZIDO';
			if(isset($item['CDFILIAL'], $item['NRVENDAREST'], $item['NRCOMANDA'], $item['NRPRODCOMVEN'])){
				$this->KDSManagerService->updateSaleMesa($NRPEDIDOFOS, $item['CDFILIAL'], $item['NRVENDAREST'], $item['NRCOMANDA'], $item['NRPRODCOMVEN']);
			}
			if(isset($item['CDFILIAL'], $item['CDCAIXA'], $item['NRSEQVENDA'], $item['NRSEQUITVEND'])){
				$this->KDSManagerService->updateSaleVenda($NRPEDIDOFOS, $item['CDFILIAL'], $item['CDCAIXA'], $item['NRSEQVENDA'], $item['NRSEQUITVEND']);
			}
		}
	}

    private function handleItem($item, $CDSETOR, $IDTIPOSETOR, $DSCHAVEPEDPAI, $NRTEMPOPROD, $TIPOSETOR, $arrayDadosPaiExpedicao, $NRTEMPOEXIB, $NRCORVGM) {
		// preparing order params to insertion
    	$CDFILIAL = $item['CDFILIAL'];
    	$CDLOJA = $item['CDLOJA'];
		$DSPEDIDOFOS = $item['CHAVE'];
    	$DSCHAVEPEDFOS = $item['CHAVE'];
    	$DTPEDIDOFOS = $item['DATA'];
		$IDSTATUSPEDFOS = '1';
		$IDATIVO = 'S';
		$DSTIPOPEDFOS = $item['VENDA'];
		$NRMESA = $item['NRMESA'];
		$NRCOMANDA = $item['NRCOMANDA'];
		$DSCOMANDA = $item['DSCOMANDA'];
		$QTMAXPEDFOS = null;
		$CDSENHAPED = $item['CDSENHAPED'];
		$NMCONSUMIDOR = $item['NMCONSUMIDOR'];
		$CDGRPOCOR = $item['CDGRPOCOR'];
		$CDOCORR = $item['CDOCORR'];
		$OBSDIGITADA = $item['OBSDIGITADA'];
		$DTHREXIBICAOPROD = new \Datetime($item['NOW'], new \DateTimeZone(date_default_timezone_get()));
		if (($item['NRATRAPROD']== 0)) {
			$CHAVEPEDIDO = $item['CHAVE'];
			$NRATRAPROD = null;
		} else {
			$CHAVEPEDIDO = $item['CHAVE'] . $item['NRATRAPROD'];
			$NRATRAPROD = $item['NRATRAPROD'];
		}
		$NRLUGARMESAIT = intval($item['NRLUGARMESA']);
		$IDORIGEMVENDA = $item['IDORIGEMVENDA'];
		$IDITORIGEMVENDA = $item['IDITORIGEMVENDA'];

		// preparing order item params to insertion
		$CDPRODUTO = $item['CDPRODUTO'];
		$QTPRODPEFOS = $item['QTDEPROD'];
		$CDCAIXA = $item['CDCAIXA'];
		$NRSEQVENDA = $item['NRSEQVENDA'];
		$NRSEQUITVEND = $item['NRSEQUITVEND'];
		$NRVENDAREST = $item['NRVENDAREST'];
		$NRCOMANDA = $item['NRCOMANDA'];
		$NRPRODCOMVEN = $item['NRPRODCOMVEN'];
		$IDSITITPEDFOS = 'E'; // 'E' -> não inicializado

		// caso seja promoção inteligente
		$CDPRODPROMOKDS = $item['CDPRODPROMOKDS'];
		$NRSEQPRODCOMKDS = $item['NRSEQPRODCOMKDS'];
		$CHAVEITEM = $item['CHAVEITEM'];
		$IDITORIGEMVENDA = $item['IDITORIGEMVENDA'];

		// confere se o pedido já existe
		// irá entrar aqui se o pedido vier do FOS pois a chave é diferente
		$chave = $this->KDSManagerService->checkOrderExistence($item['CHAVE']);
		if (empty($chave)) {
			// se o pedido veio do FOS
			if ($item['IDORIPED'] === 'F') {
				$this->KDSManagerService->deleteItemPedidofos($CDFILIAL, $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);
				$this->KDSManagerService->deletePedidofos($CDFILIAL, $item['NRPEDIDOFOS']);
			}
			// se o pedido ainda não existir, insere na PEDIDOFOS
			$this->util->newCode('PEDIDOFOS' . $CDFILIAL);
			$NRPEDIDOFOS = $this->KDSManagerService->getNewCode('PEDIDOFOS' . $CDFILIAL);
			$NRPEDIDOFOS = $NRPEDIDOFOS[0]['NRSEQUENCIAL'];
			$NRPEDIDOFOS = substr($NRPEDIDOFOS, -10);
			$NRPEDIDOFOSMSDE = $NRPEDIDOFOS;
			$NRPEDIDOFOSAUX = $NRPEDIDOFOS;
			// insere o pedido
			$this->KDSManagerService->insertOrder($CDFILIAL, $NRPEDIDOFOS, $DSPEDIDOFOS, $DSCHAVEPEDFOS,
		 										  $DTPEDIDOFOS, $IDSTATUSPEDFOS, $DSTIPOPEDFOS, $NRMESA,
		 										  $NRCOMANDA, $DSCOMANDA, $QTMAXPEDFOS, $CDSETOR,
		 										  $NRPEDIDOFOSAUX, $CDLOJA, $CDSENHAPED, $NRPEDIDOFOSMSDE,
		 										  $NMCONSUMIDOR, $IDATIVO);
		} else {
			// se o pedido já existir, insere somente na ITPEDIDOFOS
			// se esse pedido veio do FOS, apaga ele e recria
    		if ($item['IDORIPED'] === 'F') {
    			$this->KDSManagerService->deleteItemPedidofos($CDFILIAL, $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);
				$item['QUANTIDADE'] = $item['QTDEPROD'];
				$productsPromoction = array();
				array_push($productsPromoction, $item);
    		}
			$NRPEDIDOFOS = $chave[0]['NRPEDIDOFOS'];
			$NRPEDIDOFOSMSDE = $NRPEDIDOFOS;
			$NRPEDIDOFOSAUX = $NRPEDIDOFOS;
		}

		$NRITPEDIDOFOS = $this->generateNewNRITPEDIDOFOS($CDFILIAL, $NRPEDIDOFOS);

		// insere o relacionamento do item atual com o item pai na expedição (junior na montagem por exemplo)
		if (!empty($arrayDadosPaiExpedicao)) {
			$NRSEQITPEDPAI = $this->generateNewNRSEQITPEDPAI($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS);
			array_push($this->itemsRelations, array(
				'CDFILIAL'         => $CDFILIAL,
				'NRPEDIDOFOS'      => $NRPEDIDOFOS,
				'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
				'NRSEQITPEDPAI'    => $NRSEQITPEDPAI,
				'CDFILIALPAI'      => $arrayDadosPaiExpedicao['CDFILIAL'],
				'NRPEDIDOFOSPAI'   => $arrayDadosPaiExpedicao['NRPEDIDOFOS'],
				'NRITPEDIDOFOSPAI' => $arrayDadosPaiExpedicao['NRITPEDIDOFOS']
			));
		}

		// monta dados do produto pai
		$DSCHAVEPEDPAI = $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS;
		$arrayDadosPaiExpedicao = array(
			'CDFILIAL' => $CDFILIAL,
			'NRPEDIDOFOS' => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);

		// busca se há alguma observação pré cadastrada pro item
		$observacoes = $this->KDSManagerService->getAllItemObservations($CHAVEITEM);
		if (!empty($observacoes)) {
			// define quais observações irão aparecer pra esse item
			// busca as observações cadastradas na SETORPRODOBS
			$todasObsSetorProduto = $this->KDSManagerService->getSetorProdutoObservations($CDSETOR, $CDPRODUTO);
			if (!empty($todasObsSetorProduto)) {
				// se possui algo na SETORPRODOBS para esse produto neste setor, busca as observações que são compatíveis
				$observacoes = $this->KDSManagerService->getItemObservationsBySetorProduto($CHAVEITEM, $CDSETOR, $CDPRODUTO);
			} /*else {
				// se esse produto não tiver nenhum registro na SETORPRODOBS (pra este setor),
				// mostra todas as observações do item
			}*/
		}

		// constrói array de observações para este item
		if(isset($item['TXPRODPED'])){
			try{
				$TXPRODPED = json_decode($item['TXPRODPED'], TRUE);
			}catch(\Exception $e){

			}
		}else{
			$TXPRODPED = null;
		}
		if (!empty($observacoes)) {
			$TXPRODPED = array();
			foreach ($observacoes as $observacao) {
				array_push($TXPRODPED, array(
					'OBSERVACAO' => $observacao['OBSERVACAO'],
					'NRCORSINAL' => $observacao['NRCORSINAL']
				));
				$NRTEMPOPROD = intval($NRTEMPOPROD) + intval($observacao['NRTEMPOPROD']);
				$NRTEMPOEXIB = intval($NRTEMPOEXIB) + intval($observacao['NRTEMPOPROD']);
			}
			// converte pra string senão da pau no cálculo dos tempos
			$NRTEMPOPROD = (string)$NRTEMPOPROD;
			$NRTEMPOEXIB = (string)$NRTEMPOEXIB;
			if (!empty($OBSDIGITADA)) {
				try{
					$digitada = json_decode($OBSDIGITADA, TRUE);
					if(!empty($digitada)){
						array_push($TXPRODPED, $digitada);
					}else{
						array_push($TXPRODPED, array(
							'OBSERVACAO' => $OBSDIGITADA,
							'NRCORSINAL' => 'FFFFFF'
						));	
					}
				}catch(\Exception $e){
					array_push($TXPRODPED, array(
						'OBSERVACAO' => $OBSDIGITADA,
						'NRCORSINAL' => 'FFFFFF'
					));
				}
			}
		} else if (!empty($OBSDIGITADA)) {
			$TXPRODPED = array();
			if (!empty($OBSDIGITADA)) {
				try{
					$digitada = json_decode($OBSDIGITADA, TRUE);
					if(!empty($digitada)){
						array_push($TXPRODPED, $digitada);
					}else{
						array_push($TXPRODPED, array(
							'OBSERVACAO' => $OBSDIGITADA,
							'NRCORSINAL' => 'FFFFFF'
						));	
					}
				}catch(\Exception $e){
					array_push($TXPRODPED, array(
						'OBSERVACAO' => $OBSDIGITADA,
						'NRCORSINAL' => 'FFFFFF'
					));
				}
			}
		}

		//Nova implementação para viagem
		if(!is_null($IDITORIGEMVENDA)){
			if(!isset($TXPRODPED)){
				$TXPRODPED = Array();
			}
			$has = false;
			foreach($TXPRODPED as $key => $value){
				if(strpos('  '.$value['OBSERVACAO'], 'VIAGEM') != ''){
					//REMOVE OBSERVAÇÃO;
					$TXPRODPED[$key]['NRCORSINAL'] = $NRCORVGM;
					$has = true;
			 	}
			}

			if($has == false){
				array_push($TXPRODPED, array(
					'OBSERVACAO' => 'VIAGEM',
					'NRCORSINAL' => $NRCORVGM
				));
			}
		}
		
		// cria array para relacionamento de um item (não composição) com seu item de venda (ITCOMANDAVEN)
		// relacionamento tabela ITPEDIDOFOSREL
		$RELITCOMANDAVEN = array();
		if (($DSTIPOPEDFOS == 'COMANDA') || ($DSTIPOPEDFOS == 'MESA')) {
			// se for venda balcão, esse relacionamento não existe
			array_push($RELITCOMANDAVEN, array(
				'NRVENDAREST'   => $NRVENDAREST,
				'NRCOMANDA'     => $NRCOMANDA,
				'NRPRODCOMVEN'  => $NRPRODCOMVEN,
				'QTPRODPEFOS'   => $QTPRODPEFOS,
				'IDSITITPEDFOS' => $IDSITITPEDFOS
			));
		}



		array_push($this->itemsForInsertion, array(
			'CDFILIAL'         => $CDFILIAL,
			'NRPEDIDOFOS'      => $NRPEDIDOFOS,
			'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
			'CDPRODUTO'        => $CDPRODUTO,
			'QTPRODPEFOS'      => $QTPRODPEFOS,
			'CDCAIXA' 		   => $CDCAIXA,
			'NRSEQVENDA'       => $NRSEQVENDA,
			'NRSEQUITVEND'     => $NRSEQUITVEND,
			'NRVENDAREST'      => $NRVENDAREST,
			'NRCOMANDA'        => $NRCOMANDA,
			'NRPRODCOMVEN'     => $NRPRODCOMVEN,
			'TXPRODPED'        => $TXPRODPED,
			'IDSITITPEDFOS'    => $IDSITITPEDFOS,
			'CDSETOR'          => $CDSETOR,
			'CDGRPOCOR'        => $CDGRPOCOR,
			'CDOCORR'          => $CDOCORR,
			'DTHREXIBICAOPROD' => $DTHREXIBICAOPROD,
			'DSCHAVEPEDPAI'    => $DSCHAVEPEDPAI,
			'CHAVEPEDIDO'      => $CHAVEPEDIDO,
			'DTPEDIDOFOS'      => $DTPEDIDOFOS,
			'CDPRODUTOPAI'     => null,
			'IDTIPOSETOR'      => $IDTIPOSETOR,
			'CDPRODPROMOKDS'   => $CDPRODPROMOKDS,
			'NRSEQPRODCOMKDS'  => $NRSEQPRODCOMKDS,
			'NRTEMPOPROD'      => $NRTEMPOPROD,
			'NRTEMPOEXIB'      => $NRTEMPOEXIB,
			'NRATRAPROD'       => $NRATRAPROD,
			'DSAPELIDOKDS'     => null,
			'RELITCOMANDAVEN'  => $RELITCOMANDAVEN,
			'NRLUGARMESAIT'    => $NRLUGARMESAIT,
			"IDORIGEMVENDA"    => $IDORIGEMVENDA
		));

		// se for modo expedição, chama a handleItem para os filhos da expedição (para o mesmo produto)
		if ($TIPOSETOR == 'EXPEDICAO') {
			// busca se item está no setor montagem (se estiver, deve ser pai do resto (junto com expedição))
			$itemMontagem = $this->KDSManagerService->getProductSectorByType($item['CDPRODUTO'], $item['CDFILIAL'], $item['CDLOJA'], 'M');
			foreach ($itemMontagem as $currentSector) {
				$this->handleItem($item, $currentSector['CDSETOR'], $currentSector['IDTIPOSETOR'], $DSCHAVEPEDPAI, $currentSector['NRTEMPOPROD'], 'MONTAGEM', $arrayDadosPaiExpedicao, $currentSector['NRTEMPOEXIB'], $currentSector['NRCORVGM']);
			}
		}

		if (($TIPOSETOR == 'MONTAGEM') || (empty($itemMontagem) && $TIPOSETOR == 'EXPEDICAO')) {
			// valida se é para buscar a composição deste produto
			$this->validateComposition($CHAVEITEM, $CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS,
	                                   $CDPRODUTO, $TXPRODPED, $QTPRODPEFOS, $CDCAIXA,
	                                   $NRSEQVENDA, $NRSEQUITVEND, $NRVENDAREST, $NRCOMANDA,
	                                   $NRPRODCOMVEN, $IDSITITPEDFOS, $DSCHAVEPEDPAI, $DTPEDIDOFOS,
	                                   $CHAVEPEDIDO, $CDOCORR, $CDGRPOCOR, $NRATRAPROD,
	                                   $DSTIPOPEDFOS, $OBSDIGITADA, $NRLUGARMESAIT, $IDORIGEMVENDA, $IDITORIGEMVENDA);

			if(!in_array($item['CHAVEITEM'], $this->productionItemProcessed)){
				array_push($this->productionItemProcessed, $item['CHAVEITEM']);

				//Busca itens do setor de produção
				$itemProduction = $this->KDSManagerService->getProductSectorByType($item['CDPRODUTO'], $item['CDFILIAL'], $item['CDLOJA'], 'P');
				foreach ($itemProduction as $currentSector) {
					$this->handleItem($item, $currentSector['CDSETOR'], $currentSector['IDTIPOSETOR'], $DSCHAVEPEDPAI, $currentSector['NRTEMPOPROD'], 'PRODUCAO', $arrayDadosPaiExpedicao, $currentSector['NRTEMPOEXIB'], $currentSector['NRCORVGM']);
				}
			}
		}

    	// da update no item na venda para avisar que já foi tratado pelo KDS
		switch ($DSTIPOPEDFOS) {
  			case 'MESA';
			case 'COMANDA';
				$this->KDSManagerService->updateSaleMesa($NRPEDIDOFOS, $CDFILIAL, $NRVENDAREST, $NRCOMANDA, $NRPRODCOMVEN);
			break;
			case 'VENDA';
				$this->KDSManagerService->updateSaleVenda($NRPEDIDOFOS, $CDFILIAL, $CDCAIXA, $NRSEQVENDA, $NRSEQUITVEND);
			break;
		}
    }

    private function validateComposition($CHAVEITEM, $CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS,
                                         $CDPRODUTO, $TXPRODPED, $QTPRODPEFOS, $CDCAIXA,
                                         $NRSEQVENDA, $NRSEQUITVEND, $NRVENDAREST, $NRCOMANDA,
                                         $NRPRODCOMVEN, $IDSITITPEDFOS, $DSCHAVEPEDPAI, $DTPEDIDOFOS,
                                         $CHAVEPEDIDO, $CDOCORR, $CDGRPOCOR, $NRATRAPROD,
                                         $DSTIPOPEDFOS, $OBSDIGITADA, $NRLUGARMESAIT, $IDORIGEMVENDA, $IDITORIGEMVENDA) {
		// valida se o item atual já existe no array para procurar a composição, evita duplicar
		if (!$this->checkInCompositionArray($CHAVEITEM, $this->itemsToHandleComposition)) {

			// relacionamento tabela ITPEDIDOFOSPAI
			$arrayDadosPai = array(
				'CDFILIAL' => $CDFILIAL,
				'NRPEDIDOFOS' => $NRPEDIDOFOS,
				'NRITPEDIDOFOS' => $NRITPEDIDOFOS
			);

			// relacionamento tabela ITPEDIDOFOSREL
			$RELITCOMANDAVEN = array();
			if (($DSTIPOPEDFOS == 'COMANDA') || ($DSTIPOPEDFOS == 'MESA')) {
				// se for venda balcão, esse relacionamento não existe
				array_push($RELITCOMANDAVEN, array(
					'NRVENDAREST' => $NRVENDAREST,
					'NRCOMANDA' => $NRCOMANDA,
					'NRPRODCOMVEN' => $NRPRODCOMVEN,
					'QTPRODPEFOS' => $QTPRODPEFOS,
					'IDSITITPEDFOS' => $IDSITITPEDFOS
				));
			}

			// tenta agrupar os produtos(PAIS) iguais, se não conseguir, coloca um novo item no array de composição
			if (!$this->groupComposition($CDFILIAL, $NRPEDIDOFOS, $CDPRODUTO, $TXPRODPED,
			                             $QTPRODPEFOS, $CHAVEITEM, $NRATRAPROD, $arrayDadosPai,
			                             $RELITCOMANDAVEN)) {
				$arrayChaveItem = array(
					'CHAVEITEM' => $CHAVEITEM
				);
				array_push($this->itemsToHandleComposition, array(
					'CDFILIAL'        => $CDFILIAL,
					'CDPRODUTO'       => $CDPRODUTO,
					'QTPRODPEFOS'     => $QTPRODPEFOS,
					'NRPEDIDOFOS'     => $NRPEDIDOFOS,
					'CDCAIXA'         => $CDCAIXA,
					'NRSEQVENDA'      => $NRSEQVENDA,
					'NRSEQUITVEND'    => $NRSEQUITVEND,
					'NRVENDAREST'     => $NRVENDAREST,
					'NRCOMANDA'       => $NRCOMANDA,
					'NRPRODCOMVEN'    => $NRPRODCOMVEN,
					'TXPRODPED'       => $TXPRODPED,
					'IDSITITPEDFOS'   => $IDSITITPEDFOS,
					'DSCHAVEPEDPAI'   => $DSCHAVEPEDPAI,
					'DTPEDIDOFOS'     => $DTPEDIDOFOS,
					'NRITPEDIDOFOS'   => $NRITPEDIDOFOS,
					'CHAVEPEDIDO'     => $CHAVEPEDIDO,
					'CDOCORR'         => $CDOCORR,
					'CDGRPOCOR'       => $CDGRPOCOR,
					'CHAVEITEM'       => array($arrayChaveItem),
					'ARRAYPAI'        => array($arrayDadosPai),
					'NRATRAPROD'      => $NRATRAPROD,
					'RELITCOMANDAVEN' => $RELITCOMANDAVEN,
					'OBSDIGITADA'     => $OBSDIGITADA,
					'NRLUGARMESAIT'   => $NRLUGARMESAIT,
					'IDORIGEMVENDA'   => $IDORIGEMVENDA,
					'IDITORIGEMVENDA' => $IDITORIGEMVENDA
				));
			}
		}
    }

	private function generateNewNRITPEDIDOFOS($CDFILIAL, $NRPEDIDOFOS) {
		$validKey = false;
		while ($validKey == false) {
			$this->util->newCode('ITPEDIDOFOS' . $CDFILIAL . $NRPEDIDOFOS);
			$NRITPEDIDOFOS = $this->KDSManagerService->getNewCode('ITPEDIDOFOS' . $CDFILIAL . $NRPEDIDOFOS);
			$NRITPEDIDOFOS = $NRITPEDIDOFOS[0]['NRSEQUENCIAL'];
			$NRITPEDIDOFOS = substr($NRITPEDIDOFOS, -10);

			$validKey = $this->KDSManagerService->checkIfKeyExists($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS);
		}
		return $NRITPEDIDOFOS;
	}

	private function generateNewNRSEQITPEDPAI($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$validKey = false;
		while ($validKey == false) {
			$this->util->newCode('ITPEDIDOFOSPAI' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS);
			$NRSEQITPEDPAI = $this->KDSManagerService->getNewCode('ITPEDIDOFOSPAI' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS);
			$NRSEQITPEDPAI = $NRSEQITPEDPAI[0]['NRSEQUENCIAL'];
			$NRSEQITPEDPAI = substr($NRSEQITPEDPAI, -10);

			$validKey = $this->KDSManagerService->checkIfITPEDIDOFOSPAIExists($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $NRSEQITPEDPAI);
		}
		return $NRSEQITPEDPAI;
	}

	private function generateNewNRSEQITPEDREL($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$this->util->newCode('ITPEDIDOFOSREL' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS);
		$NRSEQITPEDREL = $this->KDSManagerService->getNewCode('ITPEDIDOFOSREL' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS);
		$NRSEQITPEDREL = $NRSEQITPEDREL[0]['NRSEQUENCIAL'];
		$NRSEQITPEDREL = substr($NRSEQITPEDREL, -10);
		return $NRSEQITPEDREL;
	}

    private function checkInCompositionArray($key, $array) {
    	foreach ($array as $currentItem) {
    		foreach ($currentItem['CHAVEITEM'] as $currentKey) {
	    		if ($currentKey['CHAVEITEM'] == $key) {
	    			return true;
	    		}
    		}
    	}
    	return false;
    }

    private function groupComposition($CDFILIAL, $NRPEDIDOFOS, $CDPRODUTO, $TXPRODPED,
                                      $QTPRODPEFOS, $CHAVEITEM, $NRATRAPROD, $arrayDadosPai,
                                      $RELITCOMANDAVEN) {
    	foreach ($this->itemsToHandleComposition as &$currentItem) {

    		if (($currentItem['CDFILIAL'] == $CDFILIAL) && ($currentItem['NRPEDIDOFOS'] == $NRPEDIDOFOS) &&
                ($currentItem['CDPRODUTO'] == $CDPRODUTO) && ($currentItem['TXPRODPED'] == $TXPRODPED) &&
                ($currentItem['NRATRAPROD'] == $NRATRAPROD)) {

    			$currentItem['QTPRODPEFOS'] += $QTPRODPEFOS;

    			if (!empty($CHAVEITEM)) {
	    			// trata chave do item para não duplicar
	    			$arrayChaveItem = $currentItem['CHAVEITEM'];
					array_push($arrayChaveItem, array(
						'CHAVEITEM' => $CHAVEITEM
					));
					$currentItem['CHAVEITEM'] = $arrayChaveItem;
    			}

				// coloca chave do pai do item no array para inserir na ITPEDIDOFOSPAI
				$arrayPai = $currentItem['ARRAYPAI'];
				array_push($arrayPai, $arrayDadosPai);
				$currentItem['ARRAYPAI'] = $arrayPai;

				// junta relacionamentos (ITPEDIDOFOSREL)
				$currentItem['RELITCOMANDAVEN'] = array_merge($currentItem['RELITCOMANDAVEN'], $RELITCOMANDAVEN);

    			return true;
    		}
    	}
    	return false;
    }

	public function buildDataSource($CDSETOR = null) {
		// busca todos os items para montar as caixas do KDS
		// será um pedido por item (uma caixa por produto)

		$pedidos = array();
		$itemsArray = $this->KDSManagerService->getRequestItem($CDSETOR);

		foreach ($itemsArray as $currentItem) {

			// trata cancelamento na venda mesa, comanda ou delivery
			if (!empty($currentItem['NRVENDAREST'])) {
				// se a caixa não está toda cancelada
				if ($currentItem['IDSITITPEDFOS'] != 'C') {
					// relação com ITCOMANDAVEN
					$itemsRelations = $this->KDSManagerService->getItemsRelations($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS'], $currentItem['NRITPEDIDOFOS']);
					$newQuantity = 0;
					$canceledQuantity = 0;
					foreach ($itemsRelations as $relation) {
						if ($relation['IDSITITPEDFOS'] != 'C') {
							$newQuantity = $newQuantity + $relation['QTPRODPEFOS'];
						} else {
							$canceledQuantity = $canceledQuantity + $relation['QTPRODPEFOS'];
						}
					}

					// se a nova quantidade for igual a zero, cancela o item pai (na ITPEDIDOFOS)
					if ($newQuantity <= 0) {
						$currentItem['IDSITITPEDFOS'] = 'C';
						$this->KDSManagerService->cancelItem($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS'], $currentItem['NRITPEDIDOFOS']);

						if ($currentItem['IDLIBERADO'] == 'N') {
							// expede se não tiver liberado para impedir que ele apareça na produção
							$currentItem['IDSITITPEDFOS'] = 'X';
							$this->KDSManagerService->changeItemStatusReleased($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS'], $currentItem['NRITPEDIDOFOS']);
						}
					} else if ($newQuantity != $currentItem['QTPRODPEFOS'] && $canceledQuantity > 0) {
						// se a quantidade mudou
						// se um ou mais itens (não todos) foram cancelados, updata a nova quantidade
						$currentItem['QTPRODPEFOS'] = $newQuantity;
						$this->KDSManagerService->changeItemQuantity($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS'], $currentItem['NRITPEDIDOFOS'], $currentItem['QTPRODPEFOS']);
					}
					if($canceledQuantity > 0) {
	                    // muda label para mostrar os itens cancelados dentro da mesma caixa
	                    if (empty($currentItem['TXPRODPED'])) {
	                            $currentItem['TXPRODPED'] = array();
	                    }else{
	                            $currentItem['TXPRODPED'] = json_decode($currentItem['TXPRODPED']);
	                    }

	                    array_push($currentItem['TXPRODPED'], array(
	                            'OBSERVACAO' => 'QTD CANCELADA: ' . $canceledQuantity,
	                            'NRCORSINAL' => 'EE0000'
	                    ));

	                    $currentItem['TXPRODPED'] = json_encode($currentItem['TXPRODPED']);
					}
				} else {
					// recalcula quantidade do item pai quando cancelar os filhos
					$itemsRelations = $this->KDSManagerService->getItemsRelations($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS'], $currentItem['NRITPEDIDOFOS']);
					$canceledQuantity = 0;
					foreach ($itemsRelations as $relation) {
						if ($relation['IDSITITPEDFOS'] == 'C') {
							$canceledQuantity = $canceledQuantity + $relation['QTPRODPEFOS'];
						}
					}
					if ($canceledQuantity > 0 && $canceledQuantity != $currentItem['QTPRODPEFOS']) {
						$NEWNRITPEDIDOFOS = $this->generateNewNRITPEDIDOFOS($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS']);
						$this->KDSManagerService->changeItemQuantity($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS'], $currentItem['NRITPEDIDOFOS'], $currentItem['QTPRODPEFOS'] - $canceledQuantity);
						$currentItem['QTPRODPEFOS'] = $canceledQuantity;
					}
				}
			}

			// se for venda balcão, o número do pedido será o mesmo impresso no cupom fiscal
			$currentItem['orderCode'] = $currentItem['CDFILIAL'] . $currentItem['NRPEDIDOFOS'] . $currentItem['NRITPEDIDOFOS']. $currentItem['NRSEQLIBERADO'];
			$currentItem['label'] = $currentItem['CDSENHAPED'];
			// retira os zeros do número da mesa
			$currentItem['NRMESA'] = intval($currentItem['NRMESA']);
			// retira os zeros do número da mesa antiga
			$currentItem['NRMESAOLD'] = intval($currentItem['NRMESAOLD']);
			// retira os zeros da quantidade
			if(is_int($currentItem['QTPRODPEFOS'])){
				$currentItem['QTPRODPEFOS'] = intval($currentItem['QTPRODPEFOS']);
			}
			// busca intervalos de produção do item
			$currentItem['INTERVALS'] = $this->KDSManagerService->getItemIntervals($currentItem['CDPRODUTO'], $currentItem['CDSETOR']);
			// busca origem do item
			$currentItem['ORIGEM'] = $this->KDSManagerService->getItemOrigin($currentItem['IDORIGEMVENDA']);
			// substitui o setor do pedido pelo setor do produto (gambiarra) - WHY?!
			$currentItem['IDTIPOSETOR'] = 'P';
			// cria um array com somente um item
			$item = array();
			array_push($item, $currentItem);
			$currentItem['items'] = $item;

			if ($currentItem['IDSITITPEDFOS'] != 'X') {
				// coloca o pedido atual no array de retorno
				array_push($pedidos, $currentItem);
			}
		}
		return $pedidos;
	}



	function filterExpedition($item)
	{
		$result = $item['NRPEDIDOFOS'] != $this->oldOrder;
		$this->oldOrder = $item['NRPEDIDOFOS'];
		return $result;
	}

	function filterItems($item)
	{
		return $item['NRPEDIDOFOS'] == $this->order;
	}

	public function buildDataSourceExpedition($CDSETOR = null) {

		$returnArray = array();


		$init_mcr = microtime(true);

		$init_mcr = microtime(true);
		// $timer = ElapsedTime::create('getExpedition');
		// $timer->start();

		$returnToSector = $CDSETOR !== null;


		$sectorLists = $this->KDSManagerService->getExpeditionAndMountListFromItPedidofos();

		$resultArray = [];

		foreach($sectorLists as $currentSector){

			$expeditionArray = $this->KDSManagerService->getExpedition($currentSector['CDSETOR'], $returnToSector);
			// $timer->end();

			// $timer = ElapsedTime::create('foreach');
			// $timer->start();
			$count = 0;
			$keyExpedition = 0;
			$lastIdx = 0;
			if(!empty($expeditionArray)){
				while($keyExpedition < sizeof($expeditionArray)) {
					$expedition = $expeditionArray[$keyExpedition];
					$trueItemsExp = array();
					$trueItemsMont = array();
					// $this->order = $expedition['NRPEDIDOFOS'];

					$itemsExpedition = array();
					array_push($itemsExpedition, $expeditionArray[$keyExpedition]);
					$lastIdx = $keyExpedition + 1;
					if(isset($expeditionArray[$lastIdx])){
						$expeditionArray[$lastIdx]['orderCode'] = $expeditionArray[$lastIdx]['CDFILIAL'] . $expeditionArray[$lastIdx]['NRPEDIDOFOS'] . $expeditionArray[$lastIdx]['NRSEQLIBERADO'];
					}
					$expedition['orderCode'] = $expedition['CDFILIAL'] . $expedition['NRPEDIDOFOS']. $expedition['NRSEQLIBERADO'];

					while(isset($expeditionArray[$lastIdx]) && $expedition['orderCode'] == $expeditionArray[$lastIdx]['orderCode']){
						array_push($itemsExpedition,  $expeditionArray[$lastIdx]);
						//unset($expeditionArray[$lastIdx]);
						$lastIdx++;
						if(isset($expeditionArray[$lastIdx])){
							$expeditionArray[$lastIdx]['orderCode'] = $expeditionArray[$lastIdx]['CDFILIAL'] . $expeditionArray[$lastIdx]['NRPEDIDOFOS'] . $expeditionArray[$lastIdx]['NRSEQLIBERADO'];
						}
					}
					$keyExpedition = $lastIdx;

					//nunca vai estar empty mas eu gosto deste bloco
					if (!empty($itemsExpedition)) {

						// se for venda balcão, o número do pedido será o mesmo impresso no cupom fiscal
						$expedition['orderCode'] = $expedition['CDFILIAL'] . $expedition['NRPEDIDOFOS'];
						$expedition['label'] = $expedition['CDSENHAPED'];

						// retira os zeros do número da mesa
						$expedition['NRMESA'] = intval($expedition['NRMESA']);

						// retira os zeros do número da mesa antiga
						$expedition['NRMESAOLD'] = intval($expedition['NRMESAOLD']);

						// coloca o atraso
						$expedition['DELAYTIME'] = $itemsExpedition[0]['DELAYTIME'];

						// para tratar ordenação dos pedidos no frontend
						$expedition['DTHREXIBICAOPRODISO'] = $itemsExpedition[0]['DTHREXIBICAOPRODISO'];
						$expedition['DTHREXIBICAOPROD'] = $itemsExpedition[0]['DTHREXIBICAOPROD'];
						$expedition['NRSEQLIBERADO'] = $itemsExpedition[0]['NRSEQLIBERADO'];

						// verifica se todos os itens do pedido estão cancelados
						$canCancel = 0;
						// verifica se todos os itens do pedido estão cancelados
						$doneItems = 0;

						// maior tempo do pedido
						$biggestTime = 0;

						foreach ($itemsExpedition as $key => $item) {

							if ($key == 0) {
								$expedition['orderKey'] = $item['CDFILIAL'] . '-' . $item['NRPEDIDOFOS'] . $item['NRITPEDIDOFOS'];
							}

							// trata cancelamento na venda mesa, comanda ou delivery
							if (!empty($item['NRVENDAREST'])) {
								// se o item não está cancelado
								if ($item['IDSITITPEDFOS'] != 'C') {
									// relação com ITCOMANDAVEN
									$itemsRelations = $this->KDSManagerService->getItemsRelations($item['CDFILIAL'], $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);
									$newQuantity = 0;
									foreach ($itemsRelations as $relation) {
										if ($relation['IDSITITPEDFOS'] != 'C') {
											$newQuantity = $newQuantity + $relation['QTPRODPEFOS'];
										}
									}
									// se a nova quantidade for igual a zero, cancela o item pai (na ITPEDIDOFOS)
									if ($newQuantity <= 0) {
										$item['IDSITITPEDFOS'] = 'C';
										$this->KDSManagerService->cancelItem($item['CDFILIAL'], $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);

										/*if ($item['IDLIBERADO'] == 'N') {
											// expede se não tiver liberado para impedir que ele apareça na produção
											$item['IDSITITPEDFOS'] = 'X';
											$this->KDSManagerService->changeItemStatusReleased($item['CDFILIAL'], $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);
										}*/
									} else if ($newQuantity != $item['QTPRODPEFOS']) {
										// se a quantidade mudou
										// se um ou mais itens (não todos) foram cancelados, updata a nova quantidade
										$item['QTPRODPEFOS'] = $newQuantity;
										$this->KDSManagerService->changeItemQuantity($item['CDFILIAL'], $item['NRPEDIDOFOS'],  $item['NRITPEDIDOFOS'], $item['QTPRODPEFOS']);
									}
								}
							}

							//Solução Temporária do Combo
							if($this->util->getParameter('comboAlias') != ''){
								$item['NMPROMOCAO'] = preg_replace('/COMBO.*/',$this->util->getParameter('ComboAlias'), $item['NMPROMOCAO']);
							}

							// X - EXPEDIDO
							// verifica se todos os itens filhos desse item já estão prontos
							if ($item['IDSITITPEDFOS'] != 'X') {
								$item = $this->updateExpeditionStatus($item['CDFILIAL'], $item);
							}

							// se item está cancelado
							if ($item['IDSITITPEDFOS'] == 'C' ) {
								$canCancel++;
							}
							// se item está cancelado
							if ($item['IDSITITPEDFOS'] == 'C' || $item['IDSITITPEDFOS'] == 'F' || $item['IDSITITPEDFOS'] == 'X' ) {
								$doneItems++;
							}


							if ($item['IDSITITPEDFOS'] != 'X') {
								if ($item['IDTIPOSETOR'] == 'E') {
									// se tipo setor é expedição
									//if($item['CDSETOR'] == $expedition['CDSETOR']){
										array_push($trueItemsExp, $item);
									//}
								} else if ($item['IDTIPOSETOR'] == 'M') {
									// se tipo setor é montagem
									if($item['CDSETOR'] == $expedition['CDSETOR']){
										array_push($trueItemsMont, $item);
									}								
								}
							}

							if ($item['TEMPOCORES'] > $biggestTime) {
								$biggestTime = $item['TEMPOCORES'];
							}
						}


						if ($canCancel == count($itemsExpedition)) {
						// se todos os itens do pedido estão cancelados
							$expedition['IDSITITPEDFOS'] = "C";

							/*if ($expedition['CDSENHAPED'] == '') {
								$expedition['label'] = $expedition['orderCode'];
							}*/
						}else if ($doneItems == count($itemsExpedition)) {
						// se todos os itens do pedido estão prontos
							$expedition['IDSITITPEDFOS'] = "F";
						}else{
							$expedition['IDSITITPEDFOS'] = "E";
						}

						$expedition['IDTIPOSETOR'] = $item['IDTIPOSETOR'];
						$expedition['TEMPOCORES'] = $biggestTime;
						//$expedition['NRTEMPOPROD'] = $biggestTime;
						if( $expedition['IDORIGEMVENDA'] ){
							$expedition['ORIGEM'] = $this->KDSManagerService->getItemOrigin($expedition['IDORIGEMVENDA']);
						}
						if (!empty($trueItemsExp)) {
							// substitui o setor do pedido pelo setor do produto (gambiarra pra função de tempo funcionar corretamente)
							$expedition['CDSETOR'] = $trueItemsExp[0]['CDSETOR'];
							$expedition['items'] = $trueItemsExp;
							array_push($returnArray, $expedition);
						}
						if (!empty($trueItemsMont)) {
							// substitui o setor do pedido pelo setor do produto (gambiarra pra função de tempo funcionar corretamente)
							$expedition['CDSETOR'] = $trueItemsMont[0]['CDSETOR'];
							$expedition['items'] = $trueItemsMont;
							array_push($returnArray, $expedition);
						}
					}
				}

			}
			$resultArray = array_merge($resultArray, $returnArray);
		}

		// $timer->end();

		return $resultArray;
	}

	public function updateExpeditionStatus($CDFILIAL, $item) {
		// busca todos os sub-itens do produto pai
		$childProducts = $this->KDSManagerService->getChildProducts($CDFILIAL, $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);
		// busca todos os itens filhos desse pai que estão prontos
		$doneChildProducts = $this->KDSManagerService->checkChildDone($CDFILIAL, $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS'],$item['IDTIPOSETOR']);
		// busca todos os itens filhos desse pai que estão em produção
		$childProduction = $this->KDSManagerService->checkChildProduction($CDFILIAL, $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);
		$IDSITITPEDFOS = $item['IDSITITPEDFOS'];

		$NRPEDIDOFOS = $item['NRPEDIDOFOS'];

		$canSetHowDone = NULL;

		if( $item['IDTIPOSETOR'] == 'M' ){
			$canSetHowDone = $this->KDSManagerService->checkIfCanDoneMount($NRPEDIDOFOS);	
		}

		// verifica se item pai está cancelado (se esse if for removido, o sistema estrará em loop eterno)
		if ($IDSITITPEDFOS == 'C') {
			$item['IDSITITPEDFOS'] = 'C';

		// item não tem subprodutos já entra como feito na expedição
		} else if ((empty($childProducts)) && ($IDSITITPEDFOS != 'F')) {
			
			if($item['IDTIPOSETOR'] != 'M' || ($canSetHowDone != NULL && $item['CDSETOR'] == $canSetHowDone[0]['CDSETOR'] )){
				$IDSITITPEDFOS = 'F';
				$this->KDSManagerService->changeStatusItemRequestConclude($CDFILIAL, $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);
			}


		// filhos concluídos, entra como feito
		} else if ((count($doneChildProducts) == count($childProducts)) && ($IDSITITPEDFOS != 'F')) {
			if (!empty($doneChildProducts)) {
				if($item['IDTIPOSETOR'] != 'M' || ($canSetHowDone != NULL && $item['CDSETOR'] == $canSetHowDone[0]['CDSETOR'] )) {
					$IDSITITPEDFOS = 'F';
					$this->KDSManagerService->changeStatusItemRequestConclude($CDFILIAL, $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);
				} 	
			}				

		// produto em produção, mostra a engrenagem
		} else if ($IDSITITPEDFOS != 'P' && $IDSITITPEDFOS != 'F') {
			if (!empty($childProduction) || !empty($doneChildProducts)) {
				$IDSITITPEDFOS = 'P';
				$this->KDSManagerService->changeStatusItemRequestPlay($CDFILIAL, $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS']);
			}
		}

		$item['IDSITITPEDFOS'] = $IDSITITPEDFOS;
		if ($item['IDSITITPEDFOS'] == 'F' || $item['IDSITITPEDFOS'] == 'C' || $item['IDSITITPEDFOS'] == 'X') {
		 	$item['PRODUCTED'] = true;
		} else {
			$item['PRODUCTED'] = false;
		}
		return $item;
	}

	public function updateTimeByObservationExpedition($item, $observations) {
		$detailObservation = self::getDetailObservation($observations);
		$maxTime = $detailObservation['maxtime']; // Maior tempo encontrado no array de observação
		$DSOCORR = $detailObservation['DSOCORR']; // String com todas as observações do pedido
		$item['DSOCORR'] = $DSOCORR;
		$item['NRTEMPOPROD'] = $maxTime;
		return $item;
	}

    private function handleComposition($compositionArray){
    	foreach ($compositionArray as $currentComposition) {


    		

    		$this->fillComposition(
				$currentComposition['CDFILIAL'],
				$currentComposition['CDPRODUTO'],
				$currentComposition['QTPRODPEFOS'],
				$currentComposition['NRPEDIDOFOS'],
				$currentComposition['CDCAIXA'],
				$currentComposition['NRSEQVENDA'],
				$currentComposition['NRSEQUITVEND'],
				$currentComposition['NRVENDAREST'],
				$currentComposition['NRCOMANDA'],
				$currentComposition['NRPRODCOMVEN'],
				$currentComposition['TXPRODPED'],
				$currentComposition['IDSITITPEDFOS'],
				$currentComposition['DSCHAVEPEDPAI'],
				$currentComposition['DTPEDIDOFOS'],
				$currentComposition['NRITPEDIDOFOS'],
				$currentComposition['CHAVEPEDIDO'],
				$currentComposition['CDOCORR'],
				$currentComposition['CDGRPOCOR'],
				$currentComposition['ARRAYPAI'],
				$currentComposition['NRATRAPROD'],
				$currentComposition['CHAVEITEM'],
				$currentComposition['RELITCOMANDAVEN'],
				$currentComposition['OBSDIGITADA'],
				$currentComposition['NRLUGARMESAIT'],
				$currentComposition['IDORIGEMVENDA'],
				$currentComposition['IDITORIGEMVENDA']
    		);
    	}
    }

    public function fillComposition($CDFILIAL, $CDPRODUTOPAI, $QTPRODPEFOS, $NRPEDIDOFOS,
     								$CDCAIXA, $NRSEQVENDA, $NRSEQUITVEND, $NRVENDAREST,
     								$NRCOMANDA, $NRPRODCOMVEN, $TXPRODPED, $IDSITITPEDFOS,
     								$DSCHAVEPEDPAI, $DTPEDIDOFOS, $NRITPEDIDOFOSPAI, $CHAVEPEDIDO,
     								$CDOCORR, $CDGRPOCOR, $ARRAYPAIS, $NRATRAPROD,
     								$CHAVEITEM, $RELITCOMANDAVEN, $OBSDIGITADA, $NRLUGARMESAIT, $IDORIGEMVENDA, $IDITORIGEMVENDA) {

	// busca composição local
    	$composition = $this->KDSManagerService->searchLocalComposition($CDFILIAL, $CDPRODUTOPAI);
    	// se não tiver composição local, procura a padrão
    	if (empty($composition)) {
			$composition = $this->KDSManagerService->searchPatternComposition($CDPRODUTOPAI, $CDFILIAL);
    	}

    	// se tiver composição local ou padrão
    	if (!empty($composition)) {
    		$DSCHAVEPEDPAI = $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOSPAI;
    		foreach ($composition as $prodComposition) {
				if ($this->validateProduct($prodComposition['CDSUBPRODUTO'])) {
					$CDSUBPRODUTO  = $prodComposition['CDSUBPRODUTO'];
					$DSAPELIDOKDS = null;

					if (!empty($prodComposition['DSAPELIDOKDS'])) {
						$DSAPELIDOKDS = $prodComposition['DSAPELIDOKDS'];
					}
					if ($CDPRODUTOPAI != $CDSUBPRODUTO) { // somente de subproduto for diferente do produto de origem

						$QTDSUBPRD = $prodComposition['QUANTIDADE'];
		    			$QTDSUBPRD = ($QTDSUBPRD * $QTPRODPEFOS);
		    			$QTDSUBPRD = number_format($QTDSUBPRD, 3);

		    			// quantidade usada na ITPEDIDOFOSREL
						$QTCOMPOSICAO = $prodComposition['QUANTIDADE'];

		    			// busca os setores em que o produto está
						$productSectors = $this->KDSManagerService->getProductSector($CDSUBPRODUTO, $CDFILIAL);
		    			if (!empty($productSectors)) {
		    				foreach ($productSectors as $currentSector) {

    							$TXPRODPED = null;
    							$NRTEMPOPROD = $currentSector['NRTEMPOPROD'];
    							$NRTEMPOEXIB = $currentSector['NRTEMPOEXIB'];
    							$CDSETOR = $currentSector['CDSETOR'];
    							if (is_array($CHAVEITEM)) {
    								$key = $CHAVEITEM[0]['CHAVEITEM'];
    							} else {
    								$key = $CHAVEITEM;
    							}

    							// busca se há alguma observação pro item
    							$observacoes = $this->KDSManagerService->getAllItemObservations($key);
								if (!empty($observacoes)) {
	    							// define quais observações irão aparecer pra esse item
	    							// busca as observações cadastradas na SETORPRODOBS
									$todasObsSetorProduto = $this->KDSManagerService->getSetorProdutoObservations($CDSETOR, $CDSUBPRODUTO);
									if (!empty($todasObsSetorProduto)) {
										// se possui algo na SETORPRODOBS para esse produto neste setor, busca as observações que são compatíveis
										$observacoes = $this->KDSManagerService->getItemObservationsBySetorProduto($key, $CDSETOR, $CDSUBPRODUTO);
									} /*else {
										// se esse produto não tiver nenhum registro na SETORPRODOBS (pra este setor),
										// mostra todas as observações do item
									}*/
								}

								// monta observações pro front-end e soma/subtrai as alterações de tempo por observação
								if (!empty($observacoes)) {
									$TXPRODPED = array();
									foreach ($observacoes as $observacao) {
										array_push($TXPRODPED, array(
											'OBSERVACAO' => $observacao['OBSERVACAO'],
											'NRCORSINAL' => $observacao['NRCORSINAL']
										));
										$NRTEMPOPROD = intval($NRTEMPOPROD) + intval($observacao['NRTEMPOPROD']);
										$NRTEMPOEXIB = intval($NRTEMPOEXIB) + intval($observacao['NRTEMPOPROD']);
									}
									$NRTEMPOPROD = (string)$NRTEMPOPROD;
									$NRTEMPOEXIB = (string)$NRTEMPOEXIB;

									if (!empty($OBSDIGITADA)) {
										try{
											$digitada = json_decode($OBSDIGITADA, TRUE);
											if(!empty($digitada)){
												array_push($TXPRODPED, $digitada);
											}else{
												array_push($TXPRODPED, array(
													'OBSERVACAO' => $OBSDIGITADA,
													'NRCORSINAL' => 'FFFFFF'
												));	
											}
										}catch(\Exception $e){
											array_push($TXPRODPED, array(
												'OBSERVACAO' => $OBSDIGITADA,
												'NRCORSINAL' => 'FFFFFF'
											));
										}
									}
								} else if (!empty($OBSDIGITADA)) {
									$TXPRODPED = array();
									if (!empty($OBSDIGITADA)) {
										try{
											$digitada = json_decode($OBSDIGITADA, TRUE);
											if(!empty($digitada)){
												array_push($TXPRODPED, $digitada);
											}else{
												array_push($TXPRODPED, array(
													'OBSERVACAO' => $OBSDIGITADA,
													'NRCORSINAL' => 'FFFFFF'
												));	
											}
										}catch(\Exception $e){
											array_push($TXPRODPED, array(
												'OBSERVACAO' => $OBSDIGITADA,
												'NRCORSINAL' => 'FFFFFF'
											));
										}
									}
  								}

	  							//Nova implementação para viagem
								if(!is_null($IDITORIGEMVENDA)){
									$NRCORVGM = $currentSector['NRCORVGM'];
									if(!isset($TXPRODPED)){
										$TXPRODPED = Array();
									}
									$has = false;
									foreach($TXPRODPED as $key => $value){
										if(strpos('  '.$value['OBSERVACAO'], 'VIAGEM') != ''){
											//REMOVE OBSERVAÇÃO;
											$TXPRODPED[$key]['NRCORSINAL'] = $NRCORVGM;
											$has = true;
									 	}
									}

									if($has == false){
										array_push($TXPRODPED, array(
											'OBSERVACAO' => 'VIAGEM',
											'NRCORSINAL' => $NRCORVGM
										));
									}
								}

	    						// substitui a quantidade da composição (na ITPEDIDOFOSREL)
	    						$RELITCOMANDAVENcomp = $this->changeRelationsQuantity($RELITCOMANDAVEN, $QTCOMPOSICAO);

		    					if (!$this->groupCompositionFromDifferentProducts($CDFILIAL, $NRPEDIDOFOS, $CDSUBPRODUTO, $DSAPELIDOKDS,
		    					                                                  $TXPRODPED, $QTDSUBPRD, $NRATRAPROD, $ARRAYPAIS,
		    					                                                  $RELITCOMANDAVENcomp)) {

		    						// insere novo item no array
			    					$NRITPEDIDOFOS = $this->generateNewNRITPEDIDOFOS($CDFILIAL, $NRPEDIDOFOS);
									array_push($this->itemsForInsertion, array(
										'CDFILIAL'        => $CDFILIAL,
										'NRPEDIDOFOS'     => $NRPEDIDOFOS,
										'NRITPEDIDOFOS'   => $NRITPEDIDOFOS,
										'CDPRODUTO' 	  => $CDSUBPRODUTO,
										'QTPRODPEFOS' 	  => $QTDSUBPRD,
										'CDCAIXA' 		  => $CDCAIXA,
										'NRSEQVENDA' 	  => $NRSEQVENDA,
										'NRSEQUITVEND'    => $NRSEQUITVEND,
										'NRVENDAREST' 	  => $NRVENDAREST,
										'NRCOMANDA' 	  => $NRCOMANDA,
										'NRPRODCOMVEN'    => $NRPRODCOMVEN,
										'TXPRODPED' 	  => $TXPRODPED,
										'IDSITITPEDFOS'   => $IDSITITPEDFOS,
										'CDSETOR'         => $CDSETOR,
										'CDGRPOCOR'       => $CDGRPOCOR,
										'CDOCORR'         => $CDOCORR,
										'DSCHAVEPEDPAI'   => $DSCHAVEPEDPAI,
										'CHAVEPEDIDO'     => $CHAVEPEDIDO,
										'DTPEDIDOFOS'     => $DTPEDIDOFOS,
										'CDPRODUTOPAI'    => $CDPRODUTOPAI,
										'IDTIPOSETOR'     => $currentSector['IDTIPOSETOR'],
										'CDPRODPROMOKDS'  => null,
										'NRSEQPRODCOMKDS' => null,
										'NRTEMPOPROD'     => $NRTEMPOPROD,
										'NRTEMPOEXIB'     => $NRTEMPOEXIB,
										'NRATRAPROD'      => $NRATRAPROD,
										'DSAPELIDOKDS'    => $DSAPELIDOKDS,
										'RELITCOMANDAVEN' => $RELITCOMANDAVENcomp,
										'NRLUGARMESAIT'   => $NRLUGARMESAIT,
										'IDORIGEMVENDA'   => $IDORIGEMVENDA
									));

									// insere uma linha para cada pai dessa composição na ITPEDIDOFOSPAI
									// uma composição pode ter vários pais, pois será agrupada com outros itens
									foreach ($ARRAYPAIS as $currentPai) {
										$NRSEQITPEDPAI = $this->generateNewNRSEQITPEDPAI($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS);
										array_push($this->itemsRelations, array(
											'CDFILIAL'         => $CDFILIAL,
											'NRPEDIDOFOS'      => $NRPEDIDOFOS,
											'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
											'NRSEQITPEDPAI'    => $NRSEQITPEDPAI,
											'CDFILIALPAI'      => $currentPai['CDFILIAL'],
											'NRPEDIDOFOSPAI'   => $currentPai['NRPEDIDOFOS'],
											'NRITPEDIDOFOSPAI' => $currentPai['NRITPEDIDOFOS']
										));
									}
								}
		    				}
		    			}
		    		}
		   		}
    		}
    	}
    }

	private function changeRelationsQuantity($RELITCOMANDAVEN, $QTDSUBPRD) {
		$RELITCOMANDAVENcomp = array();
		foreach ($RELITCOMANDAVEN as $currentRelation) {
			$currentRelation['QTPRODPEFOS'] = $QTDSUBPRD;
			array_push($RELITCOMANDAVENcomp, $currentRelation);
		}
		return $RELITCOMANDAVENcomp;
	}

    private function groupCompositionFromDifferentProducts($CDFILIAL, $NRPEDIDOFOS, $CDSUBPRODUTO, $DSAPELIDOKDS,
                                                           $TXPRODPED, $QTPRODPEFOS, $NRATRAPROD, $ARRAYPAIS,
                                                           $RELITCOMANDAVEN) {
		foreach ($this->itemsForInsertion as &$currentItem) {
			if (($CDFILIAL == $currentItem['CDFILIAL']) && ($NRPEDIDOFOS == $currentItem['NRPEDIDOFOS']) &&
			    ($CDSUBPRODUTO == $currentItem['CDPRODUTO']) && ($TXPRODPED == $currentItem['TXPRODPED']) &&
			    ($DSAPELIDOKDS == $currentItem['DSAPELIDOKDS']) &&
			    ($NRATRAPROD == $currentItem['NRATRAPROD'])) {

				$currentItem['QTPRODPEFOS'] += $QTPRODPEFOS;

				//$RELITCOMANDAVENcomp = $this->changeRelationsQuantity($RELITCOMANDAVEN, $QTPRODPEFOS);

				$currentItem['RELITCOMANDAVEN'] = array_merge($currentItem['RELITCOMANDAVEN'], $RELITCOMANDAVEN);

				// insere uma linha para cada pai dessa composição na ITPEDIDOFOSPAI
				// uma composição pode ter vários pais, pois será agrupada com outros itens
				foreach ($ARRAYPAIS as $currentPai) {
					$NRSEQITPEDPAI = $this->generateNewNRSEQITPEDPAI($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS'], $currentItem['NRITPEDIDOFOS']);
					array_push($this->itemsRelations, array(
						'CDFILIAL'         => $currentItem['CDFILIAL'],
						'NRPEDIDOFOS'      => $currentItem['NRPEDIDOFOS'],
						'NRITPEDIDOFOS'    => $currentItem['NRITPEDIDOFOS'],
						'NRSEQITPEDPAI'    => $NRSEQITPEDPAI,
						'CDFILIALPAI'      => $currentPai['CDFILIAL'],
						'NRPEDIDOFOSPAI'   => $currentPai['NRPEDIDOFOS'],
						'NRITPEDIDOFOSPAI' => $currentPai['NRITPEDIDOFOS']
					));
				}
				return true;
			}
		}
		return false;
	}

	public function concludeRequest(Request\Filter $request, Response $response) {
		try{
			$params = $request->getFilterCriteria()->getConditions();

			$CDFILIAL      = $params[0]['value'];
			$NRPEDIDOFOS   = $params[1]['value'];
			$NRITPEDIDOFOS = $params[2]['value'];
			$CDLOJA        = $params[3]['value'];
			$CDSETOR       = $params[4]['value'];

			//F de feito
			$IDSITITPEDFOS = 'F';
			$this->KDSManagerService->changeStatusItemRequestConclude($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $IDSITITPEDFOS);
			$response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('RequestsRepo', array()));
		} catch (\Exception $e) {
			$this->util->logException($e->getMessage());
            $response->addMessage(new Message($e->getMessage()));
        }
	}

	public function getTimersForBoxes($pedidos) {
		foreach ($pedidos as &$pedido) {
			$item = $pedido['items'][0];

			$data = $item['DTHREXIBICAOPROD'];
			if (($pedido['IDTIPOSETOR'] == 'E') || ($pedido['IDTIPOSETOR'] == 'M')) {
				// IDTIPOSETOR = E
				// setor de expedição, cada caixa tem N itens
				// busca o maior tempo de produção do pedido
				$maxTime = $this->KDSManagerService->getMaxProductionTime($pedido['CDFILIAL'], $pedido['NRPEDIDOFOS'], ($pedido['NRSEQLIBERADO'] != ''));



				$NRTEMPOPROD = $maxTime[0]['TEMPO'];
			} else {
				// IDTIPOSETOR = P
				// setor de produção, cada caixa tem somente um item
    			$NRTEMPOPROD = $item['NRTEMPOPROD'];
			}
			$pedido['NRTEMPOPROD'] = $NRTEMPOPROD;

            // coloca o timer no pedido
            $now = new \Datetime($item['NOW'], new \DateTimeZone(date_default_timezone_get()));
            $data = new \Datetime($data, new \DateTimeZone(date_default_timezone_get()));

			if ($now < $data ) {
				$timer ='wait';
				if(!isset($pedido['NRATRAPRODITPE']) || $pedido['NRATRAPRODITPE'] == 0){
					$pedido['waiting'] = true;
				}else{
					$pedido['waiting'] = false;
				}
				$pedido['IDLIBERADO'] = "N";
			} else {
				//libera o treco.
				$pedido['IDLIBERADO'] = "S";

				$timer = $now->diff($data);
				$timer = $timer->format('1/1/1 %H:%i:%s');
	    		$pedido['waiting'] = false;
			}
	    	$pedido['timer'] = $timer;
		}

		return $pedidos;
	}

	public function getColors(Request $request, Response $response){
		try {
			$colorsParams = $this->KDSManagerService->getColourParams();
			$response->addDataSet(new DataSet('getColorsReponse', array('success' => true, 'colors'=> $colorsParams)));
		} catch (\Exception $e) {
			$this->util->logException($e->getMessage());
			$response->addDataSet(new DataSet('getColorsReponse', array('error' => true, 'message'=> $e->getMessage())));
	    }
	}

    public function generateITPEDIDOFOS(Request $request, Response $response) {
        $inputJSON = file_get_contents('php://input');
        $input = json_decode($inputJSON, TRUE);
       	$this->util->beginTransaction();
        try {
            if (empty($input)) {
                throw new \Exception('Não foram recebidos parâmetros');
            }

            //CHAVE, Chave unica do pedido a ser gerado.  VE.CDFILIAL + VE.CDCAIXA + VE.NRSEQVENDA  se for venda, VE.CDFILIAL + IT.NRSEQPRODCUP se for pedido
            //VENDA, Identificador de onde veio a venda. 'ODHENAPI' caso gerado pela api, VENDA caso balcão, COMANDA caso pedido
            //CDFILIAL, Filial relacionada ao item
            //NRPEDIDO, Chave unica do pedido a ser gerado. pode ser a CHAVE
            //DATA, data do pedido. "agora" geralmente
            //NOW, agora, mesmo
            //CDPRODUTO, codigo do produto
            //QTDEPROD, quantidade
            //CDCAIXA, caso VENDA
            //NRSEQVENDA, caso VENDA
            //NRMESA do pedido, caso haja
            //NRCOMANDAVND, NRCOMANDA caso venda.  NRCOMANDA caso pedido
            //DSCOMANDAVND, DSCOMANDAVND caso venda. DSCOMANDA caso pedido
            //NRSEQUITVEND, caso venda
            //NRCOMANDA, caso pedido. retundancia a gente ve por aqui
            //DSCOMANDA, caso pedido
            //NRVENDAREST, caso pedido
            //NRPRODCOMVEN, caso pedido
            //QTMAXPEDFOS, não sei o que é isso @lua
            //CDLOJA, codigo da loja do pedido
            //OBSDIGITADA, obeservação personalizada do pedido. DSOBSPEDDIGITA caso venda. DSOBSPEDDIGCMD caso pedido.
            //CDSENHAPED, codigo do pedido na tela do kds.
            //NMCONSUMIDOR, nome do consumidor do pedido
            //CDGRPOCOR, caso o item seja uma observação ?
            //CDOCORR, caso o item seja uma observação ?
            //CHAVEPEDIDO, CHAVE? DE NOVO!?
            //IDORIPED, K! (O kds do fos insere F)
            //NRPEDIDOFOS, null
            //NRITPEDIDOFOS, null
            //NRSEQPRODCOM, NRSEQPRODCOMIT caso venda, NRSEQPRODCOM caso pedido
            //CDPRODPROMOCAO,
            //CHAVEITEM, chave unica do item a ser inserido. IT.CDFILIAL + IT.CDCAIXA + IT.NRSEQVENDA + IT.NRSEQUITVEND caso venda,IT.CDFILIAL + IT.NRVENDAREST + IT.NRCOMANDA + IT.NRPRODCOMVEN caso pedido
            //NRATRAPROD, tempo de atraso no item, famigerado "SEGURA". NRATRAPRODITVE caso venda, NRATRAPRODCOVE caso pedido
            //NRLUGARMESA, posição na mesa


			$items = $input['items'];
			if (empty($items)) {
                throw new \Exception('Não foram recebidos items');
            }
            $requiredFields = array(
				'CHAVE',
				'VENDA',
				'CDFILIAL',
				'DATA',
				'NOW',
				'CDPRODUTO',
				'QTDEPROD',
				'CDLOJA',
				'CDSENHAPED',
				'CHAVEITEM'
			);
			$nullableFields = array(
				'CDCAIXA',
				'NRSEQVENDA',
				'NRMESA',
				'NRCOMANDAVND',
				'DSCOMANDAVND',
				'NRSEQUITVEND',
				'NRCOMANDA',
				'DSCOMANDA',
				'NRVENDAREST',
				'NRPRODCOMVEN',
				'OBSDIGITADA',
				'NMCONSUMIDOR',
				'CDGRPOCOR',
				'CDOCORR',
				'NRSEQPRODCOM',
				'CDPRODPROMOCAO',
				'NRATRAPROD',
				'NRLUGARMESA',
				'IDORIGEMVENDA',
				'IDITORIGEMVENDA',
				'TXPRODPED'
			);

			foreach ($items as &$item) {
				$item['IDORIPED'] = 'K';
				$item['NRPEDIDOFOS'] = null;
				$item['NRITPEDIDOFOS'] = null;
				try{
					$data = new \DateTime();
					$data = $data->createFromFormat('H:i:s d/m/Y', $item['DATA']);
					$item['DATA'] = $data->format('c');
					$item['DATA'] = substr($item['DATA'], 0, -6);
				}catch(\Exception $e){
				}
				try{
					$data = new \DateTime();
					$data = $data->createFromFormat('H:i:s d/m/Y', $item['NOW']);
					$item['NOW'] = $data->format('H:i:s m/d/Y');
				}catch(\Exception $e){
				}

				foreach ($requiredFields as $requiredField) {
					if(!array_key_exists($requiredField , $item) || !isset($item[$requiredField])){
						throw new \Exception('Item {$item}, sem o campo {$requiredField}. Por favor revise os dados.');
					}
				}
				foreach ($nullableFields as $nullableField) {
					if(!array_key_exists($nullableField, $item)){
						$item[$nullableField] = null;
					}
				}
			}

            $itemsForInsertion = $this->pedidoFosGenerator($items);
            if (!empty($itemsForInsertion)) {
                // ordena, define hora de exibição e insere na ITPEDIDOFOS
                $this->handleProductsForDisplay($itemsForInsertion);
            }

            $message = 'Pedidos inseridos com sucesso.';
            $response->addMessage(new Message($message, self::SUCCESS_MESSAGE));
            $this->util->commit();
        } catch (\Exception $e) {
            $this->util->rollBack();
            $message = 'Erro ao inserir pedidos. '.$e->getMessage();
            $response->addMessage(new Message($message, self::ERROR_MESSAGE));
        }
	}
	public function generateDumbITPEDIDOFOS(Request $request, Response $response) {
        $inputJSON = file_get_contents('php://input');
        $input = json_decode($inputJSON, TRUE);
       	$this->util->beginTransaction();
        try {
            if (empty($input)) {
                throw new \Exception('Não foram recebidos parâmetros');
            }

            //CHAVE, Chave unica do pedido a ser gerado.  VE.CDFILIAL + VE.CDCAIXA + VE.NRSEQVENDA  se for venda, VE.CDFILIAL + IT.NRSEQPRODCUP se for pedido
            //VENDA, Identificador de onde veio a venda. 'ODHENAPI' caso gerado pela api, VENDA caso balcão, COMANDA caso pedido
            //CDFILIAL, Filial relacionada ao item
            //NRPEDIDO, Chave unica do pedido a ser gerado. pode ser a CHAVE
            //DATA, data do pedido. "agora" geralmente
            //NOW, agora, mesmo
            //CDPRODUTO, codigo do produto
            //QTDEPROD, quantidade
            //CDCAIXA, caso VENDA
            //NRSEQVENDA, caso VENDA
            //NRMESA do pedido, caso haja
            //NRCOMANDAVND, NRCOMANDA caso venda.  NRCOMANDA caso pedido
            //DSCOMANDAVND, DSCOMANDAVND caso venda. DSCOMANDA caso pedido
            //NRSEQUITVEND, caso venda
            //NRCOMANDA, caso pedido. retundancia a gente ve por aqui
            //DSCOMANDA, caso pedido
            //NRVENDAREST, caso pedido
            //NRPRODCOMVEN, caso pedido
            //QTMAXPEDFOS, não sei o que é isso @lua
            //CDLOJA, codigo da loja do pedido
            //OBSDIGITADA, obeservação personalizada do pedido. DSOBSPEDDIGITA caso venda. DSOBSPEDDIGCMD caso pedido.
            //CDSENHAPED, codigo do pedido na tela do kds.
            //NMCONSUMIDOR, nome do consumidor do pedido
            //CDGRPOCOR, caso o item seja uma observação ?
            //CDOCORR, caso o item seja uma observação ?
            //CHAVEPEDIDO, CHAVE? DE NOVO!?
            //IDORIPED, K! (O kds do fos insere F)
            //NRPEDIDOFOS, null
            //NRITPEDIDOFOS, null
            //NRSEQPRODCOM, NRSEQPRODCOMIT caso venda, NRSEQPRODCOM caso pedido
            //CDPRODPROMOCAO,
            //CHAVEITEM, chave unica do item a ser inserido. IT.CDFILIAL + IT.CDCAIXA + IT.NRSEQVENDA + IT.NRSEQUITVEND caso venda,IT.CDFILIAL + IT.NRVENDAREST + IT.NRCOMANDA + IT.NRPRODCOMVEN caso pedido
            //NRATRAPROD, tempo de atraso no item, famigerado "SEGURA". NRATRAPRODITVE caso venda, NRATRAPRODCOVE caso pedido
            //NRLUGARMESA, posição na mesa

			$items = $input['items'];
			if (empty($items)) {
                throw new \Exception('Não foram recebidos items');
            }
            $requiredFields = array(
				"CDFILIAL",
				"CHAVE",
				"CDSETOR",
				"CDLOJA",
				"CDSENHAPED",
				"CDPRODUTO",
				"QTPRODPEFOS",
				"NRTEMPOPROD",
				"NRTEMPOEXIB"
			);
			$nullableFields = array(
				'NRMESA',
				"NRLUGARMESAIT",
				'NMCONSUMIDOR',
				'NRSEQVENDA',
				'NRSEQPRODCOMKDS',
				'CDPRODPROMOKDS',
				'CDPRODUTOPAI',
				'DSCHAVEPEDPAI',
				'CDOCORR',
				'CDGRPOCOR',
				'NRPRODCOMVEN',
				'NRCOMANDA',
				'NRVENDAREST',
				'NRSEQUITVEND',
				'NRSEQVENDA',
				'CDCAIXA',
				'CDPRODPROMOCAO',
				'QTMAXPEDFOS',
				"TXPRODPED",
				"DSCOMANDA"
			);

			foreach ($items as &$item) {
				foreach ($requiredFields as $requiredField) {
					if(!array_key_exists($requiredField , $item) || !isset($item[$requiredField])){
						if($requiredField == 'CHAVE') {
							throw new \Exception("Um pedido sem chave foi recebido. Por favor revise os dados.");
						} else {
							throw new \Exception("Item {$item['CHAVE']}, sem o campo $requiredField. Por favor revise os dados.");
						}
					}
					if($requiredField == 'QTPRODPEFOS' && $item[$requiredField] <=0 ) {
						throw new \Exception("Quantidade do pedido inserido deve ser maior que zero.");
					}
				}
				foreach ($nullableFields as $nullableField) {
					if(!array_key_exists($nullableField, $item)){
						$item[$nullableField] = null;
					}
				}
			}

            $itemsForInsertion = $this->dumbPedidoFosGenerator($items);
            if (!empty($itemsForInsertion)) {
                // ordena, define hora de exibição e insere na ITPEDIDOFOS
                $this->handleProductsForDisplay($itemsForInsertion);
            }

            $message = 'Pedidos inseridos com sucesso.';
            $response->addMessage(new Message($message, self::SUCCESS_MESSAGE));
            $this->util->commit();
        } catch (\Exception $e) {
            $this->util->rollBack();
            $message = 'Erro ao inserir pedidos. '.$e->getMessage();
            $response->addMessage(new Message($message, self::ERROR_MESSAGE));
        }
	}

	private function dumbPedidoFosGenerator ($items){
		foreach($items as $item){
			$CDFILIAL = $item['CDFILIAL'];
			$CDPRODUTO = $item['CDPRODUTO'];
			$QTPRODPEFOS = $item['QTPRODPEFOS'];
			$CDCAIXA = $item['CDCAIXA'];
			$NRSEQVENDA = $item['NRSEQVENDA'];
			$NRSEQUITVEND = $item['NRSEQUITVEND'];
			$NRVENDAREST = $item['NRVENDAREST'];
			$NRCOMANDA = $item['NRCOMANDA'];
			$NRPRODCOMVEN = $item['NRPRODCOMVEN'];
			$TXPRODPED = !empty($item['TXPRODPED']) ? $item['TXPRODPED']:  null;
			$CDSETOR = $item['CDSETOR'];
			$CDGRPOCOR = $item['CDGRPOCOR'];
			$CDOCORR = $item['CDOCORR'];
			$DSCHAVEPEDPAI = $item['DSCHAVEPEDPAI'];
			$CDPRODUTOPAI = $item['CDPRODUTOPAI'];
			$CDPRODPROMOKDS = $item['CDPRODPROMOKDS'];
			$NRSEQPRODCOMKDS = $item['NRSEQPRODCOMKDS'];
			$NRTEMPOPROD = $item['NRTEMPOPROD'];
			$NRTEMPOEXIB = $item['NRTEMPOEXIB'];
			$NRLUGARMESAIT = 0;
			$IDLIBERADO = 'N';
			$IDSTATUSPEDFOS = 'E';
			$DSTIPOPEDFOS = 'ODHENAPI';
			$NRMESA		  = $item['NRMESA'];
			$DSCOMANDA    = $item['DSCOMANDA'];
			$QTMAXPEDFOS  = $item['QTMAXPEDFOS'];
			$CDSENHAPED   = $item['CDSENHAPED'];
			$NMCONSUMIDOR = $item['NMCONSUMIDOR'];
			$IDSITITPEDFOS = '1';
			$IDATIVO       = 'S';
			$DSPEDIDOFOS   = $item['CHAVE'];
			$DSCHAVEPEDFOS = $item['CHAVE'];
			$CHAVEPEDIDO   = $item['CHAVE'];
			$NRMAIORTEMPO  = $item['NRTEMPOPROD'];
			$CDLOJA = $item['CDLOJA'];
			$DTPEDIDOFOS   = new \Datetime();
			$DTHREXIBICAOPROD = new \Datetime();
			$NRATRAPROD  = 0;
			$this->util->newCode('PEDIDOFOS' . $CDFILIAL);
			$NRPEDIDOFOS = $this->KDSManagerService->getNewCode('PEDIDOFOS' . $CDFILIAL);
			$NRPEDIDOFOS = $NRPEDIDOFOS[0]['NRSEQUENCIAL'];
			$NRPEDIDOFOS = substr($NRPEDIDOFOS, -10);
			$NRPEDIDOFOSMSDE = $NRPEDIDOFOS;
			$NRPEDIDOFOSAUX  = $NRPEDIDOFOS;
			$IDORIGEMVENDA = isset($item['IDORIGEMVENDA'])?$item['IDORIGEMVENDA']:'ODH_API';
			$this->KDSManagerService->insertOrder($CDFILIAL, $NRPEDIDOFOS, $DSPEDIDOFOS, $DSCHAVEPEDFOS, $DTPEDIDOFOS, $IDSTATUSPEDFOS,$DSTIPOPEDFOS, $NRMESA, $NRCOMANDA, $DSCOMANDA, $QTMAXPEDFOS, $CDSETOR, $NRPEDIDOFOSAUX, $CDLOJA, $CDSENHAPED, $NRPEDIDOFOSMSDE,	$NMCONSUMIDOR, $IDATIVO);
			$NRITPEDIDOFOS = $this->generateNewNRITPEDIDOFOS($CDFILIAL, $NRPEDIDOFOS);
			$this->KDSManagerService->insertOrderItem( $CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $CDPRODUTO, $QTPRODPEFOS, $CDCAIXA, $NRSEQVENDA, $NRSEQUITVEND, $NRVENDAREST, $NRCOMANDA, $NRPRODCOMVEN, $TXPRODPED, $IDSITITPEDFOS, $CDSETOR, $CDGRPOCOR, $CDOCORR, $DTHREXIBICAOPROD, $DSCHAVEPEDPAI, $CDPRODUTOPAI, $CDPRODPROMOKDS, $NRSEQPRODCOMKDS, $NRTEMPOPROD, $NRTEMPOEXIB, $NRATRAPROD, $NRLUGARMESAIT, $IDLIBERADO, $NRMAIORTEMPO, $IDORIGEMVENDA);
		}
	}

	public function getOrders($CDSETOR = null){

		// constrói os quadros da PRODUÇÃO
		// $timero = ElapsedTime::create('getOrders');
		// $timero->start();
		$productionOrders = $this->buildDataSource($CDSETOR);

		// $timer = ElapsedTime::create('buildDataSourceExpedition');
		// $timer->start();
		// constrói os dados da EXPEDIÇÃO
		$expeditionOrders = $this->buildDataSourceExpedition($CDSETOR);

		// $timer->end();
		// junta os pedidos de produção e expedição para enviar para o frontend
		$orders = array_merge($productionOrders, $expeditionOrders);

		// busca os tempos de troca de cor para cada pedido
		$orders = $this->getTimersForBoxes($orders);
		// $timero->end();
		return $orders;
	}

	public function getStatisticsFromOneClient($CDFILIAL, $CDSETOR, $socketClient){

		$newStatistics = $this->KDSManagerService->getStatisticsFromOneClient($CDFILIAL, $CDSETOR);

		if(!empty($newStatistics)){
			$packageToSend = array(
                'event' => 'sendStatistics',
                'data'  => $newStatistics
            );
			$socketClient->send(json_encode($packageToSend));
		}

	}

	public function getDataFromOneClient($CDFILIAL, $CDSETOR, $socketClient) {


		// busca os pedidos para enviar para o client que acabou de logar
		$orders = $this->getOrders($CDSETOR);

		$arrayToSend = array();

		foreach ($orders as $item) {
			$orderKey =	$item['CDFILIAL'] . '-' . $item['NRPEDIDOFOS'] . $item['items'][0]['NRITPEDIDOFOS'];
			$item['orderKey'] = $orderKey;
			$item['clientKey'] = $item['CDFILIAL'] . '-' . $item['items'][0]['CDSETOR'];
			if($item['clientKey'] == $CDFILIAL . '-' . $CDSETOR){
				if (empty($arrayToSend[$item['clientKey']])){
					// se ainda não existe o array de itens para este cliente, cria ele
					$orderArray = array(
						$item['orderKey'] => $item
					);
					$arrayToSend[$item['clientKey']] = $orderArray;
				} else {
					// se já existe o array, somente adiciona o próximo
					$arrayToSend[$item['clientKey']][$item['orderKey']] = $item;
				}
			}
		}

		if (!empty($arrayToSend)) {
			$packageToSend = array(
                'event' => 'sendChanges',
                'data'  => $arrayToSend
            );
			$socketClient->send(json_encode($packageToSend));
		}

        // busca as estatísticas para enviar para o client que acabou de logar
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':CDSETOR'  => $CDSETOR
		);

		$newStatistics = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_STATISTICS_ALL, $params);
		$arrayToSend = array();
		foreach ($newStatistics as $current) {
			$clientKey = $current['CDFILIAL'] . '-' . $current['CDSETOR'];
			if($clientKey == $CDFILIAL . '-' . $CDSETOR){
				$arrayToSend[$clientKey] = $current;
			}
		}

		if (!empty($arrayToSend)) {
			$packageToSend = array(
                'event' => 'sendStatistics',
                'data'  => $arrayToSend
            );
            $socketClient->send(json_encode($packageToSend));
		}
	}
}