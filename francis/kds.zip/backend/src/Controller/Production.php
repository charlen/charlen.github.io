<?php
namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource\DataSet;

class Production extends \Zeedhi\Framework\Controller\Simple {

	protected $KDSMessage;
	protected $util;
	protected $KDSManagerService;
	protected $entityManager;

 	public function __construct(\Util\KDSMessage $KDSMessage, \Util\Util $util, \Service\KDSManager $KDSManagerService, \Doctrine\ORM\EntityManager $entityManager) {
		$this->KDSMessage        = $KDSMessage;
		$this->util              = $util;
		$this->KDSManagerService = $KDSManagerService;
		$this->entityManager 	 = $entityManager;	
	}
	
	public function getFixedSummaryItems(Request $request, Response $response){
		try {
			$params          = $request->getRow();
			$CDFILIAL        = $params['CDFILIAL'];
			$CDSETOR         = $params['CDSETOR'];
			$fixedItems = $this->KDSManagerService->getFixedSummaryItems($CDFILIAL, $CDSETOR);
			$response->addDataSet(new DataSet('summary', array('error' => false, 'fixedItems'=> $fixedItems)));
		} catch (\Exception $e) {
			$this->util->logException($e->getMessage());
			$response->addDataSet(new DataSet('summary', array('error' => true, 'message'=> $e->getMessage())));
	    }
	}

}