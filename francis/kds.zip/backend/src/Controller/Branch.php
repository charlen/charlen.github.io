<?php
namespace Controller;

use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource\DataSet;

class Branch extends \Zeedhi\Framework\Controller\Simple {

	protected $branchService;

	public function __construct(\Service\Branch $branchService) {
		$this->branchService = $branchService;
	}

	public function getBranch(Request $request, Response $response){
		try {
			$branch = $this->branchService->getBranch();

			if (empty($branch)) {
				throw new \Exception('Não existem filiais cadastradas.');
			}

		 	$response->addDataSet(new DataSet('branch', array('error' => false, 'branch'=> $branch)));
		} catch (\Exception $e) {
			$response->addDataSet(new DataSet('branch', array('error' => true, 'message'=>$e->getMessage())));
		}
	}

}