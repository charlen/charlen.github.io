<?php
namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
use Zeedhi\Framework\DataSource\DataSet;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource;


class Notification extends \Zeedhi\Framework\Controller\Simple {

    private $notificationService;

    public function __construct(\Service\Notification $notificationService){
        $this->notificationService = $notificationService;
    }

    public function notifyClient(Request\Row $request, Response $response){
        try {
			$params          = $request->getRow();
			$CDFILIAL        = $params['CDFILIAL'];
			$NRVENDAREST     = $params['NRVENDAREST'];
			$NRCOMANDA       = $params['NRCOMANDA'];
			$CDSENHAPED      = $params['CDSENHAPED'];
			$NRPEDIDOFOS     = $params['NRPEDIDOFOS'];
			$CDSETOR         = $params['CDSETOR'];
			$NRSEQVENDA      = isset($params['NRSEQVENDA'])?$params['NRSEQVENDA']:null;
			$CDCAIXA         = isset($params['CDCAIXA'])?$params['CDCAIXA']:null;
			$DOT  			 = $params['DOT'];
			$NRPRODCOMVEN = $params['NRPRODCOMVEN'];
			$notificationResponse = $this->notificationService->notifyClient($CDFILIAL, $NRVENDAREST, $NRCOMANDA, $CDSENHAPED, $CDSETOR, $NRPEDIDOFOS, $NRSEQVENDA, $CDCAIXA, $DOT, $NRPRODCOMVEN);

			$response->addDataSet(new DataSet('notifyClient', $notificationResponse));
        } catch (Exception $e) {
            $response->addDataSet(new DataSet('notifyClient', array('error' =>  true, 'message'=> $e->getMessage())));
        }
	}
}