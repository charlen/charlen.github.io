<?php
namespace Util;

class KDSMessage {

    public function getMessage($id) {
        return $this->messages[$id];
    }

    private $messages = array(
        0 => 'E-mail ou senha inválidos.',
        1 => 'Não existe operador cadastrado para o email informado.',
        2 => 'Um email foi encaminhado para o endereço informado.',
		3 => 'Operação bloqueada: Existe mais de um caixa nesta filial, do tipo "Controle de Produção", parametrizado para este setor. Para utilizar o KDS cada setor deve estar associado à apenas um caixa.',
		4 => 'Operação bloqueada: Não foi encontrado nenhum caixa desta filial, do tipo "Controle de Produção", parametrizado para este setor.',
		5 => 'Operação concluida.',
		6 => "O setor informado não está associado à filial.",
		7 => 'Existe mais de uma filial parametrizada.'
    );

}
