<?php

namespace Util;

class OrderStash {

    protected $ordersIndexedByKey = array();

    public function __construct(){}

    //this also updates
    public function insertOrder($order) {
        $this->ordersIndexedByKey[$this->buildOrderKey($order)] = $order;
    }

    public function getAllOrders() {
        return $this->ordersIndexedByKey;
    }

    public function getOrder($orderKey) {
        if(isset($this->ordersIndexedByKey[$orderKey])){
            $order = $this->ordersIndexedByKey[$orderKey];
        } else {
            $order = null;
        }
        return $order;
    }

    public function checkOrder($orderKey) {
        return $this->getOrder($orderKey) != null;
    }

    public function deleteOrder($orderKey) {
        unset($this->ordersIndexedByKey[$orderKey]);
    }

    public function deleteAllOrders(){
        $this->ordersIndexedByKey = array();
    }
    // clone of generateRequestKey from checkforupdate
    private function buildOrderKey($order) {
        return $order['CDFILIAL'] . '-' . $order['NRPEDIDOFOS'] . $order['items'][0]['NRITPEDIDOFOS'];
    }

    // It'll return the result if arrays are equal or different
    public function orderHasChanged($newOrder) {
        return true;
/*
        $orderKey = $this->buildOrderKey($newOrder);

        $oldOrder = $this->getOrder($orderKey);
        if(isset($oldOrder)){
            // Clean properties that'll be always different
            $this->prepareOrdersToCompare($oldOrder, $newOrder);

            // Check properties from this two arrays to check if they're equal of different
            foreach ($oldOrder as $oldOrderProperty => $oldOrderPropertyValue) {
                // check if current position isn't an array (items)
                if (!is_array($oldOrderPropertyValue)) {
                    // if it's not an array it checks current property
                    if (isset($newOrder[$oldOrderProperty]) && $oldOrderPropertyValue != $newOrder[$oldOrderProperty]) {
                        // means that orders are different
                        return true;
                    }
                } else {
                    if ((count($oldOrderPropertyValue)) == (count($newOrder[$oldOrderProperty]))) {
                        // if it's an array do a foreach and check every property from the array
                        $oldItems = $oldOrderPropertyValue;
                        $newItems = $newOrder[$oldOrderProperty];
                        for ($idx = 0; $idx < count($oldItems); $idx++) {
                            foreach ($oldItems[$idx] as $oldItemProperty => $oldItemPropertyValue) {
                                if ($oldItemPropertyValue != $newItems[$idx][$oldItemProperty]) {
                                    return true;
                                }
                            }
                        }
                    } else {
                        return true;
                    }
                }
            }

        }
        else
        {
            return true;
        }

        // means that orders are equal
        return false;*/
    }

    public function prepareOrdersToCompare(&$oldOrder, &$newOrder) {
/*        $oldOrder['DTULTATU'] = null;
        $oldOrder['NOW'] = null;
        $oldOrder['LASTUPDATE'] = null;
        $oldOrder['DTULTATU_ITEMS'] = null;
        $oldOrder['SOMAHORAMAIORTEMPO'] = null;
        $oldOrder['timer'] = null;
        empty($oldOrder['ARRAYLABELCANC'])? $oldOrder['ARRAYLABELCANC'] = null:$oldOrder['ARRAYLABELCANC'] = $oldOrder['ARRAYLABELCANC'];

        foreach ($oldOrder['items'] as &$oldOrderItem) {
            $oldOrderItem['DTULTATU'] = null;
            $oldOrderItem['SOMAHORAMAIORTEMPO'] = null;
            $oldOrderItem['NOW'] = null;
            $oldOrderItem['LASTUPDATE'] = null;
            $oldOrderItem['DTULTATU_ITEMS'] = null;
            empty($oldOrderItem['ARRAYLABELCANC'])? $oldOrderItem['ARRAYLABELCANC'] = null:$oldOrderItem['ARRAYLABELCANC'] = $oldOrderItem['ARRAYLABELCANC'];
        }

        $newOrder['DTULTATU'] = null;
        $newOrder['NOW'] = null;
        $newOrder['LASTUPDATE'] = null;
        $newOrder['DTULTATU_ITEMS'] = null;
        $newOrder['SOMAHORAMAIORTEMPO'] = null;
        $newOrder['timer'] = null;
        empty($newOrder['ARRAYLABELCANC'])? $newOrder['ARRAYLABELCANC'] = null:$newOrder['ARRAYLABELCANC'] = $newOrder['ARRAYLABELCANC'];

        foreach ($newOrder['items'] as &$newOrderItem) {
            $newOrderItem['DTULTATU'] = null;
            $newOrderItem['SOMAHORAMAIORTEMPO'] = null;
            $newOrderItem['NOW'] = null;
            $newOrderItem['LASTUPDATE'] = null;
            $newOrderItem['DTULTATU_ITEMS'] = null;
            empty($newOrderItem['ARRAYLABELCANC'])? $newOrderItem['ARRAYLABELCANC'] = null:$newOrderItem['ARRAYLABELCANC'] = $newOrderItem['ARRAYLABELCANC'];
        }
    */
    }

}