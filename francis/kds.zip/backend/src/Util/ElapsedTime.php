<?php
namespace Util;

class ElapsedTime{
	const CREATE = 1;
	private $_name;
	private $_start;
	private static $instances = array();

	public function __construct($name = "No Name"){
		$this->_name = $name;
	}

	public function start(){
		$this->_start = microtime(true);
		return $this;
	}

	public function end(){
		$elapsedTime = number_format(microtime(true) - $this->_start, 9);
		echo "{$this->_name} Elapsed Time : {$elapsedTime}\n\r";
		return $this;
	}

	public static function create($name){
		self::$instances[$name] = new ElapsedTime($name);
		return self::$instances[$name];
	}

	public static function __callStatic ( $name , $arguments ){
		if(!isset(self::$instances[$name])){
			self::$instances[$name] = self::create($name);
		}
		return self::$instances[$name];
	}

}