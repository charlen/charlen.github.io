<?php
namespace Util;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

use Zeedhi\Framework\DB\StoredProcedure\StoredProcedure;
use Zeedhi\Framework\DB\StoredProcedure\Param;

class Util extends \Zeedhi\Framework\Controller\Simple {

	protected $instanceManager;
    protected $entityManager;
    protected $KDSMessage;

	public function __construct(\Zeedhi\Framework\DependencyInjection\InstanceManager $instanceManager, \Util\KDSMessage $KDSMessage, \Doctrine\ORM\EntityManager $entityManager) {
		$this->instanceManager = $instanceManager;
		$this->KDSMessage  = $KDSMessage;
        $this->entityManager = $entityManager;
        $this->connection    = $this->entityManager->getConnection();
    }
    
    public function factoryFromFileData(array $fileData, $destinationFolder, $ID) {
        $filePath = $destinationFolder . "\\". $ID . $fileData['name'];
        file_put_contents($filePath, base64_decode($fileData['b64File']));
    }

    public function beginTransaction(){
        $this->connection->beginTransaction();
    }
    public function commit(){
        $this->connection->commit();
    }
    public function rollBack(){
        $this->connection->rollBack();
    }
    public static function encrypt($text, $salt = 'setforms') {
        return md5('odhen'.$text.'7833');
    }

	public static function oldEncrypt($text, $salt = 'setforms') {
        return  trim(
            base64_encode(
                mcrypt_encrypt(
                    MCRYPT_RIJNDAEL_256,
                    $salt,
                    $text,
                    MCRYPT_MODE_ECB,
                    mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)
                )
            )
        );
    }

    public static function decrypt($text, $salt = 'setforms') {
        return trim(
            mcrypt_decrypt(
                MCRYPT_RIJNDAEL_256,
                $salt,
                base64_decode($text),
                MCRYPT_MODE_ECB,
                mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)
            )
        );
    }

    public function newCode($counterName, $size = '20'){
        $nrseq = null;
        $connection = $this->entityManager->getConnection();
        //$storedProcedure = $connection->e;//new StoredProcedure($connection, 'NOVO_CODIGO');
        //$storedProcedure->addParam(new Param('P_CONTADOR', Param::PARAM_INPUT, $counterName, Param::PARAM_TYPE_STR, strlen($counterName)));
        //$storedProcedure->addParam(new Param('P_SEQUENCIAL', Param::PARAM_OUTPUT, $nrseq, Param::PARAM_TYPE_INT, 20));
        $connection->executeQuery("EXECUTE NOVO_CODIGO :CDCONTADOR, '', :QTDE", array('CDCONTADOR' => $counterName, 'QTDE' => '1'));
    }

	public function getNewCode($CDCONTADOR, $size = 20){
		$params = array(
			':CDCONTADOR' => $CDCONTADOR
		);
		$code = $this->entityManager->getConnection()->fetchAssoc(self::GET_NEW_CODE, $params);
		$code = substr($code['NRSEQUENCIAL'], strlen($code['NRSEQUENCIAL']) - $size);
		return $code;
	}    

	const GET_NEW_CODE = "
		SELECT CDCONTADOR, NRSEQUENCIAL
		  FROM NOVOCODIGO
		 WHERE CDCONTADOR = :CDCONTADOR
	";	

    public function buildInputParam ($paramName, $paramValue) {
        return new Param($paramName, Param::PARAM_INPUT, $paramValue, Param::PARAM_TYPE_STR, strlen($paramValue));
    }

    public function getOneHourInterval() {
		$interval = new \DateInterval('PT1H'); // cria intevalo de 1 hora
		$startDate = new \Datetime();
		$endDate = new \Datetime();
		$startDate->sub($interval);
		$endDate = $endDate->format('d/m/Y H:i:s');
		$startDate = $startDate->format('d/m/Y H:i:s');
		return array(
			'startDate' => $startDate,
			'endDate' => $endDate
		);
    }
    
    public function logException($info){
        //testa se a pasta existe e cria caso não exista
        $folder = substr(__DIR__, 0, 1) . ":\\TEKNISA\\kds\\logs\\";
        if (!file_exists($folder)) {
            mkdir($folder, 0777, true);
        }
        //--grava o log
        $line = date("d-m-Y H:i:s") . " - " . $info . "\n";
        $drive = substr(__DIR__, 0, 1);
        $date = date("dmY");
        file_put_contents($drive . ":\\TEKNISA\\kds\\logs\\logException" . $date . ".txt", $line, FILE_APPEND);
    }

    public function logTransferencia($info){
        //testa se a pasta existe e cria caso não exista
        $folder = substr(__DIR__, 0, 1) . ":\\TEKNISA\\kds\\logs\\";
        if (!file_exists($folder)) {
            mkdir($folder, 0777, true);
        }
        //--grava o log
        $line = date("d-m-Y H:i:s") . " - " . $info . "\n";
        $drive = substr(__DIR__, 0, 1);
        $date = date("dmY");
        file_put_contents($drive . ":\\TEKNISA\\kds\\logs\\logTransferencia" . $date . ".txt", $line, FILE_APPEND);
    }

    public function logUpdate($info){
        //testa se a pasta existe e cria caso não exista
        $folder = substr(__DIR__, 0, 1) . ":\\TEKNISA\\kds\\logs\\";
        if (!file_exists($folder)) {
            mkdir($folder, 0777, true);
        }
        //--grava o log
        $line = date("d-m-Y H:i:s") . " - " . $info . "\n";
        $drive = substr(__DIR__, 0, 1);
        $date = date("dmY");
        file_put_contents($drive . ":\\TEKNISA\\kds\\logs\\logUpdate" . $date . ".txt", $line, FILE_APPEND);
    }

	public function logTemp($info){
        //testa se a pasta existe e cria caso não exista
        $folder = substr(__DIR__, 0, 1) . ":\\TEKNISA\\kds\\logs\\";
        if (!file_exists($folder)) {
            mkdir($folder, 0777, true);
        }
        //--grava o log
        $line = date("d-m-Y H:i:s") . " - " . $info . "\r\n";
        $drive = substr(__DIR__, 0, 1);
        $date = date("dmY");
        file_put_contents($drive . ":\\TEKNISA\\kds\\logs\\logTemp" . $date . ".txt", $line, FILE_APPEND);
    }
    public function directoryCheck($directory){
        
        if ( !is_dir($directory) && ! @mkdir($directory, 0777, true)) {
            throw new \InvalidArgumentException(sprintf(
                'O diretório "%s" não pode ser criado.',
                $directory
            ));
        }

        if ( ! is_writable($directory)) {
            throw new \InvalidArgumentException(sprintf(
                'O diretório "%s" não pode tem permissão de escrita.',
                $directory
            ));
        }
    }

    public function getParameter($p){
        return $this->instanceManager->getParameter($p);
    }
}