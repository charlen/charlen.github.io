<?php

namespace Service;

use WebSocket\Client;

class MessageService {

	protected  $entityManager;
	protected  $util;

	public function __construct(
		\Doctrine\ORM\EntityManager $entityManager, \Util\Util $util, $wsport) {

		$this->entityManager = $entityManager;
		$this->util = $util;
		$this->wsport = $wsport;
		$this->connectedWebSocket();
		$this->NRHORAANTERIOR = 0;
	}

	public function connectedWebSocket() {
		if(!isset($this->socketClient) || !$this->socketClient->isConnected()){
			$this->socketClient = new Client("ws://localhost:".$this->wsport."/");
		}
	}
	const DIRECTORY = __DIR__."\\..\\..\\sounds";
	public  function getMessages(){
		try {
			$now = new \DateTime();
			$NRHORA = ((int)$now->format('G')*60)+(int)$now->format('i');
			if($this->NRHORAANTERIOR == 0 || $NRHORA == 0 || $NRHORA > $this->NRHORAANTERIOR){
				if($NRHORA == 0){
					$this->NRHORAANTERIOR = -1;
				}
		        $this->deactivateOldMessages();
				$params =  array(
					'NRDIA' => ($now->format('N')%7) + 1,//não mais ISO, seguindo a modelagem
					'NRHORA' => $NRHORA,
					'NRHORAANTERIOR' => $this->NRHORAANTERIOR,
					'CDSETOR' => null
				);
				$messages = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_KDS_MESSAGES, $params);
				$this->NRHORAANTERIOR = $NRHORA;
				if (count($messages) > 0) {
					$indexedNewMessages = array();
					foreach ($messages as $message) {
						if (!empty($message["NMARQUIVO"])){
				            if(!file_exists(self::DIRECTORY)){
				                $this->util->directoryCheck(self::DIRECTORY);
				            }
							$soundDirectory = realpath(self::DIRECTORY);
				            $pathArquivo = $soundDirectory.'\\'.$message["CDARQUIVO"].$message["NMARQUIVO"];
				            if(!file_exists($pathArquivo)){
					            $sound = array(
						            'b64File' => (string)($this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_ARQUIVO, array('CDARQUIVO' => $message["CDARQUIVO"]))["ARQUIVO"]),
									'name' => $message["NMARQUIVO"],
									'size' => '1'
					            );

				            	$file = $this->util->factoryFromFileData($sound, $soundDirectory, $message["CDARQUIVO"]);
				            }
				            $pathArquivo = str_replace('\\', "/", $pathArquivo);
				            $message['sound'] = $pathArquivo;
						} else {
							$message['sound'] = null;
						}

						if(isset($message['NRREPTINTERV']) && $message['NRREPTINTERV']> 0 && $message['NRQTDREPTINTERV'] == '0'){
							$message['NRQTDREPTINTERV'] = round((1440 - $NRHORA)/$message['NRREPTINTERV']);
						}
						$message['timeout'] = 0; 
						$message['NOW'] = $NRHORA;
						$clientKey = $message['CDFILIAL'] . '-' . $message['CDSETOR'];
						// indexa por client key
						$indexedNewMessages[$clientKey][] = $message;
					}
		        	// cria um payload e envia pro socket sendStatistics
		            $newMessage = array(
		                'event' => 'newMessage',
		                'data'  => $indexedNewMessages
		            );

		            $this->sendToBrowser($newMessage);
		        }
		    }
		} catch (Exception $e) {
			$this->util->logException($e->getMessage());
		}
	}

	public function sendToBrowser($packageToSend){
		$this->socketClient->send(json_encode($packageToSend));
	}

	public function sendDeletedMessagesToBrowser($messages){
		$deleteMessage = array(
            'event' => 'deleteMessage',
            'data'  => $messages
        );
        $this->sendToBrowser($deleteMessage);
	}

	public function deactivateOldMessages(){
		$now = new \DateTime();
		$NRHORA = ((int)$now->format('G')*60)+(int)$now->format('i');
		$messages = $this->getOldMessages();
		foreach ($messages as $message) {
			if($message['IDREPETEDIAS'] == 'N'){
				if(($message['IDREPETINDEF'] == 'S' && $NRHORA == 12*60+59) ||
				    (intval($message['NRREPTINTERV']) > 0 && ((intval($message['NRQTDREPTINTERV']) * intval($message['NRREPTINTERV'])) + intval($message['NRHORA']) < $NRHORA))){
					$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_KDS_MESSAGE, $message);
				}
			}
		} 
	}
	
	public function getOldMessages($CDSETOR = null){
		$now = new \DateTime();
		$params =  array(
			'NRDIA' => ($now->format('N')%7) + 1,//não mais ISO, seguindo a modelagem
			'NRHORA' => ((int)$now->format('G')*60)+(int)$now->format('i'),
			'NRHORAANTERIOR' => -1,
			'CDSETOR' => $CDSETOR
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_KDS_MESSAGES, $params);
	}

	public function getAndSendOldMessages($CDSETOR, $socketClient){
		$messages = $this->getOldMessages($CDSETOR);
		$messagesToSend = array();
		$now = new \DateTime();
		$NRHORA = ((int)$now->format('G')*60)+(int)$now->format('i');
        foreach ($messages as $message) {
			if(($message['IDREPETINDEF'] == 'S') || ((intval($message['NRQTDREPTINTERV']) * intval($message['NRREPTINTERV']) + intval($message['NRHORA'])) > $NRHORA)){
					if (!empty($message["NMARQUIVO"])){
			            if(!file_exists(self::DIRECTORY)){
			                $this->util->directoryCheck(self::DIRECTORY);
			            }
						$soundDirectory = realpath(self::DIRECTORY);
			            $pathArquivo = $soundDirectory.'\\'.$message["CDARQUIVO"].$message["NMARQUIVO"];
			            if(!file_exists($pathArquivo)){
				            $sound = array(
					            'b64File' => (string)($this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_ARQUIVO, array('CDARQUIVO' => $message["CDARQUIVO"]))["ARQUIVO"]),
								'name' => $message["NMARQUIVO"],
								'size' => '1'
				            );

			            	$file = $this->util->factoryFromFileData($sound, $soundDirectory, $message["CDARQUIVO"]);
			            }
			            $pathArquivo = str_replace('\\', "/", $pathArquivo);
			            $message['sound'] = $pathArquivo;
					} else {
						$message['sound'] = null;
					}

					if(isset($message['NRREPTINTERV']) && 
					  (intval($message['NRREPTINTERV']) > 0 && ($message['NRQTDREPTINTERV'] == '0' || $message['IDREPETINDEF'] == 'S'))){
						$message['NRQTDREPTINTERV'] = round((1440 - $NRHORA)/(intval($message['NRREPTINTERV'])));
					}
					$message['NOW'] = $NRHORA;
					$timeout = 0;
					if($message['NRQTDREPTINTERV'] > 0){
						$timeout = $message['NRREPTINTERV'] - ((($message['NOW'] - intval($message["NRHORA"])) % intval($message['NRREPTINTERV'])));
					}
					$message['timeout'] = $timeout; 
					array_push($messagesToSend, $message);
			}				
		} 
        if (!empty($messagesToSend)) {
			$packageToSend = array(
                'event' => 'newMessage',
                'data'  => array($message['CDFILIAL'] . '-' . $message['CDSETOR'] => $messagesToSend)
            );
			$socketClient->send(json_encode($packageToSend));
		}
	}	
	

}