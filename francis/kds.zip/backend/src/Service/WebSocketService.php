<?php

namespace Service;

class WebSocketService {

	protected $entityManager;
	protected $util;

	public function __construct(
		\Doctrine\ORM\EntityManager $entityManager,
		\Util\Util $util) {

		$this->entityManager = $entityManager;
		$this->util = $util;
	}

	public function playItem($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$operationParams = array(
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		$operation = array(
			'operation' => 'playItem',
			'params'   => $operationParams
		);
		$operation = json_encode($operation);
		$params = array(
			':NRSEQOPERACAO' => $this->getNewKDSOPERACAOTEMP(),
			':DSOPERACAO'    => $operation
		);
		$this->entityManager->getConnection()->executeQuery(self::INSERT_KDSOPERACAOTEMP, $params);
	}

	public function concludeItem($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $IDSITITPEDFOS) {
		$operationParams = array(
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS,
			'IDSITITPEDFOS' => $IDSITITPEDFOS
		);
		$operation = array(
			'operation' => 'concludeItem',
			'params'   => $operationParams
		);
		$operation = json_encode($operation);
		$params = array(
			':NRSEQOPERACAO' => $this->getNewKDSOPERACAOTEMP(),
			':DSOPERACAO'    => $operation
		);
		$this->entityManager->getConnection()->executeQuery(self::INSERT_KDSOPERACAOTEMP, $params);
 	}

	public function expediteOrder($CDFILIAL, $CDSETOR, $itemsArray) {
		$operationParams = array(
			'CDFILIAL'   => $CDFILIAL,
			'CDSETOR'    => $CDSETOR,
			'itemsArray' => $itemsArray
		);
		$operation = array(
			'operation' => 'expediteOrder',
			'params'   => $operationParams
		);
		$operation = json_encode($operation);
		$params = array(
			':NRSEQOPERACAO' => $this->getNewKDSOPERACAOTEMP(),
			':DSOPERACAO'    => $operation
		);
		$this->entityManager->getConnection()->executeQuery(self::INSERT_KDSOPERACAOTEMP, $params);
 	}

 	public function getDataFromOneClient($CDFILIAL, $CDSETOR) {
		$operationParams = array(
			'CDFILIAL'   => $CDFILIAL,
			'CDSETOR'    => $CDSETOR
		);
		$operation = array(
			'operation' => 'getDataFromOneClient',
			'params'   => $operationParams
		);
		$operation = json_encode($operation);
		$params = array(
			':DSOPERACAO'    => $operation
		);
		$notExists = empty($this->entityManager->getConnection()->fetchAssoc(self::GET_KDSOPERACAOTEMP_BY_DSOPERACAO, $params));
		if($notExists){
			$params[':NRSEQOPERACAO'] = $this->getNewKDSOPERACAOTEMP();

			$this->entityManager->getConnection()->executeQuery(self::INSERT_KDSOPERACAOTEMP, $params);
		}
	 } 

 	private function getNewKDSOPERACAOTEMP() {
        $this->util->newCode('KDSOPERACAOTEMP');
		return $this->util->getNewCode('KDSOPERACAOTEMP', 10);
    }

	public function clearRequestsScreen($CDFILIAL, $NRHORA) {
		$operationParams = array(
			'CDFILIAL' => $CDFILIAL,
			'NRHORA' => $NRHORA
		);
		$operation = array(
			'operation' => 'clearRequestsScreen',
			'params' => $operationParams
		);
		$operation = json_encode($operation);
		$params = array(
			':DSOPERACAO'    => $operation
		);

		$notExists = empty($this->entityManager->getConnection()->fetchAssoc(self::GET_KDSOPERACAOTEMP_BY_DSOPERACAO, $params));
		if($notExists){
			$params[':NRSEQOPERACAO'] = $this->getNewKDSOPERACAOTEMP();

			$this->entityManager->getConnection()->executeQuery(self::INSERT_KDSOPERACAOTEMP, $params);
		}
 	}

	const INSERT_KDSOPERACAOTEMP = "
		INSERT INTO KDSOPERACAOTEMP
		(NRSEQOPERACAO, DSOPERACAO)
		VALUES
		(:NRSEQOPERACAO, :DSOPERACAO)
	";

	const GET_KDSOPERACAOTEMP_BY_DSOPERACAO = "
		SELECT NRSEQOPERACAO, DSOPERACAO
		  FROM KDSOPERACAOTEMP
		 WHERE DSOPERACAO = :DSOPERACAO
	";
}