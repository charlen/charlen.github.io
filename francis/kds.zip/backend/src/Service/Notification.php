<?php

namespace Service;

class Notification {

	protected $entityManager;
	protected $util;

	public function __construct(
		\Doctrine\ORM\EntityManager $entityManager,
		\Util\Util $util,
		$endPointPushNotification,
		$endPointPagerNotification,
		$endPointVoiceNotification,
		$useCallByName) {

		$this->entityManager = $entityManager;
		$this->util = $util;
		$this->endPointPushNotification  = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_INTEGRATION_ADDRESS);
		$this->endPointPagerNotification = isset($this->endPointPushNotification['DSWSINTEGRAPAGER']) ? $this->endPointPushNotification['DSWSINTEGRAPAGER'] : $endPointPagerNotification;
		$this->endPointPushNotification  = isset($this->endPointPushNotification['DSWSINTEGRAAPP']) ? $this->endPointPushNotification['DSWSINTEGRAAPP'] : $endPointPushNotification;
		$this->endPointVoiceNotification = $endPointVoiceNotification;
		$this->useCallByName = $useCallByName;
	}

	public function notifyClient($CDFILIAL, $NRVENDAREST, $NRCOMANDA, $CDSENHAPED, $CDSETOR, $NRPEDIDOFOS, $NRSEQVENDA = 0, $CDCAIXA = 0, $dot, $NRPRODCOMVEN) {

		$this->imprimeCupom($NRVENDAREST, $CDFILIAL);

		$params = array(
			'CDFILIAL' => $CDFILIAL,
			'CDSETOR' => $CDSETOR
		);

		$return = [];

		$displayPainel = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::VERIFICA_DISPLAY_NOTIFICATION, $params);
		$notifyByPanel = $displayPainel['IDUTLINTPAINEL'] == 'S' ? true : false;
		$notifyByPager = $displayPainel['IDHABWSPAGER']   == 'S' ? true : false;

		if ($notifyByPager === true) {
			// --- Sale customer notification by pager or push
			if (empty($NRVENDAREST) && !empty($CDSENHAPED)) {
				try {
					$this->notifyCostumerPager(intval($CDSENHAPED));
					$return['pager'] = array('error' => false, 'message' => 'Cliente notificado por pager!');
				} catch (\Throwable $th) {
					$return['pager'] = array('error' => true, 'message' => 'Não foi possível notificar o pager.');
				}				 
			} else {
				$params = array(
					'CDFILIAL'    => $CDFILIAL,
					'NRVENDAREST' => $NRVENDAREST
				);


				$saleOrigin = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_SALE_ORIGIN, $params);

				if (!empty($saleOrigin)) {
					try {
						$this->notifyCostumerPager(intval($CDSENHAPED));
						$return['pager'] = array('error' => false, 'message' => 'Cliente notificado por pager!');
					} catch (\Throwable $th) {
						$return['pager'] = array('error' => true, 'message' => 'Não foi possível notificar o pager.');
					}
				} else {
					$consumerDetails = $this->getExternalCode($NRVENDAREST, $CDFILIAL);
					if ($consumerDetails['NRCOMANDAEXT']) {
						try {
							$this->sendCostumerNotification($consumerDetails['NRCOMANDAEXT']);
							$return['pager'] = array('error' => false, 'message' => 'Cliente notificado por pager!');
						} catch (\Throwable $th) {
							$return['pager'] = array('error' => true, 'message' => 'Não foi possível notificar o pager.');
						}
					}
				}
			}
			$p_order = array(
				'CDFILIAL' => $CDFILIAL,
				'NRPEDIDOFOS'  => $NRPEDIDOFOS
			);
			$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_ORDER_DTHRPRIEXPED, $p_order);
		}
		$p_key = array(
			'CDFILIAL'     => $CDFILIAL,
			'CDCAIXA'      => $CDCAIXA,
			'NRVENDAREST'  => $NRVENDAREST,
			'NRCOMANDA'    => $NRCOMANDA,
			'NRSEQVENDA'   => $NRSEQVENDA,
			'NRPEDIDOFOS'  => $NRPEDIDOFOS
		);
		$venda_data = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_VENDA_KEY, $p_key);

		if(empty($venda_data)){
			$params = Array(
				'NRPEDIDOFOS' => $NRPEDIDOFOS
			);
			$venda_data = array();
			$venda_data['NMCONSUMIDOR'] = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_NMCONSUMIDOR_BY_NRPEDIDOFOS, $params); //Buscar pela nrpedidofos
			$venda_data['NRSEQVENDA'] = $NRPEDIDOFOS.$NRVENDAREST.$NRCOMANDA.$NRPRODCOMVEN;
		}



		if ($notifyByPanel === true) {

			// Print notification by panel			
			if(!empty($venda_data)){
				if($NRCOMANDA != ''){
					$params_cdloja = Array('NRCOMANDA'=>$NRCOMANDA);
					$caixa = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_ANY_CDCAIXA_BY_NRCOMANDA, $params_cdloja)['CDCAIXA'];
					if(empty($caixa)){
						$params_cdloja = Array('NRCOMANDAVND'=>$NRCOMANDA);
						$caixa = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_ANY_CDCAIXA_BY_NRCOMANDAVND, $params_cdloja)['CDCAIXA'];
					}
					$venda_data['CDCAIXA'] = $caixa;
				}

				$params = array(
					'CDFILIAL' => $CDFILIAL,
					'CDCAIXA' => $venda_data['CDCAIXA'],
					'NRSEQVENDA' => $venda_data['NRSEQVENDA'],
					'CDSENHAPED' => $CDSENHAPED,
					'NRPEDIDOFOS'  => $NRPEDIDOFOS
				);

				$notifyExists = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::VERIFY_NOTIFICATION_EXISTS, $params);
				$removedExists = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::VERIFY_REMOVED_EXISTS, $params);
				if($removedExists['COUNT'] > 0 && $dot == false){
					$params['IDSTATUS'] ='C';
					$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_STATUS_SENHAPED, $params);
					$return['painel'] = array('error' => false, 'message' => 'Senha Removida do Painel');
				} else {
					if($notifyExists['COUNT'] > 0){
						$params['IDSTATUS'] ='A';
						$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_STATUS_SENHAPED, $params);
						if($dot == false){
							$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_ORDER_DTHRPRIEXPED, $params);
						}
						$return['painel'] = array('error' => false, 'message' => 'Cliente notificado via painel!');
					} else {
						$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_ORDER_DTHRPRIEXPED, $params);

						//Inserção solicitada pelo junior
						if($dot == false){
							$return['painel'] = array('error' => true, 'message' => 'Entrega direta ao consumidor sem notificação');
						} else {
							$this->entityManager->getConnection()->executeQuery(\Util\Query::INSERT_PASSWORD_DISPLAY_NOTIFICATION, $params);
							$return['painel'] = array('error' => false, 'message' => 'Consumidor notificado via painel!');
						}
					}
				}
			} else{
				$return['painel'] = array('error' => true, 'message' => 'Venda não é do tipo balcão para poder usar o painel de senhas.');
			}
		}

		if ($this->useCallByName === true && isset($this->endPointVoiceNotification)) {
			if($dot == false){
				$return['voz'] = array('error' => true, 'message' => 'Entrega direta: Cliente não foi chamado por voz');
			} else if(isset($venda_data['NMCONSUMIDOR']) && $venda_data['NMCONSUMIDOR'] != ''){
				try {
					$voz = $this->callMeByMyName($venda_data['NMCONSUMIDOR']);
					if ($voz == 'OK'){
						$return['voz'] = array('error' => false, 'message' => 'Cliente notificado por voz!');
					}
				} catch (\Throwable $th) {
					$return['voz'] = array('error' => true, 'message' => 'Não foi possível acessar a API de voz');
				}
			}
			$p_order = array(
				'CDFILIAL' => $CDFILIAL,
				'NRPEDIDOFOS'  => $NRPEDIDOFOS
			);
			$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_ORDER_DTHRPRIEXPED, $p_order);
		}

		if (sizeof($return)){
			return $return;
		}

		return array('error' => false, 'message' => 'Não há sistema de notificação parametrizado');
	}

	public function imprimeCupom($NRVENDAREST, $CDFILIAL) {
		// --- Automatic sale generation by FOS
		$paramsIdimpcupexp = array(
			':CDFILIAL' => $CDFILIAL,
			':NRVENDAREST' => $NRVENDAREST
		);

		$sale = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_SALE_IDIMPCUPEXP, $paramsIdimpcupexp);

		if($sale){
			// --- Checks if the KDS needs to change the automatic sale generation parameter value
			if($sale['IDIMPCUPEXP'] == '1'){
				$paramsIdimpcupexp = array(
					':CDFILIAL' => $CDFILIAL,
					':NRVENDAREST' => $NRVENDAREST,
					':IDIMPCUPEXP' => '2'
				);
				$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_SALE_IDIMPCUPEXP, $paramsIdimpcupexp);
			}
		}
	}


	public function getExternalCode($NRVENDAREST, $CDFILIAL) {
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':NRVENDAREST' => $NRVENDAREST
		);
		return $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_EXTERNAL_CODE, $params);
	}

	private function sendCostumerNotification($NRCOMANDAEXT){
		try {
			$method = 'POST';
			$header_params = array (
				'Content-Type:application/json',
				'ZUMO-API-VERSION:2.0.0',
				'RM-EXT-KEY:773d8f0d6f1a679634187f51335a8b76'
			);
			$curl_parameters = array (
				'CodComanda' => $NRCOMANDAEXT
			);
			$curl_parameters = json_encode($curl_parameters);
			return $this->executeWebService($this->endPointPushNotification, $method, $curl_parameters, $header_params);
		} catch(\Exception $e){
			$this->util->logException($e->getMessage());
			throw new \Exception($e->getMessage());
		}
	}

	private function callMeByMyName($NMCONSUMIDOR){
		try {
			$method = 'POST';
			$header_params = array (
				'Content-Type:application/json'
			);
			$curl_parameters = array (
				'text' => $NMCONSUMIDOR
			);

			$curl_parameters = json_encode($curl_parameters);
			return $this->executeWebService($this->endPointVoiceNotification, $method, $curl_parameters, $header_params);
		} catch(\Exception $e){
			$this->util->logException($e->getMessage());
			throw new \Exception($e->getMessage());
		}
	}

	private function notifyCostumerPager($pagerNumber){
		try {
			if ($this->endPointPagerNotification != NULL){
				$endpoint = $this->endPointPagerNotification . $pagerNumber;
				$response = file_get_contents($endpoint);
				$response = json_decode($response, true);
				if($response != 0) {
					throw new \Exception('Erro ao tentar notificar o pager do consumidor.');
				}
			}
		} catch(\Exception $e){
			$this->util->logException($e->getMessage());
			throw new \Exception($e->getMessage());
		}
	}

	public function executeWebService($service_url, $method = 'GET', $curl_parameters = array(), $header_params = array()){
		if ($service_url!= NULL){
			// $service_url = $this->WEBSERVICE_PARAMS['SERVICE_URL'].$function;
			/* Configures cURL to execute the webservice. */
			$curl = curl_init();

			curl_setopt($curl, CURLOPT_URL, $service_url);
			curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
			curl_setopt($curl, CURLOPT_HTTPHEADER, $header_params);
			if($method == 'POST') {
				curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_parameters);
				curl_setopt($curl, CURLOPT_POST, true);
			}
			curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl, CURLOPT_TIMEOUT, 30);
			/*curl_setopt($curl, CURLOPT_PROXY, $this->WEBSERVICE_PARAMS['PROXYURL']);
			curl_setopt($curl, CURLOPT_PROXYUSERPWD, $this->WEBSERVICE_PARAMS['PROXYCREDENTIALS']);*/

			/* Executes the webservice. */
			$curl_response = curl_exec($curl);
			if (curl_errno($curl)) {
				throw new \Exception('Erro ao consumir REST api - '.curl_errno($curl));
			}
			curl_close($curl);
			return $curl_response;
		}
	}

}