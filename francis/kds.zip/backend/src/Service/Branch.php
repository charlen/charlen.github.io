<?php

namespace Service;

class Branch {
	
	protected $entityManager;

	public function __construct(\Doctrine\ORM\EntityManager $entityManager){
		$this->entityManager = $entityManager;
	}

	public function getBranch(){
		return $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_FILIAL, array());
	}
} 
