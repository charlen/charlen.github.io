<?php

namespace Service;

use WebSocket\Client;
use Zeedhi\Framework\Socket\Server\Bridge;
use Zeedhi\Framework\Socket\Server\Client\ClientInterface;
use Zeedhi\Framework\Socket\Server\Event\ConnectionEvent;
use Zeedhi\Framework\Socket\Server\Payload;
use Psr\Log\LoggerInterface;
use Zeedhi\Framework\Socket\Server\Connection\ConnectionManagerInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Util\ElapsedTime;


class CheckForUpdate extends Bridge {

	protected $KDSManagerController;
	protected $KDSTransferController;
	protected $entityManager;
	protected $instanceManager;
	protected $connection;
	protected $util;
	protected $query;
	protected $webSocketUpdateHandler;
	protected $messageService;
	protected $orderStash;

	protected $lastUpdate = null;
	protected $frozen = false;
	protected $freezeTime = null;


	public function __construct(
		ConnectionManagerInterface $connectionManager,
		EventDispatcherInterface $eventDispatcher,
		LoggerInterface $logger,
		\Controller\KDSManager $KDSManagerController,
		\Controller\KDSTransfer $KDSTransferController,
		\Doctrine\ORM\EntityManager $entityManager,
		\Zeedhi\Framework\DependencyInjection\InstanceManager $instanceManager,
		\Doctrine\DBAL\Connection $connection,
		\Util\Util $util,
		\Util\Query $query,
		\Service\WebSocketUpdateHandler $webSocketUpdateHandler,
		\Service\MessageService $messageService,
		\Util\OrderStash $orderStash,
		$wsport) {
		parent::__construct($connectionManager, $eventDispatcher, $logger);
		$this->KDSManagerController = $KDSManagerController;
		$this->KDSTransferController = $KDSTransferController;
		$this->entityManager = $entityManager;
		$this->instanceManager = $instanceManager;
		$this->util = $util;
		$this->connection = $entityManager->getConnection();
		$this->query = $query;
		$this->webSocketUpdateHandler = $webSocketUpdateHandler;
		$this->messageService = $messageService;
		$this->wsport = $wsport;
		$this->orderStash = $orderStash;
	}

	public function connectedWebSocket() {
		if(!isset($this->socketClient) || !$this->socketClient->isConnected()){
			$this->socketClient = new Client("ws://localhost:".$this->wsport."/");
			$packageToWebSocket = array(
				'event' => 'loginBrowser',
				'data'  => array(
					'CDFILIAL' => 'CHECK',
	 				'CDSETOR'  => '1',
	 				'SECURITYKEY' => 'CHECKFORUPDATES'
	 			)
			);
			$this->sendToBrowser($packageToWebSocket);
		}
	}
	public static function getSubscribedEvents() {
		return array(
			'freezeUpdates'        => array('freezeUpdates'),
			'unfreezeUpdates'      => array('unfreezeUpdates')
		);
	}

	public function checkForUpdates() {
		$this->connectedWebSocket();
		$localQuery = $this->query;

		try{
			$check_entities = [
				//Cria trigger TGR_PEDIDOFOS se não existir
                ["GET_TRIGGER_PEDIDOFOS","TGR_PEDIDOFOS"],
                //Cria trigger TGR_ITPEDIDOFOS se não existir
                ["GET_TRIGGER_ITPEDIDOFOS","TGR_ITPEDIDOFOS"],
                //Cria trigger TGR_ITPEDIDOFOSREL se não existir
                ["GET_TRIGGER_ITPEDIDOFOSREL","TGR_ITPEDIDOFOSREL"],
                //Cria trigger TRIGGER_KDSMENSAGEM_ON_DELETE se não existir
                ["GET_TRIGGER_KDSMENSAGEM_ON_DELETE","TRIGGER_KDSMENSAGEM_ON_DELETE"],
                //Cria tabela PEDIDO_KDS_TEMP se não existir
                ["GET_PEDIDO_KDS_TEMP","CREATE_PEDIDO_KDS_TEMP"],
                //Cria trigger TGR_AI_ITCOMANDAVEN_INS_PED_KDS_TMP se não existir
                ["GET_TRIGGER_AI_ITCOMANDAVEN_INS_PED_KDS_TMP","TGR_AI_ITCOMANDAVEN_INS_PED_KDS_TMP"],
                //Cria trigger TGR_AI_VENDA_INS_PED_KDS_TMP se não existir
                ["GET_TRIGGER_AI_VENDA_INS_PED_KDS_TMP","TGR_AI_VENDA_INS_PED_KDS_TMP"],
                //Cria trigger CREATE_UPDATE_PEDIDO_KDS_TEMP se não existir
                ["GET_UPDATE_PEDIDO_KDS_TEMP","CREATE_UPDATE_PEDIDO_KDS_TEMP"],
                //Cria trigger TGR_FIU_PEDIDOFOS_INS_UPD_PED_KDS_TMP se não existir
                ["GET_TRIGGER_FIU_PEDIDOFOS_INS_UPD_PED_KDS_TMP","TGR_FIU_PEDIDOFOS_INS_UPD_PED_KDS_TMP"],
                //Cria trigger TGR_FIU_ITPEDIDOFOS_INS_UPD_PED_KDS_TMP se não existir
                ["GET_TRIGGER_FIU_ITPEDIDOFOS_INS_UPD_PED_KDS_TMP","TGR_FIU_ITPEDIDOFOS_INS_UPD_PED_KDS_TMP"],
                //Cria trigger TGR_FIU_ITPEDIDOFOSREL_INS_UPD_PED_KDS_TMP se não existir
                ["GET_TRIGGER_FIU_ITPEDIDOFOSREL_INS_UPD_PED_KDS_TMP","TGR_FIU_ITPEDIDOFOSREL_INS_UPD_PED_KDS_TMP"],
                //Cria trigger TGR_FIU_ITPEDIDOFOSEST_INS_UPD_PED_KDS_TMP se não existir
                ["GET_TRIGGER_FIU_ITPEDIDOFOSEST_INS_UPD_PED_KDS_TMP","TGR_FIU_ITPEDIDOFOSEST_INS_UPD_PED_KDS_TMP"],
                //Cria ALTERS_VERSION_350 se não existir
				["GET_FIELD_NRTEMPOATRASOEXP","ALTERS_VERSION_350"],
				//Cria TGR_MOVCAIXADLV
				["GET_TGR_MOVCAIXADLV","TGR_MOVCAIXADLV"]
				
            ];

            foreach($check_entities as $actual_entity){
                $count_obj = $this->connection->fetchAll($localQuery::getConst($actual_entity[0]));

                if (count($count_obj) == 0){
                    $this->connection->executeQuery($localQuery::getConst($actual_entity[1]));
                    $this->util->logUpdate("Objeto ".$actual_entity[1]." aplicado no banco.");
                }
            }

			$filiais = $this->connection->fetchAll($localQuery::GET_FILIAL);

			if (count($filiais) > 1) {
				echo "Existe mais de uma filial cadastrada na base. Nao foi possivel inicializar o serviço.";
				$this->util->logException("Existe mais de uma filial cadastrada na base. Nao foi possivel inicializar o serviço.");
			} else {
				$CDFILIAL = $filiais[0]['CDFILIAL'];
				$noErro = true;

				//Processar posteriormente
				$afterProcess = Array();

				do {
					// $cfu_time = ElapsedTime::create("CFU");
					// $cfu_time->start();
					try {
						$this->frozen = $this->getFrozen();
						if(!$this->frozen){
							$this->connected = false;
							$params = array(
								':CDFILIAL' => $CDFILIAL
							);

							//Pega pedido_kds_temp
							$pedido_kds_temp = $this->connection->fetchAll($localQuery::SELECT_PEDIDO_KDS_TEMP, $params);


							// só executa a rotina de inserção caso existam novos pedidos
							if (!empty($pedido_kds_temp)) {

								for($i=0; $i<count($pedido_kds_temp); $i++){
									$item_pedido_kds_temp = $pedido_kds_temp[$i];

									$this->connection->executeQuery($localQuery::UPDATE_STATUS_PEDIDO_KDS_TEMP_BY_ID, $item_pedido_kds_temp);


									$this->connected = true;
									$this->connection->beginTransaction();


									if($item_pedido_kds_temp['TP_PEDIDO'] == 'VEN'){
										$newOrders = $this->connection->fetchAll($localQuery::GET_SALES_VEN, $item_pedido_kds_temp);
									} else {
										$newOrders = $this->connection->fetchAll($localQuery::GET_SALES_COM, $item_pedido_kds_temp);
									}

									if (!empty($newOrders)) {
										// insere os itens na PEDIDOFOS e ITPEDIDOFOS
										$itemsForInsertion = $this->KDSManagerController->pedidoFosGenerator($newOrders);
										if (!empty($itemsForInsertion)) {
											// ordena, define hora de exibição e insere na ITPEDIDOFOS
											$this->KDSManagerController->handleProductsForDisplay($itemsForInsertion);
										}
									}

									//Deleta pedido que já foi processado
									$this->connection->executeQuery($localQuery::DELETE_PEDIDO_KDS_TEMP_BY_ID, $item_pedido_kds_temp);
									$this->connection->commit();

									if(empty($newOrders)){
										array_push($afterProcess, $item_pedido_kds_temp['NRCOMANDA']);
									}

									$this->connected = false;
								}

							}

							$this->connected = true;
							$this->connection->beginTransaction();

							//ISSOS PODEM SER REQUISICOES
							// verifica se tem alguma transferência a ser checkForTransfersfeita
							$itemsToDeleteInFront = $this->checkForTransfers($CDFILIAL);

							// deleta os itens transferidos do front
							$this->deleteItemsInFront($itemsToDeleteInFront);


							// $init_mcr = microtime(true);
							// faz as alterações solicitadas no web socket
							$this->webSocketUpdateHandler->handleUpdates($this->socketClient);
							//die();

							//$total = number_format(microtime(true)-$init_mcr, 9);
							// $init_mcr = microtime(true);


							// $total = number_format(microtime(true)-$init_mcr, 9);
							// $init_mcr = microtime(true);

							$this->messageService->getMessages();
							$this->connection->commit();

							//ISSO PROVAVELMENTE CONTINUA
							// procura por mudanças no KDS (status, liberações, etc)
							$this->handleOrdersToSend();

							// Trigger updates for orders with payment confirmed
							if(sizeof($afterProcess)){
								foreach ($afterProcess as $key => $item) {
									$current_param = Array("NRCOMANDA" => $item);

									$ped_vnd_nrcomanda = $this->connection->fetchAll($localQuery::CHECK_NRPEDIDOFOS_NRSEQVENDA_BY_NRCOMANDA, $current_param);

									if(!empty($ped_vnd_nrcomanda[0]['NRSEQVENDA']) || !empty($ped_vnd_nrcomanda[0]['NRSEQMOVDLV'])){
										$this->connection->beginTransaction();
										$this->connection->executeQuery($localQuery::UPDATE_DTULTATU_ITPEDIDOFOS_BY_NRCOMANDA, $current_param);
										$this->connection->commit();
										unset($afterProcess[$key]);
									} else if (empty($ped_vnd_nrcomanda[0]['NRPEDIDOFOS'])){
										unset($afterProcess[$key]);
									}
								}
							}
						}

						// $cfu_time->end();
						//Resolve o problema dos pedidos presos no caixa automático que já foram expedidos
						$countPedConc = $this->connection->fetchAll($localQuery::GET_NRVENDAREST_COUNT_PEDCONC);
						if($countPedConc[0]['NUMPED'] > 0){
							$this->connection->executeQuery($localQuery::UPDATE_IDIMPCUPEXP_PEDCONC);
						}

						sleep(1);
					} catch(\Exception $e){
						$this->util->logException($e->getMessage());
						if ($this->connected){
							$this->connection->rollBack();
						}
						$this->socketClient = null;
						$this->lastUpdate = null;
						$this->orderStash->deleteAllOrders();
						sleep(1);
						$this->connectedWebSocket();
						$noErro = false;
						$this->checkForUpdates();
					}
				} while ($noErro);
			}
		} catch(\Exception $e){
			$this->util->logException($e->getMessage());
			sleep(5);
			$this->checkForUpdates();
		}
	}

	public function microtime_float()
	{
	    list($usec, $sec) = explode(" ", microtime());
	    return ((float)$usec + (float)$sec);
	}

	public function freezeUpdates(ConnectionEvent $msgEvent){
		$this->frozen = true;
		$localQuery = $this->query;
		$this->freezeTime = $this->connection->fetchAssoc("SELECT GETDATE() AS DATA")['DATA'];
		$params = array(':IDKDSHABILITADO' => 'N');
		$this->connection->executeQuery($localQuery::UPDATE_IDKDSHABILITADO, $params);
	}

	public function unfreezeUpdates(ConnectionEvent $msgEvent){
		$this->frozen = false;
		$this->lastUpdate = $this->freezeTime;
		$localQuery = $this->query;

		$params = array(':HORACONGELAMENTO' => new \Datetime($this->freezeTime), ':NRPEDIDOFOS' => 'NPRODUZIDO');
		$this->connection->executeQuery($localQuery::UPDATE_OLD_REQUESTS_VENDA, $params);
		$this->connection->executeQuery($localQuery::UPDATE_OLD_REQUESTS_COMANDA, $params);

		$params = array(':IDKDSHABILITADO' => 'S');
		$this->connection->executeQuery($localQuery::UPDATE_IDKDSHABILITADO, $params);
	}

	private function checkForTransfers($CDFILIAL) {
		$params = array(':CDFILIAL' => $CDFILIAL);
		$transfers = $this->connection->fetchAll(self::CHECK_FOR_TRANSFERS, $params);
		if (!empty($transfers)) {
			return $this->KDSTransferController->handleTransfer($transfers);
		} else {
			return array();
		}
	}

	public function compareTimers($a, $b){
		return strcmp($b['NREXIBPROD'], $a['NREXIBPROD']);
	}

	public function generateRequestKey($order){
		return $order['CDFILIAL'] . '-' . $order['NRPEDIDOFOS'] . $order['items'][0]['NRITPEDIDOFOS'];
	}

	public function insertItemsToShowOnPedidoTemp(){
		$localQuery = $this->query;
		if(!isset($this->OLDDATE)){
			$this->OLDDATE = array('OLDDATE' => null);
		}
		$this->connection->executeQuery($localQuery::UPDATE_ITPEDIDOFOS_TO_SHOW_ON_FRONT, $this->OLDDATE);

		$this->OLDDATE = $this->connection->fetchAssoc("SELECT CONVERT(DATETIME, GETDATE(), 121) AS OLDDATE");
	}

	private function handleOrdersToSend() {

		//$this->updatePedidoTemp();
		$this->insertItemsToShowOnPedidoTemp();

		$localQuery = $this->query;
		$this->connection->executeQuery($localQuery::UPDATE_STATUS_UPDATE_PEDIDO_KDS_TEMP);

		$orders = $this->KDSManagerController->getOrders();

		$orders = $this->buildOrdersToSend($orders);

		// envia os dados pro cliente
		if(!empty($orders['data'])){
			$this->sendToBrowser($orders);
		}

		//tambem usand a trigger
		$this->getStatisticsForAllClients();

		//$this->deletePedidoTemp();
		$this->connection->executeQuery($localQuery::DELETE_TREATED_UPDATE_PEDIDO_KDS_TEMP);

	}

	public  function getStatisticsForAllClients(){
		// envia estatisticas
		$params = array(
			':CDFILIAL' => 'T', // T de todos
			':CDSETOR'  => 'T' // T de todos
		);
		$newStatistics = $this->connection->fetchAll(\Util\Query::GET_STATISTICS, $params);
		if (count($newStatistics) > 0) {
			// indexa por client key
            $indexedNewStatistics = $this->indexStatisticsByClientKey($newStatistics);
        	// cria um payload e envia pro socket sendStatistics
            $sendStatistics = array(
                'event' => 'sendStatistics',
                'data'  => $indexedNewStatistics
            );
            $this->sendToBrowser($sendStatistics);
        }
	}

	private function deleteItemsInFront($itemsToDeleteInFront) {
		if (sizeof($itemsToDeleteInFront) > 0) {
			$itemsToDeleteIndexedByOrderKey = $this->indexItemsToDeleteByOrderKey($itemsToDeleteInFront);
			$itemsToDeleteIndexedByClientKey = $this->indexArrayByClientKey($itemsToDeleteIndexedByOrderKey);

			// envia pro websocket os itens que devem ser apagados do frontend
			$packageToWebSocket = array(
				'event' => 'deleteOrders',
				'data'  => $itemsToDeleteIndexedByClientKey
			);
			$this->sendToBrowser($packageToWebSocket);
		}
	}

	private function indexStatisticsByClientKey($statistics){
		$returnArray = array();
		foreach ($statistics as $current) {
			$clientKey = $current['CDFILIAL'] . '-' . $current['CDSETOR'];
			$returnArray[$clientKey] = $current;
		}
		return $returnArray;
	}

	public function indexItemsToDeleteByOrderKey($orders){
		// pedidos indexados por chave
		$currentOrders = array();

		foreach ($orders as $currentOrder) {
			$orderKey = $currentOrder['CDFILIAL'] . '-' . $currentOrder['NRPEDIDOFOS'] . $currentOrder['NRITPEDIDOFOS'];
			$currentOrders[$orderKey] = $currentOrder;
			// coloca chave do item e chave do client (browser) dentro do array de itens
			$currentOrders[$orderKey]['orderKey'] = $orderKey;
			$currentOrders[$orderKey]['clientKey'] = $currentOrder['CDFILIAL'] . '-' . $currentOrder['CDSETOR'];
		}
		return $currentOrders;
	}

	public function sendToBrowser($packageToSend){
		$this->socketClient->send(json_encode($packageToSend));
	}

	private function buildOrdersToSend($orders) {
		// pedidos que foram alterados, serão enviados para o frontend
		$ordersThatChanged = array();

		// indexa o array pela chave do pedido
		$currentOrders = $this->indexOrdersByOrderKey($orders);

		foreach ($currentOrders as $key => $order) {
			if ($this->orderStash->orderHasChanged($order)) {
				// preenche array com os pedidos e itens que mudaram para mandar pro frontend
				$ordersThatChanged[$key] = $order;
				$this->orderStash->insertOrder($order);
			}
		}

		// verifica se os itens estão produzidos para a expedição
		$ordersThatChanged = $this->handleProducedItems($ordersThatChanged);

		//indexa pedidos pela chave do cliente
		$ordersIndexedByClientKey = $this->indexArrayByClientKey($ordersThatChanged);

		return array(
			'event' => 'sendChanges',
			'data'  => $ordersIndexedByClientKey
		);
	}

	private function handleProducedItems($orders) {
		$returnArray = array();
		foreach ($orders as $order) {
			if ($order['IDTIPOSETOR'] == "E") {
				// para cada item da expedição, verifica se sua composição está pronta
				$itemsArray = array();
				foreach ($order['items'] as $item) {
					$item = $this->KDSManagerController->updateExpeditionStatus($order['CDFILIAL'], $item);
					array_push($itemsArray, $item);
				}
				$order['items'] = $itemsArray;
			}
			$returnArray[$order['orderKey']] = $order;
		}
		return $returnArray;
	}

	public function indexOrdersByOrderKey($orders){
		// pedidos indexados por chave
		$currentOrders = array();

		foreach ($orders as $request) {
			$orderKey = $this->generateRequestKey($request);
			$currentOrders[$orderKey] = $request;
			// coloca chave do item e chave do client (browser) dentro do array de itens
			$currentOrders[$orderKey]['orderKey'] = $orderKey;
			$currentOrders[$orderKey]['clientKey'] = $request['CDFILIAL'] . '-' . $request['items'][0]['CDSETOR'];
		}
		return $currentOrders;
	}

	public function indexArrayByClientKey($orders){
		$ordersIndexedByClientKey = array();
		foreach ($orders as $item) {
			if (empty($ordersIndexedByClientKey[$item['clientKey']])){
				// se ainda não existe o array de itens para este cliente, cria ele
				$orderArray = array(
					$item['orderKey'] => $item
				);
				$ordersIndexedByClientKey[$item['clientKey']] = $orderArray;
			} else {
				// se já existe o array, somente adiciona o próximo
				$ordersIndexedByClientKey[$item['clientKey']][$item['orderKey']] = $item;
			}
		}
		return $ordersIndexedByClientKey;
	}

	const CHECK_FOR_TRANSFERS = "
		SELECT CDFILIALOLD, NRVENDARESTOLD, NRCOMANDAOLD, NRPRODCOMVENOLD, NRVENDAREST, NRCOMANDA, NRPRODCOMVEN, NRSEQPRODCUP, NRMESA, NRLUGARMESAIT
		  FROM PEDIDOALT
		 WHERE CDFILIALOLD = :CDFILIAL
	";
	public function getFrozen(){
		$localQuery = $this->query;
		return $this->connection->fetchAssoc($localQuery::GET_IDKDSHABILITADO)['IDKDSHABILITADO'] == 'N';
	}
}