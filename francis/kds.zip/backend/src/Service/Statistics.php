<?php

namespace Service;

class Statistics {

	protected $entityManager;
	protected $util;
	protected $query;

	public function __construct(
		\Doctrine\ORM\EntityManager $entityManager,
		\Util\Util $util,
		\Util\Query $query)  {

		$this->entityManager = $entityManager;
		$this->util = $util;
		$this->query = $query;
		$this->connection = $entityManager->getConnection();
	}

	public function playItemStatistics($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$query = $this->query;
		try{
			$params = array(
				'CDFILIAL'      => $CDFILIAL,
				'NRPEDIDOFOS'   => $NRPEDIDOFOS,
				'NRITPEDIDOFOS' => $NRITPEDIDOFOS
			);
			$itemData = $this->connection->fetchAssoc($query::SQL_GET_ITEM_DATA, $params);
			if (!empty($itemData)) {
				$CDSETOR = $itemData['CDSETOR'];
				$TIMETOSTART = $itemData['TIMETOSTART'];
				$QTPRODPEFOS = $itemData['QTPRODPEFOS'];
				$QTPRODPEFOS = floatval($QTPRODPEFOS);

				$params = array(
					'TIMETOSTART' => $TIMETOSTART,
					'CDFILIAL'    => $CDFILIAL,
					'CDSETOR'     => $CDSETOR,
					'QTPRODPEFOS' => $QTPRODPEFOS <= 0 ? 1 : $QTPRODPEFOS,
				);
				$this->deleteOldStatistics();
				$sectorStatistics = $this->getSectorStatistics($CDFILIAL, $CDSETOR);
				if(empty($sectorStatistics)) {
					$this->connection->executeQuery($query::SQL_INSERT_STATISTICS_ON_PLAY, $params);
				} else {
					$this->connection->executeQuery($query::SQL_UPDATE_STATISTICS_PLAY, $params);
				}
			}
		} catch(\Exception $e){
			$this->util->logException($e->getMessage());
		}
	}

	public function concludeItemStatistics($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$query = $this->query;
		$params = array(
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		$itemData = $this->connection->fetchAssoc($query::SQL_GET_ITEM_DATA, $params);
		if (!empty($itemData)) {
			$CDSETOR = $itemData['CDSETOR'];
			$TIMETOPRODUCE = $itemData['TIMETOPRODUCE'];
			$NRTEMPOPRODIT = $itemData['NRTEMPOPRODIT'];
			$QTPRODPEFOS = $itemData['QTPRODPEFOS'];
			$QTPRODPEFOS = floatval($QTPRODPEFOS);

			$this->calculateAndConclude($CDFILIAL, $CDSETOR, $TIMETOPRODUCE, $NRTEMPOPRODIT, $QTPRODPEFOS);
		}
	}

		private function calculateAndConclude($CDFILIAL, $CDSETOR, $TIMETOPRODUCE, $NRTEMPOPRODIT, $QTPRODPEFOS) {
		$query = $this->query;
		try{
			$QTPRODPEFOS = is_null($QTPRODPEFOS) || $QTPRODPEFOS <= 0 ? 1 : $QTPRODPEFOS;
			if ($TIMETOPRODUCE > $NRTEMPOPRODIT) {
				$DELAYTIME = $TIMETOPRODUCE - $NRTEMPOPRODIT;
				$QTATRASADO = $QTPRODPEFOS;
			} else {
				$DELAYTIME = 0;
				$QTATRASADO = 0;
			}


			$params = array(
				'TIMETOPRODUCE' => $TIMETOPRODUCE,
				'DELAYTIME'     => $DELAYTIME,
				'QTATRASADO'    => $QTATRASADO,
				'CDFILIAL'      => $CDFILIAL,
				'CDSETOR'       => $CDSETOR,
				'QTPRODPEFOS'   => $QTPRODPEFOS
			);

			$this->deleteOldStatistics();
			$sectorStatistics = $this->getSectorStatistics($CDFILIAL, $CDSETOR);

			if(empty($sectorStatistics)) {
				$this->connection->executeQuery($query::SQL_INSERT_STATISTICS_ON_CONCLUSION, $params);
			} else  {								
				$this->connection->executeQuery($query::SQL_UPDATE_STATISTICS_CONCLUSION, $params);
			}

		} catch(\Exception $e){
			$this->util->logException($e->getMessage());
		}
	}

	public function expediteOrderStatistics($CDFILIAL, $CDSETOR, $itemsArray) {
		$query = $this->query;
		try {
			foreach ($itemsArray as $currentItem) {
				$params = array(
					'CDFILIAL'      => $currentItem['CDFILIAL'],
					'NRPEDIDOFOS'   => $currentItem['NRPEDIDOFOS'],
					'NRITPEDIDOFOS' => $currentItem['NRITPEDIDOFOS']
				);
				$itemData = $this->connection->fetchAssoc($query::SQL_GET_ITEM_DATA, $params);
				if (!empty($itemData)) {
					$TIMETOPRODUCE = $itemData['TIMETOPRODUCE'];
					$NRTEMPOPRODIT = $itemData['NRTEMPOPRODIT'];
					$QTPRODPEFOS = $itemData['QTPRODPEFOS'];
					$QTPRODPEFOS = floatval($QTPRODPEFOS);
					$this->calculateAndConclude($CDFILIAL, $CDSETOR, $TIMETOPRODUCE, $NRTEMPOPRODIT, $QTPRODPEFOS);
				}
			}
		}  catch(\Exception $e){
			$this->util->logException($e->getMessage());
		}
	}
	public function deleteOldStatistics(){
		$query = $this->query;
		$this->connection->executeQuery($query::DELETE_OLD_STATISTICS);
	}

	public function getSectorStatistics($CDFILIAL, $CDSETOR){
		$query = $this->query;
		$params = array(
			'CDFILIAL' => $CDFILIAL,
			'CDSETOR'  => $CDSETOR
		);
		return $this->connection->fetchAssoc($query::SQL_GET_STATISTICS_EXISTS, $params);
	}

	public function registrySectorConclusionQuants($CDFILIAL, $CDSETOR){
		$query = $this->query;
		$existentStatistics = $this->getSectorStatistics( $CDFILIAL, $CDSETOR);

		$IDDIA = getdate()['mday'];
		$IDHORA = getdate()['hours'];
		$QTDIA = 1;
		$QTHORA = 1;


		if(empty($existentStatistics)){
			$this->connection->executeQuery($query::SQL_INSERT_STATISTICS, Array( 'CDFILIAL' => $CDFILIAL, 'CDSETOR' => $CDSETOR));
		} else {
			if($existentStatistics['IDHORA'] == $IDHORA ){
				$QTHORA = $existentStatistics['QTHORA'] + 1;
			}
			if($existentStatistics['IDDIA'] == $IDDIA ){
				$QTDIA = $existentStatistics['QTDIA'] + 1;
			}
		}

		$params = array(
			'CDFILIAL'		=> $CDFILIAL,
			'CDSETOR'		=> $CDSETOR,
			'IDDIA'			=> $IDDIA,
			'IDHORA'		=> $IDHORA,
			'QTDIA'			=> $QTDIA,
			'QTHORA'		=> $QTHORA
		);

		$this->connection->executeQuery($query::SQL_UPDATE_DIAHORA_QT_STATISTICS, $params);

	}

}