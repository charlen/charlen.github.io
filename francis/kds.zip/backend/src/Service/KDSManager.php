<?php

namespace Service;

class KDSManager {

	protected $entityManager;
	protected $notificationService;

	public function __construct(\Doctrine\ORM\EntityManager $entityManager,
	\Service\Notification $notificationService,
	\Service\Statistics $statisticsService)  {
		$this->entityManager = $entityManager;
		$this->notificationService = $notificationService;
		$this->statisticsService = $statisticsService;
	}

	public function getSales($CDFILIAL){
		$params = array(
			':CDFILIAL' => $CDFILIAL
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_SALES, $params);
	}

	public function getTriggers(){
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_TRIGGERS_KDS, $params);
	}

	public function getRequestForProductionDisplay($CDFILIAL, $NRPEDIDOFOS){
		$params = array(
			':CDFILIAL'    => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_REQUEST_FOR_PRODUCTION, $params);
	}

	public function getRequestItem($CDSETOR){
		$params = array(
			':CDSETOR' => $CDSETOR
		);
		if(isset($CDSETOR)){
			return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCTION_REQUESTS_BY_CDSETOR, $params);
		} else {
			return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCTION_REQUESTS, $params);
		}
	}

	public function getExpedition($CDSETOR, $UPDATED = false){
		$params = array(
			':CDSETOR' => $CDSETOR
		);
		if(isset($CDSETOR) && $UPDATED != false){
			return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_EXPEDITION_BY_CDSETOR, $params);
		} else {
			return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_EXPEDITION_UPDATED_BY_CDSETOR, $params);
		}
	}

	public function getExpeditionItem($CDFILIAL, $NRPEDIDOFOS, $IDATRASO, $NRSEQLIBERADO, $CDSETOR){
		$params = array(
			':CDFILIAL'      => $CDFILIAL,
			':NRPEDIDOFOS'   => $NRPEDIDOFOS,
			':IDATRASO'      => $IDATRASO,
			':NRSEQLIBERADO' => $NRSEQLIBERADO,
			':CDSETOR' => $CDSETOR
		   );

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_EXPEDITION_REQUEST_ITEM, $params);
	}

	public function insertOrder($CDFILIAL, $NRPEDIDOFOS, $DSPEDIDOFOS, $DSCHAVEPEDFOS,
				 				$DTPEDIDOFOS, $IDSTATUSPEDFOS, $DSTIPOPEDFOS, $NRMESA,
				 				$NRCOMANDA, $DSCOMANDA, $QTMAXPEDFOS, $CDSETOR,
				 				$NRPEDIDOFOSAUX, $CDLOJA, $CDSENHAPED, $NRPEDIDOFOSMSDE,
				 				$NMCONSUMIDOR, $IDATIVO){
		$params = array(
			':CDFILIAL'        => $CDFILIAL,
			':NRPEDIDOFOS'     => $NRPEDIDOFOS,
			':DSPEDIDOFOS'     => $DSPEDIDOFOS,
			':DSCHAVEPEDFOS'   => $DSCHAVEPEDFOS,
			':DTPEDIDOFOS'     => $DTPEDIDOFOS,
			':IDSTATUSPEDFOS'  => $IDSTATUSPEDFOS,
			':DSTIPOPEDFOS'    => $DSTIPOPEDFOS,
			':NRMESA'          => $NRMESA,
			':NRCOMANDA'       => $NRCOMANDA,
			':DSCOMANDA'       => $DSCOMANDA,
			':QTMAXPEDFOS'     => $QTMAXPEDFOS,
			':CDSETOR'         => $CDSETOR,
			':NRPEDIDOFOSAUX'  => $NRPEDIDOFOSAUX,
			':CDLOJA'          => $CDLOJA,
			':CDSENHAPED'      => $CDSENHAPED,
			':NRPEDIDOFOSMSDE' => $NRPEDIDOFOSMSDE,
			':NMCONSUMIDOR'    => $NMCONSUMIDOR,
			':IDATIVO'         => $IDATIVO
		);

		return $this->entityManager->getConnection()->executeQuery(\Util\Query::INSERT_ORDER, $params);
	}

	public function insertOrderItem($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $CDPRODUTO,
			 						$QTPRODPEFOS, $CDCAIXA, $NRSEQVENDA, $NRSEQUITVEND,
			 						$NRVENDAREST, $NRCOMANDA, $NRPRODCOMVEN, $TXPRODPED,
			 						$IDSITITPEDFOS, $CDSETOR, $CDGRPOCOR, $CDOCORR,
			 						$DTHREXIBICAOPROD, $DSCHAVEPEDPAI, $CDPRODUTOPAI,
			 						$CDPRODPROMOKDS, $NRSEQPRODCOMKDS, $NRTEMPOPRODIT, $NRTEMPOEXIBIT,
			 						$NRATRAPRODITPE, $NRLUGARMESAIT, $IDLIBERADO, $NRMAIORTEMPO,
			 						$IDORIGEMVENDA){
		$params = array(
			':CDFILIAL'         => $CDFILIAL,
			':NRPEDIDOFOS'      => $NRPEDIDOFOS,
			':NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
			':CDPRODUTO'        => $CDPRODUTO,
			':QTPRODPEFOS'      => $QTPRODPEFOS,
			':CDCAIXA' 		    => $CDCAIXA,
			':NRSEQVENDA'       => $NRSEQVENDA,
			':NRSEQUITVEND'     => $NRSEQUITVEND,
			':NRVENDAREST'      => $NRVENDAREST,
			':NRCOMANDA'        => $NRCOMANDA,
			':NRPRODCOMVEN'     => $NRPRODCOMVEN,
			':TXPRODPED'        => $TXPRODPED,
			':IDSITITPEDFOS'    => $IDSITITPEDFOS,
			':CDSETOR'          => $CDSETOR,
			':CDGRPOCOR'        => $CDGRPOCOR,
			':CDOCORR'          => $CDOCORR,
			':DTHREXIBICAOPROD' => $DTHREXIBICAOPROD,
			':DSCHAVEPEDPAI'    => $DSCHAVEPEDPAI,
			':CDPRODUTOPAI'     => $CDPRODUTOPAI,
			':CDPRODPROMOKDS'   => $CDPRODPROMOKDS,
			':NRSEQPRODCOMKDS'  => $NRSEQPRODCOMKDS,
			':NRTEMPOPRODIT'    => $NRTEMPOPRODIT,
			':NRTEMPOEXIBIT'    => $NRTEMPOEXIBIT,
			':NRATRAPRODITPE'   => $NRATRAPRODITPE,
			':NRLUGARMESAIT'    => $NRLUGARMESAIT,
			':IDLIBERADO'       => $IDLIBERADO,
			':NRMAIORTEMPO'     => $NRMAIORTEMPO,
			':IDORIGEMVENDA'    => $IDORIGEMVENDA

		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::INSERT_ORDER_ITEMS, $params);
	}

	public function insertOrderComposition($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $CDPRODUTO,
				 						   $QTPRODPEFOS, $CDCAIXA, $NRSEQVENDA, $NRSEQUITVEND,
				 						   $NRVENDAREST, $NRCOMANDA, $NRPRODCOMVEN, $TXPRODPED,
				 						   $IDSITITPEDFOS, $DSCHAVEPEDPAI, $CDSETOR, $NRLUGARMESAIT){
		$params = array(
			':CDFILIAL' 	 => $CDFILIAL,
			':NRPEDIDOFOS' 	 => $NRPEDIDOFOS,
			':NRITPEDIDOFOS' => $NRITPEDIDOFOS,
			':CDPRODUTO' 	 => $CDPRODUTO,
			':QTPRODPEFOS' 	 => $QTPRODPEFOS,
			':CDCAIXA' 		 => $CDCAIXA,
			':NRSEQVENDA' 	 => $NRSEQVENDA,
			':NRSEQUITVEND'  => $NRSEQUITVEND,
			':NRVENDAREST' 	 => $NRVENDAREST,
			':NRCOMANDA' 	 => $NRCOMANDA,
			':NRPRODCOMVEN'  => $NRPRODCOMVEN,
			':TXPRODPED' 	 => $TXPRODPED,
			':IDSITITPEDFOS' => $IDSITITPEDFOS,
			':DSCHAVEPEDPAI' => $DSCHAVEPEDPAI,
			':CDSETOR'       => $CDSETOR,
			':NRLUGARMESAIT'     => $NRLUGARMESAIT

		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::INSERT_ORDER_COMPOSITION, $params);
	}

	public function updateSaleMesa($NRPEDIDOFOS, $CDFILIAL, $NRVENDAREST, $NRCOMANDA, $NRPRODCOMVEN ){
		$params = array(
			':NRPEDIDOFOS'  => $NRPEDIDOFOS,
			':CDFILIAL'     => $CDFILIAL,
			':NRVENDAREST'  => $NRVENDAREST,
			':NRCOMANDA'    => $NRCOMANDA,
			':NRPRODCOMVEN' => $NRPRODCOMVEN
		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_SALE_MESA, $params);
	}

	public function updateSaleVenda($NRPEDIDOFOS, $CDFILIAL, $CDCAIXA, $NRSEQVENDA, $NRSEQUITVEND ){
		$params = array(
			':NRPEDIDOFOS'  => $NRPEDIDOFOS,
			':CDFILIAL'     => $CDFILIAL,
			':CDCAIXA'      => $CDCAIXA,
			':NRSEQVENDA'   => $NRSEQVENDA,
			':NRSEQUITVEND' => $NRSEQUITVEND
		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_SALE_VENDA, $params);
	}

	public function doConclude($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		// change status to F
		$this->changeStatusItemRequestConclude($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS);
		// check if must expedite this item if he doesn't have a father, otherwise he will never receive status X
		$parents = $this->getItemParent($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS);
		if (empty($parents)) {
			$this->changeStatusItemRequestExpedite($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS);
			$this->updateDoneOrder($CDFILIAL, $NRPEDIDOFOS);
		}
 	}

 	public function doExpedition($CDFILIAL, $CDSETOR, $itemsArray) {
		$mustSendConclusions = false;
		$itemsToUpdate = array();
		$getSectorTypeParams = array(':CDSETOR' => $CDSETOR);
		$sectorparams = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_SECTOR_DATA, $getSectorTypeParams);
		if(!empty($sectorparams) && isset($sectorparams['IDTIPOSETOR']) && $sectorparams['IDTIPOSETOR'] == 'E') {
			$this->notificationService->imprimeCupom($itemsArray[0]['NRVENDAREST'], $itemsArray[0]['CDFILIAL']);
		}
		foreach ($itemsArray as $currentItem) {
			$this->expediteItem($currentItem['CDFILIAL'], $currentItem['NRPEDIDOFOS'], $currentItem['NRITPEDIDOFOS'], $itemsToUpdate, 'S');
		}
		$this->updateExpediteItem($itemsToUpdate);
		$mustSendConclusions = $this->checkIfMustSendConclusions($CDFILIAL, $CDSETOR, $itemsArray[0]['NRPEDIDOFOS']);
		$this->updatePedidofosLastAtualization($CDFILIAL, $itemsArray[0]['NRPEDIDOFOS']);
		$this->updateDoneOrder($CDFILIAL, $itemsArray[0]['NRPEDIDOFOS'], $itemsArray[0]['NRCOMANDA'], $itemsArray[0]['NRVENDAREST']);
 	}

	public function updateExpediteItem($itemsToUpdate){
		$listToUpdateWithTime = "";
		$listToUpdateWithoutTime = "";
		foreach ($itemsToUpdate as $currentItem) {
			if ($currentItem['updateEndOfProduction'] == 'S') {
				$listToUpdateWithTime = $listToUpdateWithTime . "'" . $currentItem['CDFILIAL'] . $currentItem['NRPEDIDOFOS'] . $currentItem['NRITPEDIDOFOS'] . "'". ',' ;
			} else {
				$listToUpdateWithoutTime = $listToUpdateWithoutTime . "'" . $currentItem['CDFILIAL'] . $currentItem['NRPEDIDOFOS'] . $currentItem['NRITPEDIDOFOS'] . "'". ',';
			}
		}

		if (!empty($listToUpdateWithTime)) {
			$listToUpdateWithTime = rtrim($listToUpdateWithTime, ",");
			$this->entityManager->getConnection()->executeQuery("UPDATE ITPEDIDOFOS " .
			   "SET IDSITITPEDFOS   = 'X', " .
			       "DTHRFINPRODUCAO = GETDATE() " .
			 "WHERE CDFILIAL + NRPEDIDOFOS + NRITPEDIDOFOS IN ($listToUpdateWithTime)");
		}

		if (!empty($listToUpdateWithoutTime)) {
			$listToUpdateWithoutTime = rtrim($listToUpdateWithoutTime, ",");
			$this->entityManager->getConnection()->executeQuery("UPDATE ITPEDIDOFOS " .
			   "SET IDSITITPEDFOS   = 'X' " .
			 "WHERE CDFILIAL + NRPEDIDOFOS + NRITPEDIDOFOS IN ($listToUpdateWithoutTime)");
		}
	}

	public function expediteItem($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, &$itemsToUpdate, $updateEndOfProduction) {
		// expede o item atual
		// não coloque : na frente!
		$item = array(
			'CDFILIAL'              => $CDFILIAL,
			'NRPEDIDOFOS'           => $NRPEDIDOFOS,
			'NRITPEDIDOFOS'         => $NRITPEDIDOFOS,
			'updateEndOfProduction' => $updateEndOfProduction
		);
	    array_push($itemsToUpdate, $item);

	    // verifica se item possui filhos
		$params = array(
			':CDFILIALPAI'      => $CDFILIAL,
			':NRPEDIDOFOSPAI'   => $NRPEDIDOFOS,
			':NRITPEDIDOFOSPAI' => $NRITPEDIDOFOS
		);
	    $sons = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_ITEM_SONS, $params);
		if (!empty($sons)) {
			// se item possui filhos, libera um por um
			foreach ($sons as $currentSon) {
				$this->expediteItem($currentSon['CDFILIAL'], $currentSon['NRPEDIDOFOS'], $currentSon['NRITPEDIDOFOS'], $itemsToUpdate, 'N');
			}
		}
	}

	public function updateDoneOrder($CDFILIAL, $NRPEDIDOFOS, $NRCOMANDA = null, $NRVENDAREST = null){
	    // verifica se todos os itens já foram expedidos
		$params = array(
			':CDFILIAL'    => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS,
			':NRCOMANDA'   => $NRCOMANDA,
			':NRVENDAREST' => $NRVENDAREST
		);

	    $pendingItems = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PENDING_PRODUCTS, $params);
	    if (empty($pendingItems)){
	    	// se todos os itens já foram expedidos, expede o pedido
			$this->entityManager->getConnection()->executeQuery(\Util\Query::EXPEDITE_ORDER, $params);
			$sectors = $this->entityManager->getConnection()->executeQuery(\Util\Query::GET_EXPEDITIONS_BY_NRPEDIDOFOS, $params);

			foreach( $sectors as $sector){
				//Atualizar quantidade da estatística aqui
				$this->statisticsService->registrySectorConclusionQuants($CDFILIAL, $sector['CDSETOR']);
			}

			// if($NRCOMANDA !== null){
			// 	$this->entityManager->getConnection()->executeQuery(\Util\Query::EXPEDITE_COMANDA, $params);
			// }
	    } else {
	    	// procura por items na expedição ou montagem que não estejam expedidos
	    	$params = array(
				':CDFILIAL'    => $CDFILIAL,
				':NRPEDIDOFOS' => $NRPEDIDOFOS
			);
		    $pendingItemsExpedition = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PENDING_PRODUCTS_EXPEDITION, $params);
		    if (empty($pendingItemsExpedition)) {

				// procura todos os itens da produção que já foram concluídos mas não expedidos
				$params = array(
					':CDFILIAL'    => $CDFILIAL,
					':NRPEDIDOFOS' => $NRPEDIDOFOS
				);
				$pendingItemsProduction = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PENDING_PRODUCTS_PRODUCTION, $params);

				// expede todos estes itens que não têm pais
				foreach ($pendingItemsProduction as $currentItem) {
					$params = array(
						':CDFILIAL'      => $currentItem['CDFILIAL'],
						':NRPEDIDOFOS'   => $currentItem['NRPEDIDOFOS'],
						':NRITPEDIDOFOS' => $currentItem['NRITPEDIDOFOS']
					);
					$this->entityManager->getConnection()->fetchAll(\Util\Query::CHANGE_ITEM_STATUS_RELEASED, $params);
				}

				// verifica se pode expedir o pedido
				$params = array(
					':CDFILIAL'    => $CDFILIAL,
					':NRPEDIDOFOS' => $NRPEDIDOFOS
				);
			    $pendingItems = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PENDING_PRODUCTS, $params);
			    if (empty($pendingItems)){
			    	// se todos os itens já foram expedidos, expede o pedido
					$this->entityManager->getConnection()->executeQuery(\Util\Query::EXPEDITE_ORDER, $params);

					$sectorsInner = $this->entityManager->getConnection()->executeQuery(\Util\Query::GET_EXPEDITIONS_BY_NRPEDIDOFOS, $params);

					var_dump($sectorsInner);

					foreach( $sectorsInner as $sectorInner){

						var_dump($sectorInner);
						//Atualizar quantidade da estatística aqui
						$this->statisticsService->registrySectorConclusionQuants($CDFILIAL, $sectorInner['CDSETOR']);
					}
			    }
		    }
	    }
	}

	public function getExpeditionsByNrpedidofos($CDFILIAL, $NRPEDIDOFOS){
		$params = array(
			'CDFILIAL' => $CDFILIAL,
			'NRPEDIDOFOS' => $NRPEDIDOFOS
		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::GET_EXPEDITION_BY_NRPEDIDOFOS, $params);
	}

	public function changeStatusItemRequestPlay($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			':CDFILIAL'      => $CDFILIAL,
			':NRPEDIDOFOS'   => $NRPEDIDOFOS,
			':NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::CHANGE_STATUS_REQUEST_ITEM_PLAY, $params);
	}

	public function changeStatusItemRequestConclude($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			':CDFILIAL'      => $CDFILIAL,
			':NRPEDIDOFOS'   => $NRPEDIDOFOS,
			':NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::CHANGE_STATUS_REQUEST_ITEM_CONCLUDE, $params);
	}

	public function changeStatusItemRequestExpedite($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			':CDFILIAL'      => $CDFILIAL,
			':NRPEDIDOFOS'   => $NRPEDIDOFOS,
			':NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::CHANGE_STATUS_REQUEST_ITEM_EXPEDITE, $params);
	}

	public function checkOrderExistence($CHAVE) {
		$params = array(
			':DSCHAVEPEDFOS' => $CHAVE
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::CHECK_ORDER_EXISTENCE, $params);
	}

	public function getNewCode($CDCONTADOR){
		$params = array(
			':CDCONTADOR' => $CDCONTADOR
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_NEW_CODE, $params);
	}

	public function getColourParams(){
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_COLOUR_PARAMS);
	}


	public function getProductionOrder($NRITPEDIDOFOS, $NRPEDIDOFOS){
		$params = array(
			':NRITPEDIDOFOS' => $NRITPEDIDOFOS,
			':NRPEDIDOFOS'   => $NRPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCTION_ORDER, $params);
	}

	public function searchLocalComposition($CDFILIAL, $CDPRODUTO){
		$params = array(
			':CDFILIAL'  => $CDFILIAL,
			':CDPRODUTO' => $CDPRODUTO
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_LOCAL_COMPOSITION, $params);
	}

	public function searchPatternComposition($CDPRODUTO, $CDFILIAL){
		$params = array(
			':CDPRODUTO' => $CDPRODUTO,
			':CDFILIAL'  => $CDFILIAL
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PATTERN_COMPOSITION, $params);
	}

	public function getAllItemObservations($CHAVEITEM){
		$params = array(
			':CHAVEITEM' => $CHAVEITEM
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_ALL_ITEM_OBSERVATIONS, $params);
	}

	public function getItemObservationsBySetorProduto($CHAVEITEM, $CDSETOR, $CDPRODUTO){
		$params = array(
			':CHAVEITEM' => $CHAVEITEM,
			':CDSETOR' => $CDSETOR,
			':CDPRODUTO' => $CDPRODUTO
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_ITEM_OBSERVATIONS_BY_SETOR_PRODUTO, $params);
	}

	public function getSetorProdutoObservations($CDSETOR, $CDPRODUTO){
		$params = array(
			':CDSETOR' => $CDSETOR,
			':CDPRODUTO' => $CDPRODUTO
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_SECTOR_OBSERVATIONS, $params);
	}

	public function getProductPromoComanda($CDFILIAL, $NRCOMANDA, $NRPRODCOMVEN, $NRVENDAREST){
		$params = array(
			':CDFILIAL'     => $CDFILIAL,
			':NRCOMANDA'	=> $NRCOMANDA,
			':NRPRODCOMVEN' => $NRPRODCOMVEN,
			':NRVENDAREST'  => $NRVENDAREST
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCT_PROMOTION_COMANDA, $params);
	}

	public function getProductPromoVenda($CDFILIAL, $CDCAIXA, $NRSEQVENDA, $NRSEQUITVEND ){
		$params = array(
			':CDFILIAL'   => $CDFILIAL,
			':CDCAIXA'    => $CDCAIXA,
			':NRSEQVENDA' => $NRSEQVENDA,
			':NRSEQUITVEND' => $NRSEQUITVEND
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCT_PROMOTION_VENDA, $params);
	}

	public function sendItemsToProduction($NRITPEDIDOFOS, $DSCHAVEPEDPAI, $DTHREXIBICAOPROD){
		$params = array(
			':NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
			':DSCHAVEPEDPAI'    => $DSCHAVEPEDPAI,
			':DTHREXIBICAOPROD' => $DTHREXIBICAOPROD
		);

		return $this->entityManager->getConnection()->executeQuery(\Util\Query::SEND_ITEMS_TO_PRODUCTION, $params);
	}


	public function getPatternProduct($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS){
		$params = array(
			':CDFILIAL'       => $CDFILIAL,
			':NRPEDIDOFOS'    => $NRPEDIDOFOS,
			':NRITPEDIDOFOS'  => $NRITPEDIDOFOS
		);

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PATTERN_PRODUCT, $params);
	}

	public function searchPatternCompositionByChave($DSCHAVEPEDPAI, $CDPRODUTO){
		$params = array(
			':DSCHAVEPEDPAI' => $DSCHAVEPEDPAI,
			':CDPRODUTO'     => $CDPRODUTO
		);

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PATTERN_COMPOSITION_BY_CHAVE, $params);
	}

	public function getMaxProductionTime($CDFILIAL, $NRPEDIDOFOS, $NRSEQLIBERADO = false){
		$params = array(
			':CDFILIAL'    => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS
		);
		if($NRSEQLIBERADO == false){
			return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_MAX_PRODUCTION_TIME, $params);
		} else {
			return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_MAX_PRODUCTION_TIME_NRATRAPRODITPED, $params);
		}
	}

	public function getProductSector($CDPRODUTO, $CDFILIAL){
		$params = array(
			':CDFILIAL'  => $CDFILIAL,
			':CDPRODUTO' => $CDPRODUTO
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCT_SECTOR, $params);
	}

	public function getProductSectorByType($CDPRODUTO, $CDFILIAL, $CDLOJA, $IDTIPOSETOR) {
		$params = array(
			':CDFILIAL'    => $CDFILIAL,
			':CDPRODUTO'   => $CDPRODUTO,
			':CDLOJA'      => $CDLOJA,
			':IDTIPOSETOR' => $IDTIPOSETOR
		);
		$expedition = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCT_SECTOR_BY_TYPE_STORE, $params);
		if (count($expedition) == 0) {
			$params = array(
				':CDFILIAL' => $CDFILIAL,
				':CDLOJA'   => $CDLOJA
			);
			$countSectorStore = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_SECTOR_STORE_COUNT, $params);
			if (count($countSectorStore) == 0) {
				$params = array(
					':CDFILIAL'    => $CDFILIAL,
					':CDPRODUTO'   => $CDPRODUTO,
					':IDTIPOSETOR' => $IDTIPOSETOR
				);
				$expedition = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCT_SECTOR_BY_TYPE, $params);
			}
		}
		return $expedition;
	}

	public function checkStatusProduction($DSCHAVEPEDPAI){
		$params = array(
			':DSCHAVEPEDPAI' => $DSCHAVEPEDPAI
		);

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_CHECK_PRODUCTION, $params);
	}

	public function checkStatusDone($DSCHAVEPEDPAI){
		$params = array(
			':DSCHAVEPEDPAI' => $DSCHAVEPEDPAI
		);

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_CHECK_DONE, $params);
	}

	public function getSubProducts($DSCHAVEPEDPAI){
		$params = array(
			':DSCHAVEPEDPAI' => $DSCHAVEPEDPAI
		);

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_SUBPRODUCTS, $params);
	}

	public function getChildProducts($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			'CDFILIAL' => $CDFILIAL,
			'NRPEDIDOFOS' => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		$spawn = array();
		$sons = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_CHILD_PRODUCTS, $params);
		$spawn = array_merge($spawn, $sons);
		foreach ($sons as $son) {
			$grandSons = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_CHILD_PRODUCTS, $son);
			$spawn = array_merge($spawn, $grandSons);
		}
		return $spawn;
	}

	public function checkChildDone($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $IDTIPOSETOR) {
		$params = array(
			'CDFILIAL' => $CDFILIAL,
			'NRPEDIDOFOS' => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		$spawn = array();
		$sons = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_CHILD_PRODUCTS, $params);
		foreach ($sons as $son) {
			if(($son['IDSITITPEDFOS'] == 'F' && $son['IDTIPOSETOR'] == 'P')|| $son['IDSITITPEDFOS'] == 'X'){
				$spawn = array_merge($spawn, array($son));
			}
			$grandSons = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_CHILD_DONE, $son);
			$spawn = array_merge($spawn, $grandSons);
		}
		return $spawn;
	}

	public function checkChildProduction($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			'CDFILIAL' => $CDFILIAL,
			'NRPEDIDOFOS' => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		$spawn = array();
		$sons = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_CHILD_PRODUCTS, $params);
		foreach ($sons as $son) {
			if($son['IDSITITPEDFOS'] == 'P') {
				$spawn = array_merge($spawn, array($son));
			}
			$grandSons = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_CHILD_PRODUCTION, $son);
			$spawn = array_merge($spawn, $grandSons);
		}
		return $spawn;
	}

	public function getObservation($CDPRODUTO){
		$params = array(
			':CDPRODUTO' => $CDPRODUTO
		);

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_OBSERVATION, $params);
	}

	public function getProductBySeqOrder($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			':CDFILIAL' 	 =>$CDFILIAL,
			':NRPEDIDOFOS' 	 =>$NRPEDIDOFOS,
			':NRITPEDIDOFOS' =>$NRITPEDIDOFOS
		);

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCT_BY_SEQ_ORDER, $params);
	}

	public function clearRequestsScreen($CDFILIAL, $hoursNumber) {
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':NRHORA' => $hoursNumber
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::CLEAN_PEDIDOFOS, $params);
	}

	public function updatePedidofosLastAtualization($CDFILIAL, $NRPEDIDOFOS) {
		$params = array(
			':CDFILIAL'    => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_DTULTATU_PEDIDOFOS, $params);
	}

	public function getPedidofosByVenda($CDFILIAL, $NRSEQVENDA, $NRSEQUITVEND){
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':NRSEQVENDA' => $NRSEQVENDA,
			':NRSEQUITVEND' => $NRSEQUITVEND
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PEDIDOFOS_BY_VENDA, $params);
	}

	public function getNewTemporaryCode($CDFILIAL, $NRPEDIDOFOS){
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_NEW_TEMPORARY_CODE, $params);
	}

	public function getProductPromoBalcaoSemVenda($CDFILIAL, $NRPEDIDOFOS){
		$params = array(
			':CDFILIAL'   => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCT_SEM_VENDA, $params);
	}

	public function checkIfKeyExists($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS){
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS,
			':NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		$count = $this->entityManager->getConnection()->fetchAll(\Util\Query::CHECK_IF_KEY_EXISTS, $params);
		if (empty($count)) {
			return true;
		} else {
			return false;
		}
	}

	public function checkIfITPEDIDOFOSPAIExists($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $NRSEQITPEDPAI){
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS,
			':NRITPEDIDOFOS' => $NRITPEDIDOFOS,
			':NRSEQITPEDPAI' => $NRSEQITPEDPAI
		);
		$count = $this->entityManager->getConnection()->fetchAll(\Util\Query::CHECK_IF_ITPEDIDOFOSPAI_EXISTS, $params);
		if (empty($count)) {
			return true;
		} else {
			return false;
		}
	}

	public function findOldRequests($CDFILIAL){
		$params = array(
			':CDFILIAL'   => $CDFILIAL
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::FIND_OLD_REQUESTS, $params);
	}

	public function deleteItemPedidofos($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS){
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS,
			':NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::DELETE_ITPEDIDOFOS, $params);
	}

	public function deletePedidofos($CDFILIAL, $NRPEDIDOFOS){
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':NRPEDIDOFOS' => $NRPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::DELETE_PEDIDOFOS, $params);
	}

	public function getSetorProdutoFilial($CDPRODUTO, $CDFILIAL, $IDTIPOSETOR, $CDSETOR){
		$params = array(
			':CDPRODUTO' => $CDPRODUTO,
			':CDFILIAL' => $CDFILIAL,
			':IDTIPOSETOR' => $IDTIPOSETOR,
			':CDSETOR' => $CDSETOR
		);

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUTO_FILIAL, $params);
	}

	public function insertRelation($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $NRSEQITPEDPAI, $CDFILIALPAI, $NRPEDIDOFOSPAI, $NRITPEDIDOFOSPAI){
		$params = array(
			'CDFILIAL'         => $CDFILIAL,
			'NRPEDIDOFOS'      => $NRPEDIDOFOS,
			'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
			'NRSEQITPEDPAI'    => $NRSEQITPEDPAI,
			'CDFILIALPAI'      => $CDFILIALPAI,
			'NRPEDIDOFOSPAI'   => $NRPEDIDOFOSPAI,
			'NRITPEDIDOFOSPAI' => $NRITPEDIDOFOSPAI
		);

		return $this->entityManager->getConnection()->executeQuery(\Util\Query::INSERT_ITPEDIDOFOSPAI, $params);
	}

	public function getProductByCode($CDPRODUTO){
		$params = array(
			'CDPRODUTO' => $CDPRODUTO
		);

		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_PRODUCT_BY_CODE, $params);
	}

	public function insertOrderRelation($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $NRSEQITPEDREL,
	                                    $NRVENDAREST, $NRCOMANDA, $NRPRODCOMVEN, $QTPRODPEFOS,
	                                    $IDSITITPEDFOS){
		$params = array(
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS,
			'NRSEQITPEDREL' => $NRSEQITPEDREL,
			'NRVENDAREST'   => $NRVENDAREST,
			'NRCOMANDA'     => $NRCOMANDA,
			'NRPRODCOMVEN'  => $NRPRODCOMVEN,
			'QTPRODPEFOS'   => $QTPRODPEFOS,
			'IDSITITPEDFOS' => $IDSITITPEDFOS
		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::INSERT_ITPEDIDOFOSREL, $params);
	}

	public function getItemsRelations($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			'CDFILIAL' => $CDFILIAL,
			'NRPEDIDOFOS' => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_ITEMS_RELATION, $params);
	}

	public function getExpeditionAndMountListFromItPedidofos(){
		$params = [];
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_EXPEDITIONS_AND_MOUNTS_CDSETOR_FROM_ITPEDIDOFOS, $params);
	}

	public function cancelItem($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::CANCEL_ITEM, $params);
	}

	public function changeItemQuantity($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $QTPRODPEFOS) {
		$params = array(
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS,
			'QTPRODPEFOS'   => $QTPRODPEFOS
		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::CHANGE_ITEM_QUANTITY, $params);
	}

	public function getItemIntervals($CDPRODUTO, $CDSETOR) {
		$params = array(
			'CDPRODUTO' => $CDPRODUTO,
			'CDSETOR'   => $CDSETOR
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_ITEM_INTERVALS, $params);
	}

	public function releaseItem($NRSEQLIBERADO, $CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			'NRSEQLIBERADO' => $NRSEQLIBERADO,
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::RELEASE_ITEM, $params);
	}

	public function getItemParent($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_ITEM_PARENT, $params);
	}

	public function getItemCascade($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_ITEM_CASCADE, $params);
	}

	public function checkIfMustSendConclusions($CDFILIAL, $CDSETOR, $NRPEDIDOFOS) {
		$params = array(
			'CDFILIAL'    => $CDFILIAL,
			'CDSETOR'     => $CDSETOR,
			'NRPEDIDOFOS' => $NRPEDIDOFOS
		);
		$nonExpeditedItems = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_IF_MUST_SEND_CONCLUSIONS, $params);
		if (count($nonExpeditedItems) > 0) {
			return false;
		} else {
			return true;
		}
	}

	public function changeItemStatusReleased($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			'CDFILIAL'      => $CDFILIAL,
			'NRPEDIDOFOS'   => $NRPEDIDOFOS,
			'NRITPEDIDOFOS' => $NRITPEDIDOFOS
		);
		return $this->entityManager->getConnection()->executeQuery(\Util\Query::CHANGE_ITEM_STATUS_RELEASED, $params);
	}

	public function getMappedKeys() {
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_MAPPED_KEYS);
	}

	private function logExceptionWSService($info){
        //testa se a pasta existe e cria caso não exista
        $folder = substr(__DIR__, 0, 1) . ":\\TEKNISA\\kds\\logs\\";
        if (!file_exists($folder)) {
            mkdir($folder, 0777, true);
        }
        //--grava o log
        $line = date("d-m-Y H:i:s") . " - " . $info . "\n";
        $drive = substr(__DIR__, 0, 1);
        $date = date("dmY");
        file_put_contents($drive . ":\\TEKNISA\\kds\\logs\\logExceptionWSService" . $date . ".txt", $line, FILE_APPEND);
    }

    public function getDefaultFilial(){
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_DEFAULT_FILIAL);
	}

	public function getFixedSummaryItems($CDFILIAL, $CDSETOR){
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':CDSETOR'  => $CDSETOR
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_FIXED_SUMMARY_ITEMS, $params);
	}

	public function getItemOrigin($origem) {
		if(strpos(' '.$origem, 'DLV')!= false){
			return "Delivery";
		} else if(strpos(' '.$origem, 'THR')!= false){
			return "Drive";
		} else if(strpos(' '.$origem, 'TGO')!= false){
			return "Viagem";
		} else {
			return "Balcão";
		}
	}

	public function updateDtUltAtuItPedidoFosByNrPedidoFos($CDFILIAL, $NRPEDIDOFOS) {
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':NRPEDIDOFOS'  => $NRPEDIDOFOS
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_DTULTATU_ITPEDIDOFOS_BY_NRPEDIDOFOS, $params);
	}

	public function checkIfCanDoneMount($NRPEDIDOFOS){
		$params = array(
			':NRPEDIDOFOS' => $NRPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_CDSETOR_PRIORM_BY_NRPEDIDOFOS, $params);
	}

	public function getStatisticsFromOneClient($CDFILIAL, $CDSETOR){
		// envia estatisticas
		$params = array(
			':CDFILIAL' => $CDFILIAL, // T de todos
			':CDSETOR'  => $CDSETOR // T de todos
		);
		$newStatistics = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_STATISTICS_ALL, $params);
		return $newStatistics;
	}

}