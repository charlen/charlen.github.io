<?php

namespace Service;

class KDSTransfer {

	protected $entityManager;
	protected $util;

	public function __construct(
		\Doctrine\ORM\EntityManager $entityManager,
		\Util\Util $util)  {

		$this->entityManager = $entityManager;
		$this->util = $util;
	}

	public function getItemsBySaleRelation($CDFILIAL, $oldNRVENDAREST, $oldNRCOMANDA, $oldNRPRODCOMVEN) {
	    $params = array(
	        $CDFILIAL,
	        $oldNRVENDAREST,
	        $oldNRCOMANDA,
	        $oldNRPRODCOMVEN
	    );
	    return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_ITPEDIDOFOS_BY_ITPEDIDOFOSREL, $params);
	}

  public function insertOrder($NRPEDIDOFOS, $DSPEDIDOFOS, $DSCHAVEPEDFOS, $NRMESA, $NRCOMANDA, $DSCOMANDA, $NRPEDIDOFOSAUX, $NRPEDIDOFOSMSDE, $CDFILIAL, $oldNRPEDIDOFOS) {
      $params = array(
          $NRPEDIDOFOS,
          $DSPEDIDOFOS,
          $DSCHAVEPEDFOS,
          $NRMESA,
	        $NRCOMANDA,
	        $DSCOMANDA,
	        $NRPEDIDOFOSAUX,
	        $NRPEDIDOFOSMSDE,
	        $CDFILIAL,
	        $oldNRPEDIDOFOS
	    );
	    $this->entityManager->getConnection()->executeQuery(self::INS_PEDIDOFOS, $params);
	}

    const INS_PEDIDOFOS = "
        INSERT INTO PEDIDOFOS
        (CDFILIAL, NRPEDIDOFOS, DSPEDIDOFOS, DSCHAVEPEDFOS,
        DTPEDIDOFOS, IDSTATUSPEDFOS, QTTEMPOPEDFOS, QTMAXPEDFOS,
        DSTIPOPEDFOS, NRMESA, NRCOMANDA, DSCOMANDA,
        CDSETOR, NRPEDIDOFOSAUX, CDLOJA, CDSENHAPED,
        NRPEDIDOFOSMSDE, IDIMPPEDIDOFOS, NMCONSUMIDOR, NRMESAOLD)
        SELECT CDFILIAL, ?, ?, ?,
               DTPEDIDOFOS, IDSTATUSPEDFOS, QTTEMPOPEDFOS, QTMAXPEDFOS,
               DSTIPOPEDFOS, ?, ?, ?,
               CDSETOR, ?, CDLOJA, CDSENHAPED,
               ?, IDIMPPEDIDOFOS, NMCONSUMIDOR, NRMESA
          FROM PEDIDOFOS
         WHERE CDFILIAL = ?
           AND NRPEDIDOFOS = ?
    ";

    public function insertItemOrder($NRPEDIDOFOS, $NRITPEDIDOFOS, $NRLUGARMESAIT, $CDFILIAL, $oldNRPEDIDOFOS, $oldNRITPEDIDOFOS, $newQtd) {
    	$params = array(
    		$NRPEDIDOFOS,
        	$NRITPEDIDOFOS,
          	$newQtd,
        	$NRLUGARMESAIT,
        	$CDFILIAL,
        	$oldNRPEDIDOFOS,
        	$oldNRITPEDIDOFOS
        );
        $this->entityManager->getConnection()->executeQuery(self::SQL_INSERT_NEW_BOX_TRANSFER, $params);
    }

    const SQL_INSERT_NEW_BOX_TRANSFER = "
    	INSERT INTO ITPEDIDOFOS
    	(CDFILIAL, NRPEDIDOFOS, NRITPEDIDOFOS, CDPRODUTO,
    	QTPRODPEFOS, CDCAIXA, NRSEQVENDA, NRSEQUITVEND,
    	NRVENDAREST, NRCOMANDA, NRPRODCOMVEN, NRORG,
    	IDATIVO, DTINCLUSAO, DTULTATU, NRORGINCLUSAO,
    	CDOPERINCLUSAO, NRORGULTATU, CDOPERULTATU, TXPRODPED,
    	IDSITITPEDFOS, DTCANCITPED, DTHRINIPRODUCAO, DTHRFINPRODUCAO,
    	DSCHAVEPEDPAI, IDPRODUTOESPERA, DTHREXIBICAOPROD, CDSETOR,
    	CDPRODUTOPAI, CDPRODPROMOKDS, NRSEQPRODCOMKDS, IDORIPED,
    	NRTEMPOPRODIT, NRTEMPOEXIBIT, IDLIBERADO, NRATRAPRODITPE,
    	NRLUGARMESAIT, NRSEQLIBERADO)
		SELECT CDFILIAL, ?, ?, CDPRODUTO,
    	       ?, CDCAIXA, NRSEQVENDA, NRSEQUITVEND,
    	       NRVENDAREST, NRCOMANDA, NRPRODCOMVEN, NRORG,
    	       IDATIVO, DTINCLUSAO, DTULTATU, NRORGINCLUSAO,
    	       CDOPERINCLUSAO, NRORGULTATU, CDOPERULTATU, TXPRODPED,
    	       IDSITITPEDFOS, DTCANCITPED, DTHRINIPRODUCAO, DTHRFINPRODUCAO,
    	       DSCHAVEPEDPAI, IDPRODUTOESPERA, DTHREXIBICAOPROD, CDSETOR,
    	       CDPRODUTOPAI, CDPRODPROMOKDS, NRSEQPRODCOMKDS, IDORIPED,
    	       NRTEMPOPRODIT, NRTEMPOEXIBIT, IDLIBERADO, NRATRAPRODITPE,
    	       ?, NRSEQLIBERADO
    	  FROM ITPEDIDOFOS
    	 WHERE CDFILIAL = ?
    	   AND NRPEDIDOFOS = ?
    	   AND NRITPEDIDOFOS = ?
    ";

    public function setNewItemQuantity($QTREL, $CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
        $params = array(
            $QTREL,
            $CDFILIAL,
			$NRPEDIDOFOS,
			$NRITPEDIDOFOS,
        );
        $this->entityManager->getConnection()->executeQuery(self::SQL_UPDATE_ITPEDIDOFOS, $params);
    }

    const SQL_UPDATE_ITPEDIDOFOS = "
    	UPDATE ITPEDIDOFOS
    	   SET QTPRODPEFOS =  ?
    	 WHERE CDFILIAL = ?
    	   AND NRPEDIDOFOS = ?
    	   AND NRITPEDIDOFOS = ?
    ";

    public function getOldParentsRelations($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
    	$params = array(
			$CDFILIAL,
			$NRPEDIDOFOS,
			$NRITPEDIDOFOS
        );
        return $this->entityManager->getConnection()->fetchAll(self::GET_OLD_PARENTS_RELATIONS, $params);
    }

    const GET_OLD_PARENTS_RELATIONS = "
    	SELECT *
    	  FROM ITPEDIDOFOSPAI
    	 WHERE CDFILIAL = ?
    	   AND NRPEDIDOFOS = ?
    	   AND NRITPEDIDOFOS = ?
    ";

    public function changeOrderOfItem($NRPEDIDOFOS, $NRITPEDIDOFOS, $NRLUGARMESAIT, $oldCDFILIAL, $oldNRPEDIDOFOS, $oldNRITPEDIDOFOS) {
		// somente troca esse item de mesa (não insere outra caixa)
		$params = array(
			$NRPEDIDOFOS,
        	$NRITPEDIDOFOS,
        	$NRLUGARMESAIT,
        	$oldCDFILIAL,
        	$oldNRPEDIDOFOS,
        	$oldNRITPEDIDOFOS
		);
		$this->entityManager->getConnection()->executeQuery(self::SQL_TROCA_PEDIDO, $params);
    }

	const SQL_TROCA_PEDIDO = "
		UPDATE ITPEDIDOFOS
		   SET NRPEDIDOFOS = ?,
		       NRITPEDIDOFOS = ?,
		       NRLUGARMESAIT = ?
		 WHERE CDFILIAL = ?
		   AND NRPEDIDOFOS = ?
		   AND NRITPEDIDOFOS = ?
	";

	public function changeOrderOfItemREL($NRPEDIDOFOS, $NRITPEDIDOFOS, $oldCDFILIAL, $oldNRPEDIDOFOS, $oldNRITPEDIDOFOS, $oldNRSEQITPEDREL) {
		// troca número do pedido na ITPEDIDOFOSREL
		$params = array(
			$NRPEDIDOFOS,
        	$NRITPEDIDOFOS,
        	$oldCDFILIAL,
        	$oldNRPEDIDOFOS,
        	$oldNRITPEDIDOFOS,
        	$oldNRSEQITPEDREL
		);
		$this->entityManager->getConnection()->executeQuery(self::SQL_TROCA_PEDIDO_REL, $params);
	}

	const SQL_TROCA_PEDIDO_REL = "
		UPDATE ITPEDIDOFOSREL
		   SET NRPEDIDOFOS = ?,
		       NRITPEDIDOFOS = ?
		 WHERE CDFILIAL = ?
		   AND NRPEDIDOFOS = ?
		   AND NRITPEDIDOFOS = ?
		   AND NRSEQITPEDREL = ?
	";

    public function changeOrderOfItemPai($NRPEDIDOFOS, $NRITPEDIDOFOS, $NRSEQITPEDPAI, $NRPEDIDOFOSPAI, $oldCDFILIAL, $oldNRPEDIDOFOS, $oldNRITPEDIDOFOS, $oldNRSEQITPEDPAI) {
    	$params = array(
			$NRPEDIDOFOS,
			$NRITPEDIDOFOS,
			$NRSEQITPEDPAI,
			$NRPEDIDOFOSPAI,
			$oldCDFILIAL,
			$oldNRPEDIDOFOS,
			$oldNRITPEDIDOFOS,
			$oldNRSEQITPEDPAI
        );
        $this->entityManager->getConnection()->executeQuery(self::UPDATE_ITPEDIDOFOSPAI, $params);
    }

    const UPDATE_ITPEDIDOFOSPAI = "
    	UPDATE ITPEDIDOFOSPAI
    	   SET NRPEDIDOFOS = ?,
    	       NRITPEDIDOFOS = ?,
    	       NRSEQITPEDPAI = ?,
    	       NRPEDIDOFOSPAI = ?
    	 WHERE CDFILIAL = ?
    	   AND NRPEDIDOFOS = ?
    	   AND NRITPEDIDOFOS = ?
    	   AND NRSEQITPEDPAI = ?
    ";

	public function changeFatherOfItemPai($NRITPEDIDOFOSPAI, $CDFILIALPAI, $NRPEDIDOFOSPAI, $oldNRITPEDIDOFOSPAI) {
		$params = array(
        	$NRITPEDIDOFOSPAI,
            $oldNRITPEDIDOFOSPAI,
        	$CDFILIALPAI,
        	$NRPEDIDOFOSPAI,
        	$oldNRITPEDIDOFOSPAI
		);
		$this->entityManager->getConnection()->executeQuery(self::SQL_CHANGE_PAI_ITPEDIDOFOSPAI, $params);
	}

	const SQL_CHANGE_PAI_ITPEDIDOFOSPAI = "
		UPDATE ITPEDIDOFOSPAI
		   SET NRITPEDIDOFOSPAI = ?,
               NRITPEDIDOFOSPAIANT = ?
		 WHERE CDFILIALPAI = ?
		   AND NRPEDIDOFOSPAI = ?
		   AND NRITPEDIDOFOSPAI = ?
           AND NRITPEDIDOFOSPAIANT IS NULL
	";

	public function changeItemsRelationWithSale($NRVENDAREST, $NRCOMANDA, $NRPRODCOMVEN, $CDFILIAL, $oldNRVENDAREST, $oldNRCOMANDA, $oldNRPRODCOMVEN) {
	    $params = array(
	        $NRVENDAREST,
	        $NRCOMANDA,
	        $NRPRODCOMVEN,
	        $CDFILIAL,
	        $oldNRVENDAREST,
	        $oldNRCOMANDA,
	        $oldNRPRODCOMVEN
	    );
	    $this->entityManager->getConnection()->executeQuery(self::SQL_UPDATE_ITPEDIDOFOSREL, $params);
	}

    const SQL_UPDATE_ITPEDIDOFOSREL = "
        UPDATE ITPEDIDOFOSREL
           SET NRVENDAREST = ?,
               NRCOMANDA = ?,
               NRPRODCOMVEN = ?
         WHERE CDFILIAL = ?
           AND NRVENDAREST = ?
           AND NRCOMANDA = ?
           AND NRPRODCOMVEN = ?
    ";

	public function deleteTransfer($CDFILIAL, $oldNRVENDAREST, $oldNRCOMANDA, $oldNRPRODCOMVEN) {
		// apaga a solicitação de transferência da tabela temporária
		$params = array(
	        $CDFILIAL,
	        $oldNRVENDAREST,
	        $oldNRCOMANDA,
	        $oldNRPRODCOMVEN
		);
		$this->entityManager->getConnection()->executeQuery(self::SQL_DELETE_TRANSFER, $params);
	}

	const SQL_DELETE_TRANSFER = "
		DELETE
		  FROM PEDIDOALT
		 WHERE CDFILIALOLD = ?
		   AND NRVENDARESTOLD = ?
		   AND NRCOMANDAOLD = ?
		   AND NRPRODCOMVENOLD = ?
	";

    public function getItemSons($CDFILIALPAI, $NRPEDIDOFOSPAI, $NRITPEDIDOFOSPAI) {
        $params = array(
            $CDFILIALPAI,
            $NRPEDIDOFOSPAI,
            $NRITPEDIDOFOSPAI
        );
        return $this->entityManager->getConnection()->fetchAll(self::SQL_GET_ITEM_SONS, $params);
    }

    const SQL_GET_ITEM_SONS = "
        SELECT *
          FROM ITPEDIDOFOSPAI
         WHERE CDFILIALPAI = ?
           AND NRPEDIDOFOSPAI = ?
           AND NRITPEDIDOFOSPAI = ?
    ";

    public function eraseNRITPEDIDOFOSPAIANT() {
        // apaga o campo temporário usado no transferência
        $this->entityManager->getConnection()->executeQuery(self::SQL_ERASE_TEMP_TRANSFER_FIELD);
    }

    const SQL_ERASE_TEMP_TRANSFER_FIELD = "
        UPDATE ITPEDIDOFOSPAI
           SET NRITPEDIDOFOSPAIANT = NULL
    ";

    public function updateOrderDTULTATU($CDFILIAL, $NRPEDIDOFOS) {
        $params = array(
            ':CDFILIAL'    =>  $CDFILIAL,
            ':NRPEDIDOFOS' =>  $NRPEDIDOFOS
        );
    	$this->entityManager->getConnection()->executeQuery(self::SQL_UPDATE_ORDER_DTULTATU, $params);
    }

    const SQL_UPDATE_ORDER_DTULTATU = "
    	UPDATE ITPEDIDOFOS
    	   SET DTULTATU = GETDATE()
    	 WHERE CDFILIAL = :CDFILIAL
           AND NRPEDIDOFOS = :NRPEDIDOFOS
    ";

    public function getNewNRPEDIDOFOS($CDFILIAL){
        $this->util->newCode('PEDIDOFOS' . $CDFILIAL);
        return $this->util->getNewCode('PEDIDOFOS' . $CDFILIAL, 10);
    }

    public function getNewNRITPEDIDOFOS($CDFILIAL, $NRPEDIDOFOS) {
        $this->util->newCode('ITPEDIDOFOS' . $CDFILIAL . $NRPEDIDOFOS);
		return $this->util->getNewCode('ITPEDIDOFOS' . $CDFILIAL . $NRPEDIDOFOS, 10);
    }

    public function getNewNRSEQITPEDPAI($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
        $this->util->newCode('ITPEDIDOFOSPAI' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS);
		return $this->util->getNewCode('ITPEDIDOFOSPAI' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS, 10);
    }

    public function updateTransferTable($statusMesa, $NRPRODCOMVEN, $itemComanda, $mesaDestino, $mesaOrigem){
        // Atualiza a tabela ITPEDIDOFOSREL com a mesa nova.
        $params = array(
          $statusMesa['NRVENDAREST'],
          $statusMesa['NRCOMANDA'],
          $NRPRODCOMVEN,
          $itemComanda['CDFILIAL'],
          $itemComanda['NRVENDAREST'],
          $itemComanda['NRCOMANDA'],
          $itemComanda['NRPRODCOMVEN']
        );
        $this->entityManager->getConnection()->executeQuery(\Util\Query::SQL_UPDATE_ITPEDIDOFOSREL, $params);

        $params = array(
          $itemComanda['CDFILIAL'],
          $statusMesa['NRVENDAREST'],
          $statusMesa['NRCOMANDA'],
          $NRPRODCOMVEN
        );
        $paramsForChangingOrderTable = $this->entityManager->getConnection()->fetchAssoc(\Util\Query::SQL_GET_NRPEDIDOFOS, $params);
        if (!empty($paramsForChangingOrderTable)) {
          // Atualiza PEDIDOFOS para alterar o número da mesa na caixinha do K-D-S.
          $params = array(
            $mesaDestino,
            $mesaOrigem,
            $itemComanda['CDFILIAL'],
            $paramsForChangingOrderTable['NRPEDIDOFOS']
          );
          $this->entityManager->getConnection()->executeQuery(\Util\Query::SQL_UPDATE_PEDIDOFOS, $params);
        }
    }

    public function updateTransferPositions($CDFILIAL, $stNrVendaRestOri, $stNrComandaOri, $stNrProdComVenOri, $posicao){
        // Atualiza a posição no KDS.
        $params = array(
            $CDFILIAL,
            $stNrVendaRestOri,
            $stNrComandaOri,
            $stNrProdComVenOri
        );
        $itensITPEDIDOFOS = $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_ITPEDIDOFOS_BY_ITPEDIDOFOSREL, $params);

        // Para cada item a ser trocado de posição, deve-se procurar a chave dele na ITPEDIDOFOS
        foreach ($itensITPEDIDOFOS as $oldItem) {
            $params = array(
                floatval($posicao),
                $oldItem['CDFILIAL'],
                $oldItem['NRPEDIDOFOS'],
                $oldItem['NRITPEDIDOFOS']
            );
            $this->entityManager->getConnection()->executeQuery(\Util\Query::SQL_UPD_POS_KDS, $params);
        }
    }



}