<?php

namespace Service;

class OrdersEngine {

	protected $entityManager;
	protected $util;

	public function __construct(\Doctrine\ORM\EntityManager $entityManager, \Util\Util $util){
		$this->entityManager = $entityManager;
		$this->util = $util;
	}

	public function releaseOrder($releaseOperationParams){
		try {
			$CDFILIAL = $releaseOperationParams['CDFILIAL'];

			$productsReleaseList = json_decode($releaseOperationParams['PRODUCTS'], true);

			$relations = array();
			$mergedRelations = array();
			// pra cada item selecionado para liberação
			foreach ($productsReleaseList as $currentItem) {
				// busca as caixas (ITPEDIDOFOSREL) que estão associadas a ele e suas respectivas quantidades
				$newRelations = $this->getItemsByRelations($currentItem['CDFILIAL'], $currentItem['NRVENDAREST'], $currentItem['NRCOMANDA'], $currentItem['NRPRODCOMVEN']);
				foreach ($newRelations as $currentNewRelation) {
					// para cada relação, tenta agrupar
					$this->mergeRelations($relations, $currentNewRelation, $mergedRelations);
				}
			}

			$itemsToCalculate = array();
			// pra cada relação, verifica se a quantidade está diferente
			foreach ($relations as $currentRelation) {
				$currentRelation['DTHREXIBATRASO'] = new \Datetime($currentRelation['DTHREXIBATRASO'], new \DateTimeZone(date_default_timezone_get()));
				if ($currentRelation['QTPEDIDO'] != $currentRelation['QTCAIXA']) {
					// updata a caixa velha diminuindo X quantidades
					$newQuantity = $currentRelation['QTCAIXA'] - $currentRelation['QTPEDIDO'];
					// altera a quantidade da caixa antiga (ITPEDIDOFOS)
					$this->setNewBoxQuantity($currentRelation['CDFILIAL'], $currentRelation['NRPEDIDOFOS'], $currentRelation['NRITPEDIDOFOS'], $newQuantity);

					// cria nova caixa para o item atual (ITPEDIDOFOS)
					$currentRelation['oldNRITPEDIDOFOS'] = $currentRelation['NRITPEDIDOFOS'];
					$currentRelation['NRITPEDIDOFOS'] = $this->getNewNRITPEDIDOFOS($currentRelation['CDFILIAL'], $currentRelation['NRPEDIDOFOS']);
					$currentRelation['QTPRODPEFOS'] = $currentRelation['QTPEDIDO'];

					// constrói novos relacionamentos para registro na ITPEDIDOFOSREL e altera relação antiga
					$this->buildNewRelations($currentRelation, $mergedRelations, $relations);

					// insere na ITPEDIDOFOS
					$this->insertNewBox($currentRelation);
				}
				array_push($itemsToCalculate, $currentRelation);
			}

			/* *** RECALCULA O TEMPO DE EXIBIÇÃO DOS ITENS *** */
			// remove tempo de produção dos items da montagem e expedição
			$itemsToCalculate = $this->removeProductionTimeFromProducts($itemsToCalculate);
			// Ordena array por tempo de produção.
			$arrayOfItemsToUpdate = $this->orderArrayByProductionTime($itemsToCalculate);
			// Define os tempos de exibição de cada produto.
			$arrayOfItemsToUpdate = $this->defineOrderTimers($arrayOfItemsToUpdate);
			// Sequencial da liberação (para agrupar no KDS)
			$NRSEQLIBERADO = $this->getNewLiberationSeq($CDFILIAL);
			// Para cada item que foi recalculado, faz update na ITPEDIDOFOS com o tempo de atraso restante.
			foreach ($arrayOfItemsToUpdate as $item){
				// trata atraso da expedição e montagem
				$newDelay = 0;
				$this->updateProductShowtime($item['DTHREXIBICAOPROD'], $newDelay, $item['CDFILIAL'], $item['NRPEDIDOFOS'], $item['NRITPEDIDOFOS'], $NRSEQLIBERADO);
			}

		} catch (\Exception $e){
			$this->util->logException($e->getMessage());
			$response->addMessage(new Message('Ocorreu um erro na hora de liberar o produto: '.$e->getMessage()));
		}
	}

	private function compareProductionTime($a, $b){
		return strnatcmp((string)$b['NRTEMPOPRODIT'], (string)$a['NRTEMPOPRODIT']);
	}

	private function defineOrderTimers($products){
		$arrayOfItemsToUpdate = array();
		$biggestTime = 0;
		$delay = 'first';
		foreach ($products as $product){
			//coloca que já está liberado.
			$product['IDLIBERADO'] = 'S';
			// Cria intervalo de 0 segundos.
			$interval = new \DateInterval('PT0S');
			if ($delay === 'first') {
				$delay = 0;
				$biggestTime = $product['NRTEMPOPRODIT'];
			} else {
				$delay = $biggestTime - $product['NRTEMPOPRODIT'];
				$interval = new \DateInterval('PT' . $delay . 'S'); // cria intevalo de $interval segundos
			}
			if ($product['NRTEMPOPRODIT'] == 0) {
				$product['NRTEMPOPRODIT'] = $biggestTime;
				$interval = new \DateInterval('PT0S');
			}
			$DTHREXIBICAOPROD = new \Datetime($product['NOW'], new \DateTimeZone(date_default_timezone_get()));
			if ($product['IDTIPOSETOR'] == 'P') {
				$DTHREXIBICAOPROD = $DTHREXIBICAOPROD->add($interval);
			}
			$product['DTHREXIBICAOPROD'] = $DTHREXIBICAOPROD;
			array_push($arrayOfItemsToUpdate, $product);
		}
		return $arrayOfItemsToUpdate;
	}

	private function removeProductionTimeFromProducts($arrayForInsertion) {
		foreach ($arrayForInsertion as &$currentItem) {
			if ($currentItem['IDTIPOSETOR'] != 'P') {
				$currentItem['NRTEMPOPRODIT'] = '0';
				$currentItem['NRTEMPOEXIBIT'] = '0';
			}
		}
		return $arrayForInsertion;
	}

	private function orderArrayByProductionTime($order){
		usort($order, array($this, 'compareProductionTime'));
		return $order;
	}

	private function mergeRelations(&$relations, $currentNewRelation, &$mergedRelations) {
		$merged = false;
		foreach ($relations as &$currentRelation) {
			if (($currentRelation['CDFILIAL'] == $currentNewRelation['CDFILIAL']) &&
				($currentRelation['NRPEDIDOFOS'] == $currentNewRelation['NRPEDIDOFOS']) &&
				 ($currentRelation['NRITPEDIDOFOS'] == $currentNewRelation['NRITPEDIDOFOS'])) {

				// junta uma relação com a outra
				$currentRelation['QTPEDIDO'] = $currentRelation['QTPEDIDO'] + $currentNewRelation['QTPEDIDO'];
				$merged = true;
			}
		}
		if ($merged == false){
			// insere a nova relação no array
			array_push($relations, $currentNewRelation);
		}
		array_push($mergedRelations, array(
			'CDFILIAL'      => $currentNewRelation['CDFILIAL'],
			'NRPEDIDOFOS'   => $currentNewRelation['NRPEDIDOFOS'],
			'NRITPEDIDOFOS' => $currentNewRelation['NRITPEDIDOFOS'],
			'NRSEQITPEDREL' => $currentNewRelation['NRSEQITPEDREL'],
			'NRVENDAREST'   => $currentNewRelation['NRVENDAREST'],
			'NRCOMANDA'     => $currentNewRelation['NRCOMANDA'],
			'NRPRODCOMVEN'  => $currentNewRelation['NRPRODCOMVEN'],
			'IDSITITPEDFOS' => $currentNewRelation['IDSITITPEDFOS'],
			'NOW'           => $currentNewRelation['NOW']
		));
	}

	public function setNewBoxQuantity($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $QTPRODPEFOS) {
		$params = array(
			$QTPRODPEFOS,
			$CDFILIAL,
			$NRPEDIDOFOS,
			$NRITPEDIDOFOS
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::SQL_SET_NEW_QUANTITY, $params);
	}

	public function getNewNRITPEDIDOFOS($CDFILIAL, $NRPEDIDOFOS) {
		$this->util->newCode('ITPEDIDOFOS' . $CDFILIAL . $NRPEDIDOFOS);
		return $this->util->getNewCode('ITPEDIDOFOS' . $CDFILIAL . $NRPEDIDOFOS, 10);
	}

	public function getNewLiberationSeq($CDFILIAL) {
		$this->util->newCode('ITPEDIDOFOSNRSEQLIBERADO' . $CDFILIAL);
		return $this->util->getNewCode('ITPEDIDOFOSNRSEQLIBERADO' . $CDFILIAL, 10);
	}

	public function getNewNRSEQITPEDREL($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$this->util->newCode('ITPEDIDOFOSREL' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS);
		return $this->util->getNewCode('ITPEDIDOFOSREL' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS, 10);
	}

	public function getNewNRSEQITPEDPAI($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$this->util->newCode('ITPEDIDOFOSPAI' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS);
		return $this->util->getNewCode('ITPEDIDOFOSPAI' . $CDFILIAL . $NRPEDIDOFOS . $NRITPEDIDOFOS, 10);
	}

	private function buildNewRelations($currentRelation, $mergedRelations, $relations){
		foreach ($mergedRelations as $currentMergedRelation) {
			if (($currentMergedRelation['CDFILIAL'] == $currentRelation['CDFILIAL']) &&
				($currentMergedRelation['NRPEDIDOFOS'] == $currentRelation['NRPEDIDOFOS']) &&
				($currentMergedRelation['NRITPEDIDOFOS'] == $currentRelation['oldNRITPEDIDOFOS'])) {

				// da update na relação existente (ITPEDIDOFOSREL)
				$newNRSEQITPEDREL = $this->getNewNRSEQITPEDREL($currentMergedRelation['CDFILIAL'], $currentMergedRelation['NRPEDIDOFOS'], $currentRelation['NRITPEDIDOFOS']);
				$this->updateOldRelation($currentMergedRelation['CDFILIAL'], $currentMergedRelation['NRPEDIDOFOS'], $currentMergedRelation['NRITPEDIDOFOS'], $currentMergedRelation['NRSEQITPEDREL'], $currentRelation['NRITPEDIDOFOS'], $newNRSEQITPEDREL);

				// cria nova relação entre as caixas (ITPEDIDOFOSPAI)
				$oldParentsRelations = $this->getOldParentsRelations($currentMergedRelation['CDFILIAL'], $currentMergedRelation['NRPEDIDOFOS'], $currentMergedRelation['NRITPEDIDOFOS']);
				foreach ($oldParentsRelations as $currentParentRelation) {
					// verifica se o item pai da relação atual a ser criada foi liberado ou não
					$parentRelation = $this->checkIfReleased($currentParentRelation, $relations);
					if (!empty($parentRelation)) {
						$this->deleteOldParentsRelations(
							$currentRelation['CDFILIAL'],
							$currentRelation['NRPEDIDOFOS'],
							$currentRelation['oldNRITPEDIDOFOS'],
							$parentRelation['CDFILIALPAI'],
							$parentRelation['NRPEDIDOFOSPAI'],
							$parentRelation['NRITPEDIDOFOSPAI']
						);
						$this->insertNewParentRelation(
							$currentRelation['CDFILIAL'],
							$currentRelation['NRPEDIDOFOS'],
							$currentRelation['NRITPEDIDOFOS'],
							$this->getNewNRSEQITPEDPAI($currentRelation['CDFILIAL'], $currentRelation['NRPEDIDOFOS'], $currentRelation['NRITPEDIDOFOS']),
							$currentParentRelation['CDFILIALPAI'],
							$currentParentRelation['NRPEDIDOFOSPAI'],
							$currentParentRelation['NRITPEDIDOFOSPAI']
						);
					}
				}
			}
		}
	}

	private function checkIfReleased($currentParentRelation, $relations){
		foreach ($relations as $currentRelation) {
			if (($currentRelation['CDFILIAL'] == $currentParentRelation['CDFILIALPAI']) &&
				($currentRelation['NRPEDIDOFOS'] == $currentParentRelation['NRPEDIDOFOSPAI']) &&
				($currentRelation['NRITPEDIDOFOS'] == $currentParentRelation['NRITPEDIDOFOSPAI'])) {
				return array(
					'CDFILIALPAI' => $currentParentRelation['CDFILIALPAI'],
					'NRPEDIDOFOSPAI' => $currentParentRelation['NRPEDIDOFOSPAI'],
					'NRITPEDIDOFOSPAI' => $currentParentRelation['NRITPEDIDOFOSPAI']
				);
			}
		}
		return false;
	}

	public function getItemsByRelations($CDFILIAL, $NRVENDAREST, $NRCOMANDA, $NRPRODCOMVEN) {
		$params = array(
			$CDFILIAL,
			$NRVENDAREST,
			$NRCOMANDA,
			$NRPRODCOMVEN
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::SQL_GET_ITEMS_BY_RELATIONS, $params);
	}

	public function updateParentRelation($NRPEDIDOFOS, $NRITPEDIDOFOS, $NRSEQITPEDPAI, $NRPEDIDOFOSPAI, $oldCDFILIAL, $oldNRPEDIDOFOS, $oldNRITPEDIDOFOS, $oldNRSEQITPEDPAI) {
		$params = array(
			$NRPEDIDOFOS,
			$NRITPEDIDOFOS,
			$NRSEQITPEDPAI,
			$NRPEDIDOFOSPAI,
			$oldCDFILIAL,
			$oldNRPEDIDOFOS,
			$oldNRITPEDIDOFOS,
			$oldNRSEQITPEDPAI
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_ITPEDIDOFOSPAI, $params);
	}

	public function getOldParentsRelations($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS) {
		$params = array(
			$CDFILIAL,
			$NRPEDIDOFOS,
			$NRITPEDIDOFOS
		);
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_OLD_PARENTS_RELATIONS, $params);
	}

	public function deleteOldParentsRelations($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $CDFILIALPAI, $NRPEDIDOFOSPAI, $NRITPEDIDOFOSPAI) {
		$params = array(
			$CDFILIAL,
			$NRPEDIDOFOS,
			$NRITPEDIDOFOS,
			$CDFILIALPAI,
			$NRPEDIDOFOSPAI,
			$NRITPEDIDOFOSPAI
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::DELETE_OLD_PARENTS_RELATIONS, $params);
	}

	public function insertNewRelation($item) {
		$params = array(
			'CDFILIAL'      => $item['CDFILIAL'],
			'NRPEDIDOFOS'   => $item['NRPEDIDOFOS'],
			'NRITPEDIDOFOS' => $item['NRITPEDIDOFOS'],
			'NRSEQITPEDREL' => $item['NRSEQITPEDREL'],
			'NRVENDAREST'   => $item['NRVENDAREST'],
			'NRCOMANDA'     => $item['NRCOMANDA'],
			'NRPRODCOMVEN'  => $item['NRPRODCOMVEN'],
			'QTPRODPEFOS'   => $item['QTPRODPEFOS'],
			'IDSITITPEDFOS' => $item['IDSITITPEDFOS']
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::INSERT_ITPEDIDOFOSREL, $params);
	}

	public function updateOldRelation($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $NRSEQITPEDREL, $newNRITPEDIDOFOS, $newNRSEQITPEDREL) {
		$params = array(
			$newNRITPEDIDOFOS,
			$newNRSEQITPEDREL,
			$CDFILIAL,
			$NRPEDIDOFOS,
			$NRITPEDIDOFOS,
			$NRSEQITPEDREL
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::UPDATE_OLD_ITPEDIDOFOSREL, $params);
	}

	public function insertNewParentRelation($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $NRSEQITPEDPAI, $CDFILIALPAI, $NRPEDIDOFOSPAI, $NRITPEDIDOFOSPAI) {
		$params = array(
			'CDFILIAL'         => $CDFILIAL,
			'NRPEDIDOFOS'      => $NRPEDIDOFOS,
			'NRITPEDIDOFOS'    => $NRITPEDIDOFOS,
			'NRSEQITPEDPAI'    => $NRSEQITPEDPAI,
			'CDFILIALPAI'      => $CDFILIALPAI,
			'NRPEDIDOFOSPAI'   => $NRPEDIDOFOSPAI,
			'NRITPEDIDOFOSPAI' => $NRITPEDIDOFOSPAI
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::INSERT_ITPEDIDOFOSPAI, $params);
	}

	public function updateProductShowtime($exibitionTime, $newDelay, $CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $NRSEQLIBERADO){
		try {
			$params = array(
				$exibitionTime,
				$newDelay,
				$NRSEQLIBERADO,
				$CDFILIAL,
				$NRPEDIDOFOS,
				$NRITPEDIDOFOS
			);
			$this->entityManager->getConnection()->executeQuery(\Util\Query::SQL_UPDATE_PRODUCT_SHOWTIME, $params);
			$this->changeObservation($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS);
		} catch(\Exception $e) {
			throw new \Exception('Não foi possível atualizar o tempo de exibição do produto: ' . $e->getMessage());
		}
	}

	public function changeObservation($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS){
		try {
			$params = array(
				$CDFILIAL,
				$NRPEDIDOFOS,
				$NRITPEDIDOFOS
			);
			$itemObs = $this->entityManager->getConnection()->fetchAll(\Util\Query::SQL_GET_ITEM_OBS, $params);
			if (!empty($itemObs)){
				$updateObs = false;
				$newObs = array();
				$observations = json_decode($itemObs[0]['TXPRODPED'], true);
				for ($idx = 0; $idx < count($observations); $idx++) {
					if (!empty($observations[$idx]['TIPO'])) {
						$updateObs = true;
						array_push($newObs, array(
							'OBSERVACAO' => 'PODE MANDAR',
							'NRCORSINAL' => 'FFFFFF'
						));
					} else {
						array_push($newObs, $observations[$idx]);
					}
				}
				if ($updateObs) {
					$TXPRODPED = json_encode($newObs);
					$params = array(
						$TXPRODPED,
						$CDFILIAL,
						$NRPEDIDOFOS,
						$NRITPEDIDOFOS
					);
					$this->entityManager->getConnection()->executeQuery(\Util\Query::SQL_UPDATE_PRODUCT_OBS, $params);
				}
			}
		} catch(\Exception $e) {
			throw new \Exception('Não foi possível atualizar o tempo de exibição do produto: '.$e->getMessage());
		}
	}

	public function insertNewBox($item) {
		$params = array(
			$item['NRITPEDIDOFOS'],
			$item['QTPRODPEFOS'],
			$item['CDFILIAL'],
			$item['NRPEDIDOFOS'],
			$item['oldNRITPEDIDOFOS']
		);
		$this->entityManager->getConnection()->executeQuery(\Util\Query::SQL_INSERT_NEW_BOX, $params);
	}

	public function cancelItem($releaseOperationParams){
		try {
			if(isset($releaseOperationParams['QTPRODPEFOS'])) {
				$this->entityManager->getConnection()->executeQuery(\Util\Query::CANCEL_QUANT_KDS, $releaseOperationParams);
			} else {
				$this->entityManager->getConnection()->executeQuery(\Util\Query::CANCEL_ITEM_KDS, $releaseOperationParams);
			}
		} catch (\Exception $e){
			$this->util->logException($e->getMessage());
		}
	}
}