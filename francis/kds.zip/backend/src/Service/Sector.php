<?php

namespace Service;

class Sector {

	protected $entityManager;

	public function __construct(\Doctrine\ORM\EntityManager $entityManager){
		$this->entityManager = $entityManager;
	}

	public function getSectors(){
		return $this->entityManager->getConnection()->fetchAll(\Util\Query::GET_KDS_SECTORS, array());
	}

	public function getSetorParameters($CDFILIAL, $CDSETOR){
		$params = array(
			':CDFILIAL' => $CDFILIAL,
			':CDSETOR'  => $CDSETOR
		);
		return $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_SECTOR_PARAMETERS, $params);
	}


}
