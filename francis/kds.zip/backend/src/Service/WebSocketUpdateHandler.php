<?php

namespace Service;

class WebSocketUpdateHandler {

	protected $entityManager;
	protected $KDSManagerService;
	protected $KDSManagerController;
	protected $statistics;
	protected $messageService;
	protected $KDSTransferService;
	protected $orderStash;

	public function __construct(
		\Doctrine\ORM\EntityManager $entityManager,
		\Service\KDSManager $KDSManagerService,
		\Controller\KDSManager $KDSManagerController,
		\Service\OrdersEngine $OrdersEngine,
		\Service\Statistics $statistics,
		\Service\MessageService $messageService,
		\Service\KDSTransfer $KDSTransferService,
		\Util\OrderStash $orderStash) {


		$this->entityManager = $entityManager;
		$this->KDSManagerService = $KDSManagerService;
		$this->KDSManagerController = $KDSManagerController;
		$this->OrdersEngine = $OrdersEngine;
		$this->statistics = $statistics;
		$this->messageService = $messageService;
		$this->KDSTransferService = $KDSTransferService;
		$this->orderStash = $orderStash;
	}

	public function handleUpdates($socketClient) {
		$newUpdates = $this->entityManager->getConnection()->fetchAll(self::GET_KDSOPERACAOTEMP);
		foreach ($newUpdates as $currentUpdate) {
			$operation = json_decode($currentUpdate['DSOPERACAO'], true);
			switch ($operation['operation']) {
				case 'playItem':
					$this->playItem($operation['params']);
				break;
				case 'concludeItem':
					$this->concludeItem($operation['params']);
				break;
				case 'expediteOrder':
					$this->expediteOrder($operation['params']);
				break;
				case 'releaseItem' :
					$this->releaseOrder($operation['params']);
				break;
				case 'cancelItem':
					$this->cancelItem($operation['params']);
				break;
				case 'getDataFromOneClient':
					$this->getDataFromOneClient($operation['params'], $socketClient);
				break;
				case 'clearRequestsScreen':
					$this->clearRequestsScreen($operation['params']);
				break;
				case 'deleteMessage':
					$this->deleteMessage($operation['params']);
				break;
				case 'updateTransferTable':
					$this->updateTransferTable($operation['params']);
				break;
				default:
					// operação não reconhecida
				break;
			}
			// apagar registro da KDSOPERACAOTEMP passando NRSEQOPERACAO como parametro
			$params = array(
				':NRSEQOPERACAO' => $currentUpdate['NRSEQOPERACAO']
			);
			$this->entityManager->getConnection()->executeQuery(self::DEL_KDSOPERACAOTEMP, $params);
		}
	}

	private function playItem($params) {
		$this->KDSManagerService->changeStatusItemRequestPlay($params['CDFILIAL'], $params['NRPEDIDOFOS'], $params['NRITPEDIDOFOS']);
		$this->statistics->playItemStatistics($params['CDFILIAL'], $params['NRPEDIDOFOS'], $params['NRITPEDIDOFOS']);
		$this->KDSManagerService->updateDtUltAtuItPedidoFosByNrPedidoFos($params['CDFILIAL'], $params['NRPEDIDOFOS']);
	}

	private function concludeItem($params) {
		$this->KDSManagerService->doConclude($params['CDFILIAL'], $params['NRPEDIDOFOS'], $params['NRITPEDIDOFOS'], $params['IDSITITPEDFOS']);
		$this->orderStash->deleteOrder($params['CDFILIAL'] . '-' . $params['NRPEDIDOFOS'] . $params['NRITPEDIDOFOS']);
		$this->statistics->concludeItemStatistics($params['CDFILIAL'], $params['NRPEDIDOFOS'], $params['NRITPEDIDOFOS']);
		$this->KDSManagerService->updateDtUltAtuItPedidoFosByNrPedidoFos($params['CDFILIAL'], $params['NRPEDIDOFOS']);
	}

	private function expediteOrder($params) {
		$this->KDSManagerService->doExpedition($params['CDFILIAL'], $params['CDSETOR'], $params['itemsArray']);
		$this->orderStash->deleteOrder($params['CDFILIAL'] . '-' . $params['itemsArray'][0]['NRPEDIDOFOS'] . $params['itemsArray'][0]['NRITPEDIDOFOS']);
		$this->statistics->expediteOrderStatistics($params['CDFILIAL'], $params['CDSETOR'], $params['itemsArray']);
		$this->KDSManagerService->updateDtUltAtuItPedidoFosByNrPedidoFos($params['CDFILIAL'], $params['itemsArray'][0]['NRPEDIDOFOS']);
	}

	private function releaseOrder($params) {
		$this->OrdersEngine->releaseOrder($params);
	}

	private function cancelItem($params) {
		$this->OrdersEngine->cancelItem($params);
	}

	private function deleteMessage($params) {
		// um dia isso vai ser um socket amem
		$this->messageService->sendDeletedMessagesToBrowser(array($params['CDMENSAGEM']));
	}

	public function getDataFromOneClient($params, $socketClient) {

		$this->statistics->deleteOldStatistics();
		$this->KDSManagerController->getDataFromOneClient($params['CDFILIAL'], $params['CDSETOR'], $socketClient);
	    $this->messageService->getAndSendOldMessages($params['CDSETOR'], $socketClient);
	}

	private function clearRequestsScreen($params) {
		$this->KDSManagerService->clearRequestsScreen($params['CDFILIAL'], $params['NRHORA']);
	}

	private function updateTransferTable($params) {
		$this->KDSTransferService->updateTransferTable($params['statusMesa'], $params['NRPRODCOMVEN'], $params['itemComanda'], $params['mesaDestino'], $params['mesaOrigem']);
	}

	private function updateTransferPositions($params) {
		$this->KDSTransferService->updateTransferPositions($params['CDFILIAL'], $params['stNrVendaRestOri'], $params['stNrComandaOri'], $params['stNrProdComVenOri'], $params['posicao']);
	}

	const GET_KDSOPERACAOTEMP = "
		SELECT NRSEQOPERACAO, DSOPERACAO
		  FROM KDSOPERACAOTEMP
	";

	const DEL_KDSOPERACAOTEMP = "
		DELETE
		  FROM KDSOPERACAOTEMP
		 WHERE NRSEQOPERACAO = :NRSEQOPERACAO
	";
}