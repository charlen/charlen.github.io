<?php
namespace Service;

use Zeedhi\Framework\Socket\Server\Bridge;
use Zeedhi\Framework\Socket\Server\Client\ClientInterface;
use Zeedhi\Framework\Socket\Server\Event\ConnectionEvent;
use Zeedhi\Framework\Socket\Server\Payload;
use Psr\Log\LoggerInterface;
use Zeedhi\Framework\Socket\Server\Connection\ConnectionManagerInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use WebSocket\Client;

class WebSocket extends Bridge {

	protected $checkForUpdate;
	protected $webSocketService;
	protected $frozen = false;

	public function __construct(
		ConnectionManagerInterface $connectionManager,
		EventDispatcherInterface $eventDispatcher,
		LoggerInterface $logger,
		\Service\CheckForUpdate $checkForUpdate,
		\Service\WebSocketService $webSocketService
	){
		parent::__construct($connectionManager, $eventDispatcher, $logger);
		$this->checkForUpdate = $checkForUpdate;
		$this->webSocketService = $webSocketService;
	}

	const BROWSER = 'BROWSER';
	protected $browserClients = array();

	public static function getSubscribedEvents() {
		return array(
			'loginBrowser'      => array('login'),
			'logoffBrowser'     => array('logoffClient'),
			'sendChanges'       => array('sendChanges'),
			'playRequest'       => array('playRequest'),
			'ping'              => array('ping'),
			'concludeRequest'   => array('concludeRequest'),
			'expeditionRequest' => array('expeditionRequest'),
			'deleteOrders'      => array('deleteOrders'),
			'sendStatistics'    => array('sendStatistics'),
			'clearScreen'       => array('clearScreen'),
			'getData'           => array('getDataFromSector'),
			'newMessage'        => array('sendNewMessage'),
			'deleteMessage'     => array('sendDeleteMessage'),
			'freezeUpdates'     => array('freezeUpdates'),
			'unfreezeUpdates'   => array('unfreezeUpdates')
		);
	}

	public function logoffClient(ConnectionEvent $msgEvent) {
		try {
			$logoffData = $msgEvent->getPayload()->getData();
			$client = $msgEvent->getConnection();
			//$this->logExceptionWS("Matando conexão (logoff) - browser desconectado, CHAVE :" . $logoffData['SECURITYKEY']);
			unset($this->browserClients[$logoffData["SECURITYKEY"]]);
			$client->close();
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a logoffClient: ' . $e->getMessage());
		}
	}

	public function closeBrowserConnection(ConnectionEvent $msgEvent) {
		try {
			$logoffData = $msgEvent->getPayload()->getData();
			$client = $msgEvent->getConnection();
			$this->logExceptionWS("Matando conexão (closeBrowserConnection)");
			if(isset($logoffData["SECURITYKEY"])){
				unset($this->browserClients[$logoffData["SECURITYKEY"]]);
			}
			$client->close();
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a closeBrowserConnection: ' . $e->getMessage());
		}
	}

	public function ping(ConnectionEvent $msgEvent) {
		$connection = $msgEvent->getConnection();
		$payloadToClient = new Payload('pong', $msgEvent->getPayload()->getData());
		$eventToSend = new ConnectionEvent($connection, $payloadToClient);
		$connection->emit($payloadToClient, $connection->getClient());
	}

	public function login(ConnectionEvent $msgEvent) {
		try {
			$loginData = $msgEvent->getPayload()->getData();
			$clientInstance = $msgEvent->getConnection()->getClient();
			$client = array(
				"key" => $loginData['CDFILIAL'] . '-' . $loginData['CDSETOR'],
				"instance" => $clientInstance,
				// key usada para evitar substituição de keys no login
				"SECURITYKEY" => $loginData['SECURITYKEY']
			);
			// indexa array de browsers por key + microtime
			$this->browserClients[$client['SECURITYKEY']] = $client;
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar o login: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function getDataFromSector(ConnectionEvent $msgEvent) {
		try {
			$sectorData = $msgEvent->getPayload()->getData();

			// busca os pedidos para o novo login
			//agora pede pro checkForUpdate fazer isso
			$this->frozen = $this->checkForUpdate->getFrozen();
			if(!$this->frozen){
				$this->webSocketService->getDataFromOneClient($sectorData['CDFILIAL'], $sectorData['CDSETOR']);
			}else{
				$connection = $msgEvent->getConnection();
				$payloadToClient = new Payload('freezeUpdates',  array());
				foreach ($this->browserClients as $clientKey => &$client) {
					if($client['key'] == $sectorData['CDFILIAL'] . '-' . $sectorData['CDSETOR']){
						// envia para o client (browser)
						$connection->emit($payloadToClient, $client['instance']);
					}
				}
			}

		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel buscar os dados: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function sendChanges(ConnectionEvent $msgEvent) {
		try {
			$connection = $msgEvent->getConnection();
			// busca os itens indexados por client
			$payload = $msgEvent->getPayload();
			$ordersIndexedByClientKey = $payload->getData();
			// para cada browser, envia os respectivos itens
			foreach ($this->browserClients as $clientKey => &$client) {
				// verifica se há itens para este client
				if (!empty($ordersIndexedByClientKey[$client['key']])) {
					// incrementa o contador de sendChanges para este client
					if (!empty($client['COUNTER_CHANGES'])) {
						$client['COUNTER_CHANGES'] = $client['COUNTER_CHANGES'] + 1;
					} else {
						$client['COUNTER_CHANGES'] = 1;
					}
					$stuffToSend = array(
						'orders'=> $ordersIndexedByClientKey[$client['key']],
						'COUNTER_CHANGES' => $client['COUNTER_CHANGES']
					);
					// monta o novo payload
					$payloadToClient = new Payload('sendChanges', $stuffToSend);
					// envia para o client (browser)
					$connection->emit($payloadToClient, $client['instance']);
					
				}
			}
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a sendChanges: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function sendStatistics(ConnectionEvent $msgEvent) {
		try {
			$connection = $msgEvent->getConnection();

			// busca os itens indexados por client
			$payload = $msgEvent->getPayload();
			$dataIndexedByClientKey = $payload->getData();

			// para cada browser, envia os respectivos itens
			foreach ($this->browserClients as $clientKey => $client) {
				// verifica se há itens para este client
				if (!empty($dataIndexedByClientKey[$client['key']])) {
					// monta o novo payload
					$payloadToClient = new Payload('sendStatistics', $dataIndexedByClientKey[$client['key']]);

					// envia para o client (browser)
					$connection->emit($payloadToClient, $client['instance']);
				}
			}
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a sendStatistics: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function sendConclusions($orderKey, $clientKeyToSend, $msgEvent) {
		try {
			$connection = $msgEvent->getConnection();
			// para cada browser, envia os respectivos itens
			foreach ($this->browserClients as $clientKey => $client) {
				// verifica se há itens para este client
				if ($client['key'] == $clientKeyToSend) {
					// monta o novo payload
					$payloadToClient = new Payload('sendConclusions', $orderKey);
					// envia para o client (browser)
					$connection->emit($payloadToClient, $client['instance']);
				}
			}
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a sendConclusions: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function playRequest(ConnectionEvent $msgEvent){
		try {
			$params        = $msgEvent->getPayload()->getData();
			$CDFILIAL      = $params['CDFILIAL'];
			$NRPEDIDOFOS   = $params['NRPEDIDOFOS'];
			$NRITPEDIDOFOS = $params['NRITPEDIDOFOS'];
			$CDSETOR       = $params['CDSETOR'];

			$this->webSocketService->playItem($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS);
			
		} catch(\Exception $e) {
			$this->logExceptionWS('Nao possivel executar a playRequest: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function concludeRequest(ConnectionEvent $msgEvent){
		try {
			$params 	   = $msgEvent->getPayload()->getData();
			$CDFILIAL      = $params['CDFILIAL'];
			$NRPEDIDOFOS   = $params['NRPEDIDOFOS'];
			$NRITPEDIDOFOS = $params['NRITPEDIDOFOS'];
			$IDSITITPEDFOS = 'F'; // F de finalizado.
			$orderKey      = $params['orderKey'];
			$clientKey     = $params['clientKey'];
			$CDSETOR       = $params['CDSETOR'];

			$this->webSocketService->concludeItem($CDFILIAL, $NRPEDIDOFOS, $NRITPEDIDOFOS, $IDSITITPEDFOS);
			$this->sendConclusions($orderKey, $clientKey, $msgEvent);
			//$this->getStatisticsFromOneClient($CDFILIAL, $CDSETOR, $msgEvent);
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a concludeRequest: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function expeditionRequest(ConnectionEvent $msgEvent){
		try {
			$params     = $msgEvent->getPayload()->getData();
			$CDFILIAL   = $params['CDFILIAL'];
			$CDSETOR    = $params['CDSETOR'];
	 		$itemsArray = json_decode($params['itemsArray'], true);
			$orderKey   = $params['orderKey'];
			$clientKey  = $params['clientKey'];

			$this->webSocketService->expediteOrder($CDFILIAL, $CDSETOR, $itemsArray);

			// avaliar se deve ser sempre chamado ou somente quando não existem itens que não foram expedidos ainda
			//$this->sendConclusions($orderKey, $clientKey, $msgEvent);
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a expeditionRequest: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function deleteOrders(ConnectionEvent $msgEvent) {
		try {
			$connection = $msgEvent->getConnection();

			// busca os itens indexados por client
			$payload = $msgEvent->getPayload();
			$itemsToDeleteIndexedByClientKey = $payload->getData();

			// para cada browser, envia os respectivos itens
			foreach ($this->browserClients as $clientKey => $client) {
				// verifica se há itens para este client
				if (!empty($itemsToDeleteIndexedByClientKey[$client['key']])) {
					// monta o novo payload
					$payloadToClient = new Payload('deleteOrders', $itemsToDeleteIndexedByClientKey[$client['key']]);

					// envia para o client (browser)
					$connection->emit($payloadToClient, $client['instance']);
				}
			}
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a deleteOrders: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function clearScreen(ConnectionEvent $msgEvent) {
		try {
			$connection = $msgEvent->getConnection();

			// busca o payload
			$payload = $msgEvent->getPayload();
			$requestData = $payload->getData();
			$this->webSocketService->clearRequestsScreen($requestData['CDFILIAL'], $requestData['hoursNumber']);
			// para cada browser, envia os respectivos rebuilds
			foreach ($this->browserClients as $clientKey => $client) {
				$rebuildData = array(
					'event' => 'deleteOrders',
					'clear' => true,
					'client' => $client
				);
				$payloadToClient = new Payload('deleteOrders', $rebuildData);
				$connection->emit($payloadToClient, $client['instance']);
			}
		} catch(\Exception $e) {
			$this->logExceptionWS('Nao foi possivel executar a clearScreen: ' . $e->getMessage());
			$this->closeBrowserConnection($msgEvent);
		}
	}

	public function sendNewMessage(ConnectionEvent $msgEvent) {
		try {
			$connection = $msgEvent->getConnection();
			// busca os itens indexados por client
			$payload = $msgEvent->getPayload();
			$messageData = $payload->getData();
			// para cada browser, envia os respectivos itens
			foreach ($this->browserClients as $clientKey => &$client) {
				// verifica se há itens para este client
				if (!empty($messageData[$client['key']])) {
					// monta o novo payload
					$payloadToClient = new Payload('newMessage', $messageData[$client['key']]);
					// envia para o client (browser)
					$connection->emit($payloadToClient, $client['instance']);
				}
			}
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a logoffClient: ' . $e->getMessage());
		}
	}

	//isso é um broadcast
	public function sendDeleteMessage(ConnectionEvent $msgEvent) {
		try {
			$connection = $msgEvent->getConnection();
			$payload = $msgEvent->getPayload();
			$messageData = $payload->getData();
			// para cada browser, envia a mensagem
			foreach ($this->browserClients as $clientKey => &$client) {
				// monta o novo payload
				$payloadToClient = new Payload('deleteMessage', $messageData);
				// envia para o client (browser)
				$connection->emit($payloadToClient, $client['instance']);
			}
		} catch(\Exception $e){
			$this->logExceptionWS('Nao foi possivel executar a logoffClient: ' . $e->getMessage());
		}
	}

    //isso é um broadcast
    public function freezeUpdates(ConnectionEvent $msgEvent){
    	$connection = $msgEvent->getConnection();
		$payload = $msgEvent->getPayload();
		$messageData = $payload->getData();
		// para cada browser, envia a mensagem
		foreach ($this->browserClients as $clientKey => &$client) {
			// monta o novo payload
			$payloadToClient = new Payload('freezeUpdates', $messageData);
			// envia para o client (browser)
			$connection->emit($payloadToClient, $client['instance']);
		}
		$this->frozen = true;
	}
	//isso é um broadcast
	public function unfreezeUpdates(ConnectionEvent $msgEvent){
    	$connection = $msgEvent->getConnection();
		$payload = $msgEvent->getPayload();
		$messageData = $payload->getData();
		// para cada browser, envia a mensagem
		foreach ($this->browserClients as $clientKey => &$client) {
			// monta o novo payload
			$payloadToClient = new Payload('unfreezeUpdates', $messageData);
			// envia para o client (browser)
			$connection->emit($payloadToClient, $client['instance']);
		}
		$this->frozen = false;
	}

    private function logExceptionWS($info) {
        //testa se a pasta existe e cria caso não exista
        $folder = substr(__DIR__, 0, 1) . ":\\TEKNISA\\kds\\logs\\";
        if (!file_exists($folder)) {
            mkdir($folder, 0777, true);
        }
        //--grava o log
        $line = date("d-m-Y H:i:s") . " - " . $info . "\n";
        $drive = substr(__DIR__, 0, 1);
        $date = date("dmY");
        file_put_contents($drive . ":\\TEKNISA\\kds\\logs\\logExceptionWS" . $date . ".txt", $line, FILE_APPEND);
    }
}