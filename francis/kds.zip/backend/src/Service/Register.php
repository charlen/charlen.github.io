<?php

namespace Service;

class Register {
	
	protected $entityManager;

	public function __construct(\Doctrine\ORM\EntityManager $entityManager){
		$this->entityManager = $entityManager;
	}

	public function getControlRegister($CDSETOR){
		$params = array(
			':CDSETOR'  => $CDSETOR
		);
		return $this->entityManager->getConnection()->fetchAssoc(\Util\Query::GET_CONTROL_REGISTER, $params);
	}
} 
