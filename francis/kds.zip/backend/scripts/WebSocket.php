<?php
//#!/usr/bin/env php
require __DIR__.'/bootstrap.php';
$socketServer = $instanceManager->getService('socketServerFactory');
/** @var \Zeedhi\Framework\Socket\Server\Factory $socketServer */
$socketServer->run();