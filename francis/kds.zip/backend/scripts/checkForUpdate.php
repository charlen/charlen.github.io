<?php
//#!/usr/bin/env php
require __DIR__.'/bootstrap.php';
$socketServer = $instanceManager->getService('\Service\CheckForUpdate');
$socketServer->checkForUpdates();