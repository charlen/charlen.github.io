cd backend\scripts
:before
C:\xampp\php\php.exe MessageService.php
timeout 5
goto before
PAUSE