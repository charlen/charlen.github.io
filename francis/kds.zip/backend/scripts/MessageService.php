<?php
//#!/usr/bin/env php
require __DIR__.'/bootstrap.php';
$messageService = $instanceManager->getService('\Service\MessageService');
$messageService->getMessages();