<?php

header('Location: ./mobile');