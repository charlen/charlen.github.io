function gruntConfig(grunt) {
    const fs = require('fs');
    const clientConfig = JSON.parse(fs.readFileSync('config.json', 'utf8')).client;
    const cssPath = [
        "lib/zeedhi-frontend/assets/fonts/font-zeedhi/stylesheet.css",
        "lib/zeedhi-frontend/assets/css/libs/bootstrap.min.css",
        "lib/zeedhi-frontend/assets/css/general.css",
        "lib/zeedhi-frontend/assets/css/styles/styles-odhen.css",
        "css/all.min.css",
        "css/style.css",
        "css/custom-modal.css",
        "src/taa.css",
        `css/${clientConfig}.css`,
        'src/pages/**/*.css',
        'src/components/**/*.css'
    ];
    const zeedhiPath = ['lib/zeedhi-frontend/assets/dist/main.js']
    const assetsPath = [
        'js/config/*.js',
        'js/model/**/*.js',
        'js/services/**/*.js',
        'js/controllers/*.js',
        'src/config/*.js',
        'src/service/*.js',
        'src/directives/*.js',
        'src/register/*.js',
        'src/pages/**/*.js',
        'src/components/**/*.js',
        'src/*.js'
    ];

    const babelPath = [
        'build/es6/js/config/*.js',
        'build/es6/js/model/**/*.js',
        'build/es6/js/services/**/*.js',
        'build/es6/js/controllers/*.js',
        'build/es6/src/config/*.js',
        'build/es6/src/service/*.js',
        'build/es6/src/directives/*.js',
        'build/es6/src/register/*.js',
        'build/es6/src/pages/**/*.js',
        'build/es6/src/components/**/*.js',
        'build/es6/src/*.js'
    ];

    const copyFiles = [
        './json/**',
        './build/app.js',
        './build/main.css',
        './*.json',
        './lib/**',
        './src/**',
        './webfonts/**',
        './images/*',
        `./images/${clientConfig}/**`,
        `./images/button-icons/**`,
        `./images/default/**`,
        '!./node_modules/**',
        '!./lib/zeedhi-frontend/*',
        '!./lib/zeedhi-frontend/assets/compass/**',
        '!./lib/zeedhi-frontend/assets/*',
        '!./lib/zeedhi-frontend/assets/js/**',
        '!./lib/zeedhi-frontend/assets/runer/**',
        '!./lib/zeedhi-frontend/assets/specs/**',
        '!./lib/zeedhi-frontend/docs/**',
        '!./lib/zeedhi-frontend/assets/css/globals/**',
        '!./src/**/**.js',
    ];

    grunt.initConfig({
        concat: {
            zh: {
                options: {
                    process: function(src, filepath) {
                        console.log(filepath)
                        return '\n' + '// FILE: ' + filepath + '\n' + src;
                    }
                },
                src: [zeedhiPath, babelPath],
                dest: 'build/app.js'
            }
        },
        uglify: {
            options: {
                mangle: false,
                compress: true,
                report: 'min',
                // the banner is inserted at the top of the output
                banner: '/*! <%= grunt.template.today("dd-mm-yyyy") %> */\n'
            },
            main: {
                options: {
                    sourceMap: true,
                    sourceMapName: 'build/sourceMap.map',
                },
                src: 'build/taa.js',
                dest: 'build/app.js'
            }
        },
        watch: {
            options: {
                livereload: true
            },
            json: {
                files: ['config.json'],
                tasks: ['concat', 'concat_css']
            },
            js: {
                files: assetsPath,
                tasks: ['babel', 'concat']
            },
            css: {
                files: cssPath,
                tasks: ['concat_css']
            }
        },
        concat_css: {
            options: {},
            all: {
                src: cssPath,
                dest: "build/main.css"
            }
        },
        copy: {
            main: {
                files: [{
                        expand: false,
                        src: './public/index.html',
                        dest: '../build/mobile/'
                    }, { expand: true, src: copyFiles, dest: '../build/mobile/' },
                    // { expand: true, src: '../backend/**', dest: '../build/backend/' },
                ]
            }
        },
        babel: {
            options: {
                sourceMap: true
            },
            dist: {
                files: [{
                    "expand": true,
                    "src": assetsPath,
                    "dest": "build/es6/",
                    "ext": "-compiled.js"
                }]
            }
        }
    });

    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-concat-css');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-babel');

    // Default task.
    // grunt.registerTask('default', ['babel', 'concat', 'uglify', 'concat_css']);
    grunt.registerTask('default', ['babel', 'concat', 'concat_css']); //no uglify
}

module.exports = gruntConfig;