function DashboardController(
    FilialService, 
    CaixaService, 
    LojaService, 
    ProdutoService, 
    RecebimentoService,
    FilialRepository,
    CaixaRepository,
    Utilities,
    ScreenService) {
    this.init = function (widget) {
        const CDFILIAL = localStorage.getItem('filial');
        const CDCAIXA = localStorage.getItem('lock_register')
        FilialService.fetch(CDFILIAL).then((filial) => {
            const NRORG = filial.NRORG
            Promise.all([
                CaixaService.fetch(CDFILIAL, CDCAIXA, NRORG),
                RecebimentoService.fetch(CDFILIAL, CDCAIXA)])
            .then(response => {
                const caixa = response[0].shift()
                widget.getField('BTN1').readOnly = !caixa.status.is_open
                widget.getField('openRegisterButton').readOnly = caixa.status.is_open
                widget.getField('closeRegisterButton').readOnly = !caixa.status.is_open
                const CDCLIENTE = filial.CDCLIENTE
                const NRCONFTELA = caixa.NRCONFTELA;
                const CDLOJA = caixa.CDLOJA;
                LojaService.fetch(CDFILIAL, CDLOJA)
                ProdutoService.fetch(CDFILIAL, CDLOJA, CDCLIENTE, NRCONFTELA)
            })
        })

    }

    this.prepareTAA = function () {
        Promise.all([FilialRepository.findOne(), CaixaRepository.findOne()])
        .then(response => {
            Utilities.toggleFullScreen();
            ScreenService.openWindow("taa_template");
        })
    };
}

Configuration(function (ContextRegister) {
    ContextRegister.register('DashboardController', DashboardController);
});