function OperatorController(ZHPromise, Query, templateManager, ParamsService, ScreenService, RegisterService, CardapioRepository, AuthRepository, Utilities, OperatorsRepo, AuthService) {

	this.login = (row, widget) => {
		if (widget.isValid()) {
			$.getJSON('./config.json', config => {
                AuthService.auth(row.CDFILIAL, row.CDCAIXA, row.CDOPERADOR, row.CDSENHOPER, config.simulationParams)
                .then((data) => {
                        localStorage.setItem('filial', row.CDFILIAL)
                        localStorage.setItem('lock_register', row.CDCAIXA);
						ScreenService.openWindow('dashboard');
				});
			});
		}
	};

	this.prepareTAA = (loginWidget) => {
		templateManager.updateURL(this.urlTAA);
		this.loadLoginData(loginWidget);
		// Prepare window for developer mode
		$.getJSON('./config.json', jsonData => window.taaDeveloperMode = jsonData.developerMode);
		Utilities.loadVersion(loginWidget.getField('version'));
	};

	this.loadRegisters = (row, RegisterField) => {
		RegisterService.loadRegisters(row.CDFILIAL).then(function (response) {
			if (response.length === 0) {
				ScreenService.showMessage('Não existem caixas parametrizados para a modalidade TAA.');
			} else {
				RegisterField.dataSource.data = response;
				RegisterField.readOnly = false;
			}
		});
	};

	this.loadOperators = function (row, operatorsField, cdOperatorField) {
		row.LABELOPERADOR = "";
		row.CDOPERADOR = "";
		operatorsField.dataSource.data = "";
		if (row.CDCAIXA === "") {
			cdOperatorField.readOnly = true;
		} else {
			cdOperatorField.readOnly = false;
		}
		RegisterService.loadOperators(row.CDFILIAL).then(function (response) {
			if (response.length === 0) {
				ScreenService.showMessage('Não existe um operador associado a esta filial.');
			} else {
				operatorsField.dataSource.data = response;
			}
		});
	};

	this.getOperator = function (widget) {
		widget.currentRow.LABELOPERADOR = '';
		widget.currentRow.CDOPERADOR = Utilities.padWithZeros(widget.currentRow.CDOPERADOR, 12);
		OperatorsRepo.findOne(Query.build().where('CDOPERADOR').equals(widget.currentRow.CDOPERADOR)).then(function (operator) {
			if (operator) {
				widget.currentRow.LABELOPERADOR = operator.NMOPERADOR;
			} else {
				ScreenService.showMessage('Operador não identificado.').then(function () {
					widget.currentRow.CDOPERADOR = '';
					widget.currentRow.LABELOPERADOR = '';
				});
			}
		});
	};

	this.loadLoginData = function (loginWidget) {
		ParamsService.getFiliais().then((filiais) => {
			var filialField = templateManager.container.getWidget('loginWidget').getField('LABELFILIAL');
			loginWidget.currentRow.LABELOPERADOR = '';
			loginWidget.currentRow.CDOPERADOR = '';
			if (filiais.length == 1) {
				var filial = filiais[0];
				filialField.readOnly = true;
				filialField.setValue(filial.LABELFILIAL);
				loginWidget.currentRow.CDFILIAL = filial.CDFILIAL;
				RegisterService.loadRegisters(filial.CDFILIAL).then((registers) => {
					if (localStorage.getItem('lock_register')) {
						var registersField = templateManager.container.getWidget('loginWidget').getField('LABELCAIXA');
						var IDCAIXALOCK = localStorage.getItem('lock_register');
						var register = registers.find(function (register) {
							return register.CDCAIXA == IDCAIXALOCK;
						});
						registersField.readOnly = true;
						registersField.setCurrentRow(register);
						registersField.setValue(register.LABELCAIXA);
						loginWidget.currentRow.CDCAIXA = register.CDCAIXA;
						templateManager.container.getWidget('loginWidget').getField('CDOPERADOR').readOnly = false;
						RegisterService.loadOperators(filial.CDFILIAL).then(function (operators) {
							var operatorsField = templateManager.container.getWidget('loginWidget').getField('LABELOPERADOR');
							if (operators.length == 1) {
								var operator = operators[0];
								operatorsField.setCurrentRow(operator);
								operatorsField.setValue(operator.LABELOPERADOR);
							} else {
								operatorsField.dataSource.data = operators;
							}
						});
					} else if (!localStorage.getItem('Lock_register')) {
						var registersField = templateManager.container.getWidget('loginWidget').getField('LABELCAIXA');
						if (registers.length == 1) {
							var register = registers[0];
							registersField.setCurrentRow(register);
							registersField.setValue(register.LABELCAIXA);
							loginWidget.currentRow.CDCAIXA = register.CDCAIXA;
							localStorage.setItem('lock_register', register.CDCAIXA);
							templateManager.container.getWidget('loginWidget').getField('CDOPERADOR').readOnly = false;
							RegisterService.loadOperators(filial.CDFILIAL).then(function (operators) {
							var operatorsField = templateManager.container.getWidget('loginWidget').getField('LABELOPERADOR');
							if (operators.length == 1) {
								var operator = operators[0];
								operatorsField.setCurrentRow(operator);
								operatorsField.setValue(operator.LABELOPERADOR);
								} else {
									operatorsField.dataSource.data = operators;
								}
							});
						} else {
							registersField.readOnly = false;
							registersField.dataSource.data = registers;
						}
					}
				})
			}
		})
	};

	this.logout = function () {
		ScreenService.confirmMessage(
			'Deseja realmente sair?',
			'question',
			() => {
				var promises = [];
				promises.push(AuthRepository.clearAll());
				promises.push(CardapioRepository.clearAll());
				ZHPromise.all(promises).then(function (data) {
					ScreenService.openWindow('login');
				});
			},
			() => {
				ScreenService.goBack();
			}
		);
	};

	this.validateOperatorPass = function (widget) {
		var SENHADIG = widget.currentRow.SENHADIG,
			CDOPERADOR = widget.currentRow.CDOPERADOR,
			CDFILIAL = widget.currentRow.CDFILIAL;
		if (!SENHADIG) {
			ScreenService.notificationMessage("Preencha os dados.", 'error', 4000);
		} else {
			ParamsService.validateOperatorPass(SENHADIG, CDOPERADOR, CDFILIAL).then(function (data) {
				if (data[0].error) {
					ScreenService.showMessage(data[0].message);
				} else {
					Utilities.toggleFullScreen();
					ScreenService.openWindow('dashboard');
					widget.container.showFooter = false;
				}
			});
		}
	};

	this.cancelValidatePass = (validateOperatorWidget) => {
		validateOperatorWidget.activate();
		ScreenService.closeSwipe(0);
	};
}

Configuration(function (ContextRegister) {
	ContextRegister.register('OperatorController', OperatorController);
});