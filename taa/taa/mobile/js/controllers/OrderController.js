function OrderController(ZHPromise, AuthRepository, OpenRegisterRepository, OrderService, ScreenService, TEFTransactionRepo) {
    this.loadBilletData = function(CDFILIAL, DSCOMANDA) {
        return OrderService.loadBilletData(CDFILIAL, DSCOMANDA);
    }
}

Configuration(function(ContextRegister) {
	ContextRegister.register('OrderController', OrderController);
});