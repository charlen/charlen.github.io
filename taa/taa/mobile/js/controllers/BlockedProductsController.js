function BlockedProductsController(
    ProdutoRepository,
    CaixaRepository,
    BlockedProductsService,
    ScreenService,
    BlockedProductsRepository,
    templateManager
) {
    this.loadMenuProducts = function (gridWidget)  {
        var promises = [
            CaixaRepository.findOne(),
            ProdutoRepository.findOne(),
        ]
        Promise.all(promises)
        .then(function(response) {
            var caixa = response[0]
            var product = response[1]
            console.log(product);
            BlockedProductsService.getBlockedProducts(caixa.CDFILIAL, caixa.CDLOJA).then(response => {
                var menuProducts = product.products;
                var productsBlocked = response;
                menuProducts.forEach(function (crrProd, crrIndex){
                    
                    const indexMenu = productsBlocked.findIndex(function (bloqProd){
                        return bloqProd.CDPRODUTO === crrProd.CDPRODUTO;
                    });

                    if(indexMenu >= 0) {
                        menuProducts[crrIndex].IDPRODBLOCK = "Bloqueado";
                        menuProducts[crrIndex].IDPRODBLOCKBOOL = true;
                    } else  {                      
                        menuProducts[crrIndex].IDPRODBLOCK = "Desbloqueado";
                        menuProducts[crrIndex].IDPRODBLOCKBOOL = false;
                    }
                });

                ProdutoRepository.save(product).then(function() {
                    ProdutoRepository.findOne().then(product => {
                        const products = product.products;
                        const groupProducts = product.groups;
                        const subGroupProducts = product.subGroups;
                        let gridProducts = [];
            
                        products.forEach(prod => {
                            groupProducts.forEach(prodGrup => {
                                if (prodGrup.CDGRUPO === prod.CDGRUPO) {
                                    prod.LABELGRUPO =
                                        prod.CDGRUPO + ' - ' + prodGrup.NMGRUPO;
                                }
                            });
                            subGroupProducts.forEach(prodSubGrup => {
                                if (prodSubGrup.CDGRUPO == prod.CDGRUPO) {
                                    prod.LABELSUBGRUPO =
                                        prod.CDGRUPO + ' - ' + prodSubGrup.NMSUBGRUPO;
                                }
                            });
                            gridProducts.push(prod);
                        });
                        gridWidget.dataSource.data = gridProducts;
                    });
                })
            });
        });


        
    };

    this.loadMenuPromoGroups = (productsData, promoGroupsWidget) => {
        const promoGroups = _getPromoGroups(productsData);
        BlockedProductsRepository.findAll().then(blockedProducts => {
            const products = _buildProductsForGrid(
                promoGroups,
                blockedProducts
            );

            /* Hide promo groups tab if doesn't have any product */
            if (!products.length) promoGroupsWidget.isVisible = false;

            promoGroupsWidget.dataSource.data = products;
        });
    };

    const _getPromoGroups = products => {
        // Filter all promo groups from menu (remove repeated ones)
        let promoGroups = [];
        products
            .filter(product => product.IDTIPOCOMPPROD == '3')
            .forEach(comboProduct => {
                Object.keys(comboProduct.GRUPOS).forEach(groupKey => {
                    const currentGroup = comboProduct.GRUPOS[groupKey];
                    const isNewGroup = promoGroups.every(
                        promoGroup =>
                            promoGroup.grupo.CDGRUPROMOC !=
                            currentGroup.grupo.CDGRUPROMOC
                    );
                    if (isNewGroup) promoGroups.push(currentGroup);
                });
            });
        return promoGroups;
    };

    const _buildProductsForGrid = (promoGroups) => {
        let builtProducts = [];
        promoGroups.forEach(promoGroup => {
            Object.keys(promoGroup.produtos).forEach(promoProductKey => {
                let currentProduct = promoGroup.produtos[promoProductKey];
                currentProduct.LABELGRUPO =
                    promoGroup.grupo.CDGRUPROMOC +
                    ' - ' +
                    promoGroup.grupo.NMGRUPROMOC;
                builtProducts.push(currentProduct);
            });
        });
        return builtProducts;
    };

    this.handleBlockProduct = function(row, dataSource) {
        const hasToBlock = !row.IDPRODBLOCKBOOL;
        CaixaRepository.findOne().then(caixa => {
            ScreenService.confirmMessage(
                `Deseja ${hasToBlock ? 'bloquear' : 'desbloquear'} o produto ${
                    row.NMPRODUTO
                } ?`,
                'question',
                () => {
                    /* @toDo: Refactor this request using restEngine */
                    BlockedProductsService.handleBlockProduct(
                        hasToBlock,
                        caixa.CDFILIAL,
                        caixa.CDLOJA,
                        caixa.CDOPERADOR,
                        row.CDPRODUTO
                    ).then(response => {
                        if (!response.error) {
                            row.IDPRODBLOCKBOOL = !row.IDPRODBLOCKBOOL;
                            templateManager.updateTemplate();
                            if (hasToBlock) {
                                row.IDPRODBLOCK = 'Bloqueado';
                                ScreenService.showMessage(
                                    'Produto bloqueado com sucesso!'
                                );
                            } else {
                                row.IDPRODBLOCK = 'Desbloqueado';
                                ScreenService.showMessage(
                                    'Produto desbloqueado com sucesso!'
                                    );
                            }
                            ProdutoRepository.findOne().then(function(product){
                                produtos = product.products;
                                const indexEncontrado = produtos.findIndex(function (produto){
                                    return row.CDPRODUTO == produto.CDPRODUTO;
                                })
                                produtos[indexEncontrado] = row;
                                ProdutoRepository.save(product);
                            })
                        } else {
                            ScreenService.showMessage(
                                'Erro ao realizar operação.'
                            );
                        }
                    
                    });
                },
                () => {}
            );
        });
    };

    this.loadBlockedProducts = blockedProductsWidget => {
        CaixaRepository.findOne().then(caixa => {
            const { parametros } = caixa;
            BlockedProductsService.getBlockedProducts(
                parametros.CDFILIAL,
                parametros.CDLOJA,
                parametros.CDOPERADOR
            ).then(blockedProducts => {
                blockedProductsWidget.dataSource.data = blockedProducts;
            });
        });
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register(
        'BlockedProductsController',
        BlockedProductsController
    );
});
