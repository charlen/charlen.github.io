function DownloadController(CaixaRepository, DownloadImagesService, ScreenService) {

    this.downloader = function(FORCEDOWNLOAD){
        CaixaRepository.findOne().then((caixa) => {
            const nrConfTela = caixa.NRCONFTELA;
            DownloadImagesService.downloader(nrConfTela, FORCEDOWNLOAD)
            .then((response) => {
                    if(response.dataset.folderExists.success == true && response.messages[0].message == "callQuestion"){
                        this.chooseOption(nrConfTela);
                    }
                }
            ).catch((error) => {
                console.log(error)
                this.errorMessage();
            })
        });

    }

    this.chooseOption = function(nrConfTela) {
        ScreenService.confirmMessage(
            "Já existe imagens baixadas neste TAA. \nDeseja baixar novamente?",
            "CONFIRMATION",
            () => {
                this.forceDownloadOn(nrConfTela);
            }
        );
    };

    this.forceDownloadOn = function(nrConfTela){
        DownloadImagesService.downloader(nrConfTela, true)
        .then((response) => {
        }).catch((error) => {
            console.log(error)
            this.errorMessage();
        })
    }

    this.errorMessage = function(){
        ScreenService.showMessage("Erro ao criar a pasta");
    } 
}

Configuration(function(ContextRegister) {
    ContextRegister.register('DownloadController', DownloadController);
});