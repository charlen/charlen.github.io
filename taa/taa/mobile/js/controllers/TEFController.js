function TEFController(TEFService, FilialRepository, AuthRepository, CaixaRepository, ScreenService, Utilities, ZHPromise, CapptaService) {

    const SOFTWARE_EXPRESS_ID = '0';
    const CAPPTA_PAYMENT_ID = '2';
	this.performTransaction = function (payment, simulateTef, totalSale, capptaInstance) {
		totalSale = parseInt(totalSale * 100)/100;
		if (simulateTef) {
			return _getTefSimulationData();
		} else {
			return CaixaRepository.findOne().then(caixa => {
				if (caixa.IDTPTEF === CAPPTA_PAYMENT_ID) {
					return CapptaService.performTransaction(capptaInstance, payment, totalSale).then(response => {
						if (response.error) {
							return response;
						} else {
							const { administrativeCode } = response;
							const { cardBrandCode } = response;
							return TEFService.getCapptaTransaction(cardBrandCode, administrativeCode).then(response => response.dataset.CapptaTransaction);
						}
					});
				} else if(caixa.IDTPTEF === SOFTWARE_EXPRESS_ID) {
					var promises = [];
					promises.push(FilialRepository.findOne());
					promises.push(CaixaRepository.findOne());
					promises.push(AuthRepository.findOne());
					return ZHPromise.all(promises).then(function(data) {
						const filial = data[0]
						const caixa = data[1]
						const operador = data[2]
						return doTransaction(filial, caixa, operador, payment, simulateTef, totalSale, false);
					})
			}
			});
		}
	};

	function doTransaction(filial, caixa, operador, payment, simulateTef, totalSale, isContinuation) {
		return TEFService.performTransaction(filial, caixa, operador, payment.CDTIPORECE, payment.IDTIPORECE, simulateTef, totalSale, isContinuation)
			.then(response => {
				response =  response.dataset.TEFTransactionRepo;
				ScreenService.changeLoadingMessage(Utilities.capitilizeFirstLetter(response.message));
				return transactionReponseCallback(filial, caixa, operador, payment, simulateTef, totalSale, response);
			});
	}

	function transactionReponseCallback(filial, caixa, operador, payment, simulateTef, totalSale, response) {
		if(response && !response.finishedTransaction) {
			return doTransaction(filial, caixa, operador, payment, simulateTef, totalSale, true);
		} else {
			return ZHPromise.when(response);
		}
	}

	const _getTefSimulationData = () => {
		const tefData = {
			error: false,
			canceled: false,
			dados: {
				CDNSUHOSTTEF: '999999999',
				CDTIPORECE: '008',
				IDSENHACUP: 'S'
			},
			message: 'Modo de simulação',
			finishedTransaction: true
		};

		return Promise.resolve(tefData);
    };
    
    this.performCancellation = function(widget) {
        if(widget.isValid()) {
            ScreenService.restoreDefaultLoadingMessage();
            const {DOCTEF, VALORVENDA, TYPECANCELLATION, DTVENDA} = widget.currentRow;
            AuthRepository.findOne()
            .then(response => {
                const {CDFILIAL, CDCAIXA, CDOPERADOR} = response.parametros;
                doCancellation(CDFILIAL, CDCAIXA, DOCTEF, TYPECANCELLATION, VALORVENDA, DTVENDA, CDOPERADOR, false)
            })
        }

    }

    function doCancellation(CDFILIAL, CDCAIXA, DOCTEF, TYPECANCELLATION, VALORVENDA, DTVENDA, CDOPERADOR, isContinuation) {
        TEFService.performCancellation({
            CDFILIAL, CDCAIXA, DOCTEF, TYPECANCELLATION, VALORVENDA, DTVENDA, CDOPERADOR, isContinuation
        })
        .then(function(response) {
            response =  response.dataset.TEFCancellationRepo;
            ScreenService.changeLoadingMessage(Utilities.capitilizeFirstLetter(response.message));
            return cancellationResponseCallback(CDFILIAL, CDCAIXA, DOCTEF, TYPECANCELLATION, VALORVENDA, DTVENDA, CDOPERADOR, response);
        })
        .catch(function(error){
            console.log(error)
        })
    }

    function cancellationResponseCallback(CDFILIAL, CDCAIXA, DOCTEF, TYPECANCELLATION, VALORVENDA, DTVENDA, CDOPERADOR, response) {
		if(response && !response.finishedTransaction) {
			return doCancellation(CDFILIAL, CDCAIXA, DOCTEF, TYPECANCELLATION, VALORVENDA, DTVENDA, CDOPERADOR, true);
		} else {
            return ScreenService.showMessage(response.message)
            .then(function(){
                ScreenService.openWindow('dashboard');
            });
		}
	}
}

Configuration(function(ContextRegister) {
	ContextRegister.register('TEFController', TEFController);
});