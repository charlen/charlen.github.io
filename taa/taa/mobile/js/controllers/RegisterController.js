function RegisterController(
  ScreenService,
  AuthRepository,
  RegisterService,
  OpenRegisterRepository,
  ZHPromise,
  Utilities,
  CaixaRepository,
  FilialRepository
) {
  this.loadOpenRegisterParams = function(openRegisterWidget) {
    AuthRepository.findAll().then(function(loginData) {
      var generalParams = loginData[0].parametros;

      openRegisterWidget.getField("CDFILIAL").setValue(generalParams.CDFILIAL);
      openRegisterWidget.getField("NMFILIAL").setValue(generalParams.NMFILIAL);
      openRegisterWidget.getField("CDCAIXA").setValue(generalParams.CDCAIXA);
      openRegisterWidget.getField("NMCAIXA").setValue(generalParams.NMCAIXA);
      openRegisterWidget
        .getField("CDOPERADOR")
        .setValue(generalParams.CDOPERADOR);
      openRegisterWidget
        .getField("NMOPERADOR")
        .setValue(generalParams.NMOPERADOR);
      openRegisterWidget
        .getField("DTABERCAIX")
        .setValue(moment().format("DD/MM/YYYY HH:mm:ss"));
    });
  };

  this.openRegister = function(openRegisterWidget, row) {
    if (openRegisterWidget.isValid()) {
      RegisterService.openRegister(
        row.CDFILIAL,
        row.CDCAIXA,
        row.CDOPERADOR,
        row.VRMOVIVEND
      ).then(function(response) {
        ScreenService.showMessage(response[0].message);
        ScreenService.openWindow("dashboard");
      });
    } else {
      ScreenService.showMessage("Preencha todos os campos obrigatórios");
    }
  };

  this.checkRegisterStatus = function(widget) {
    var promises = [];
    promises.push(OpenRegisterRepository.findOne());
    promises.push(AuthRepository.findOne());

    ZHPromise.all(promises).then(data => {
      var registerData = data[0];
      var generalParams = data[1].parametros;
      var registerNameLabel = widget.getField("NMCAIXA");

      if (registerData.estado == "fechado") {
        widget.getField("openRegisterButton").readOnly = false;
        widget.getField("closeRegisterButton").readOnly = true;
        widget.getField("BTN1").readOnly = true;

        ScreenService.confirmMessage(
          "Caixa fechado, deseja abrir?",
          "question",
          function() {
            ScreenService.openWindow("openRegister");
            Utilities.toggleFullScreen();
          },
          function() {}
        );
      } else {
        widget.getField("openRegisterButton").readOnly = true;
        widget.getField("closeRegisterButton").readOnly = false;
        widget.getField("BTN1").readOnly = false;

        this.validateRegisterOpening(
          registerData.DTABERCAIX,
          registerData.CDOPERABER,
          generalParams.CDOPERADOR
        );
      }

      // Updates register label on dashboard
      if (registerData.estado) {
        registerNameLabel.label =
          "O CAIXA " +
          generalParams.CDCAIXA +
          " SE ENCONTRA " +
          registerData.estado.toUpperCase();
      }
    });
  };

  this.validateRegisterOpening = function(
    openRegisterData,
    openingOperator,
    loginOperator
  ) {
    if (openRegisterData) {
      var currentDate = new Date();

      var dates = openRegisterData.split(" ")[0].split("/");
      // Had to subtract one from month because javascript starts month from 0.
      var openRegisterDate = new Date(dates[2], dates[1] - 1, dates[0]);

      if (openingOperator && openingOperator != loginOperator) {
        ScreenService.confirmMessage(
          "O caixa foi aberto por outro operador (" +
            openingOperator +
            ")<p>Deseja fechar?</p>",
          "question",
          function() {
            ScreenService.openWindow("closeRegister");
          },
          function() {
            ScreenService.openWindow("login");
          }
        );
      } else if (currentDate.withoutTime() > openRegisterDate) {
        ScreenService.showMessage(
          "Caixa aberto no dia anterior. Neste momento o sistema irá fechar o caixa automaticamente."
        ).then(function() {
          ScreenService.openWindow("closeRegister");
        });
      }
    }
  };

  this.closeRegisterAutomatically = function() {
    var promises = [];
    promises.push(FilialRepository.findOne());
    promises.push(CaixaRepository.findOne());
    promises.push(AuthRepository.findOne());

    ScreenService.changeLoadingMessage("Fechando caixa...");
    ZHPromise.all(promises).then(function(data) {
      const {CDFILIAL, NRORG} = data[0]
      const {CDCAIXA, NRCONFTELA} = data[1]
      const {CDOPERADOR} = data[2]
      $.getJSON("./config.json", function(jsonData) {
        if (!jsonData.simulationParams.simulatePrinter) {
          ScreenService.confirmMessage(
            "Gostaria de imprimir relatório de fechamento?",
            "QUESTION",
            function() {
              _callCloseRegister(CDFILIAL, CDCAIXA, CDOPERADOR, NRCONFTELA, NRORG, true);
            },
            function() {
              _callCloseRegister(CDFILIAL, CDCAIXA, CDOPERADOR, NRCONFTELA, NRORG, false);
            }
          );
        } else {
          _callCloseRegister(CDFILIAL, CDCAIXA, CDOPERADOR, NRCONFTELA, NRORG, false);
        }
      });
    });
  };

  const _callCloseRegister = (
    CDFILIAL, CDCAIXA, CDOPERADOR, NRCONFTELA, NRORG, printReport
  ) => {
    RegisterService.closeRegister(
      CDFILIAL,
      CDCAIXA,
      CDOPERADOR,
      NRCONFTELA,
      NRORG,
      printReport
    ).then(function(response) {
      if (!response[0].error) {
        let message = response[0].message;
        if (response[0].mensagemImpressao) {
          message = `${message} ${response[0].mensagemImpressao}`;
        }
        ScreenService.openWindow("dashboard");
      } else {
        ScreenService.showMessage(response[0].message);
        ScreenService.openWindow("dashboard");
      }
    });
  };

  this.openRegisterAutomatically = function() {
    ScreenService.changeLoadingMessage("Abrindo caixa...");
    var promises = [];
    promises.push(FilialRepository.findOne());
    promises.push(CaixaRepository.findOne());
    promises.push(AuthRepository.findOne());
    ZHPromise.all(promises).then(function(data) {
      const {CDFILIAL, NRORG} = data[0]
      const {CDCAIXA} = data[1]
      const {CDOPERADOR} = data[2]
      RegisterService.openRegister(
        CDFILIAL,
        CDCAIXA,
        CDOPERADOR,
        NRORG
      ).then(response => {
        if (response[0].error) {
          ScreenService.openWindow("dashboard");
        } else {
          ScreenService.openWindow("taa_template");
        }
      });
    });
  };

  this.closeScreenFields = function(widget) {
    
    let promises = [];
    promises.push(CaixaRepository.findOne());
    promises.push(AuthRepository.findOne());
    promises.push(FilialRepository.findOne());

    ZHPromise.all(promises)
    .then((data) => {
        const caixa = data[0];
        const operator = data[1];
        const filial = data[2];
        widget.getField("LABELCAIXA").value(caixa.CDCAIXA + ' - ' + caixa.NMCAIXA);
        widget
          .getField("LABELFILIAL")
          .value(filial.CDFILIAL + " - " + filial.NMFILIAL);
        widget
          .getField("CDFILIAL")
          .value(filial.CDFILIAL);
      })
  };
}

Configuration(function(ContextRegister) {
  ContextRegister.register("RegisterController", RegisterController);
});
