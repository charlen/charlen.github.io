function CancelRechargeController(ScreenService, CancelRechargeService, AuthRepository, ConsumerService) {

    this.getDeposiconsData = function(widget) {
        AuthRepository.findOne().then(loginData => {
            const { CDFILIAL } = loginData.parametros;
            const { NRDEPOSICONS, CDIDCONSUMID, CDCLIENTE } = widget.currentRow;
            CancelRechargeService.getDeposiconsData(NRDEPOSICONS, CDIDCONSUMID, CDFILIAL, CDCLIENTE)
            .then(function(data){
                if(!!data.dataset.DEPOSICONSDATA.error){
                    ScreenService.showMessage(data.dataset.DEPOSICONSDATA.message);
                } else {
                    ScreenService.confirmMessage(`<p>Nome: ${data.dataset.DEPOSICONSDATA.DEPOSICONSDATA.NMCONSUMIDOR}</p>
                                                  <p>Valor da recarga: ${data.dataset.DEPOSICONSDATA.DEPOSICONSDATA.VRMOVEXTCONS.toMoney()} </p>
                                                  Deseja cancelar a recarga?`, 'QUESTION', _confirmCancelRecharge(data.dataset.DEPOSICONSDATA.DEPOSICONSDATA, generalParams.CDFILIAL, generalParams.CDCAIXA, generalParams.NRORG, NRDEPOSICONS), _denyCancelRecharge())
                }
            });
        });
    }
    
    _confirmCancelRecharge = (DEPOSICONSDATA, CDFILIAL, CDCAIXA, NRORG, NRDEPOSICONS) => {
        return () => {
            CancelRechargeService.cancelPersonalCredit(DEPOSICONSDATA, CDFILIAL, CDCAIXA, NRORG, NRDEPOSICONS)
            .then(function (cancelResult){
                console.log(cancelResult);
            });
        }
    }

    this.getConsumer = function(widget) {
        const { CDIDCONSUMID } = widget.currentRow;
        AuthRepository.findOne().then(loginData => {
            const { CDFILIAL } = loginData.parametros;
            ConsumerService.getConsumerToCancelRecharge({
                CDFILIAL,
                CDIDCONSUMID
            })
            .then(response => {
                widget.getField('NMCONSUMIDOR').isVisible = !response.error;
                widget.getField('NRDEPOSICONS').isVisible = !response.error;
                if(response.error) {

                } else {
                    widget.currentRow.NMCONSUMIDOR = response.dataset.getConsumerToCancelRecharge.consumer.NMCONSUMIDOR
                }
            })
            .catch(error => {
                console.log(error)
            })
        })
    }

    _denyCancelRecharge = () => {
        return () => {

        }
    }
}

Configuration(function(ContextRegister) {
	ContextRegister.register('CancelRechargeController', CancelRechargeController);
});