function CancelSaleController(ScreenService, AuthRepository, CancelSaleService) {
    this.saleCancel = function(widget) {
        const { CODIGOCUPOM } = widget.currentRow;
        if(!CODIGOCUPOM) {
            return;
        }
        AuthRepository.findOne().then(loginData => {
            const { CDFILIAL, CDCAIXA, NRORG, CDOPERADOR } = loginData.parametros;
            CancelSaleService.saleCancel({
                CODIGOCUPOM,
                CDFILIAL,
                CDCAIXA,
                NRORG,
                CDOPERADOR
            })
            .then(response => {
                if(response.dataset.saleCancel.error) {
                    ScreenService.showMessage(response.dataset.saleCancel.message)
                } else {
                    ScreenService.confirmMessage(`${response.dataset.saleCancel.message} Gostaria de realizar o estorno do cartão?`, 'question', 
                    function() {
                        ScreenService.openWindow('cancelTEF')
                    },
                    function() {
                        widget.currentRow = {};
                    })
                }
            })
            .catch(error => {
                console.log(error)
            })
        })
    }
}

Configuration(function(ContextRegister) {
	ContextRegister.register('CancelSaleController', CancelSaleController);
});