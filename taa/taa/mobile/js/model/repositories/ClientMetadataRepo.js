Configuration(function(ContextRegister, RepositoryFactory) {
	var ClientMetadataRepo = RepositoryFactory.factory('/ClientMetadataRepo', 'LOCAL');
	ContextRegister.register('ClientMetadataRepo', ClientMetadataRepo);
});