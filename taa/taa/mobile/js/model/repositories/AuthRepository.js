Configuration(function(ContextRegister, RepositoryFactory) {	
	const AuthRepository = RepositoryFactory.factory('/auth', 'LOCAL', 3, 100000);
	ContextRegister.register('AuthRepository', AuthRepository);
});