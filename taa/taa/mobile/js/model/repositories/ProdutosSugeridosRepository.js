Configuration(function(ContextRegister, RepositoryFactory) {
	var ProdutosSugeridosRepository = RepositoryFactory.factory('/ProdutosSugeridosRepository', 'LOCAL');
	ContextRegister.register('ProdutosSugeridosRepository', ProdutosSugeridosRepository);
});