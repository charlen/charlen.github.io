Configuration(function(ContextRegister, RepositoryFactory) {
    var ExternalSaleDataRepo = RepositoryFactory.factory('/ExternalSaleDataRepo', 'LOCAL');
    ContextRegister.register('ExternalSaleDataRepo', ExternalSaleDataRepo);
});