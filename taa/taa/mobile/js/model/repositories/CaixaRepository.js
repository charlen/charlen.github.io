Configuration(function(ContextRegister, RepositoryFactory) {	
	const CaixaRepository = RepositoryFactory.factory('/caixa', 'LOCAL', 3, 100000);
	ContextRegister.register('CaixaRepository', CaixaRepository);
});