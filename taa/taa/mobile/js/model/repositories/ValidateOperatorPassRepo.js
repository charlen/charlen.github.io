Configuration(function(ContextRegister, RepositoryFactory) {
	var ValidateOperatorPassRepo = RepositoryFactory.factory('/ValidateOperatorPassRepo', 'LOCAL');
	ContextRegister.register('ValidateOperatorPassRepo', ValidateOperatorPassRepo);
});