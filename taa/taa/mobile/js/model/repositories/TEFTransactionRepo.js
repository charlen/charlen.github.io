Configuration(function(ContextRegister, RepositoryFactory) {
	var TEFTransactionRepo = RepositoryFactory.factory('/TEFTransactionRepo', 'LOCAL', 5, 50000000);
	ContextRegister.register('TEFTransactionRepo', TEFTransactionRepo);
});