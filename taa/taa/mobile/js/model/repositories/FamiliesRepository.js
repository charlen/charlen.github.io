Configuration(function(ContextRegister, RepositoryFactory) {
    var FamiliesRepository = RepositoryFactory.factory('/FamiliesRepository', 'LOCAL');
    ContextRegister.register('FamiliesRepository', FamiliesRepository);
});