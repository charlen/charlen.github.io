Configuration(function(ContextRegister, RepositoryFactory) {
    var BlockedProductsRepository = RepositoryFactory.factory('/BlockedProductsRepository', 'LOCAL');
    ContextRegister.register('BlockedProductsRepository', BlockedProductsRepository);
});