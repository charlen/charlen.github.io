Configuration(function(ContextRegister, RepositoryFactory) {
	var CloseRegisterRepository = RepositoryFactory.factory('/CloseRegisterRepository', 'LOCAL', 1, 60000);
	ContextRegister.register('CloseRegisterRepository', CloseRegisterRepository);
});