Configuration(function(ContextRegister, RepositoryFactory) {	
	var UtilitiesTestRepository = RepositoryFactory.factory('/UtilitiesTestRepository', 'LOCAL');
	ContextRegister.register('UtilitiesTestRepository', UtilitiesTestRepository);
});