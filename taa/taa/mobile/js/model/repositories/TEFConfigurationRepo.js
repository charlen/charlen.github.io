Configuration(function(ContextRegister, RepositoryFactory) {
    var TEFConfigurationRepo = RepositoryFactory.factory('/TEFConfigurationRepo', 'LOCAL');
    ContextRegister.register('TEFConfigurationRepo', TEFConfigurationRepo);
});