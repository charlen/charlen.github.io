Configuration(function(ContextRegister, RepositoryFactory) {
	var ObservacoesRepository = RepositoryFactory.factory('/ObservacoesRepository', 'LOCAL');
	ContextRegister.register('ObservacoesRepository', ObservacoesRepository);
});