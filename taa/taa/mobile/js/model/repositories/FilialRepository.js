Configuration(function(ContextRegister, RepositoryFactory) {	
	const FilialRepository = RepositoryFactory.factory('/filial', 'LOCAL', 3, 100000);
	ContextRegister.register('FilialRepository', FilialRepository);
});