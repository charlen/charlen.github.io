Configuration(function(ContextRegister, RepositoryFactory) {
	var PerformSaleRepository = RepositoryFactory.factory('/PerformSaleRepository', 'LOCAL',  1, 300000);
	ContextRegister.register('PerformSaleRepository', PerformSaleRepository);
});