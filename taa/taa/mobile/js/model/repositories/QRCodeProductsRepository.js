Configuration(function(ContextRegister, RepositoryFactory) {
	var QRCodeProductsRepository = RepositoryFactory.factory('/QRCodeProductsRepository', 'LOCAL');
	ContextRegister.register('QRCodeProductsRepository', QRCodeProductsRepository);
});