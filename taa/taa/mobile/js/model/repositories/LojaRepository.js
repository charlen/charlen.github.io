Configuration(function(ContextRegister, RepositoryFactory) {	
	const LojaRepository = RepositoryFactory.factory('/loja', 'LOCAL', 3, 100000);
	ContextRegister.register('LojaRepository', LojaRepository);
});