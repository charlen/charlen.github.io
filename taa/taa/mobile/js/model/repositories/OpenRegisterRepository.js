Configuration(function(ContextRegister, RepositoryFactory) {
	var OpenRegisterRepository = RepositoryFactory.factory('/OpenRegisterRepository', 'LOCAL');
	ContextRegister.register('OpenRegisterRepository', OpenRegisterRepository);
});