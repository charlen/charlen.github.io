Configuration(function(ContextRegister, RepositoryFactory) {
	var RegistersRepo = RepositoryFactory.factory('/RegistersRepo', 'LOCAL');
	ContextRegister.register('RegistersRepo', RegistersRepo);
});