Configuration(function(ContextRegister, RepositoryFactory) {	
	const ProdutosMaisVendidosRepository = RepositoryFactory.factory('/ProdutosMaisVendidos', 'LOCAL', 3, 100000);
	ContextRegister.register('ProdutosMaisVendidosRepository', ProdutosMaisVendidosRepository);
});