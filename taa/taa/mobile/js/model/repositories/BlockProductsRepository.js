Configuration(function(ContextRegister, RepositoryFactory) {
    var BlockProductsRepository = RepositoryFactory.factory('/BlockProductsRepository', 'LOCAL');
    ContextRegister.register('BlockProductsRepository', BlockProductsRepository);
});