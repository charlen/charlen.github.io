Configuration(function(ContextRegister, RepositoryFactory) {
	var FiliaisRepo = RepositoryFactory.factory('/FiliaisRepo', 'LOCAL');
	ContextRegister.register('FiliaisRepo', FiliaisRepo);
});