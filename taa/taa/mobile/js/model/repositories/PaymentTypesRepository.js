Configuration(function(ContextRegister, RepositoryFactory) {
	var PaymentTypesRepository = RepositoryFactory.factory('/PaymentTypesRepository', 'LOCAL');
	ContextRegister.register('PaymentTypesRepository', PaymentTypesRepository);
});