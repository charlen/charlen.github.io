Configuration(function(ContextRegister, RepositoryFactory) {
	var ConsumerFamiliesRepository = RepositoryFactory.factory('/ConsumerFamiliesRepository', 'LOCAL');
	ContextRegister.register('ConsumerFamiliesRepository', ConsumerFamiliesRepository);
});