Configuration(function(ContextRegister, RepositoryFactory) {
	var PrintClosingReportRepository = RepositoryFactory.factory('/PrintClosingReportRepository', 'LOCAL', 1, 50000000);
	ContextRegister.register('PrintClosingReportRepository', PrintClosingReportRepository);
});