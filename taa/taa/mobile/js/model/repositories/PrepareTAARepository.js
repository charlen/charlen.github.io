Configuration(function(ContextRegister, RepositoryFactory) {
	var PrepareTAARepository = RepositoryFactory.factory('/PrepareTAARepository', 'LOCAL', 3, 50000);
	ContextRegister.register('PrepareTAARepository', PrepareTAARepository);
});