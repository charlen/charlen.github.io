Configuration(function (ContextRegister, RepositoryFactory) {
    var CapptaTransaction = RepositoryFactory.factory('/CapptaTransaction', 'LOCAL');
    ContextRegister.register('CapptaTransaction', CapptaTransaction);
});