Configuration(function(ContextRegister, RepositoryFactory) {
    var ConsumerToRechargeRepository = RepositoryFactory.factory('/ConsumerToRechargeRepository', 'LOCAL');
    ContextRegister.register('ConsumerToRechargeRepository', ConsumerToRechargeRepository);
});