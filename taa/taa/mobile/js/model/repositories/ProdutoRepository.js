Configuration(function(ContextRegister, RepositoryFactory) {	
	const ProdutoRepository = RepositoryFactory.factory('/produto', 'LOCAL', 3, 100000);
	ContextRegister.register('ProdutoRepository', ProdutoRepository);
});