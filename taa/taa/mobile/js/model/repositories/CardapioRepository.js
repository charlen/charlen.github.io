Configuration(function(ContextRegister, RepositoryFactory) {
	var CardapioRepository = RepositoryFactory.factory('/CardapioRepository', 'LOCAL');
	ContextRegister.register('CardapioRepository', CardapioRepository);
});