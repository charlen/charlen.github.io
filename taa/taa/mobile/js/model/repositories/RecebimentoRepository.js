Configuration(function(ContextRegister, RepositoryFactory) {	
	const RecebimentoRepository = RepositoryFactory.factory('/recebimento', 'LOCAL', 3, 100000);
	ContextRegister.register('RecebimentoRepository', RecebimentoRepository);
});