Configuration(function(ContextRegister, RepositoryFactory) {
	var OperatorsRepo = RepositoryFactory.factory('/OperatorsRepo', 'LOCAL');
	ContextRegister.register('OperatorsRepo', OperatorsRepo);
});