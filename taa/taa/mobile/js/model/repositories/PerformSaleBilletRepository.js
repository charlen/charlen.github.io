Configuration(function(ContextRegister, RepositoryFactory) {
	var PerformSaleBilletRepository = RepositoryFactory.factory('/PerformSaleBilletRepository', 'LOCAL',  1, 300000);
	ContextRegister.register('PerformSaleBilletRepository', PerformSaleBilletRepository);
});