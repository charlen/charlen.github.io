function ParamsService(Query, UtilitiesTestRepository, AuthRepository, FiliaisRepo, ValidateOperatorPassRepo) {

    this.testConnection = function(){
        var query = Query.build();
        return UtilitiesTestRepository.download(query);
    };

    this.getFiliais = function() {
    	return FiliaisRepo.download(Query.build());
    };

    this.validateOperatorPass = function(SENHADIG, CDOPERADOR, CDFILIAL){
        var query = Query.build()
                        .where('CDFILIAL').equals(CDFILIAL)
                        .where('CDOPERADOR').equals(CDOPERADOR)
                        .where('SENHADIG').equals(SENHADIG);
        return ValidateOperatorPassRepo.download(query);
    };

}

Configuration(function(ContextRegister) {
	ContextRegister.register('ParamsService', ParamsService);
});