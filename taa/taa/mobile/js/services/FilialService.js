function FilialService(FilialRepository, Query) {
    this.fetch = function(CDFILIAL) {
        var query = Query.build()
            .where('CDFILIAL').equals(CDFILIAL)
            return FilialRepository.download(query)
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register('FilialService', FilialService );
});