function CapptaService(ScreenService) {
    const CREDIT_PAYMENT = '1';
    const DEBIT_PAYMENT = '2';

    this.getCapptaInstance = (CDTERTEF, NRINSJURFILI) => {
        const promise = new Promise((resolve, reject) => {
            const authenticationRequest = {
                authenticationKey: '795180024C04479982560F61B3C2C06E',
                merchantCnpj: NRINSJURFILI,
                checkoutNumber: CDTERTEF
            };

            const capptaInstance = CapptaCheckout.authenticate(
                authenticationRequest,
                response => {
                    const { authenticated, merchantCheckoutGuid } = response;
                    if (authenticated) {
                        _hideCapptaIframe();
                        resolve({ ...capptaInstance, merchantCheckoutGuid });
                    } else {
                        reject('Erro ao realizar autenticação. Por favor, tente novamente.');
                    }
                },
                response => {
                    const errMessage = response.reason;
                    reject(`Erro ao realizar autenticação. ${errMessage}`);
                },
                response => {
                    reject(`Existem transações pendentes. Por favor, entre em contato com o suporte.`);
                });

        });

        return promise;
    };

    this.performTransaction = (capptaInstance, payment, totalSale) => {
        _showCapptaIframe();
        if (payment.IDTIPORECE === DEBIT_PAYMENT) {
            return this.performDebitTransaction(capptaInstance, totalSale);
        } else {
            return this.performCreditTransaction(capptaInstance, totalSale);
        }
    };

    this.performDebitTransaction = (capptaInstance, value) => {
        const promise = new Promise((resolve, reject) => {
            const transactionData = { amount: value };
    
            capptaInstance.debitPayment(
                transactionData,
                response => {
                    _hideCapptaIframe();
                    resolve(response);
                },
                response => {
                    _hideCapptaIframe();
                    resolve({
                        error: true,
                        message: response.reason
                    });
                }
            );
        });

        return promise;
    };

    this.performCreditTransaction = (capptaInstance, value) => {
        const promise = new Promise((resolve, reject) => {
            const transactionData = { 
                amount: value,
                installments: 1
            };

            capptaInstance.creditPayment(
                transactionData,
                response => {
                    /* Response example:
                    const response = {
                        acquirerAuthorizationCode: "040093",
                        administrativeCode: "01440390024",
                        receipt: object
                    }*/
                    _hideCapptaIframe();
                    resolve({
                        ...response,
                        dados: {
                            CDNSUHOSTTEF: '999999999',
                            'CDTIPORECE': '008',
                            'IDSENHACUP': 'S'
                        }
                    });
                },
                response => {
                    _hideCapptaIframe();
                    resolve({
                        error: true,
                        message: response.reason
                    });
                }
            );
        });

        return promise;
    };

    _hideCapptaIframe = () => {
        $('#cappta-checkout-iframe')[0].style.display = 'none';
    }

    _showCapptaIframe = () => {
        $('#cappta-checkout-iframe')[0].style.display = 'initial';
    }
}

Configuration(function (ContextRegister) {
    ContextRegister.register('CapptaService', CapptaService);
});