function CancelSaleService(RestEngine) {
    this.saleCancel = function({CODIGOCUPOM, CDFILIAL, CDCAIXA, NRORG, CDOPERADOR}) {
        const route = '/saleCancel';
        const params = {
            requestType: 'Row',
            row: {
                CODIGOCUPOM,
                CDFILIAL,
                CDCAIXA,
                NRORG,
                CDOPERADOR
            }
        }
        return RestEngine.post(route, params, null, null, null, null, 60000).then(response => response);
    }
}

Configuration(function (ContextRegister) {
    ContextRegister.register('CancelSaleService', CancelSaleService);
    
});