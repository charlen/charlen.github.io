function BlockedProductsService(Query, BlockedProductsRepository, BlockProductsRepository, RestEngine) {

    this.getBlockedProducts = (CDFILIAL, CDLOJA) => {
        var query = Query.build()
                        .where('CDFILIAL').equals(CDFILIAL)
                        .where('CDLOJA').equals(CDLOJA);
        return BlockedProductsRepository.download(query);
    };

    this.handleBlockProduct = (hasToBlock, CDFILIAL, CDLOJA, CDOPERADOR, CDPRODUTO) => {
        var query = Query.build()
                        .where('hasToBlock').equals(hasToBlock)
                        .where('CDFILIAL').equals(CDFILIAL)
                        .where('CDLOJA').equals(CDLOJA)
                        .where('CDOPERADOR').equals(CDOPERADOR)
                        .where('CDPRODUTO').equals(CDPRODUTO);
        return BlockProductsRepository.download(query);
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register('BlockedProductsService', BlockedProductsService);
});