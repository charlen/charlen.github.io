function RecebimentoService(RecebimentoRepository, Query) {
    this.fetch = function(CDFILIAL, CDCAIXA) {
        var query = Query.build()
            .where('CDFILIAL').equals(CDFILIAL)
            .where('CDCAIXA').equals(CDCAIXA)
            return RecebimentoRepository.download(query)
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register('RecebimentoService', RecebimentoService );
});