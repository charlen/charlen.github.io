function ProdutoService(ProdutoRepository, Query) {
    this.fetch = function(CDFILIAL, CDLOJA, CDCLIENTE, NRCONFTELA, CDTIPOCONS = null) {
        var query = Query.build()
            .where('CDFILIAL').equals(CDFILIAL)
            .where('CDCLIENTE').equals(CDCLIENTE)
            .where('CDLOJA').equals(CDLOJA)
            .where('NRCONFTELA').equals(NRCONFTELA)
            .where('CDTIPOCONS').equals(CDTIPOCONS)
            return ProdutoRepository.download(query)
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register('ProdutoService', ProdutoService );
});