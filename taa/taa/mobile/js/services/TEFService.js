function TEFService(Query, RestEngine, TEFTransactionRepo, TEFConfigurationRepo) {

    this.configureTEF = (simulateTef, CDFILIAL, CDCAIXA) => {
    	const query = Query.build()
    					.where('simulateTef').equals(simulateTef.toString())
    					.where('CDFILIAL').equals(CDFILIAL)
    					.where('CDCAIXA').equals(CDCAIXA);
        return TEFConfigurationRepo.download(query);
    };

    this.performTransaction = (generalParams, CDTIPORECE, IDTIPORECE, simulateTef, totalSale, isContinuation) => {
        const params = {
            requestType: "Row",
            row: {
                'CDFILIAL'            : generalParams.CDFILIAL,
                'CDLOJA'              : generalParams.CDLOJA,
                'CDCAIXA'             : generalParams.CDCAIXA,
                'IDTPTEF'             : generalParams.IDTPTEF,
                'CDTIPORECE'          : CDTIPORECE,
                'IDTIPORECE'          : IDTIPORECE,
                'simulateTef'         : simulateTef,
                'CDOPERADOR'          : generalParams.CDOPERADOR,
                'totalSale'           : totalSale,
                'isContinuation'      : isContinuation
            }
        };
        return RestEngine.post('/TEFTransactionRepo', params, null, null, null, null, 50000000).then(response => response);
    };

    this.getCapptaTransaction = ( cardBrandCode, administrativeCode ) => {
        const params = {
            requestType: "Row",
            row: {
                cardBrandCode,
                administrativeCode
            }
        };
        return RestEngine.post('/getCapptaTransaction', params, null, null, null, null, 50000000).then(response => response);
    };

    this.performCancellation = function({CDFILIAL, CDCAIXA, DOCTEF, TYPECANCELLATION, VALORVENDA, DTVENDA, CDOPERADOR, isContinuation}) {
        const params = {
            requestType: "Row",
            row: {
                CDFILIAL,
                CDCAIXA,
                DOCTEF,
                TYPECANCELLATION,
                VALORVENDA, 
                DTVENDA,
                CDOPERADOR,
                isContinuation
            }
        };
        return RestEngine.post('/TEFCancellationRepo', params, null, null, null, null, 50000000).then(response => response);
    }
}

Configuration(function(ContextRegister) {
	ContextRegister.register('TEFService', TEFService);
});