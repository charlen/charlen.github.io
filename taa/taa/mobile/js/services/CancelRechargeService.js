function CancelRechargeService(Query, BlockedProductsRepository, BlockProductsRepository, RestEngine) {

    this.cancelPersonalCredit = function({ CDCLIENTE, CDCONSUMIDOR, NRSEQMOVCAIXA, }, CDFILIAL, CDCAIXA, NRORG, NRDEPOSICONS){
        const params = {
            requestType: "Row",
            row: {
                'NRDEPOSICONS': NRDEPOSICONS,
                'CDCONSUMIDOR': CDCONSUMIDOR,
                'CDCLIENTE': CDCLIENTE,
                'NRSEQMOVCAIXA': NRSEQMOVCAIXA,
                'CDFILIAL': CDFILIAL,
                'NRORG': NRORG,
                'CDCAIXA': CDCAIXA
            }
        };
        return RestEngine.post('/cancelPersonalCredit', params).then(response => response);
    };

    this.getDeposiconsData = (NRDEPOSICONS, CDIDCONSUMID, CDFILIAL, CDCLIENTE) => {
        const params = {
            requestType: "Row",
            row: {
                NRDEPOSICONS,
                CDIDCONSUMID,
                CDFILIAL,
                CDCLIENTE
            }
        };
        return RestEngine.post('/getDeposiconsData', params).then(response => response);
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register('CancelRechargeService', CancelRechargeService);
});