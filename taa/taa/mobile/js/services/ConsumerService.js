function ConsumerService(RestEngine) {

	this.saveBiometryDevice = function(CDFILIAL, CDCAIXA, CDLOJA) {
		const route = '/saveBiometryDevice';
        const params = {
            requestType: 'Row',
            row: {
				CDFILIAL, CDCAIXA, CDLOJA
			}
        }
        return RestEngine.post(route, params, null, null, null, null, 500000000).then(response => response).catch(error => error);
	}

    this.validateConsumer = ({CDIDCONSUMID, CDSENHACONSMD5, CDFILIAL, biometry = false}) => {
        CDSENHACONSMD5 = JSON.stringify(CDSENHACONSMD5);
        const route = '/validateConsumer';
        const params = {
            requestType: 'Row',
            row: {
                CDIDCONSUMID,
                CDSENHACONSMD5,
                CDFILIAL,
                biometry
            }
        }
        return RestEngine.post(route, params, null, null, null, null, 50000).then(response => response).catch(error => error);
    };

    this.getConsumerToCancelRecharge = function({CDFILIAL, CDIDCONSUMID}) {
        const route = '/getConsumerToCancelRecharge';
        const params = {
            requestType: 'Row',
            row: {
                CDIDCONSUMID, CDFILIAL
            }
        }

        return RestEngine.post(route, params, null, null, null, null, 50000).then(response => response).catch(error => error);
    }

    this.getConsumerFamilies = function({CDCONSUMIDOR, CDCLIENTE}){
        const route = '/getConsumerSaldoCons';
        const params = {
            requestType: 'Row',
            row: {
                CDCONSUMIDOR, CDCLIENTE
            }
        }

        return RestEngine.post(route, params, null, null, null, null, 50000).then(response => response).catch(error => error);
    }

    this.makeRecharge = function(payment, filialData, familiesParams, consumerParams, dadosTransacao){
        const filial = JSON.stringify(filialData);
        const paymentData = JSON.stringify(payment);
        const consumer = JSON.stringify(consumerParams);
        const families = JSON.stringify(familiesParams);
        const dataTransaction = JSON.stringify(dadosTransacao);
        const route = '/doRechargeFamily';
        const params = {
            requestType: 'Row',
            row: {
                paymentData, filial, consumer, families, dataTransaction
            }
        }
        return RestEngine.post(route, params, null, null, null, null, 50000).then(response => response).catch(error => error);
    };

    this.saveNewPassword = function({CDIDCONSUMID, CDSENHACONS}) {
        const route = '/saveNewPassword';
        const params = {
            requestType: 'Row',
            row: {
                CDIDCONSUMID: CDIDCONSUMID,
                CDSENHACONS: CDSENHACONS
            }
        }
        return RestEngine.post(route, params).then(response => response);
    }

    this.findConsumer = function (CDIDCONSUMID, biometry = false) {
        const route = '/findConsumer'
        const params = {
            requestType: 'Row',
            row: {
                biometry: biometry,
                CDIDCONSUMID: CDIDCONSUMID
            }
        }

        return RestEngine.post(route, params).then(response => response);
    }
}

Configuration(function (ContextRegister) {
    ContextRegister.register('ConsumerService', ConsumerService);
});
