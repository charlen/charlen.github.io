function LojaService(LojaRepository, Query) {
    this.fetch = function(CDFILIAL, CDLOJA) {
        var query = Query.build()
            .where('CDFILIAL').equals(CDFILIAL)
            .where('CDLOJA').equals(CDLOJA)
            return LojaRepository.download(query)
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register('LojaService', LojaService );
});