function ClientsMetadataService(ClientMetadataRepo) {
  this.loadClient = () => {
    const promises = [loadFile("./clientsMetadata.json"), loadFile("./config.json")];
    Promise.all(promises).then(function(data) {
      const clients = data[0];
      const config = data[1];
      let currentClient = Object.keys(clients)
        .filter(client => client == config.client.toLowerCase())
        .shift();

      if (currentClient) {
        clients[currentClient].name = currentClient;
        currentClient = clients[currentClient];
        // _loadClientStylesheet(currentClient.name);
      } else {
        currentClient = clients.default;
      }

      currentClient = _handleDefaultProperties(currentClient, clients.default);

      ClientMetadataRepo.save(currentClient);
      localStorage.setItem("clientData", JSON.stringify(currentClient));
    });
  };

  const loadFile = function(filePath) {
    return new Promise(function(resolve) {
      fetch(filePath)
        .then(data => data.json())
        .then(jsonData => resolve(jsonData));
    });
  };

  const _handleDefaultProperties = (currentClient, defaultClient) => {
    currentClient = angular.copy(currentClient);

    Object.keys(defaultClient).forEach(function(defaultPropertyKey) {
      if (!currentClient.hasOwnProperty(defaultPropertyKey)) {
        currentClient[defaultPropertyKey] = defaultClient[defaultPropertyKey];
      }
    });

    if (currentClient.images) {
      currentClient.images = _handleDefaultProperties(
        currentClient.images,
        defaultClient.images
      );
    }
    if (currentClient.cart) {
      currentClient.cart = _handleDefaultProperties(
        currentClient.cart,
        defaultClient.cart
      );
    }

    return currentClient;
  };
}

Configuration(function(ContextRegister) {
  ContextRegister.register("ClientsMetadataService", ClientsMetadataService);
});