function CaixaService(CaixaRepository, Query) {
    this.fetch = function(CDFILIAL, CDCAIXA, NRORG) {
        var query = Query.build()
            .where('CDFILIAL').equals(CDFILIAL)
            .where('CDCAIXA').equals(CDCAIXA)
            .where('NRORG').equals(NRORG)
            return CaixaRepository.download(query)
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register('CaixaService', CaixaService );
});