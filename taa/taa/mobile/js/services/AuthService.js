function AuthService(Query, AuthRepository) {
    this.auth = function(CDFILIAL, CDCAIXA, CDOPERADOR, CDSENHOPER, {simulateSaleValidation, simulatePrinter, simulateTef}) {
        var query = Query.build()
						.where('CDFILIAL').equals(CDFILIAL)
                        .where('CDCAIXA').equals(CDCAIXA)
                        .where('CDOPERADOR').equals(CDOPERADOR)
                        .where('CDSENHOPER').equals(CDSENHOPER)
                        .where('simulateSaleValidation').equals(simulateSaleValidation)
                        .where('simulatePrinter').equals(simulatePrinter)
                        .where('simulateTef').equals(simulateTef);
                        return AuthRepository.download(query)
    };
}

Configuration(function (ContextRegister) {
	ContextRegister.register('AuthService', AuthService);
});