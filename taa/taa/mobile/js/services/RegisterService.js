function RegisterService(
    Query,
    OpenRegisterRepository,
    CloseRegisterRepository,
    PrepareTAARepository,
    RegistersRepo,
    OperatorsRepo,
    PrintClosingReportRepository
) {
    this.openRegister = function(CDFILIAL, CDCAIXA, CDOPERADOR, NRORG) {
        var query = Query.build()
            .where("CDFILIAL")
            .equals(CDFILIAL)
            .where("CDCAIXA")
            .equals(CDCAIXA)
            .where("CDOPERADOR")
            .equals(CDOPERADOR)
            .where("NRORG")
            .equals(NRORG);
        return OpenRegisterRepository.download(query);
    };

    this.closeRegister = function(
        CDFILIAL,
        CDCAIXA,
        CDOPERADOR,
        NRCONFTELA,
        NRORG,
        PRINTREPORT
    ) {
        var query = Query.build()
            .where("CDFILIAL")
            .equals(CDFILIAL)
            .where("CDCAIXA")
            .equals(CDCAIXA)
            .where("CDOPERADOR")
            .equals(CDOPERADOR)
            .where("NRCONFTELA")
            .equals(NRCONFTELA)
            .where("PRINTREPORT")
            .equals(PRINTREPORT)
            .where("NRORG")
            .equals(NRORG);
        return CloseRegisterRepository.download(query);
    };

    this.printClosingReport = function(
        DTABERCAIX,
        CDFILIAL,
        CDCAIXA,
        CDOPERADOR
    ) {
        var query = Query.build()
            .where("DTABERCAIX")
            .equals(DTABERCAIX)
            .where("CDFILIAL")
            .equals(CDFILIAL)
            .where("CDCAIXA")
            .equals(CDCAIXA)
            .where("CDOPERADOR")
            .equals(CDOPERADOR);
        return PrintClosingReportRepository.download(query);
    };

    this.prepareTAA = function(
        CDFILIAL,
        CDCAIXA,
        CDLOJA,
        NRCONFTELA,
        NRORG,
        simulatePrinter,
        simulateSaleValidation
    ) {
        var query = Query.build()
            .where("CDFILIAL")
            .equals(CDFILIAL)
            .where("CDCAIXA")
            .equals(CDCAIXA)
            .where("CDLOJA")
            .equals(CDLOJA)
            .where("NRCONFTELA")
            .equals(NRCONFTELA)
            .where("NRORG")
            .equals(NRORG)
            .where("simulatePrinter")
            .equals(simulatePrinter)
            .where("simulateSaleValidation")
            .equals(simulateSaleValidation);
        return PrepareTAARepository.download(query);
    };

    this.loadRegisters = function(CDFILIAL) {
        var query = Query.build()
            .where("CDFILIAL")
            .equals(CDFILIAL);
        return RegistersRepo.download(query);
    };

    this.loadOperators = function(CDFILIAL) {
        var query = Query.build()
            .where("CDFILIAL")
            .equals(CDFILIAL);
        return OperatorsRepo.download(query);
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register("RegisterService", RegisterService);
});
