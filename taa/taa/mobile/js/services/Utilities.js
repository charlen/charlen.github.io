function Utilities() {

	var self = this;

	Date.prototype.withoutTime = function() {
	    this.setHours(0, 0, 0, 0);
	    return this;
	};

    this.toggleFullScreen = function() {
        var elem = document.documentElement;
        if ((document.fullScreenElement !== undefined && document.fullScreenElement === null) || (document.webkitIsFullScreen !== undefined && !document.webkitIsFullScreen)){
            if (elem.requestFullScreen) elem.requestFullScreen();
            else if (elem.webkitRequestFullScreen) elem.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
        }
        else {
            if (document.cancelFullScreen) document.cancelFullScreen();
            else if (document.webkitCancelFullScreen) document.webkitCancelFullScreen();
        }
    };

    this.padWithZeros = function(number, length) {
	    var my_string = '' + number;
	    while (my_string.length < length) {
	        my_string = '0' + my_string;
	    }
	    return my_string;
	};
	String.prototype.toMoney = function () {
		return 'R$ ' + parseFloat(this).toFixed(2).replace('.', ',');
	};

    this.capitilizeFirstLetter = function(string) {
        string = string.toLowerCase();
        string = string.charAt(0).toUpperCase() + string.slice(1);
        return self.removeDisconnectedCharacters(string);
    };

    this.removeDisconnectedCharacters = function(string) {
        return string.split('  ').shift();
	};
	
	this.loadVersion = (versionField) => {
		$.getJSON('./package.json', packageConfig => {
			console.log(packageConfig);
			versionField.label = `Versão ${packageConfig.version}`; 
		});
	};

}

Configuration(function(ContextRegister) {
	ContextRegister.register('Utilities', Utilities);
});