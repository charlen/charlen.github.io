function DownloadImagesService(RestEngine) {
    this.downloader = function(NRCONFTELA, FORCEDOWNLOAD){
        const params = {
            requestType: 'Row',
            row: {
                NRCONFTELA,
                FORCEDOWNLOAD
            }
        }
        return RestEngine.post('/downloadImages', params, null, null, null, null, 500000000).then(response => response);
    };
}

Configuration(function(ContextRegister) {
    ContextRegister.register('DownloadImagesService', DownloadImagesService );
});