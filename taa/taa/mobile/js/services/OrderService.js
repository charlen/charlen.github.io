function OrderService(RestEngine) {

    this.performSale = (
        filial,
        loja,
        caixa,
        products,
        payment,
        simulation, 
        consumer,
        operator,
        orderInfo,
        tableInfo,
        qrcodeInfo
    ) => {
        const route = '/PerformSaleRepository'
        const params = {
            requestType: 'Row',
            row: {
                filial: JSON.stringify(filial),
                loja: JSON.stringify(loja),
                caixa: JSON.stringify(caixa),
                products: JSON.stringify(products),
                payment: JSON.stringify(payment),
                simulation: JSON.stringify(simulation),
                consumer: JSON.stringify(consumer),
                operator: JSON.stringify(operator), 
                orderInfo: JSON.stringify(orderInfo),
                tableInfo: JSON.stringify(tableInfo),
                qrcodeInfo: JSON.stringify(qrcodeInfo)
            }
        }
        return RestEngine.post(route, params, null, null, null, null, 300000)
    };

    this.loadBilletData = (CDFILIAL, DSCOMANDA) => {
        const params = {
            requestType: "Row",
            row: {
                'CDFILIAL': CDFILIAL,
                'DSCOMANDA': DSCOMANDA,
            }
        };
        return RestEngine.post('/LoadBilletRepository', params, null, null, null, null, 50000000).then(response => response);
    };

    this.performCashSale = (dadosContent, dadosCliente, cart) => {
        const params = {
          requestType: 'Row',
          row: {
            dadosContent: dadosContent,
            dadosCliente: dadosCliente,
            cart: cart,
          },
        };
        return RestEngine.post(
          '/cash',
          params,
          null,
          null,
          null,
          null,
          50000000
        ).then((response) => response);
      };
}

Configuration(function (ContextRegister) {
    ContextRegister.register('OrderService', OrderService);
});