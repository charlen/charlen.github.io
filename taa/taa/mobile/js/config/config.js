window.lang = 'pt_br';

window.inDeveloperMode = false;
window.metadataUrl = "./";
window.templateUrls = [{
        package: "default",
        baseUrl: "lib/zeedhi-frontend/templates/dyman/"
    },
    {
        package: "taa-container",
        baseUrl: "src/container/"
    },
    {
        package: "taa-pages",
        baseUrl: "src/pages/"
    },
    {
        package: "taa-components",
        baseUrl: "src/components/"
    },
];
window.docsUrls = [{
    package: "default",
    baseUrl: "lib/zeedhi-frontend/docs/dyman/"
}];
window.metadataUrls = [{
    package: "zeedhiFramework",
    baseUrl: 'lib/zeedhi-frontend/assets/'
}];
window.serviceUrls = [];
window.serviceUrl = "../backend/service/index.php";