function PasswordKeyboardController($scope) {
    this.upperCase = false;
    this.initKeyboardValues = (field) => {
        $scope.defaultColspan = field.keyboardProperties.type === 'numeric' ? 2 : 4;
        $scope.inputVal = '';
        $scope.fieldRow = '';
        $scope.numericValues = [
            ['1', '2', '3'], ['4', '5', '6'], ['7', '8', '9']
        ];

        $scope.alphaValues = [
            [' ', '!', '@', '#', '$', '&', '*', '_', '+', ' '],
            ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
            ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ç'],
            [' ', 'z', 'x', 'c', 'v', 'b', 'n', 'm', '.', ' ']
        ];
    };

    this.handleCaps = function(event){
        event.stopPropagation();
        $scope.alphaValues.forEach(elementArray => {
            elementArray.forEach((element, index, array) => {
                if(!this.upperCase) {
                    array[index] = element.toUpperCase();
                } else {
                    array[index] = element.toLowerCase();
                }
            })
        });
        this.upperCase = !this.upperCase;
    }

    this.increase = (value, evt) => {
        if (value != ' ') {
            $scope.inputVal += value;
            $scope.fieldRow = $scope.inputVal;
        }
        evt.stopPropagation();
    };

    this.backspace = (evt) => {
        $scope.inputVal = $scope.inputVal.slice(0, -1);
        $scope.fieldRow = $scope.inputVal;
        evt.stopPropagation();
    };
}