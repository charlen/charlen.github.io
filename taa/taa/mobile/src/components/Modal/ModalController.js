function ModalController(
    $rootScope,
    $scope,
    ApplicationContext,
    $timeout,
    CartService
) {
    const vm = $scope.parent;
    this.father = $scope.$parent;
    this.parent = vm;
    this.root = $rootScope;
    this.productDetailController = null;

    this.state = {
        toGo: false,
        suggestionsSize: [],
        suggestionsFlavor: [],
        suggestionsCombo: [],
        selectProduct: [],
        suggestionsProduct: [],
        suggestionsGroup: [],
        allSuggestions: []
    };

    this.init = function () {
        const list = this.parent.state.suggestionsMap;
        this.state.allSuggestions = list;
        const allSuggestions = list[this.parent.state.selectedProduct.CDPRODUTO]
        if (this.parent.state.showSizeModal == true) {
            const sizes = allSuggestions.tamanho;
            sizes.forEach((size) => {
                this.state.suggestionsSize.push(size);
            });
        } else if (this.parent.state.showFlavorModal == true) {
            const flavors = allSuggestions.sabor;
            flavors.forEach((flavor) => {
                this.state.suggestionsFlavor.push(flavor);
            });
        } else if (this.parent.state.showComboModal == true) {
            this.parent.state.comboSuggestionSelected = null;
            const combos = allSuggestions.combo;
            combos.forEach((combo) => {
                this.state.suggestionsCombo.push(combo.produto);
                this.parent.state.comboOrProductSelected = undefined;
            });
        } else if (this.parent.state.showProductModal == true) {
            const produtos = allSuggestions.produto;
            produtos.forEach((produto) => {
                this.state.suggestionsProduct.push(produto);
            });
        } else if (this.parent.state.showGroupModal == true) {
            this.parent.state.grupoSuggestionSelected = []
            const grupos = allSuggestions.grupo;
            grupos.forEach((grupo) => {
                this.state.suggestionsGroup.push(grupo);
            });
        } else if (this.father && this.father.$parent.$parent.Ctrl.state.showModalObservations == true){
            this.productDetailController = this.father.$parent.$parent.Ctrl;
            if(this.productDetailController.state.product.OBSERVATIONS){
                this.observations = this.productDetailController.state.product.OBSERVATIONS
                this.originalObservations = angular.copy(this.observations);
            }            
        }
    };

    this.filterOptionalObservations = function( observation ){
        return observation.IDCONTROLAOBS === 'O';
    }

    this.changeObservation = function(observation){
        observation.selected = !observation.selected;
    }

    this.cancelObservationChanges = function(){
        this.observations = angular.copy( this.originalObservations );
    }

    this.setToGo = function (toGo) {
        this.state.toGo = toGo;
    };

    this.concludeObservations = function(){
        this.productDetailController.state.showModalObservations = false;
    }

    this.setOrderToGo = function () {
        this.parent.state.toGo = this.state.toGo;
    };

    this.closeModal = function () {
        console.log(this.father.Ctrl.state.repeatSuggestVerify )
        if(this.father.Ctrl.state.repeatSuggestVerify != undefined){
            this.father.Ctrl.state.repeatSuggestVerify = false;
        }
        if (this.parent.state.showProductModal == true || this.parent.state.showGroupModal == true) {
            if(this.parent.state.showSizeModal == true){
                this.parent.state.comboSuggestedLine = [];
            }
            this.father.Ctrl.removeSelectedProductAndCloseModal();
        } else if (this.parent.state.currentPage === "PRODUCT_DETAIL") {
            this.parent.resetOnlyShowModals();
        } else if (this.parent.state.currentPage === "GROUP_SUGGESTION"){
            this.parent.resetOnlyShowModals();
        } else{
            this.parent.resetAllSelectedSuggestions();
        }
    };

    this.btnSkipSuggestions = function () {
        this.father.Ctrl.skipSuggestions();
    };

    this.handleSelectedSuggestion = function (suggestion) {
        const idSuggestion = suggestion["IDSUGESTAOTIPO"];

        if (idSuggestion == 3) {
            if (this.parent.state.sizeSuggestionSelected.length == 0) {
                this.parent.state.sizeSuggestionSelected.push(
                    suggestion.produto
                );
            } else {
                this.parent.state.sizeSuggestionSelected.pop();
                this.parent.state.sizeSuggestionSelected.push(
                    suggestion.produto
                );
            }
        } else if (idSuggestion == 4) {
            if (this.parent.state.flavorSuggestionSelected.length == 0) {
                this.parent.state.flavorSuggestionSelected.push(
                    suggestion.produto
                );
            } else {
                this.parent.state.flavorSuggestionSelected.pop();
                this.parent.state.flavorSuggestionSelected.push(
                    suggestion.produto
                );
            }
        } else if (this.parent.state.showComboModal == true) {
            this.parent.state.comboSuggestionSelected = suggestion;
        }
    };

    this.comboOrProductSelected = function (suggestion) {
        return (
            this.parent.state.comboSuggestionSelected &&
            suggestion.CDPRODUTO ==
                this.parent.state.comboSuggestionSelected.CDPRODUTO
        );
    };

    this.isThisSelected = function (suggestion) {
        function retunrIfIncluded(arr) {
            if (arr.includes(suggestion.produto)) {
                return true;
            } else {
                return false;
            }
        }
        let arr;

        if (this.parent.state.showSizeModal == true) {
            arr = this.parent.state.sizeSuggestionSelected;
        } else if (this.parent.state.showFlavorModal == true) {
            arr = this.parent.state.flavorSuggestionSelected;
        } else if (this.parent.state.showComboModal == true) {
            arr = this.parent.state.comboSuggestionSelected;
        } else if (this.parent.state.showProductModal == true) {
            arr = this.parent.state.produtoSuggestionSelected;
            this.father.Ctrl.state.selectedSuggestedItems = arr;
            return retunrIfIncluded(arr);
        } else if (this.parent.state.showGroupModal == true) {
            arr = this.parent.state.grupoSuggestionSelected;
            this.father.Ctrl.state.selectedGroupItems = arr;
            if (arr.includes(suggestion.grupo)) {
                return true;
            } else {
                return false;
            }
        }
        if (arr[0] == suggestion.produto) {
            return true;
        } else {
            return false;
        }
    };

    this.confirmSuggestion = function () {
        if (this.parent.state.showSizeModal == true) {
            const arr = this.parent.state.sizeSuggestionSelected[0];
            this.parent.state.showSizeModal = false;
            if(this.father.Ctrl.state.repeatSuggestVerify == true){
                this.father.Ctrl.handleFlavorSuggestion(arr)
            } else{
                if(this.parent.state.currentPage == "PRODUCT_GRID"){
                    this.father.Ctrl.handleComboProductSuggestion(arr);
                } else{
                    this.father.Ctrl.configureProduct(arr);
                }
            }
            this.parent.state.sizeSuggestionSelected = [];
        } else if (this.parent.state.showFlavorModal == true) {
            const arr = this.parent.state.flavorSuggestionSelected[0];
            this.parent.state.showFlavorModal = false;
            this.parent.state.flavorSuggestionSelected = [];
            this.father.Ctrl.handleSizeSuggestion(arr);
        } else if (this.parent.state.showComboModal == true) {
            const arr = this.parent.state.comboSuggestionSelected;
            this.parent.state.showComboModal = false;
            this.father.Ctrl.configureProduct(arr);
        } else if (this.parent.state.showProductModal == true) {
            const arr = this.parent.state.produtoSuggestionSelected;
            this.parent.state.showProductModal = false;
            this.father.Ctrl.confirmSuggestions(arr);
        } else if (this.parent.state.showGroupModal == true) {
            this.parent.state.showGroupModal = false;
            this.father.Ctrl.confirmSuggestionGroup();
        }
    };

    this.isSelectedSuggestionIsEmpty = function () {
        if (this.parent.state.showSizeModal == true) {
            if (this.parent.state.sizeSuggestionSelected.length == 0) {
                return true;
            } else {
                return false;
            }
        } else if (this.parent.state.showFlavorModal == true) {
            if (this.parent.state.flavorSuggestionSelected.length == 0) {
                return true;
            } else {
                return false;
            }
        } else if (this.parent.state.showComboModal == true) {
            if (this.parent.state.comboSuggestionSelected.length == 0) {
                return true;
            } else {
                return false;
            }
        } else if (this.parent.state.showProductModal == true) {
            if (this.parent.state.produtoSuggestionSelected.length == 0) {
                return true;
            } else {
                return false;
            }
        } else if (this.parent.state.showGroupModal == true) {
            if (this.parent.state.grupoSuggestionSelected.length == 0) {
                return true;
            } else {
                return false;
            }
        }
    };

    this.handleSelectedMultipleSuggestion = function (suggestion) {
        if (this.parent.state.showGroupModal == true) {
            this.handleGroupMultipleSuggestions(suggestion);
        } else if (this.parent.state.showProductModal == true) {
            this.handleProductMultipleSuggestions(suggestion);
        }
    };

    this.handleGroupMultipleSuggestions = function(suggestion){
        const selecteds = this.parent.state.grupoSuggestionSelected;
        if (selecteds.length == 0) {
            this.parent.state.grupoSuggestionSelected.push(
                suggestion.grupo
            );
        } else {
            let count = 0;
            selecteds.forEach((element) => {
                if (element == suggestion.grupo) {
                    const index = selecteds.indexOf(suggestion.grupo);
                    if (index > -1) {
                        this.parent.state.grupoSuggestionSelected.splice(
                            index,
                            1
                        );
                    }
                    count = count + 1;
                }
            });
            if (count == 0) {
                this.parent.state.grupoSuggestionSelected.push(
                    suggestion.grupo
                );
            }
        }
    }

    this.handleProductMultipleSuggestions = function(suggestion){
        const selecteds = this.parent.state.produtoSuggestionSelected;
        if (selecteds.length == 0) {
            if (suggestion.produto.IDTIPOCOMPPROD == 3) {
                this.checkComboSuggestions(suggestion.produto);
            } else {
                this.checkSuggestionsProductNormal(suggestion.produto);
            }
        } else {
            let count = 0;
            selecteds.forEach((element) => {
                if (element == suggestion.produto) {
                    const index = selecteds.indexOf(suggestion.produto);
                    const cartAwaiting = this.father.Ctrl.state.cartAwaiting;
                    const comboAwait = this.parent.state.comboSuggestedLine
                    let itemToRemoveFromCartAwaiting = null;
                    let comboToRemoveFromLine = null;


                    cartAwaiting.forEach(( element ) => {
                        if(element.IDFORSELECTION == suggestion.produto.IDFORSELECTION){
                            itemToRemoveFromCartAwaiting = element
                        }                        
                    })
                    comboAwait.forEach(element => {
                        if(element.IDFORSELECTION == suggestion.produto.IDFORSELECTION){
                            comboToRemoveFromLine = element
                        }      
                    })

                    let indexCombo = comboAwait.indexOf(comboToRemoveFromLine);
                    let indexCart = cartAwaiting.indexOf(itemToRemoveFromCartAwaiting);
                    if (index > -1) {
                        if(indexCart > -1){
                            this.father.Ctrl.state.cartAwaiting.splice(cartAwaiting, 1);
                            this.parent.state.produtoSuggestionSelected.splice(index, 1);

                        } else if(suggestion.produto.IDTIPOCOMPPROD == 3){
                            this.parent.state.comboSuggestedLine.splice(indexCombo, 1);
                            this.parent.state.produtoSuggestionSelected.splice(index, 1);
                        }
                    }
                    count = count + 1;
                }
            });

            if (count == 0) {
                if (suggestion.produto.IDTIPOCOMPPROD == 3) {
                    this.checkComboSuggestions(suggestion.produto);
                } else {
                    this.checkSuggestionsProductNormal(suggestion.produto);
                }
            
            }
        }
    }
    
    this.checkComboSuggestions = function ( product ){
        const id = Math.floor(Math.random() * 500000);
        product.IDFORSELECTION = id;
        this.father.Ctrl.state.idAwaiting = id;
        this.parent.state.produtoSuggestionSelected.push(product);
        const list = this.state.allSuggestions[product.CDPRODUTO];
        if (list != undefined) {
            this.father.Ctrl.handleFlavorSuggestion(product);
        } else {
            this.insertOnCartAwait(product);
        }
    }


    this.checkSuggestionsProductNormal = function (product) {
        const id = Math.floor(Math.random() * 500000);
        product.IDFORSELECTION = id;
        this.father.Ctrl.state.idAwaiting = id;
        this.parent.state.produtoSuggestionSelected.push(product);

        if (this.state.allSuggestions[product.CDPRODUTO] != undefined) {
            const suggestion = this.state.allSuggestions[product.CDPRODUTO];
            this.parent.state.selectedProduct = product
            if (this.state.allSuggestions[product.CDPRODUTO] != undefined) {
                this.father.Ctrl.handleFlavorSuggestion(product);
            } else {
                this.insertOnCartAwait(product);
            }
        } else {
            this.insertOnCartAwait(product);
        }
    };

    this.insertOnCartAwait = function (product) {
        product.IDFORSELECTION = this.state.idAwaiting;
        if(product.IDTIPOCOMPPROD != 3){
            product.QTPRODVEND = 1;
            this.father.Ctrl.state.cartAwaiting.push(product);
        } else{
            this.parent.state.comboSuggestedLine.push(product)
        }
    }    

}
