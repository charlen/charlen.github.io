function Store () {

    const mapCartState = {
        ADD_PRODUCT_STATE: 'add',
        EDIT_PRODUCT_STATE: 'personalize',
        COMBO_STATE: 'combo',
        PERSONALIZE_COMBO_STATE: 'personalize-combo',
        PERSONALIZE_COMBO_ITEM_STATE: 'personalize-combo-item'
    }

    const state = {
        cart: [],
        total: 0,
        cartIsBlocked: false,
    }

    this.setState = function (prop, payload) {
        if(!state[prop]) {
            console.error(new Error('Invalid state prop'));
            return
        }
        state[prop] = payload
    }

    this.getStateProp = function (prop) {
        if(!state[prop]) {
            console.error(new Error('Invalid state prop'));
            return
        }
        return state[prop]
    }

}