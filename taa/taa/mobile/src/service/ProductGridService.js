function ProductGridService() {

    const mapValueOptions = {
        DISCOUNT: 'D',
        ADDITION: 'A'
    }

    const productMapType = {
        NORMAL: 'N',
        COMBO_PARENT: 'CP',
        COMBO_CHILD: 'CC'
    }
    this.cardapio = [];

    this.barcodeProduct = null;

    this.updateCardapio = function (cardapio) {
        this.cardapio = cardapio;
    };

    this.getBarcodeProduct = function () {
        return this.barcodeProduct;
    };

    this.setBarcodeProduct = function (product) {
        this.barcodeProduct = product;
    };

    this.resetBarcodeProduct = function () {
        this.barcodeProduct = null;
    };

    this.getCardapio = function () {
        return this.cardapio;
    };
    this.handleProductsDescription = menu => {
        menu.listaProdutos.forEach(item => {
            item.IDTIPOCOMPPROD === '3' ? item.PRODUCT_TYPE = productMapType.COMBO_PARENT : item.PRODUCT_TYPE = productMapType.NORMAL
            item.DSPRODVENDA = item.DSPRODVENDA ? item.DSPRODVENDA : null;
        });
        this.updateCardapio(menu);
    };
    this.prepareComboProductPrices = menu => {
        menu.listaProdutos
            .filter(product => product.IDTIPOCOMPPROD == "3" && product.GRUPOS)
            .forEach(function (comboProduct) {
                comboProduct.gruposPromocionais = Object.keys(comboProduct.GRUPOS).map(function (key) {
                    comboProduct.GRUPOS[key].ORDERBY = comboProduct.GRUPOS[key].grupo.NRORDPROMOGRUP
                    return comboProduct.GRUPOS[key];
                });
                if(comboProduct.IDTIPOCOMPPROD === "2") {
                    _mapGroutMutex(comboProduct)
                    comboProduct.VRPRECITEM = _getComboCalculatedPrice(comboProduct);
                }
            });
    };
    const _getComboCalculatedPrice = comboProduct => {
        let mapLowestPrice = {};
        Object.keys(comboProduct.GRUPOS).forEach(groupKey => {
            let currentGroup = comboProduct.GRUPOS[groupKey];
            currentGroup = _buildPromoProductPrices(currentGroup);
            mapLowestPrice = Object.keys(currentGroup.produtos).reduce((mapObj, productKey) => {
                const currentProduct = currentGroup.produtos[productKey]
                currentProduct.PRODUCT_TYPE = productMapType.COMBO_CHILD
                const cdMutex = currentGroup.grupo.CDGRUPMUTEX;
                const groupCode = currentGroup.grupo.CDGRUPROMOC;
                const prop = cdMutex ? cdMutex : groupCode
                if (!mapObj[prop]) {
                    mapObj[prop] = currentProduct.VRPRECITEM;
                } else if (mapObj[prop] > currentProduct.VRPRECITEM) {
                    mapObj[prop] = currentProduct.VRPRECITEM
                }
                return mapObj
            }, mapLowestPrice)
        })
        const minValue = Object.keys(mapLowestPrice).reduce((totalvalue, priceKey) => {
            const price = mapLowestPrice[priceKey];
            return price + totalvalue;
        }, 0)
        return minValue;
    };

    const _buildPromoProductPrices = currentComboGroup => {
        Object.keys(currentComboGroup.produtos).forEach((key) => {
            if (currentComboGroup.produtos[key].IDDESCACRPROMO === mapValueOptions.DISCOUNT) {
                currentComboGroup.produtos[key] = applyDiscount(currentComboGroup.produtos[key])
            }

            if (currentComboGroup.produtos[key].IDDESCACRPROMO === mapValueOptions.ADDITION) {
                currentComboGroup.produtos[key] = applyAddition(currentComboGroup.produtos[key])
            }

            if (!currentComboGroup.produtos[key].IDDESCACRPROMO) {
                currentComboGroup.produtos[key] = applyDiscount(currentComboGroup.produtos[key])
            }

            if (currentComboGroup.produtos[key].VRPRECITEM <= 0) {
                currentComboGroup.produtos[key].VRPRECITEM = 0.01;
            }

        });
        return currentComboGroup
    };

    const applyDiscount = function (currentComboProduct) {
        const product = { ...currentComboProduct }
        if (product.IDPERVALORDES == "V") {
            product.VRDESITVEND = parseFloat(product.VRDESPRODPROMOC);
        }

        if (product.IDPERVALORDES == "P") {
            product.VRDESITVEND = parseFloat(((product.VRPRECITEM * parseFloat(product.VRDESPRODPROMOC)) / 100).toFixed(3));
            product.VRDESITVEND = parseFloat(product.VRDESITVEND.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]);
            if (product.VRDESITVEND < 0.01 && product.VRDESITVEND > 0) {
                product.VRDESITVEND = 0.01;
            }
        }
        product.VRPRECITEM = parseFloat((product.VRPRECITEM - product.VRDESITVEND).toFixed(2));
        return product
    }

    const applyAddition = function (currentComboProduct) {
        const product = { ...currentComboProduct }
        if (product.IDPERVALORDES == "V") {
            product.VRACRITVEND = parseFloat(product.VRDESPRODPROMOC);
        }

        if (product.IDPERVALORDES == "P") {
            product.VRACRITVEND = parseFloat(((product.VRPRECITEM * parseFloat(product.VRDESPRODPROMOC)) / 100).toFixed(3));
            product.VRACRITVEND = parseFloat(product.VRACRITVEND.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]);
            if (product.VRACRITVEND < 0.01 && product.VRACRITVEND > 0) {
                product.VRACRITVEND = 0.01;
            }
        }
        product.VRPRECITEM = parseFloat((product.VRPRECITEM + product.VRACRITVEND).toFixed(2));
        return product
    }

    this.orderComboProducts = products => {
        const mapPosition = {
            CDPRODUTO: 0,
            IDIMPPRODUTO: 1,
            IDAPLICADESCPR: 2,
            IDPERVALORDES: 3,
            DSAPELIDOMOB: 4,
            VRDESPRODPROMOC: 5,
            IDDESCACRPROMO: 6,
            VRPRECITEM: 7,
            OBSERVACOES: 8,
            IDPRODBLOQ: 9,
            $promoPrinter: 10,
            VRALIQCOFINS: 11,
            VRALIQPIS: 12,
            VRPEALIMPFIS: 13,
            CDIMPOSTO: 14,
            CDCSTICMS: 15,
            CDCSTPISCOF: 16,
            CDCFOPPFIS: 17,
            DSPRODVENDA: 18,
            DSADICPROD: 19,
            DSENDEIMGPROMO: 20,
            NRORDPROMOPR: 21,
            IDPRODPRESELEC: 22,
            IDOBRPRODSELEC: 23,
            IDTIPOCOMPPROD: 25,
            HRINIVENPROD: 26,
            HRFIMVENPROD: 27
        };
        products
            .filter(product => product.IDTIPOCOMPPROD == "3")
            .forEach(comboProduct => {
                if (comboProduct.GRUPOS) {
                    Object.keys(comboProduct.GRUPOS).forEach(function (groupKey) {
                        Object.keys(comboProduct.GRUPOS[groupKey].produtos).forEach(
                            function (productkey) {
                                comboProduct.GRUPOS[groupKey].produtos[productkey] = _mapPositionPromoProducts(comboProduct.GRUPOS[groupKey].produtos[productkey], mapPosition);
                            }
                        );
                    });
                }
            });
    };

    const _mapPositionPromoProducts = function (product, map) {
        return {
            'CDPRODUTO': product[map['CDPRODUTO']],
            'NMPRODUTO': product[map['DSAPELIDOMOB']],
            'DSPRODVENDA': product[map['DSPRODVENDA']],
            'IMGPRODUTO': product[map['DSENDEIMGPROMO']] ? product[map['DSENDEIMGPROMO']] : null,
            'VRPRECITEM': product[map['VRPRECITEM']],
            'IDDESCACRPROMO': product[map['IDDESCACRPROMO']],
            'OBSERVACOES': product[map['OBSERVACOES']],
            'IDAPLICADESCPR': product[map['IDAPLICADESCPR']],
            'IDPERVALORDES': product[map['IDPERVALORDES']],
            'VRDESPRODPROMOC': product[map['VRDESPRODPROMOC']],
            'PRODUCT_TYPE': productMapType.COMBO_CHILD,
            'IDPRODBLOQ': product[map['IDPRODBLOQ']],
            'IDPRODPRESELEC': product[map['IDPRODPRESELEC']],
            'IDOBRPRODSELEC': product[map['IDOBRPRODSELEC']],

        };
    };

    const _mapGroutMutex = function _mapGroutMutex(comboProduct) {
        const promoGroups = comboProduct.GRUPOS;
        const mapGroupMutex = Object.keys(promoGroups)
            .filter((groupKey) => {
                const currentGroup = promoGroups[groupKey];
                return !!currentGroup.grupo.CDGRUPMUTEX
            }).reduce((mapObj, key) => {
                const mutexKey = promoGroups[key].grupo.CDGRUPMUTEX;
                if (!mapObj[mutexKey]) {
                    mapObj[mutexKey] = [];
                }
                mapObj[mutexKey].push(promoGroups[key])
                return mapObj;
            }, {})
        comboProduct.mapGroupMutex = mapGroupMutex
    }
}