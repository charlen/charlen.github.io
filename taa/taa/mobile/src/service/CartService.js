function CartService(ProductDetailService) {
    this.cart = [];
    this.cartIsBlocked = false;
    this.indexCartAuxiliar = '';

    const mapCartState = {
        ADD_PRODUCT_STATE: 'add',
        EDIT_PRODUCT_STATE: 'personalize',
        COMBO_STATE: 'combo',
        PERSONALIZE_COMBO_STATE: 'personalize-combo',
        PERSONALIZE_COMBO_ITEM_STATE: 'personalize-combo-item'
    }

    this.getIndexCartAuxiliar = function(){
        return this.indexCartAuxiliar;
    }

    this.setIndexCartAuxiliar = function(index){
        this.indexCartAuxiliar = index;
    }

    this.getOriginalState = function(){
        return this.originalState;
    }

    this.setOriginalState = function(state){
        this.originalState = mapCartState[state];
    }

    this.setCartItemState = function(state) {
        this.cartItemState = mapCartState[state];
    };

    this.getCartItemState = function() {
        return this.cartItemState;
    };


    this.clearCart = function() {
        this.cart = [];
    };

    this.getCart = function() {
        return this.cart;
    };

    this.addToCart = function(item) {
        this.cart.push(item);
    };

    this.updateItem = function (item, indexOldItem) {
        if(indexOldItem >= 0) {
            this.cart[indexOldItem] = item
        }
    }

    this.areObservationsEqual = function(item, cartItem) {
        let areEqual = false;
        if (item.IDTIPOCOMPPROD != "3" && !this.cartItemState.match("personalize")) {
            let itemSelectedObservations = item.OBSERVATIONS.filter(observation => observation.selected);
            let cartItemSelectedObservations = cartItem.OBSERVATIONS.filter(observation =>  observation.selected );
            if (itemSelectedObservations.length == cartItemSelectedObservations.length) {
                areEqual = itemSelectedObservations.every(function(itemObs, idx) {
                    return (itemObs.CDOCORR == cartItemSelectedObservations[idx].CDOCORR && itemObs.CDGRPOCOR == cartItemSelectedObservations[idx].CDGRPOCOR);
                });
            }
        } else {
            areEqual = true;
        }
        return areEqual;
    };

    this.blockCart = function() {
        this.cartIsBlocked = true;
    };

    this.unBlockCart = function() {
        this.cartIsBlocked = false;
    };

    this.getCartBlockedState = function() {
        return this.cartIsBlocked;
    };

}
