function ComboService($scope) {
    
    this.currentComboProduct = undefined;

    this.state = {
        groups: []
    }

    this.setGroups = function(groups) {
        this.state.groups = groups
    }

    this.getGroups = function() {
        return this.state.groups;
    }


    this.cancelCombo = function() {
        this.currentComboProduct = undefined;
    };

    this.getCurrentComboProduct = function() {
        return this.currentComboProduct;
    };
    
    this.setCurrentComboProduct = function(currentComboProduct) {
        this.currentComboProduct = currentComboProduct;
    };

    this.checkPromoGroupBlocked = function (groupKey) {
        if(!groupKey) {
            return
        }
        const grupromoc = this.currentComboProduct.GRUPOS[groupKey];
        const cartProducts = this.getWizardCart();
        if(grupromoc.grupo.CDGRUPMUTEX) {
            const mutexProducts = cartProducts.filter(product => product.wizardCartMutex)
            .map(key => { return {mutex: key.wizardCartMutex, groupKey: key.wizardCartKey}
            })
            const isBlocked = mutexProducts.some((product) => {
                return product.mutex === grupromoc.grupo.CDGRUPMUTEX && product.groupKey !== grupromoc.grupo.CDGRUPROMOC
            })
            grupromoc.isBlocked = isBlocked
            return isBlocked
        } else {
            return false
        }
    }

    this.checkPromoGroupFinished = function (groupKey, fromTemplate) {
        const grupromoc = this.currentComboProduct.GRUPOS[groupKey];
        let isFinished = false
        if(grupromoc.isBlocked) {
            isFinished = true
            grupromoc.isFinished = true
        } else {
            const total = this.getCountGroupProducts(groupKey)
            const min = grupromoc.grupo.QTPRGRUPROMIN
            const max = grupromoc.grupo.QTPRGRUPPROMOC
            if(min === 0) {
                isFinished = true
            }
            if(min > 0 && min < max) {
                isFinished = total >= min
            }
            if(min === max) {
                isFinished = total === max
            }
    
            grupromoc.isFinished = isFinished
    
            if(grupromoc.grupo.CDGRUPMUTEX && fromTemplate) {
                this.checkMutexGroupsFinished(isFinished, groupKey, grupromoc.grupo.CDGRUPMUTEX)
            }
        }
        return isFinished

    }

    this.checkMutexGroupsFinished = function (isFinished, groupKey, cdgrupmutex) {
        const groupKeys = Object.keys(this.currentComboProduct.GRUPOS);
        const mutexGroups = groupKeys.filter((key) => this.currentComboProduct.GRUPOS[key].grupo.CDGRUPMUTEX === cdgrupmutex && groupKey !== key)
        mutexGroups.forEach((key) => this.currentComboProduct.GRUPOS[key].isFinished = isFinished)
    }

    this.isComboMode = function() {
        return !!this.currentComboProduct;
    };

    this.getSelectedPromoGroup = function() {
        const groupKeys = Object.keys(this.currentComboProduct.GRUPOS);
        let selectedGroupKeyIndex = groupKeys.findIndex((key) => {
            const currentGroup = this.currentComboProduct.GRUPOS[key];
            return currentGroup.isSelected
        })
        if(selectedGroupKeyIndex >=0 ) {
            return this.currentComboProduct.GRUPOS[groupKeys[selectedGroupKeyIndex]]
        } else {
            return this.currentComboProduct.GRUPOS[groupKeys[0]]
        }
    };

    this.promoGroupFinished = function (key) {
        const groupKeys = Object.keys(this.currentComboProduct.GRUPOS);
        let selectedGroup = groupKeys.find((key) => {
            const currentGroup = this.currentComboProduct.GRUPOS[key];
            return currentGroup.isFinished
        })

        return selectedGroup.grupo.CDGRUPROMOC === key
    }

    this.getNextPromoGroup = function() {
        const groupKeys = Object.keys(this.currentComboProduct.GRUPOS);
        let nextPromoGroup = groupKeys.findIndex((elem) => {
            return !this.currentComboProduct.GRUPOS[elem].isFinished
        });
        if(nextPromoGroup < 0) {
            return
        }
        return groupKeys[nextPromoGroup]
        
    };

    this.setSelectedPromoGroup = function(CDGRUPROMOC) {
        let promoGroup = null;
        const groupKeys = Object.keys(this.currentComboProduct.GRUPOS);
        groupKeys.forEach((key) => {
            const currentGroup = this.currentComboProduct.GRUPOS[key];
            currentGroup.isSelected = false;
        })
        groupKeys.some((key) => {
            const currentGroup = this.currentComboProduct.GRUPOS[key];
            if(currentGroup.grupo.CDGRUPROMOC === CDGRUPROMOC) {
                currentGroup.isSelected = true;
                promoGroup = currentGroup;
                return true;
            }
        })
        
        return promoGroup
    }

    this.isComboReady = function () {
        const groupKeys = Object.keys(this.currentComboProduct.GRUPOS);
        const comboNotReady = groupKeys.some((key) => {
            return !this.currentComboProduct.GRUPOS[key].isFinished
        })
        return !comboNotReady
    }

    this.getWizardCartSize = function() {
        const mapGroupSize =  Object.keys(this.currentComboProduct.GRUPOS).reduce((mapObj, groupKey) => {
            const currentGroup = this.currentComboProduct.GRUPOS[groupKey];
            const cdMutex = currentGroup.grupo.CDGRUPMUTEX;
            const groupCode = currentGroup.grupo.CDGRUPROMOC;
            const prop = cdMutex ? cdMutex : groupCode;
            if(!mapObj[prop]) {
                mapObj[prop] = !!currentGroup.grupo.QTPRGRUPROMIN ? currentGroup.grupo.QTPRGRUPROMIN : currentGroup.grupo.QTPRGRUPPROMOC;
            } else {
                return mapObj;
            }
            return mapObj
        }, {});
        return Object.keys(mapGroupSize).reduce((size, key) => {
            const groupSize = mapGroupSize[key];
            return size + groupSize;
        }, 0)
    };

    this.getRemainingGroupQuantity = function(groupKey) {
        if (this.currentComboProduct) {
            const currentGroup = groupKey ? this.currentComboProduct.GRUPOS[groupKey] : this.getSelectedPromoGroup();
            const groupProducts = this.getWizardCartProductsGroup(currentGroup.grupo.CDGRUPROMOC);
            const totalQuantity = groupProducts.reduce((size, product) => size + product.QTPRODCOMVEN, 0);
            return currentGroup.grupo.QTPRGRUPPROMOC - totalQuantity;
        }
    };

    this.getCountGroupProducts = function(groupKey) {
        let currentGroup = this.currentComboProduct.GRUPOS[groupKey].grupo;
        let groupProducts = this.getWizardCartProductsGroup(currentGroup.CDGRUPROMOC);
        let totalQuantity = 0;
        groupProducts.forEach(function(product) {
            totalQuantity += product.QTPRODCOMVEN;
        });
        return totalQuantity;

    }

    this.getRemainingGroupQuantityMessage = function() {
        if (this.getRemainingGroupQuantity() == 1) {
            switch (localStorage.language) {
                case '"pt_br"':
                    return (
                        "Selecione " +
                        this.getRemainingGroupQuantity() +
                        " item para prosseguir"
                    );
                case '"en_us"':
                    return (
                        "Select " +
                        this.getRemainingGroupQuantity() +
                        " item to proceed"
                    );
                case '"es"':
                    return (
                        "Seleccione " +
                        this.getRemainingGroupQuantity() +
                        " elemento para continuar"
                    );
                default:
                    return (
                        "Selecione " +
                        this.getRemainingGroupQuantity() +
                        " item para prosseguir"
                    );
            }
        } else {
            switch (localStorage.language) {
                case '"pt_br"':
                    return (
                        "Selecione " +
                        this.getRemainingGroupQuantity() +
                        " itens para prosseguir"
                    );
                case '"en_us"':
                    return (
                        "Select " +
                        this.getRemainingGroupQuantity() +
                        " items to proceed"
                    );
                case '"es"':
                    return (
                        "Seleccione " +
                        this.getRemainingGroupQuantity() +
                        " elementos para continuar"
                    );
                default:
                    return (
                        "Selecione " +
                        this.getRemainingGroupQuantity() +
                        " itens para prosseguir"
                    );
            }
        }
    };

    this.getPromoGroups = function() {
        const currentComboProduct = this.currentComboProduct;
        if (currentComboProduct) {
            return currentComboProduct.GRUPOS;
        } else {
            return false;
        }
    };

    //wizardCart

    this.wizardCart = [];

    this.getWizardCart = function() {
        return this.wizardCart;
    };

    this.setWizardCart = function(wizardCart) {
        this.wizardCart = wizardCart;
    };

    this.addComboItem = function(item) {
        this.wizardCart.push(item);
        this.checkPromoGroupFinished(item.wizardCartKey, true)
    };

    this.removeComboItem = function(item) {
        const index = this.wizardCart.findIndex((cartItem) => item == cartItem);
        this.wizardCart.splice(index, 1);
        this.setSelectedPromoGroup(item.wizardCartKey)
        this.checkPromoGroupFinished(item.wizardCartKey, true)
    };

    this.updateComboItem = function (product, index) {
        const productIndex = this.wizardCart.findIndex((product) => product.indexCart === index)
        if(productIndex < 0) {
            this.wizardCart.push(product);
        } else {
            this.wizardCart[productIndex] = product
        }
    }

    this.clearWizardCart = function() {
        this.wizardCart = [];
    };

    this.getWizardCartCurrentLength = function() {
        let currentLength = 0;
        this.wizardCart.forEach(function(item) {
            currentLength += item.QTPRODCOMVEN;
        });
        return currentLength;
    };

    this.getWizardCartProductsGroup = function(wizardCartKey) {
        return this.wizardCart.filter(function(product) {
            return product.wizardCartKey == wizardCartKey;
        });
    };

}
