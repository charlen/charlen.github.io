ZeedhiServices.service("BiometricService", [function () {
    let abort = null
    let signal = null

    this.abort = function () {
        if (abort) {
            abort.abort()
        }
    }
    this.info = function () {
        return fetch('http://localhost:3000/biometry/info', {
            method: 'get',
            signal: signal
        })
            .then(success => success.json())
    }

    this.init = function () {
        abort = new AbortController()
        signal = abort.signal
        return fetch('http://localhost:3000/biometry/init', {
            method: 'get',
            signal: signal
        })
            .then(response => {
                if (response.ok) {
                    return response.json()
                } else {
                    return response.json()
                        .then(response => {
                            throw response.message
                        })
                }
            })
    }

    this.captureAndIdentify = function () {
        return fetch('http://localhost:3000/biometry/captureAndIdentify', {
            method: 'get',
            signal: signal
        })
            .then(response => {
                if (response.ok) {
                    return response.json()
                } else {
                    return response.json()
                        .then(response => {
                            throw response.message
                        })
                }
            })
    }

    this.validate = function (id) {
        return fetch('http://localhost:3000/biometry/validate', {
            method: 'post',
            signal,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id
            })
        })
            .then(response => {
                if (response.ok) {
                    return response.json()
                } else {
                    return response.json()
                        .then(response => {
                            throw response.message
                        })
                }
            })
    }

    this.terminate = function () {
        return fetch('http://localhost:3000/biometry/terminate', {
            method: 'get',
            signal: signal
        })
            .then(response => {
                if (response.ok) {
                    return response.json()
                } else {
                    return response.json()
                        .then(response => {
                            throw response.message
                        })
                }
            })
    }
}]);