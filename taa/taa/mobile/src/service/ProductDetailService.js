function ProductDetailService() {
    
    this.selectedProduct = undefined;
    this.OBSERVATIONS = [];

    this.incrementProductQtty = function() {
        if(this.selectedProduct) {
            this.selectedProduct.QTPRODCOMVEN++;
        }
    };

    this.decrementProductQtty = function() {
        if(this.selectedProduct) {
            this.selectedProduct.QTPRODCOMVEN--;
        }
    };

    this.resetSelectedProduct = function() {
        this.selectedProduct = undefined;
    };

    this.setSelectedProduct = function(product) {
        this.selectedProduct = product;
    };

    this.setObservations = function(observations) {
        this.OBSERVATIONS = observations;
    };

    this.getObservations = function() {
        return this.OBSERVATIONS;
    };

    this.getSelectedProduct = function() {
        return this.selectedProduct;
    };
    
}