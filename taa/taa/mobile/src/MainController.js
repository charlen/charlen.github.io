function MainController(
    $scope,
    $rootScope,
    $timeout,
    templateManager,
    ComboService,
    ProductGridService,
    CartService,
    maskEngine,
    ApplicationContext,
    ScreenService,
    $interval,
    ZHPromise
) {
    const mapTypeRegister = {
        COMANDA: 'APC',
        TERMINAL: 'TAA'
    };

    let headerInterval = null;
    let imageIndex = 0;

    let self = this;

    this.state = {
        capptaInstance: null,
        timeoutMinutes: 0,
        simulationParams: null,
        currentClient: null,
        saleParams: {},
        mesaParams: [],
        menu: {},
        totalSale: 0,
        orderMethod: 'kiosk',
        payment: {},
        orderCode: '',
        consumerSaleParams: {},
        currentPage: 'WAIT_SCREEN',
        consumerDoc: null,
        cardNumber: null,
        isTotem: window.innerHeight > window.innerWidth,
        orderInfo: {},
        qrcodeInfo: {},
        tableInfo: [],
        paymentAwaitingCard: false,
        paymentAwaitingMoney: false,
        paymentAwaitingQrCode: false,
        toGo: undefined,
        showSizeModal: false,
        showComboModal: false,
        showFlavorModal: false,
        sizeSuggestionSelected: [],
        flavorSuggestionSelected: [],
        produtoSuggestionSelected: [],
        grupoSuggestionSelected: [],
        sizeSuggestionSelected: [],
        showFlavorModal: false,
        flavorSuggestion: [],
        selectedProduct: {},
        showProductModal: false,
        showGroupModal: false,
        nextPage: undefined,
        showUpdateModal: false,
        indexCurrentGroup: 0,
        productsSelectedsOnSuggestion: [],
        confirmedProductsOnSuggestion: [],
        suggestionsMap: [],
        comboSuggestedLine: []
    };

    this.resetState = function() {
        this.state.payment = {};
        this.state.saleParams = {};
        this.state.toGo = undefined;
        this.state.consumerSaleParams = {};
        this.state.totalSale = 0;
        this.state.cardNumber = '';
        this.state.orderInfo = {}
        this.state.qrcodeInfo = {}
        this.state.tableInfo = [];
        this.state.paymentAwaitingCard =  false;
        this.state.paymentAwaitingQrCode = false;
        this.selectedProduct = {};
        this.state.showSizeModal = false;
        this.state.showComboModal = false;
        this.state.showFlavorModal = false;
        this.state.sizeSuggestionSelected = [];
        this.state.flavorSuggestionSelected = [];
        this.state.comboSuggestionSelected = [];
        this.state.produtoSuggestionSelected = [];
        this.state.grupoSuggestionSelected = [];
        this.state.selectedProduct = {};
        this.state.showProductModal = false;
        this.state.showGroupModal = false
    };

    this.resetOnlyShowModals = function(){
        this.state.showFlavorModal = false;
        this.state.showSizeModal = false;
        this.state.showComboModal = false;
        this.state.showProductModal = false;
        this.state.showGroupModal = false;
    }

    this.resetAllSelectedSuggestions = function () {
        this.state.sizeSuggestionSelected = [];
        this.state.flavorSuggestionSelected = [];
        this.state.comboSuggestionSelected = [];
        this.state.produtoSuggestionSelected = [];
        this.state.grupoSuggestionSelected = [];
        this.state.showFlavorModal = false;
        this.state.showSizeModal = false;
        this.state.showComboModal = false;
        this.state.showProductModal = false;
        this.state.showGroupModal = false;
    }

    this.getMainControllerWidget = function() {
        return templateManager.container.widgets[
            templateManager.container.widgetsIndexes[this.state.currentPage]
        ];
    };

    this.changePage = function(pageName) {
        // _handleBarcodeState(this.state.currentPage, pageName);
        const findedTemplate = templateManager.container.widgets.find(function(
            template
        ) {
            return pageName === template.name;
        });
        this.state.currentPage = pageName;
        this.state.mainWidget = findedTemplate;
    };

    this.changePage('WAIT_SCREEN');

    this.loadCurrentClient = function() {
        this.state.currentClient = JSON.parse(localStorage.getItem('clientData'));
        ApplicationContext.ClientMetadataRepo.findOne().then(clientConfig => {
            fetch('./config.json')
                .then(file => file.json())
                .then(jsonData => {
                    this.state.timeoutMinutes = clientConfig.timeoutMinutes;
                    this.bindTimeoutClickEvent(this.state.timeoutMinutes);
                    this.state.simulationParams = jsonData.simulationParams;
                    // ApplicationContext.ConsumerToRechargeRepository.clearAll();
                    // ApplicationContext.ConsumerFamiliesRepository.clearAll();
                    if (Array.isArray(this.state.currentClient.images.header)) {
                        headerInterval = $interval(
                            () => {
                                imageIndex++;
                                if (
                                    imageIndex >
                                    this.state.currentClient.images.header
                                    .length - 1
                                ) {
                                    imageIndex = 0;
                                }
                            },
                            10000,
                            false
                        );
                    }
                });
        });
    };

    this.handleRoute = function(IDHABCAIXAVENDA) {
        if (IDHABCAIXAVENDA === mapTypeRegister.COMANDA) {
            this.state.orderMethod = 'billet';
            this.changePage('BILLET_LOADER');
        }

        if (IDHABCAIXAVENDA === mapTypeRegister.TERMINAL) {
            _prepareProductsLanguage();
            ApplicationContext.RecebimentoRepository.findAll()
                .then(payments =>
                    payments.some(payment => payment.IDTIPORECE === '9')
                )
                .then(showIdentification => {
                    showIdentification || this.state.currentClient.showQrcode ?
                        this.changePage('DINNING_PLACE') :
                        this.changePage('PRODUCT_GRID');
                });
        }
    };

    const _prepareProductsLanguage = () => {
        switch (localStorage.language) {
            case '"pt_br"':
                templateManager.container.fieldNames.productName = 'NMPRODUTO';
                templateManager.container.fieldNames.groupName = 'NMGRUPO';
                break;
            case '"en_us"':
                templateManager.container.fieldNames.productName =
                    'NMPRODINGLES';
                templateManager.container.fieldNames.groupName =
                    'NMGRUPOINGLES';
                break;
            case '"es"':
                templateManager.container.fieldNames.productName =
                    'NMPRODESPANH';
                templateManager.container.fieldNames.groupName =
                    'NMGRUPOESPANH';
                break;
            default:
                templateManager.container.fieldNames.productName = 'NMPRODUTO';
                templateManager.container.fieldNames.groupName = 'NMGRUPO';
        }
    };

    this.setFieldNames = function(fieldNames) {
        this.state.fieldNames = fieldNames;
    };

    this.getFieldName = function(field) {
        return this.state.fieldNames[field];
    };

    this.setFieldNames(templateManager.container.fieldNames);

    $scope.accessibility = false;
    $scope.accessibilityCart = false;
    $scope.$watch('accessibility', function(value) {
        document.querySelector('html').style.fontSize = value ? '50%' : '62.5%';
        document.querySelector('body').style.fontSize = value ? '50%' : '62.5%';
        document.querySelector('.zh-container-alert').style.top = value ?
            '80%' :
            '50%';
        document.querySelector('.zh-position-loading').style.top = value ?
            '80%' :
            '50%';
    });

    this.currencyFormat = function(value) {
        return maskEngine.currencyFormat(value, {showSymbol: false});
    };

    this.currencyFormatExchangeSymbol = function() {
        let exchangeSymbol = 'R$'
        return exchangeSymbol;
    };
    
    this.currencyFormatInteger = function(value) {
        if(!value) {
            value = 0
        }
        let aux = maskEngine.currencyFormat(value, {showSymbol: false});
        let aux1 = null
        let price = null
        if(aux.includes(',')){
            aux1 = aux.split(",");
        } else{
            aux1 = aux.split(".");            
        }
        price = aux1[0];
        return price;
    };

    this.currencyFormatDecimal = function(value) {
        if(!value) {
            value = 0
        }
        let aux = maskEngine.currencyFormat(value, {showSymbol: false});
        let aux1 = null
        let price = null
        if(aux.includes(',')){
            aux1 = aux.split(",");
            price = ",";          
        } else{
            aux1 = aux.split(".");  
            price = ".";          
        }        
        price = price+aux1[1];
        return price;
    };

    this.showAccessibility = function() {
        return (
            this.state.isTotem &&
            (this.state.currentPage === 'PRODUCT_GRID' ||
                this.state.currentPage === 'BILLET_LOADER')

        );
    };

    this.getCartWidget = function() {
        return templateManager.container.widgets.find(function(template) {
            return template.name === 'CART';
        });
    };

    this.getComboCartWidget = function() {
        return templateManager.container.widgets.find(function(template) {
            return template.name === 'COMBO_CART';
        });
    };

    this.getHeaderImage = function() {
        return this.state.currentClient ?
            Array.isArray(this.state.currentClient.images.header) ?
            this.state.currentClient.images.header[imageIndex] :
            this.state.currentClient.images.header :
            null;
    };

    $rootScope.$on('resetAccessibility', function() {
        $scope.accessibility = false;
    });

    this.cancelOrder = function() {
        ScreenService.hideLoader();
        ScreenService.restoreDefaultLoadingMessage();
        CartService.clearCart();
        this.resetState();
        ComboService.clearWizardCart();
        ComboService.cancelCombo();
        ProductGridService.resetBarcodeProduct();
        this.changePage('WAIT_SCREEN');
    };

    this.handlePrint = function(togglePrint, payment, simulateTef, capptaInstance) {
        let totalValue = this.state.totalSale;
        this.state.orderInfo.imprimirNota = togglePrint
        this.submitTef(payment, simulateTef, totalValue, capptaInstance)
            .then(tefResponse => {
                this.updatePaymentState(tefResponse);
                return this.submitPayment()
            })
            .catch(reject => this.showCancelOrderConfirmation(reject));
    };

    this.updatePaymentState = function(tefResponse) {
        if (tefResponse.dados) {
            this.state.payment = {
                ...this.state.payment,
                comprovanteTef: tefResponse.dados.comprovanteTef,
                CDNSUHOSTTEF: tefResponse.dados.CDNSUHOSTTEF,
                CDTIPORECE: tefResponse.dados.CDTIPORECE
            }
        }
    }


    this.handleCashPayment = function () {
        let promises = [];
        promises.push(ApplicationContext.AuthRepository.findOne());
        promises.push(ApplicationContext.CaixaRepository.findOne());
        promises.push(ApplicationContext.LojaRepository.findOne());
        promises.push(ApplicationContext.FilialRepository.findOne());
        promises.push(ApplicationContext.OpenRegisterRepository.findOne());
        return ZHPromise.all(promises).then((data) => {
            const dadosContent = Object.assign(data[0], data[1], data[2], data[3]);
            const dadosCliente = this.state.consumerSaleParams;
            const products = CartService.getCart();
            _filterObservations(products);
            ApplicationContext.OrderService.performCashSale(
                dadosContent,
                dadosCliente,
                products
            ).then((saleResponse) => {
                ScreenService.restoreDefaultLoadingMessage();
                ScreenService.hideLoader();
                this.state.orderCode =
                    saleResponse.dataset.PerformSaleRepository.orderCode;
                this.changePage("FINALIZE_PURCHASE");
            })
            .catch((error) => {
                ScreenService.restoreDefaultLoadingMessage();
                ScreenService.hideLoader();
                if (error.messages) {
                    this.showMessage(error.messages);
                }
            });
        });
    };

    this.performTransaction = function(payment, document) {
        const simulateTef = this.state.simulationParams.simulateTef;
        const capptaInstance = this.state.capptaInstance;
        this.state.payment = payment;
        const orderMethod = this.state.orderMethod

        if (orderMethod === 'recharge') {
            this.rechargePayment(payment, simulateTef, capptaInstance)
        }
        const paymentArray = ['kiosk', 'billet'];
        if (paymentArray.includes(this.state.orderMethod)) {
            if (payment.IDTIPORECE === '9' || payment.IDTIPORECE === 'A') {
                this.changePage('CONSUMER_PASSWORD');
            } else if (payment.IDTIPORECE == "4") {
                this.handleCashPayment();
            } else if (payment.IDTIPORECE == "H") {
                this.state.paymentAwaitingQrCode = true;
            } else {
                ApplicationContext.CaixaRepository.findOne()
                    .then(caixa => {
                        if (caixa.IDIMPOPCNF == true) {
                            ScreenService.confirmMessage(
                                'Deseja imprimir a sua nota fiscal?',
                                'CONFIRMATION',
                                () => {
                                    this.handlePrint(
                                        true, payment, simulateTef, capptaInstance)
                                },
                                () => {
                                    this.handlePrint(
                                        false, payment, simulateTef, capptaInstance)
                                }
                            )
                        } else {
                            this.handlePrint(
                                true, payment, simulateTef, capptaInstance
                            )
                        }
                    });
            }
        }
    }

    this.submitPayment = function() {
        let promises = [];
        promises.push(ApplicationContext.CaixaRepository.findOne());
        promises.push(ApplicationContext.AuthRepository.findOne());
        promises.push(ApplicationContext.FilialRepository.findOne());
        promises.push(ApplicationContext.LojaRepository.findOne());

        return ZHPromise.all(promises).then((data) => {
            const caixa = data[0];
            const operator = data[1];
            caixa.status.DTABERCAIX = moment(caixa.status.DTABERCAIX, 'DD/MM/YYYY hh:mm:ss').format('YYYY-MM-DD HH:mm:ss');
            const filial = data[2];
            const loja = data[3];
            const products = CartService.getCart();
            _filterObservations(products)
            const payment = this.state.payment;
            const simulation = this.state.simulationParams
            const consumer = this.state.consumerSaleParams
            this.state.orderInfo.orderMethod = this.state.orderMethod
            const orderInfo = this.state.orderInfo
            const tableInfo = this.state.tableInfo
            const qrcodeInfo = this.state.qrcodeInfo
            ScreenService.changeLoadingMessage('Realizando venda...');
            ApplicationContext.OrderService.performSale(filial, loja, caixa, products, payment, simulation, consumer, operator, orderInfo, tableInfo, qrcodeInfo)
                .then((saleResponse) => {
                    ScreenService.restoreDefaultLoadingMessage();
                    ScreenService.hideLoader();
                    this.state.orderCode = saleResponse.dataset.PerformSaleRepository.orderCode;
                    this.changePage("FINALIZE_PURCHASE");
                })
                .catch((error) => {
                    ScreenService.restoreDefaultLoadingMessage();
                    ScreenService.hideLoader();
                    if (error.messages) {
                        this.showMessage(error.messages);
                    }
                })

        })
    };

    this.rechargePayment = function(payment, simulateTef, capptaInstance) {
        const totalValue = this.state.totalRecharge;
        this.submitTef(payment, simulateTef, totalValue, capptaInstance)
            .then(transactionResponse => {
                const promises = [];
                promises.push(ApplicationContext.AuthRepository.findOne());
                Promise.all(promises).then(data => {
                    const familiesToRecharge = this.state.familiesToRecharge;
                    const filialData = data[0].parametros;
                    const consumer = this.state.consumerSaleParams;
                    ApplicationContext.ConsumerService.makeRecharge(
                            payment,
                            filialData,
                            familiesToRecharge,
                            consumer,
                            transactionResponse.dados
                        )
                        .then(response => {
                            if (response.dataset.statusRecharge.error) {
                                ScreenService.showMessage(
                                    `Recarga feita com sucesso. \n Erro ao imprimir o comprovante. ${response.dataset.statusRecharge.message}`
                                ).then(() => {
                                    this.cancelOrder();
                                });
                            } else {
                                ScreenService.showMessage(
                                    'Recarga concluída com sucesso.'
                                ).then(() => {
                                    this.cancelOrder();
                                });
                            }
                        })
                        .catch(error =>
                            ScreenService.showMessage(error.data.error)
                        );
                });
            })
            .catch(reject => {
                this.showCancelOrderConfirmation(reject);
            });
    };

    this.submitTef = (
        payment,
        simulateTef,
        totalValue,
        capptaInstance
    ) => {
        return new Promise((resolve, reject) => {
            this.state.paymentAwaitingCard = true;
            let paymentAwaitingCard = this.state.paymentAwaitingCard;
            ApplicationContext.TEFController.performTransaction(
                payment,
                simulateTef,
                totalValue,
                capptaInstance
            ).then(transactionResponse => {
                paymentAwaitingCard = false;
                if (transactionResponse.canceled) {
                    reject(`A transação foi cancelada, deseja cancelar a compra?`)
                } else if (transactionResponse.error) {
                    reject(
                        `${transactionResponse.message} Deseja cancelar o pedido?`
                    );
                } else {
                    resolve(transactionResponse);
                }
            });
        });
    };

    this.maskNumber = function (quantity){
        if(quantity < 10){
            return `0${quantity}`;
        } else{
            return quantity;
        }        
    }

    this.showMessage = function(messages) {
        if (messages) {
            return ScreenService.showMessage(
                messages[0].message,
                messages[0].type,
                undefined,
                messages[0].variables
            );
        }
    };

    this.CartClearConfirmation = function() {
        let message = 'Deseja realmente limpar o carrinho?';
        ScreenService.confirmMessage(
            message,
            'CONFIRMATION',
            () => {
                this.resetState();
                CartService.clearCart();
                this.cancelOrder();
            }
        );
    };

    this.showCancelOrderConfirmation = function(message) {
        ScreenService.confirmMessage(
            message,
            'CONFIRMATION',
            () => {
                this.resetState();
                CartService.clearCart();
                this.cancelOrder();
            },
            () => this.changePage('ORDER_DETAIL')
        );
    };


    this.getLengthItens = function() {
        let cartLength = CartService.getCart().length;
        return cartLength > 0 ? cartLength == 1 ? "1 Item" : cartLength+" Itens" : 'Total';
        
    }
    
    this.getTotal = function() {
        let total = 0;
        let cart = CartService.getCart();
        cart.forEach((product) => {
            total += this.getProductTotalPrice(product);
        });
        total = Math.round(total * 100) / 100;
        this.state.totalSale = total
        return total;
    };

    this.getProductTotalPrice = (product) => {
        let price = 0;
        if (product != null && product.IDTIPOCOMPPROD == "3") {
            price += this.getCalculateTotalForCombo(product);
        } else if( product != null ) {
            price += this.getIngredientsTotalPrice(product) * product.QTPRODVEND;
            let preco = product.PRICE.VRPRECITEM * product.QTPRODVEND
            price += preco > 0.01 ? preco : 0.01;
        }
        if( product != null && product.embalagem.price && this.state.toGo ){
            price += product.embalagem.price * product.QTPRODVEND;
        }

        return Math.round(price * 100) / 100;;
    };
    
    this.getProductPrice = (product) => {
        let price = 0;
        if (product != null && product.IDTIPOCOMPPROD == "3") {
            price += this.getCalculateTotalForCombo(product);
        } else if( product != null ) {            
            price += this.getIngredientsTotalPrice(product) * product.QTPRODVEND;
            let preco = product.PRICE.VRPRECITEM * product.QTPRODVEND
            price += preco > 0.01 ? preco : 0.01;
        }

        return Math.round(price * 100) / 100;
    };

    this.getProductPackagePrice = (product) => {
        let price = 0.00;        
        if( product != null && product.embalagem != null ){
            price += product.embalagem.price;

            if( product.QTPRODVEND != null && product.QTPRODVEND != undefined && product.QTPRODVEND > 0 ){
                price = price * product.QTPRODVEND;
            }
        }
        

        return Math.round(price * 100) / 100;;
    };

    this.isProductPackagePriceZero = (product) => {
        if(this.getProductPackagePrice(product) == 0){
            return false;
        }
    return true;
    }

    this.getCalculateTotalForCombo = function(product) {
        if(!product.comboItems) {
            return
        }
        if (product.IDIMPPRODUTO == '2') {
            let _total = 0;
            product.comboItems.forEach(comboProduct => {
                _total +=
                    this.getIngredientsTotalPrice(comboProduct) *
                    product.QTPRODVEND;
                const preco =
                    comboProduct.PRICE.VRPRECITEM *
                    comboProduct.QTPRODVEND *
                    product.QTPRODVEND;
                _total += preco > 0.01 ? preco : 0.01;
            });
            return _total;
        } else {
            let precoPai =
                product.PRICE.VRPRECITEM * product.QTPRODVEND;
            let _totalFilhos = 0;
            product.comboItems.forEach(comboProduct => {
                _totalFilhos +=
                    this.getIngredientsTotalPrice(comboProduct) *
                    product.QTPRODVEND;
            });
            return _totalFilhos + precoPai;
        }
    };

    this.getCalculatePackageForCombo = function(product) {
        if(!product.comboItems) {
            return
        }

        if (product.IDIMPPRODUTO == '2') {
            let _total = 0;
            product.comboItems.forEach(comboProduct => {
                _total +=
                    this.getIngredientsPackagePrice(comboProduct) *
                    product.QTPRODVEND;
                const preco =
                    comboProduct.PRICE.VRPRECITEM *
                    comboProduct.QTPRODVEND *
                    product.QTPRODVEND;
                _total += preco > 0.01 ? preco : 0.01;
            });
            return _total;
        } else {
            let precoPai =
                product.embalagem.PRICE.VRPRECITEM * product.QTPRODVEND;
            let _totalFilhos = 0;
            product.comboItems.forEach(comboProduct => {
                _totalFilhos +=
                    this.getIngredientsTotalPrice(comboProduct) *
                    product.QTPRODVEND;
            });
            return _totalFilhos + precoPai;
        }
    };    

    this.getIngredientsTotalPrice = function(product) {
        var total = 0;
        if (product.OBSERVATIONS) {
            product.OBSERVATIONS.filter(observation => observation.IDCONTROLAOBS === 'A')
                .forEach(function(ingredient) {
                    if (ingredient.QTPRODVEND > 0) {
                        total +=
                            parseFloat(ingredient.PRICE.VRPRECITEM) *
                            ingredient.QTPRODVEND;
                    }
                });
        }
        return total;
    };

    this.getIngredientsPackagePrice = function(product) {
        var total = 0;
        if (product.OBSERVATIONS) {
            product.OBSERVATIONS.filter(observation => observation.IDCONTROLAOBS === 'A')
                .forEach(function(ingredient) {
                    if (ingredient.QTPRODVEND > 0) {
                        total +=
                            parseFloat(ingredient.PRICE.VRPRECITEM) *
                            ingredient.QTPRODVEND;
                    }
                });
        }
        return total;
    };    

    this.state.mainWidget = templateManager.container.widgets.find(function(template) {
        return 'WAIT_SCREEN' === template.name;
    });

    // this.cartWidget = this.getCartWidget();
    // this.comboCartWidget = this.getComboCartWidget();

    this.generateActivityTimeout = function(numberOfMinutes) {
        
        if (window.activityTimeout) {
            $timeout.cancel(window.activityTimeout);
        }
        window.activityTimeout = $timeout(() => {
            this.cancelOrder();
        }, numberOfMinutes * 60 * 1000);
    };

    this.bindTimeoutClickEvent = function(numberOfMinutes) {
        if (!window.activityTimeoutEvent) {
            window.activityTimeoutEvent = $(window).mousedown(() => this.generateActivityTimeout(numberOfMinutes));
        }
    };

    const _filterObservations = (products) => {
        products.forEach(product => {
            if (!product.QRCODE) {
                product.VRDESITVEND += product.VRDESBENEFICIO || 0;

                if (Array.isArray(product.OBSERVATIONS)) {
                    product.OBSERVATIONS = product.OBSERVATIONS.filter((observation) => observation.selected)
                } else {
                    product.OBSERVATIONS = []
                }

                if (Array.isArray(product.ingredients)) {
                    product.OBSERVATIONS = [
                        ...product.OBSERVATIONS,
                        ...product.ingredients.filter(ingredient => ingredient.QTPRODVEND > 0)
                    ]
                }

                if (product.IDTIPOCOMPPROD == '3') {
                    product.comboItems.forEach(function(comboItem) {
                        if (Array.isArray(comboItem.OBSERVATIONS)) {
                            comboItem.OBSERVATIONS = comboItem.OBSERVATIONS.filter((observation) => observation.selected)
                        } else {
                            comboItem.OBSERVATIONS = []
                        }

                        if (Array.isArray(comboItem.ingredients)) {
                            comboItem.OBSERVATIONS = [
                                ...comboItem.OBSERVATIONS,
                                ...comboItem.ingredients.filter(ingredient => ingredient.QTPRODVEND > 0)
                            ]
                        }
                    });
                }
            }
        });
    }
    
    this.getDefaultProductImage = function(){
        return this.state.currentClient ? this.state.currentClient.images.defaultCard : null;
    }

    this.nameCorrection = function(){
        function splitAndCapitalize( text ){
            let stringComplete = '';
            text.forEach(word => {
                word = word.toLowerCase();
                let firstletter = word.charAt(0).toUpperCase();
                if (word.length > 1) {
                    word = firstletter + word.substr(1, word.length);
                } else {
                    word = firstletter;
                }
                if(text[0] == word.toUpperCase()){
                    stringComplete = word;
                } else {
                    stringComplete = stringComplete + ' ' + word;
                }
            })
            return stringComplete;
        }

        this.state.menu.promoProducts.forEach(element => {
            let elementMocker
            if(element.NMPRODUTO == undefined){
                elementMocker = element["DSBUTTON"].split(" ");
            } else{
                elementMocker = element["NMPRODUTO"].split(" ");
            }
            let stringComplete = splitAndCapitalize( elementMocker );
            if(element.NMPRODUTO == undefined){
                element["DSBUTTON"] = stringComplete;
            } else {
                element["NMPRODUTO"] = stringComplete;
            }
        });

        this.state.menu.promoGroups.forEach(element => {
            let elementMocker = element["NMGRUPROMOC"].split(" ");
            let stringComplete = splitAndCapitalize( elementMocker );
            element["NMGRUPROMOC"] = stringComplete;
        });

        this.state.menu.products.forEach(element => {
            let elementMocker = element["DSBUTTON"].split(" ");
            let stringComplete = splitAndCapitalize( elementMocker );
            element["DSBUTTON"] = stringComplete;
            if(element.suggestions != undefined){
                for(let suggestionType in element.suggestions){
                    element.suggestions[suggestionType].forEach(( suggestion ) => {
                        let suggestionMocker;
                        if(suggestion.produto != undefined){
                            suggestionMocker = suggestion.produto["DSBUTTON"].split(" ");
                            let stringComplete = splitAndCapitalize( suggestionMocker );
                            suggestion.produto["DSBUTTON"] = stringComplete;
                        } else{
                            suggestionMocker = suggestion.grupo["DSBUTTON"].split(" ");
                            let stringComplete = splitAndCapitalize( suggestionMocker );
                            suggestion.grupo["DSBUTTON"] = stringComplete;
                        }
                    })
                }
            }
        });

        this.state.menu.groups.forEach(element => {
            let elementMocker = element["DSBUTTON"].split(" ");
            let stringComplete = splitAndCapitalize( elementMocker );
            element["DSBUTTON"] = stringComplete;
        });

        this.state.menu.subgroups.forEach(element => {
            elementMocker = element["DSBUTTON"].split(" ");
            stringComplete = splitAndCapitalize( elementMocker );
            element["DSBUTTON"] = stringComplete;
        });
    }

    this.initMenu = function (){
        ApplicationContext.ProdutoRepository.findOne()
        .then(menu => {
            this.state.menu.groups = menu.groups;
            this.state.menu.promoProducts = menu.promoProducts;
            this.state.menu.promoGroups = menu.promoGroups;
            this.state.menu.subgroups = menu.subGroups;
            this.state.menu.products = menu.products;
            this.state.menu.localPromoGroups = menu.localPromoGroups;
            this.state.suggestionsMap = menu.suggestionsMap; 
            this.nameCorrection();
        })
    }

    this.goToGroupSuggestion = function(){
        this.changePage('GROUP_SUGGESTION');
    }
}

