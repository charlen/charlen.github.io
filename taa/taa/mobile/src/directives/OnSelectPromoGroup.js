ZeedhiApp.directive('onSelectPromoGroup', ['$timeout', function($timeout){
    return {
        link: function($scope, el) {
            $scope.$on('onSelectPromoGroup', function(ev) {
                $timeout(function() {
                    let child = el.find('.promogroup__selected')[0]
                    if(child != undefined){
                        child.scrollIntoView(true)
                    }                    
                }, 200)
            })
        }
    }
}])