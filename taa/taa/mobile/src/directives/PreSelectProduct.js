ZeedhiApp.directive('preSelectProduct', ['ComboService', function(ComboService){
    return {
        controller: 'ProductGridController',
        controllerAs: 'ctrl',
        bindToController: true,
        link: function(scope) {
            const currentGroup = ComboService.getSelectedPromoGroup();
            const comboProduct = ComboService.getCurrentComboProduct();
            const grupromoc = ComboService.setSelectedPromoGroup(currentGroup.grupo.CDGRUPROMOC)
            const products = grupromoc.produtos ? grupromoc.produtos : {};
            const keyProducts = Object.keys(products);
            if(keyProducts.length === 1) {
                if(!products[keyProducts[0]].preSelected) {
                    ComboService.setCurrentComboProduct(comboProduct);
                    scope.ctrl.selectProduct(products[keyProducts[0]])
                    products[keyProducts[0]].preSelected = true;
                }
            }
        },
    }
}])