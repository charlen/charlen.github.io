ZeedhiApp.directive('scrollBoxShadow', ['$timeout', function(){
    return {
        link: function($scope, elementDirective) {
            let productContainer = null;
                productContainer = document.getElementsByClassName('product-container')[0];
                productContainer.addEventListener('scroll', function(event) {
                const element = event.target;
                if(element.scrollTop) {
                    elementDirective.addClass('product-grid__header--shadow');
                } else {
                    elementDirective.removeClass('product-grid__header--shadow');
                }
            })
        }
    }
}])