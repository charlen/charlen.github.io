ZeedhiApp.directive('onSelectGroup', [function(){
    return {
        link: function($scope, el) {
            $scope.$on('onSelectGroup', function(ev) {
                $(el).parent().animate({
                    scrollTop : 0
                }, 500);
            })
        }
    }
}])