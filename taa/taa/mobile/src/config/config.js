window.templateUrls = window.templateUrls || [];
var packageName = 'zh-self-checkout';

var hasPackageRegistered = window.templateUrls.some(function(templateUrl) {
    return templateUrl.package === packageName;
});

if (!hasPackageRegistered) {
    window.templateUrls.push({
        'package': packageName,
        'baseUrl': './lib/' + packageName + '/dist/templates/'
    });
}