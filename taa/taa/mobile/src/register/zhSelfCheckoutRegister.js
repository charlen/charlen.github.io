ZeedhiServices.service("CartService", ["ProductDetailService", function(ProductDetailService) {
    return new CartService(ProductDetailService);
}]);

ZeedhiServices.service("ProductDetailService", [function() {
    return new ProductDetailService();
}]);


ZeedhiServices.service("ProductGridService", [function() {
    return new ProductGridService();
}]);

ZeedhiServices.service("ComboService", [function() {
    return new ComboService();
}]);

