function GroupImageController($scope, CartService) {
    const vm = $scope.parent;
    this.parent = vm;

    this.state = {
        subGroups: [],
        products: [],
        currentGroup: {},
        currentProduct: {},
        idAwaiting: 0,
        showModalRemoverProduto: false,
        showModalObservations: false,
        showCombo: false,
        currentCombo: {},
        showModalGoCart: false,
        repeatSuggestVerify: false
    };

    this.init = function () {
        this.state.products = this.parent.state.menu.products;
        this.state.subGroups = this.parent.state.menu.subgroups;
        const index = this.parent.state.indexCurrentGroup;
        this.state.currentGroup = this.parent.state.grupoSuggestionSelected[
            index
        ];
        this.parent.state.reselectingGroupSuggestion = false;
        this.parent.state.productsSelectedsOnSuggestion = [
            ...Array(this.parent.state.grupoSuggestionSelected.length),
        ].map((_) => new Array());
        this.parent.state.confirmedProductsOnSuggestion = [
            ...Array(this.parent.state.grupoSuggestionSelected.length),
        ].map((_) => new Array());
    };

    this.isSubSuggestionsEmpity = function () {
        const index = this.parent.state.indexCurrentGroup;
        const group = this.parent.state.grupoSuggestionSelected[index];
        const allSubGroups = this.state.subGroups;

        let subgroups = allSubGroups.filter((subgroup) => {
            return (
                group.NRPGCONFTELA + group.NRBUTTON ===
                subgroup.NRPGCONFTAUX + subgroup.NRBUTTONAUX
            );
        });

        if (subgroups.length === 0) {
            return true;
        } else {
            return false;
        }
    };

    this.filterSubgroups = (subgroup) => {
        const index = this.parent.state.indexCurrentGroup;
        const group = this.parent.state.grupoSuggestionSelected[index];
        return (
            group.NRPGCONFTELA + group.NRBUTTON ===
            subgroup.NRPGCONFTAUX + subgroup.NRBUTTONAUX
        );
    };

    this.filterProducts = (product) => {
        const index = this.parent.state.indexCurrentGroup;
        const group = this.parent.state.grupoSuggestionSelected[index];
        let productMocker;
        if (this.state.products.length > 0) {
            productMocker =
                group.NRPGCONFTELA + group.NRBUTTON ==
                    product.NRPGCONFTAUX + product.NRBUTTONAUX &&
                product.IDTPBUTONAUX == "2" &&
                product.IDSHOWTAA == "S";

            return productMocker;
        }
    };

    this.filterSubProducts = (subgroup) => {
        const index = this.parent.state.indexCurrentGroup;

        const group = this.parent.state.grupoSuggestionSelected[index];
        return (product) => {
            return (
                subgroup.NRPGCONFTELA + subgroup.NRBUTTON ===
                    product.NRPGCONFTAUX + product.NRBUTTONAUX &&
                group.NRPGCONFTELA + group.NRBUTTON ==
                    product.NRPGCONFTAUX2 + product.NRBUTTONAUX2 &&
                product.IDTPBUTONAUX == "I" &&
                product.IDSHOWTAA == "S"
            );
        };
    };

    this.isSelected = function (product) {
        const list = this.parent.state.productsSelectedsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ];
        if (list.includes(product)) {
            return true;
        } else {
            return false;
        }
    };

    this.removeSelectedItemFromCart = function (item) {
        const cart = CartService.getCart();
        const obj = cart.filter((each) => {
            if (each.IDFORSELECTION != undefined) {
                return each.IDFORSELECTION == item.IDFORSELECTION;
            }
        });
        const aux = obj.length - 1;
        const index = cart.indexOf(obj[aux]);
        if (index > -1) {
            CartService.getCart().splice(index, 1);
        }
    };

    this.handleSelectedMultipleSuggestion = function (suggestion) {
        this.state.repeatSuggestVerify = false;
        const selecteds = this.parent.state.productsSelectedsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ];
        if (selecteds.length == 0) {
            if (suggestion.IDTIPOCOMPPROD == 3) {
                this.checkComboSuggestions(suggestion);
            } else {
                this.checkSuggestions(suggestion);
            }
        } else {
            let count = 0;
            selecteds.forEach((element) => {
                if (element == suggestion) {
                    const index = selecteds.indexOf(suggestion);
                    if (index > -1) {
                        this.parent.state.productsSelectedsOnSuggestion[
                            this.parent.state.indexCurrentGroup
                        ].splice(index, 1);
                        this.parent.state.confirmedProductsOnSuggestion[
                            this.parent.state.indexCurrentGroup
                        ].splice(index, 1);
                        if (
                            this.parent.state.reselectingGroupSuggestion == true
                        ) {
                            this.removeSelectedItemFromCart(suggestion);
                        }
                        this.parent.state.produtoSuggestionSelected = this.parent.state.confirmedProductsOnSuggestion[
                            this.parent.state.indexCurrentGroup
                        ];
                    }
                    count = count + 1;
                }
            });
            if (count == 0) {
                if (suggestion.IDTIPOCOMPPROD == 3) {
                    this.checkComboSuggestions(suggestion);
                } else {
                    this.checkSuggestions(suggestion);
                }
            }
        }
        this.parent.state.produtoSuggestionSelected = this.parent.state.confirmedProductsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ];
    };

    this.insertComboOnCart = function () {
        this.state.showCombo = false;
        const combo = this.state.currentCombo;
        
        this.parent.state.confirmedProductsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ].push(combo);
        this.parent.state.productsSelectedsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ].push(this.state.currentProduct);
        this.parent.state.produtoSuggestionSelected = this.parent.state.confirmedProductsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ];
    };

    this.insertOnCart = function (product) {
        product.IDFORSELECTION = this.state.idAwaiting;
        this.state.currentProduct.IDFORSELECTION = this.state.idAwaiting;
        this.parent.state.confirmedProductsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ].push(product);
        this.parent.state.productsSelectedsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ].push(this.state.currentProduct);
        this.parent.state.produtoSuggestionSelected = this.parent.state.confirmedProductsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ];
    };

    this.checkComboSuggestions = function (product) {
        this.state.currentProduct = product;
        const id = Math.floor(Math.random() * 500000);
        this.state.idAwaiting = id;
        this.state.currentProduct.IDFORSELECTION = this.state.idAwaiting;
        this.state.currentCombo = this.state.currentProduct;
        this.parent.state.selectedProduct = this.state.currentProduct;

        if (product.suggestions != undefined) {
            this.handleFlavorSuggestion(product);
        }else {
            this.state.showCombo = true;
        }
    };

    this.checkSuggestions = function (product) {
        const id = Math.floor(Math.random() * 500000);
        this.state.idAwaiting = id;
        this.state.currentProduct = product;
        this.parent.state.selectedProduct = product;
        if (product.suggestions != undefined) {
            this.handleFlavorSuggestion(product);
        } else {
            this.insertOnCart(product);
        }
    };

    this.handleFlavorSuggestion = function(product){
        const list = this.parent.state.suggestionsMap;
        const suggestions = list[product.CDPRODUTO]
        this.parent.state.selectedProduct = product;
        if(suggestions != undefined && suggestions.sabor != undefined){
            this.parent.state.showFlavorModal = true;
        } else{
            this.state.repeatSuggestVerify = true;
            this.handleSizeSuggestion(product)
        }
    }

    this.handleSizeSuggestion = function( product ){
        const list = this.parent.state.suggestionsMap;
        const suggestions = list[product.CDPRODUTO]
        if (suggestions != undefined && suggestions.tamanho != undefined) {
            this.parent.state.showSizeModal = true;
        } else if(product.PRODUCT_TYPE == "N"){
            this.insertOnCart(product);
        } else if(product.PRODUCT_TYPE == "CP"){
            this.state.showCombo = true;
        } else{
            console.log("erro")
        }
    }

    this.configureProduct = function (arr) {
        if (arr.IDTIPOCOMPPROD == 3) {
            arr.IDFORSELECTION = this.state.idAwaiting;
            this.state.currentCombo = arr;
            this.state.showCombo = true;                
        } else {
            arr.IDFORSELECTION = this.state.idAwaiting;
            this.state.currentProduct.IDFORSELECTION = this.state.idAwaiting;
            this.parent.state.confirmedProductsOnSuggestion[
                this.parent.state.indexCurrentGroup
            ].push(arr);
            this.parent.state.productsSelectedsOnSuggestion[
                this.parent.state.indexCurrentGroup
            ].push(this.state.currentProduct);
            this.parent.state.produtoSuggestionSelected = this.parent.state.confirmedProductsOnSuggestion[
                this.parent.state.indexCurrentGroup
            ];
        }
    };

    this.isEmpitySelections = function () {
        if (
            this.parent.state.productsSelectedsOnSuggestion[
                this.parent.state.indexCurrentGroup
            ].length === 0
        ) {
            return true;
        } else {
            return false;
        }
    };

    this.confirmProducts = function () {
        if (this.parent.state.grupoSuggestionSelected.length === this.parent.state.indexCurrentGroup + 1) {
            this.state.showModalGoCart = true;
        } else {
            this.parent.state.confirmedProductsOnSuggestion[
                this.parent.state.indexCurrentGroup
            ].forEach((product) => {
                product.QTPRODVEND = 1;
                CartService.addToCart(product);
            });
            this.parent.state.indexCurrentGroup++;
            this.parent.state.confirmedProductsOnSuggestion[
                this.parent.state.indexCurrentGroup
            ] = [];
        }
    };

    this.backToPreviousGroup = function () {
        if (this.parent.state.indexCurrentGroup == 0) {
            this.parent.changePage("PRODUCT_GRID");
        } else {
            this.parent.state.productsSelectedsOnSuggestion[
                this.parent.state.indexCurrentGroup
            ] = [];
            this.parent.state.indexCurrentGroup--;

            this.parent.state.reselectingGroupSuggestion = true;
            this.parent.state.confirmedProductsOnSuggestion[
                this.parent.state.indexCurrentGroup
            ] = [];
        }
    };

    this.modalPreCart = function () {
        this.parent.state.nextPage = "CART";
        this.setShowModalRemoverProduto(true);
    };

    this.setShowModalRemoverProduto = function (option) {
        this.state.showModalRemoverProduto = option;
    };

    this.returnTitle = function () {
        const index = this.parent.state.indexCurrentGroup;
        return `Escolha ${this.parent.state.grupoSuggestionSelected[index].DSBUTTON}`;
    };

    this.goToCart = function(){
        this.parent.state.confirmedProductsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ].forEach((product) => {
            product.QTPRODVEND = 1;
            CartService.addToCart(product);
        });
        this.parent.state.indexCurrentGroup = 0;
        this.parent.changePage("CART");
    }

    this.backMenu = function(){
        this.parent.state.confirmedProductsOnSuggestion[
            this.parent.state.indexCurrentGroup
        ].forEach((product) => {
            product.QTPRODVEND = 1;
            CartService.addToCart(product);
        });
        this.parent.state.indexCurrentGroup = 0;
        this.parent.changePage("PRODUCT_GRID");
    }

    this.removeSelectedProductAndCloseModal = function(){
        // Only for close goCart modal
        this.state.showModalGoCart = false;
    }
}
