function ProductGridController(
    $rootScope,
    $scope,
    ApplicationContext,
    $timeout,
    CartService
) {
    const vm = $scope.parent
    this.parent = vm

    this.state = {
        selectedGroup: null,
        selectedProduct: false,
        productselected: [],
        selectproduct: [],
        subgroups: [],
        hasProductInCombo: false,
        showModal: false,
        combo: [],
        showModalViagem: false,
        sibblingProducts: [],
        selected: '',
        selectedViagem: '',
        menu: [],
        showSizeModal: false,
        showFlavorModal: false,
        showComboModal: false,
        repeatSuggestVerify: false
    }

    $scope.$broadcast('onCancelCombo', () => {
        console.log('cancelling combo')
    })


    this.showModal = function () {
        return this.state.showModal;
    }

    this.selectGroup = function (group) {
        const {subgroups} = this.state.menu
        this.state.subgroup = subgroups.some(subgroup => group.NRPGCONFTELA + group.NRBUTTON === subgroup.NRPGCONFTAUX + subgroup.NRBUTTONAUX)
        this.state.selectedGroup = group
    };

    this.nameCorrection = function(){
        function splitAndCapitalize( text ){
            let stringComplete = '';
            text.forEach(word => {
                word = word.toLowerCase();
                let firstletter = word.charAt(0).toUpperCase();
                if (word.length > 1) {
                    word = firstletter + word.substr(1, word.length);
                } else {
                    word = firstletter;
                }
                if(text[0] == word.toUpperCase()){
                    stringComplete = word;
                } else {
                    stringComplete = stringComplete + ' ' + word;
                }
            })
            return stringComplete;
        }

        this.state.menu.promoProducts.forEach(element => {
            let elementMocker
            if(element.NMPRODUTO == undefined){
                elementMocker = element["DSBUTTON"].split(" ");
            } else{
                elementMocker = element["NMPRODUTO"].split(" ");
            }
            let stringComplete = splitAndCapitalize( elementMocker );
            if(element.NMPRODUTO == undefined){
                element["DSBUTTON"] = stringComplete;
            } else {
                element["NMPRODUTO"] = stringComplete;
            }
        });

        this.state.menu.promoGroups.forEach(element => {
            let elementMocker = element["NMGRUPROMOC"].split(" ");
            let stringComplete = splitAndCapitalize( elementMocker );
            element["NMGRUPROMOC"] = stringComplete;
        });

        this.state.menu.products.forEach(element => {
            let elementMocker = element["DSBUTTON"].split(" ");
            let stringComplete = splitAndCapitalize( elementMocker );
            element["DSBUTTON"] = stringComplete;
            if(element.suggestions != undefined){
                for(let suggestionType in element.suggestions){
                    element.suggestions[suggestionType].forEach(( suggestion ) => {
                        let suggestionMocker;
                        if(suggestion.produto != undefined){
                            suggestionMocker = suggestion.produto["DSBUTTON"].split(" ");
                            let stringComplete = splitAndCapitalize( suggestionMocker );
                            suggestion.produto["DSBUTTON"] = stringComplete;
                        } else{
                            suggestionMocker = suggestion.grupo["DSBUTTON"].split(" ");
                            let stringComplete = splitAndCapitalize( suggestionMocker );
                            suggestion.grupo["DSBUTTON"] = stringComplete;
                        }
                    })
                }
            }
        });

        this.state.menu.groups.forEach(element => {
            let elementMocker = element["DSBUTTON"].split(" ");
            let stringComplete = splitAndCapitalize( elementMocker );
            element["DSBUTTON"] = stringComplete;
        });

        this.state.menu.subgroups.forEach(element => {
            elementMocker = element["DSBUTTON"].split(" ");
            stringComplete = splitAndCapitalize( elementMocker );
            element["DSBUTTON"] = stringComplete;
        });
    }

    this.initMenu = function () {
        this.parent.initMenu();
        ApplicationContext.ProdutoRepository.findOne()
            .then(menu => {
                this.state.menu.groups = menu.groups;
                this.state.menu.promoProducts = menu.promoProducts;
                this.state.menu.promoGroups = menu.promoGroups;
                this.state.menu.subgroups = menu.subGroups;
                this.state.menu.products = menu.products;
                this.selectGroup(this.state.menu.groups[0]);
                this.nameCorrection();
                this.mapMinimumPrice()
                this.state.showModalViagem = true;
            })
    }



    this.mapMinimumPrice = function() {
        const { promoGroups, promoProducts, products } = this.state.menu
        promoGroups.forEach(group => {
            const filteredProducts = promoProducts.filter(product => product.CDGRUPROMOC === group.CDGRUPROMOC)
            let minimum = filteredProducts.reduce((prev, current) => {
                if(group.QTPRGRUPROMIN === 0) {
                    return 0
                }

                if(current.PRICE.VRPRECITEM < prev) {
                    return current.PRICE.VRPRECITEM
                } else return prev
            }, 9999)
            group.minimum = minimum
        })

        products.forEach((product, index, array) => {
            if(product.IDTIPOCOMPPROD === '3' && product.IDIMPPRODUTO === '2') {
                const filtered = promoGroups.filter(promoGroup => promoGroup.CDPRODPROMOCAO === product.CDPRODUTO)
                const minimum = filtered.reduce((prev, current) => {
                    return prev + current.minimum
                }, 0)
                product.PRICE.VRPRECITEM = minimum
            }
        })

    }

    const productMapType = {
        NORMAL: 'N',
        COMBO_PARENT: 'CP',
        COMBO_CHILD: 'CC'
    };

    this.filterProducts = product => {
        if (this.state.selectedGroup) {
            return (this.state.selectedGroup.NRPGCONFTELA + this.state.selectedGroup.NRBUTTON == product.NRPGCONFTAUX + product.NRBUTTONAUX) && product.IDTPBUTONAUX == "2" && product.IDSHOWTAA == "S";
        }
    };

    this.filterSubProducts = subgroup => {
        return (product)  => {
            return (subgroup.NRPGCONFTELA + subgroup.NRBUTTON === product.NRPGCONFTAUX + product.NRBUTTONAUX) && (this.state.selectedGroup.NRPGCONFTELA + this.state.selectedGroup.NRBUTTON == product.NRPGCONFTAUX2 + product.NRBUTTONAUX2) 
                    && product.IDTPBUTONAUX == "I"
                    && product.IDSHOWTAA == "S"
        }
    }

    this.filterSubgroups = (subgroup) => {
        if (this.state.selectedGroup) {
            return this.state.selectedGroup.NRPGCONFTELA + this.state.selectedGroup.NRBUTTON === subgroup.NRPGCONFTAUX + subgroup.NRBUTTONAUX
        }
    }

    this.setShowModal = function (modal) {
        this.state.selected = '';
        this.state.showModal = modal
    }

    this.setShowModalViagem = function (modal) {
        // this.state.selectedViagem = '';
        this.state.showModalViagem = modal
    }

    this.setCombo = function (combo) {
        const _product = angular.copy(combo);
        this.state.combo = angular.copy(combo[0]);
    }


    this.setProduto = function (produto) {
        this.state.selectproduct = angular.copy(produto);
    }


    this.checkSuggestions = function (product) {
        const list = this.parent.state.suggestionsMap;
        const suggestions = list[product.CDPRODUTO]
        this.parent.resetAllSelectedSuggestions();
        this.state.selectproduct = angular.copy(product);
        if (suggestions != undefined) {
            this.handleFlavorSuggestion(product);
        } else {
            this.configureProduct(product);
        }
    }

    this.handleFlavorSuggestion = function(product){
        const list = this.parent.state.suggestionsMap;
        const suggestions = list[product.CDPRODUTO]
        this.parent.state.selectedProduct = product;
        if(suggestions != undefined && suggestions.sabor != undefined){
            this.parent.state.showFlavorModal = true;
        } else{
            this.state.repeatSuggestVerify = true;
            this.handleSizeSuggestion(product)
        }
    }

    this.handleSizeSuggestion = function( product ){
        const list = this.parent.state.suggestionsMap;
        const suggestions = list[product.CDPRODUTO]
        if (suggestions != undefined && suggestions.tamanho != undefined) {
            this.parent.state.showSizeModal = true;
        } else{
            this.handleComboProductSuggestion(product);
        }
    }

    this.handleComboProductSuggestion = function( product ){
        const list = this.parent.state.suggestionsMap;
        const suggestions = list[product.CDPRODUTO]
        if (suggestions != undefined && suggestions.combo != undefined) {
            this.parent.state.showComboModal = true;
        } else{
            this.configureProduct(product);
        }
    }

    this.configureProduct = function (product) {
        const _product = angular.copy(product);
        this.parent.state.selectedProduct = _product;
        this.parent.state.produtoSuggestionSelected = []
        vm.changePage('PRODUCT_DETAIL')
        $timeout(() => {
            $rootScope.$broadcast('onLoadProduct', {
                product: _product,
                mode: 'ADD'
            })
        }, 100)
    };


    this.getProduct = function () {
        let produto = this.state.selected == 'product' ? this.state.selectproduct : this.state.combo;
        this.configureProduct(produto);
    };

    this.selectedProduct = function (product) {
        this.state.productselected = [angular.copy(product)];
        this.state.selected = 'product';
    }

    this.selectedCombo = function (product) {
        this.state.productselected = [angular.copy(product)];
        this.state.selected = 'combo';
    }


    this.cancelOrder = function () {
        if (this.state.selectedGroup.NRBUTTON == '00') {
            vm.cancelOrder()
        } else {
            this.selectGroup(this.state.menu.groups[0]);
        }
    }

    this.emptyCart = function () {
        return !CartService.getCart().length
    }

    this.goToCart = function () {
        vm.changePage('CART')
    }

    this.chooseClass = function (accessibility) {
        let returnClass = '';

        if (accessibility) {
            returnClass += 'product-grid-section--accesibility';
        }

        if (this.state.selectedGroup && this.state.selectedGroup.NRBUTTON == '00') {
            returnClass += ' product-grid-section-with-banner';
        }
        return returnClass;
    }


    this.getPromoHeader = function () {
        return vm.state.currentClient
            ? vm.state.currentClient.images.promoHeader
            : null;
    };

    // this.getDefaultCard = function() {
    //     return vm.state.currentClient.images.defaultCard;
    // }
}
