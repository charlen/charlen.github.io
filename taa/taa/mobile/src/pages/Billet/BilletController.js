function BilletController(
    $scope,
    CartService,
    ApplicationContext,
    ScreenService,
    ProductDetailService
) {
    const vm = $scope.parent;
    this.parent = vm
    this.state = {
        filial: null,
        cardNumber: '',
        billets: {},
        loading: false
    };

    this.hasBillets = function () {
        return Object.keys(this.state.billets).length
    } 

    this.initListener = function() {
        ApplicationContext.FiliaisRepo.findOne().then(filial => {
            this.state.filial = filial.CDFILIAL;
            this.state.loading = true
            ScreenService.changeLoadingMessage('Aproxime a comanda da leitora');
            ScreenService.showLoader();
            document.body.addEventListener('keypress', this.handleInput);
        });
    };

    this.cancelListener = function(){
        document.body.removeEventListener("keypress", this.handleInput);
        ScreenService.hideLoader();
        this.state.loading = false
        this.state.cardNumber = '';
        if(!Object.keys(this.state.billets).length) {
            vm.cancelOrder();
        }
    };

    this.handleInput = () => {
        if (event.defaultPrevented) {
            return;
        }
        const key = event.key || event.keyCode;
        if (key === 'Enter' || key === 13 || key === '13') {
            this.state.loading = false
            document.body.removeEventListener('keypress', this.handleInput);
            ApplicationContext.OrderService.loadBilletData(
                this.state.filial,
                this.state.cardNumber
            )
                .then((response) => {
                    if(this.state.billets[this.state.cardNumber]) {
                        ScreenService.hideLoader();
                        this.state.cardNumber = '';
                        return ScreenService.showMessage('Comanda já adicionada')
                    }
                    const products = response.dataset.Products;
                    const tableInfo = response.dataset.BilletData
                    tableInfo.NRLUGARMESA = products[0].NRLUGARMESA
                    vm.state.tableInfo.push(tableInfo)
                    this.state.billets[this.state.cardNumber] = tableInfo
                    this.state.billets[this.state.cardNumber].products = {}
                    products
                        .map(function({
                            QTPRODCOMVEN,
                            VRPRECCOMVEN,
                            CDPRODUTO,
                            NMPRODUTO,
                            VRUNITVENDCL,
                            DSCOMANDA,
                            NRPRODCOMVEN,
                            SGUNIDADE, 
                            IDPESAPROD
                        }) {
                        	const quantidade = 
                        		SGUNIDADE === 'KG' || IDPESAPROD === 'S'  ?
                        		 parseFloat(QTPRODCOMVEN).toFixed(3)
                        		 : parseInt(QTPRODCOMVEN);
                            return {
                                QTPRODCOMVEN: quantidade, 
                                VRPRECITEM: VRPRECCOMVEN,
                                DSCOMANDA: DSCOMANDA,
                                CDPRODUTO: CDPRODUTO,
                                NMPRODUTO: NMPRODUTO,
                                NRPRODCOMVEN: NRPRODCOMVEN,
                                observations: [],
                                ingredients: [],
                                VRDESITVEND: 0,
                                IDTIPOCOMPPROD: "0",
                                IDIMPPRODUTO: "1",
                                VRPRECITEMCL: VRUNITVENDCL,
                                comboItems: []
                            };
                        })
                        .forEach(mapProduct => {
                            this.state.billets[this.state.cardNumber].products[mapProduct.DSCOMANDA + mapProduct.NRPRODCOMVEN + mapProduct.CDPRODUTO] = mapProduct
                            ProductDetailService.setSelectedProduct(mapProduct)
                            CartService.setCartItemState('ADD_PRODUCT_STATE')
                            CartService.addToCart(mapProduct);
                        });
                    ScreenService.hideLoader();
                    this.state.cardNumber = '';
                })
                .catch((err) => {
                    this.state.loading = false
                    ScreenService.showMessage('Comanda não encontrada')
                    .then(() => {
                        this.state.cardNumber = '';
                        if(!Object.keys(this.state.billets).length) {
                            vm.cancelOrder();}
                        })

                    })
            ScreenService.hideLoader();
        } else {
            ScreenService.changeLoadingMessage('Carregando dados do leitor...');
            this.state.cardNumber += event.key;
        }
    };

    this.removeBillet = function (key) {
        ScreenService.confirmMessage('Gostaria de remover a comanda?', '', () => {
            this.removeProductFromCart(key)
            delete this.state.billets[key]
            if(!Object.keys(this.state.billets).length) {
                vm.cancelOrder();
            }
        }, null)
    }

    this.removeProductFromCart = function (key) {
        const productsToRemove = CartService.getCart().filter(function(cartProduct, index){
            return cartProduct.DSCOMANDA.toUpperCase() == key.toUpperCase()
        })

        productsToRemove.forEach( _ => {
            CartService.getCart().splice(
                CartService.getCart().findIndex(cartProduct => cartProduct.DSCOMANDA.toUpperCase() == key.toUpperCase()), 
                1
            )
        })

        const tableInfoIndex = vm.state.tableInfo.findIndex(mesa => mesa.DSCOMANDA === key)
        if(tableInfoIndex) {
        	vm.state.tableInfo.splice(tableInfoIndex, 1)
        }
    }

    this.cancelOrder = function() {
        ScreenService.confirmMessage(
            "Tem certeza que deseja cancelar a compra?",
            "CONFIRMATION",
            () => {
                vm.cancelOrder();
            }
        );
    };

    this.finishOrder = function() {
        vm.changePage("DOCUMENT");
    }

}