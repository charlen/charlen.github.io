function ProductDetailController(
    $scope,
    $rootScope,
    CartService,
    $timeout
) {
    $rootScope.$on("onLoadProduct", (_, { product, mode, qtd = 1}) => {
        this.state.subGroups = this.parent.state.menu.subgroups;
        this.state.products = this.parent.state.menu.products;
        this.state.promoGroups = this.parent.state.menu.promoGroups;
        this.state.promoProducts = this.parent.state.menu.promoProducts;
        this.state.localPromoGroups = this.parent.state.menu.localPromoGroups;
        
        this.state.oldProduct = angular.copy(product);
        this.state.product = product
        this.state.mode = mode;
        this.state.product.QTPRODVEND = qtd;

        if (
            this.state.product.OBSERVATIONS != undefined &&
            this.state.product.OBSERVATIONS.length > 0
        ) {
            this.state.product.OBSERVATIONS.forEach((itm, idx, arr) => {
                if (arr[idx].selected == undefined) {
                    arr[idx].selected = false;
                }
            });
            let observations = this.state.product.OBSERVATIONS.filter(
                (item) => item.IDCONTROLAOBS == "O"
            );
            if (observations.length > 0) {
                this.state.showModalObservations = true;
            }
        }
    });

    const vm = $scope.parent;
    this.parent = vm;
    this.father = $scope.$parent.Ctrl


    this.state = {
        product: null,
        mode: null,
        products: [],
        subGroups: [],
        selectedSuggestedItems: [],
        selectedGroupItems: [],
        showModalRemoverProduto: false,
        showModalObservations: false,
        showModalGoCart: false,
        indexOldProduct: -1,
        showUpdateModal: false,
        showCancelUpdateModal: false,
        isComboSuggested: false,
        cartAwaiting: [],
        idAwaiting: null,
        repeatSuggestVerify: false
    };

    this.populateProducts = function(){
        this.state.subGroups = this.parent.state.menu.subgroups;
        this.state.products = this.parent.state.menu.products;
        this.state.promoGroups = this.parent.state.menu.promoGroups;
        this.state.promoProducts = this.parent.state.menu.promoProducts;
        this.state.localPromoGroups = this.parent.state.menu.localPromoGroups;

        if(this.father != undefined){
            this.state.isComboSuggested = true;
            this.initOnGroupSuggestion()
        }
    }

    this.backMenu = function () {
        if(this.state.mode == "ADD"){
            if(this.state.imagesView == true){
                this.backToPreviousGroup();
            } else{
                vm.changePage("PRODUCT_GRID");
            }
        } else if(this.state.mode == "EDIT"){
            vm.changePage("CART");
        }
        
    };

    this.emptyCart = function () {
        return !CartService.getCart().length;
    }

    this.removeProduct = function (item) {
        const index = CartService.getCart().indexOf(item);
        CartService.getCart().splice(index, 1);
        this.state.showModalGoCart = true;
    };

    this.removeSelectedProductAndCloseModal = function(){
        this.removeSelectedProduct();
        this.state.showModalRemoverProduto = false;
        this.state.showModalObservations = false;
        this.state.showModalGoCart = false;
        this.parent.resetAllSelectedSuggestions();
    }

    this.removeSelectedProduct = function () {
        const item = this.parent.state.selectedProduct;
        const index = CartService.getCart().indexOf(item);
        CartService.getCart().splice(index, 1);
    };

    this.skipSuggestions = function () {
        this.parent.resetAllSelectedSuggestions();
        vm.changePage("PRODUCT_GRID");
    };

    this.checkSuggestionOfProductSuggeted = function(){
        const product = this.state.product;
        const list = this.parent.state.suggestionsMap;
        const suggestions = list[product.CDPRODUTO];

        if(suggestions != undefined){
            if (suggestions.tamanho != undefined) {
                this.parent.state.showSizeModal = true;
            } else if (suggestions.sabor != undefined) {
                this.parent.state.showFlavorModal = true;
            } else {
                // Outro tipo de sugestao cadastrada
            }
        } else{
            // Nao tem nenhum tipo de sugestao
        }
    }

    this.confirmSuggestions = function () {
        if (this.isAnySelected() == true) {
            const cartAwaiting = this.state.cartAwaiting;
            cartAwaiting.forEach(element => {
                CartService.addToCart(element)
            })
            this.parent.resetOnlyShowModals();
            this.state.cartAwaiting = []
            if(this.parent.state.comboSuggestedLine.length > 0){
                const list = this.parent.state.comboSuggestedLine;
                const currentProduct = list[0];
                this.parent.state.comboSuggestedLine.shift();
                $timeout(() => {
                    this.state.product.PRODUCT_TYPE = "N"
                }, 50)
                $timeout(() => {
                    $rootScope.$broadcast('onLoadProduct', {
                        product: currentProduct,
                        mode: 'ADD',
                    })
                }, 100)
            } else{
                this.parent.changePage("PRODUCT_GRID");
            }
        } else{
            console.log("Erro: cliclou em confirmar sugestoes e o array de produtos sugeridos selecionados esta vazio");
        }
    };

    this.isAnySelected = function () {
        if (this.state.selectedSuggestedItems.length > 0) {
            return true;
        } else {
            return false;
        }
    };

    this.goToCart = function () {
        vm.changePage("CART");
    };

    this.nextItemSuggested = function () {
        const list = this.parent.state.comboSuggestedLine;
        const currentProduct = list[0];
        this.parent.state.comboSuggestedLine.shift();

        vm.changePage('PRODUCT_DETAIL')
        $timeout(() => {
            this.state.product.PRODUCT_TYPE = "N"
        }, 50)
        $timeout(() => {
            $rootScope.$broadcast('onLoadProduct', {
                product: currentProduct,
                mode: 'ADD',
            })
        }, 100)
    };

    this.addItem = function () {
        const product = this.state.product;
        const id = Math.floor(Math.random()*(50000))
        product["ID"] = id;
        CartService.addToCart(product);

        if(this.parent.state.comboSuggestedLine.length > 0){
            this.nextItemSuggested();
        } else{
            const list = this.parent.state.suggestionsMap;
            const suggestions = list[product.CDPRODUTO];
            if (suggestions != undefined) {
                this.parent.state.selectedProduct = product;
                if (suggestions.produto != undefined) {
                    vm.state.showProductModal = true;
                } else if (suggestions.grupo != undefined) {
                    vm.state.showGroupModal = true;
                } else {
                    this.state.showModalGoCart = true;
                }
            } else{
                this.state.showModalGoCart = true;
            }
        }
    };

    this.finalizeEditItem = function(){
        const item = this.state.product;
        const cart = CartService.getCart();
        this.parent.state.selectedProduct = item;
        const indexOldItem = cart.findIndex(element => this.state.oldProduct.ID === element.ID)
        CartService.updateItem(item, indexOldItem);
        this.state.showUpdateModal = true;
    }

    this.setShowModalRemoverProduto = function (option) {
        this.state.showModalRemoverProduto = option;
    };

    this.changepage = function () {
        if(this.parent.state.nextPage == "CART"){
            vm.changePage("CART");
        } else {
            vm.changePage("PRODUCT_GRID");
        }
    };

    this.setShowCancelUpdateModal = function( option ){
        this.state.showCancelUpdateModal = option;
    }

    this.handleCancelUpdate = function(){
        this.parent.selectedProduct = this.state.oldProduct;
        this.state.product = this.state.oldProduct;
        this.changePage();
    }

    this.modalPreCart = function(){
        this.parent.state.nextPage = "CART";
        if(this.state.mode === "ADD"){
            this.setShowModalRemoverProduto(true);
        } else if(this.state.mode === "EDIT"){
            this.setShowCancelUpdateModal(true);
        }
    }

    this.confirmSuggestionGroup = function(){
        this.parent.resetOnlyShowModals();;
        this.parent.goToGroupSuggestion();
    }

    this.initOnGroupSuggestion = function(){
        this.state.oldProduct = this.father.father.state.currentCombo;
        this.state.product = this.father.father.state.currentCombo;
        this.state.mode = 'ADD';
        this.state.product.QTPRODVEND = 1;

        if (
            this.state.product.OBSERVATIONS != undefined &&
            this.state.product.OBSERVATIONS.length > 0
        ) {
            this.state.product.OBSERVATIONS.forEach((itm, idx, arr) => {
                if (arr[idx].selected == undefined) {
                    arr[idx].selected = false;
                }
            });
            let observations = this.state.product.OBSERVATIONS.filter(
                (item) => item.IDCONTROLAOBS == "O"
            );
            if (observations.length > 0) {
                this.state.showModalObservations = true;
            }
        }
    }

    // Insert of the suggestion of product suggested on cartAwait
    this.configureProduct = function(arr){
        arr.IDFORSELECTION = this.state.idAwaiting;
        if(arr.IDTIPOCOMPPROD != 3){
            arr.QTPRODVEND = 1;
            this.state.cartAwaiting.push(arr);
        } else{
            this.parent.state.comboSuggestedLine.push(arr)
        }

    }



    // this.getDefaultProductImage = function() {
    //     return vm.state.currentClient.images.defaultCard;
    // }


    this.handleFlavorSuggestion = function(product){
        const list = this.parent.state.suggestionsMap;
        const suggestions = list[product.CDPRODUTO]
        this.parent.state.selectedProduct = product;
        if(suggestions != undefined && suggestions.sabor != undefined){
            this.parent.state.showFlavorModal = true;
        } else{
            this.state.repeatSuggestVerify = true;
            this.handleSizeSuggestion(product)
        }
    }

    this.handleSizeSuggestion = function( product ){
        const list = this.parent.state.suggestionsMap;
        const suggestions = list[product.CDPRODUTO]
        if (suggestions != undefined && suggestions.tamanho != undefined) {

            this.parent.state.showSizeModal = true;
        } else{
            this.insertOnCartAwait(product);
        }
    }

    this.insertOnCartAwait = function (product) {
        product.IDFORSELECTION = this.state.idAwaiting;
        if(product.IDTIPOCOMPPROD != 3){
            product.QTPRODVEND = 1;
            this.state.cartAwaiting.push(product);
        } else{
            this.parent.state.comboSuggestedLine.push(product)
        }
    }    
}
