function ProductComboController($scope, ScreenService) {
    
    const COMBO_MODE = {
        ADD: 'ADD',
        EDIT: 'EDIT'
    }

    const PROMO_GROUP_VIEW = {
        LIST: '1',
        IMAGE: '2',
        GRID: '3'
    }

    const COMBO_VIEW = {
        GRID_LIST: 'GRID_LIST',
        GRID_IMAGE: 'GRID_IMAGE',
    }

    const vm = $scope.parent;
    this.main = vm;
    this.parent = $scope.$parent.Ctrl
    
    this.state = {
        product: null,
        mode: null,
        promoGroups: [],
        promoProducts: [],
        selectedPromogroup: null,
        imagePromoGroups: [],
        mutexKeys: [],
        selectedMutex: null,
        view: COMBO_VIEW.GRID_LIST,
        stackKeys: [],
        index: 0
    }

    this.loadProduct = function () {
        this.state.product = this.parent.state.product
        this.state.mode = this.parent.state.mode
        
        if(this.state.mode === COMBO_MODE.ADD) {
            this.state.product.comboItems = []
            this.initCombo()
        }
        if(this.state.mode === COMBO_MODE.EDIT) {
            this.initCombo()
        }

        this.state.view = COMBO_VIEW.GRID_LIST
    }

    this.canIncreaseQuantity = function (product, promoGroup) {
        const count = this.state.product.comboItems
            .filter(productFilter => productFilter.CDGRUPROMOC === promoGroup.CDGRUPROMOC && productFilter.CDPRODUTO !== product.CDPRODUTO )
            .map(product => product.QTPRODVEND)
            .reduce((initial, current) => {
                return initial + current
            }, 0)

        return (product.QTPRODVEND + 1) + count <= promoGroup.QTPRGRUPPROMOC
    }
    this.filterPromoGroups = function (promoGroups, localPromoGroups) {
        const useLocal = localPromoGroups.some(promoGroup => promoGroup.CDPRODPROMOCAO === this.state.product.CDIDENTBUTON)
        let objMutex = {}
        if(useLocal) {
            this.state.promoGroups = localPromoGroups
                .filter(group =>
                group.CDPRODPROMOCAO === this.state.product.CDIDENTBUTON
                && group.IDMODOEXIBETAA != PROMO_GROUP_VIEW.IMAGE)
        } else {
            this.state.promoGroups = promoGroups
            .filter(group =>
                group.CDPRODPROMOCAO === this.state.product.CDIDENTBUTON
                && group.IDMODOEXIBETAA != PROMO_GROUP_VIEW.IMAGE )
        }

        // this.state.promoGroups.forEach((group) => {
        //     if(!!group.CDGRUPMUTEX) {
        //         if(!objMutex[group.CDGRUPMUTEX]) {
        //             objMutex[group.CDGRUPMUTEX] = objMutex[group.CDGRUPMUTEX] || []
        //         }
        //         objMutex[group.CDGRUPMUTEX].push(group)
        //     }
        // })
        // const keysLength = Object.keys(objMutex).length
        // if(keysLength > 0) {
        //     Object.keys(objMutex)
        //         .forEach(key => {
        //             this.state.promoGroups.push(_buildSyntheticPromoGroup(objMutex[key]))
        //         })
        // }

    }

    // const _buildSyntheticPromoGroup = function (arr) {
    //     const title = arr.map(elem => elem.NMGRUPROMOC).join(' Ou ')
    //     return {
    //         'title': title,
    //         'synthetic': true
    //     }
        
    // }

    this.filterImageGroups = function (promoGroups, localPromoGroups) {
        const useLocal = localPromoGroups.some(promoGroup => promoGroup.CDPRODPROMOCAO === this.state.product.CDIDENTBUTON)
        if(useLocal) {
            this.state.imagePromoGroups = localPromoGroups
            .filter(group =>
                group.CDPRODPROMOCAO === this.state.product.CDIDENTBUTON && group.IDMODOEXIBETAA == PROMO_GROUP_VIEW.IMAGE)
        } else {
            this.state.imagePromoGroups = promoGroups
            .filter(group =>
                group.CDPRODPROMOCAO === this.state.product.CDIDENTBUTON && group.IDMODOEXIBETAA == PROMO_GROUP_VIEW.IMAGE)

        }
    }

    function getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min)) + min;
      }

    this.filterMutexKeys = function () {
        let randomInt = 0
        const {imagePromoGroups} = this.state
        imagePromoGroups.forEach((group, index, array) => {
            randomInt = getRandomInt(1, 1000)
            if(!group.CDGRUPMUTEX) {
                array[index].CDGRUPMUTEX = randomInt
            }
        })

        this.state.mutexKeys = this.state.imagePromoGroups
            .map(promoGroup =>  promoGroup.CDGRUPMUTEX)
            .filter((item, index, arr) => arr.indexOf(item) === index);
            
    }

    this.initCombo = function() {
            //const { promoGroups, promoProducts } = data            
        const promoGroups = this.parent.state.promoGroups;
        const promoProducts  = this.parent.state.promoProducts;
        const localPromoGroups  = this.parent.state.localPromoGroups;
        this.filterPromoGroups(promoGroups, localPromoGroups)
        this.filterImageGroups(promoGroups, localPromoGroups)
        this.filterMutexKeys()
        this.buildPromogroup(promoProducts)
        
        this.state.promoGroups.forEach((promoGroup) => {
            this.checkPromoGroupFinished(promoGroup)
            this.buildCompositionCombo(promoGroup)
        })

        if(this.state.mode === COMBO_MODE.ADD) {
            this.checkProdPreselection()
            const firstNotFinished = this.state.promoGroups.findIndex(promoGroup => !promoGroup.isFinished)
            
            if(firstNotFinished >= 0) {
                this.selectPromogroup(this.state.promoGroups[firstNotFinished])
            }
        }

        if(this.state.mode === COMBO_MODE.EDIT) {
            this.bindComboItems()
        }

        if(this.state.mode === COMBO_MODE.EDIT) {
            this.state.imagePromoGroups.forEach(promoGroup => {
                this.checkPromoGroupFinished(promoGroup)
                this.buildCompositionCombo(promoGroup)
            })
        }
    }

    this.bindComboItems = function () {
        const {promoProducts} = this.state
        const {comboItems} = this.state.product
        comboItems.forEach((item) => {
            const index = promoProducts.findIndex(product => product.CDPRODUTO === item.CDPRODUTO)
            if(index >= 0) {
                promoProducts[index] = item
            }
        })
    }

    this.increaseItemCount = function (product, promoGroup) {
        if(promoGroup.mainSelected) {
            return
        }
        const canIncrease = this.canIncreaseQuantity(product, promoGroup)
        if(!canIncrease) {
            ScreenService.showMessage(`Quantidade máxima limitada de ${parseInt(this.state.selectedPromogroup.QTPRGRUPPROMOC)}`)
        } else {
            if(product.QTPRODVEND === 0){
                this.onClickProduct(product, promoGroup, false)
            } else {
                product.QTPRODVEND++
            }
        }
        this.checkPromoGroupFinished(promoGroup)
        this.buildCompositionCombo(promoGroup)

        return canIncrease
    }

    this.decreaseItemCount = function (product, promoGroup) {

        if(product.QTPRODVEND === 1 && product.IDOBRPRODSELEC === 'S') {
            return
        }
        
        if (product.QTPRODVEND === 0) {
            return
        } else {
            product.QTPRODVEND--;
            if(product.QTPRODVEND === 0) {
                this.removeFromCombo(product)
            }
        }
        this.checkPromoGroupFinished(promoGroup)
        this.buildCompositionCombo(promoGroup)

    
    };

    this.removeFromCombo = function (product) {
        const indexToRemove = this.state.product.comboItems.findIndex(item => item.CDGRUPROMOC === product.CDGRUPROMOC && item.CDPRODUTO === product.CDPRODUTO)
        this.state.product.comboItems.splice(indexToRemove, 1);
    }

    this.buildPromogroup = function (promoProducts) {
        this.state.promoGroups.forEach((promoGroup, key, arr) => {
            if(!!promoGroup.synthetic) {
                return
            }
            const filterProducts = promoProducts.filter(product => promoGroup.CDGRUPROMOC === product.CDGRUPROMOC)
            //const filterProducts = promoProducts.filter(product => promoGroup.CDGRUPROMOC === product.CDGRUPROMOC && promoGroup.CDPRODPROMOCAO === product.CDPRODPROMOCAO)
            this.state.promoProducts = [...this.state.promoProducts, ...filterProducts]
            const title = this.buildHeaderTitle(promoGroup)
            arr[key].title = title
            arr[key].QTPRGRUPROMIN = promoGroup.QTPRGRUPROMIN
            arr[key].QTPRGRUPPROMOC = promoGroup.QTPRGRUPPROMOC
            const hasMainProduct = filterProducts.some(product => product.IDPRINCPROD === 'S')
            arr[key].hasMainProduct = hasMainProduct
            if(hasMainProduct) {
                this.buildMainProductsHeader(filterProducts, promoGroup)
            }
        })
        
        this.state.imagePromoGroups.forEach((promoGroup, key, arr) => {
            const filterProducts = promoProducts.filter(product => promoGroup.CDGRUPROMOC === product.CDGRUPROMOC)
            //const filterProducts = promoProducts.filter(product => promoGroup.CDGRUPROMOC === product.CDGRUPROMOC && promoGroup.CDPRODPROMOCAO === product.CDPRODPROMOCAO)
            this.state.promoProducts = [...this.state.promoProducts, ...filterProducts]
            const title = this.buildHeaderTitle(promoGroup)
            arr[key].title = title
            
            arr[key].QTPRGRUPROMIN = parseInt(promoGroup.QTPRGRUPROMIN)
            arr[key].QTPRGRUPPROMOC = parseInt(promoGroup.QTPRGRUPPROMOC)
        })

    }

    this.buildMainProductsHeader = function (filterProducts, promoGroup) {
        const mainProductsDesc = filterProducts.filter(product => product.IDPRINCPROD === 'S')
        .map(product => `${product.NMPRODUTO}`)
        .join(', ')

        promoGroup.mainProductsDesc = mainProductsDesc
    }

    this.checkProdPreselection = function () {
        const {promoProducts, promoGroups} = this.state

        const preSelectedProducts = promoProducts.filter(product => product.IDPRODPRESELEC === 'S')
        if(preSelectedProducts.length) {
            preSelectedProducts.forEach((product) => {
                const promoGroup = promoGroups.find(promoGroup => promoGroup.CDGRUPROMOC === product.CDGRUPROMOC)
                this.onClickProduct(product, promoGroup, true)
            })
        }
    }

    this.buildHeaderTitle = function(promoGroup) {
        if(!promoGroup) {
            return ''
        }
        const min = parseInt(promoGroup.QTPRGRUPROMIN)
        const max = parseInt(promoGroup.QTPRGRUPPROMOC)
        let title = ''
        if(min === 0) {
            title = `Escolha até ${max} ${promoGroup.NMGRUPROMOC}`
        }
        if(min > 0 && min < max) {
            title = `Escolha de ${min} até ${max} ${promoGroup.NMGRUPROMOC}`
        }
        if(min === max) {
            title = `Escolha ${max} ${promoGroup.NMGRUPROMOC}`
        }
        return title
    }

    this.backMenu = function () {
        vm.changePage('PRODUCT_GRID')
    }

    this.selectPromogroup = function(promoGroup) {

        $scope.$broadcast('onSelectPromoGroup');
        if(!!this.state.selectedPromogroup && (promoGroup.CDGRUPROMOC === this.state.selectedPromogroup.CDGRUPROMOC)) {
            return
        } else {
            this.state.selectedPromogroup = promoGroup
        }
    }

    this.filterPromoProducts = product => {
        if(this.state.selectedPromogroup) {
            return this.state.selectedPromogroup.CDGRUPROMOC === product.CDGRUPROMOC
        } else return null
    }

    this.onClickProduct = function (product, promoGroup, preSelection) {
        if(promoGroup.blocked) {
            console.log('blocked')
            return 
        }
        if(promoGroup.mainSelected) {
            console.log('mainSelected')
            return
        }
        if(product.IDOBRPRODSELEC === 'S' && !preSelection) {
            return
        }
        
        if(this.state.view == COMBO_VIEW.GRID_IMAGE) {
            const isProductInsideCombo = this.inserted(product)
            if(isProductInsideCombo) {
                this.decreaseItemCount(product, promoGroup)
            } else {
                if(promoGroup.QTPRGRUPPROMOC == 1) {
                    const indexToReplace = this.state.product.comboItems.findIndex(item => item.CDGRUPROMOC === product.CDGRUPROMOC)
                    product.QTPRODVEND = 1;
                    if(indexToReplace >= 0) {
                        this.state.product.comboItems[indexToReplace] = product
                    } else {
                        const id = Math.floor(Math.random()*(50000))
                        product.ID = id
                        this.state.product.comboItems.push(product)
                    }
                } else if(promoGroup.QTPRGRUPPROMOC > 1 && this.canIncreaseQuantity(product, promoGroup)) {
                    product.QTPRODVEND++;
                    const id = Math.floor(Math.random()*(50000))
                    product.ID = id
                    this.state.product.comboItems.push(product)
                }
            }
        } else {
            if(promoGroup.IDMODOEXIBETAA === PROMO_GROUP_VIEW.LIST) {
                if(promoGroup.QTPRGRUPPROMOC == 1) {
                    const indexToReplace = this.state.product.comboItems.findIndex(item => item.CDGRUPROMOC === product.CDGRUPROMOC)
                    product.QTPRODVEND = 1;
                    if(indexToReplace >= 0) {
                        this.state.product.comboItems[indexToReplace] = product
                    } else {
                        const id = Math.floor(Math.random()*(50000))
                        product.ID = id
                        this.state.product.comboItems.push(product)
                    }
                } else if(promoGroup.QTPRGRUPPROMOC > 1) {
                    const isProductInsideCombo = this.inserted(product)
                    if(isProductInsideCombo) {
                        this.decreaseItemCount(product, promoGroup)
                    } else if(this.canIncreaseQuantity(product, promoGroup)) {
                        product.QTPRODVEND++;
                        const id = Math.floor(Math.random()*(50000))
                        product.ID = id
                        this.state.product.comboItems.push(product)
                    }
                }
            } else if(promoGroup.IDMODOEXIBETAA === PROMO_GROUP_VIEW.GRID) {
                if(promoGroup.QTPRGRUPPROMOC == 1) {
                    const indexToReplace = this.state.product.comboItems.findIndex(item => item.CDGRUPROMOC === product.CDGRUPROMOC)
                    product.QTPRODVEND = 1;
                    if(indexToReplace >= 0) {
                        this.state.product.comboItems[indexToReplace] = product
                    } else {
                        const id = Math.floor(Math.random()*(50000))
                        product.ID = id
                        this.state.product.comboItems.push(product)
                    }
                } else if(promoGroup.QTPRGRUPPROMOC > 1) {
                    const isProductInsideCombo = this.inserted(product)
                    if(isProductInsideCombo) {
                        product.QTPRODVEND++;
                    } else if(this.canIncreaseQuantity(product, promoGroup)) {
                        product.QTPRODVEND++;
                        const id = Math.floor(Math.random()*(50000))
                        product.ID = id
                        this.state.product.comboItems.push(product)
                    }
                }
            }
        }
        this.buildCompositionCombo(promoGroup)
        this.checkPromoGroupFinished(promoGroup)
    }

    this.buildCompositionCombo = function (promoGroup) {
        const { comboItems } = this.state.product
        const filteredProducts = comboItems
            .filter(product => product.CDGRUPROMOC === promoGroup.CDGRUPROMOC)
            .map(product => `${product.QTPRODVEND} x ${product.NMPRODUTO}`)
            .join(', ')
        
        promoGroup.composition = filteredProducts

    }

    this.handleImagePromoGroups = function (selectedPromogroup) {
        let { imagePromoGroups, selectedMutex } = this.state;
        if(!selectedMutex) {
            return 
        }
        const currentCount = this.getCountGroupProducts(selectedPromogroup)
        const updatedimagePromoGroups = imagePromoGroups.map((promoGroup) => {
            if(promoGroup.CDGRUPROMOC === selectedPromogroup.CDGRUPROMOC) {
                const isFinished = this.checkPromoGroupFinished(selectedPromogroup)
                return {
                    ...promoGroup,
                    blocked: false,
                    isFinished
                }
            } else {
                return {
                    ...promoGroup,
                    blocked: !!currentCount && (selectedMutex === promoGroup.CDGRUPMUTEX),
                    isFinished: selectedMutex === promoGroup.CDGRUPMUTEX ? true : promoGroup.isFinished
                }
            }
        })

        this.state.imagePromoGroups = updatedimagePromoGroups
    }



    this.removeProductsFromMutexGroups = function () {
        let { imagePromoGroups } = this.state
        const mapPromogroups = imagePromoGroups
        .filter((promoGroup) => promoGroup.CDGRUPMUTEX === this.state.selectedMutex)
        .map((promoGroup) => {
            return promoGroup.CDGRUPROMOC
        })
    }

    this.inserted = function (product) {
        const index = this.state.product.comboItems.findIndex(item => item.CDGRUPROMOC === product.CDGRUPROMOC && item.CDPRODUTO === product.CDPRODUTO)
        return index >= 0
    }

    this.getCountGroupProducts = function(promoGroup) {
        let groupProducts = this.state.product.comboItems.filter(item => item.CDGRUPROMOC === promoGroup.CDGRUPROMOC);
        let totalQuantity = 0;
        groupProducts.forEach(function(product) {
            totalQuantity += product.QTPRODVEND;
        });
        return totalQuantity;
    }

    this.checkPromoGroupFinished = function (promoGroup) {
        let isFinished = false
        if(promoGroup.isBlocked) {
            isFinished = true
            promoGroup.isFinished = true
        } else {
            const total = this.getCountGroupProducts(promoGroup)
            const min = promoGroup.QTPRGRUPROMIN
            const max = promoGroup.QTPRGRUPPROMOC
            if(min === 0) {
                isFinished = true
            }
            if(min > 0 && min < max) {
                isFinished = total >= min
            }
            if(min === max) {
                isFinished = total === max
            }
            promoGroup.isFinished = isFinished
        }
        return isFinished

    }

    this.finishCombo = function () {
        if(this.state.mode == COMBO_MODE.ADD) {
            console.log(this.parent.state.isComboSuggested)
            if(this.parent.state.isComboSuggested == false){
                this.parent.addItem()
            } else{
                this.parent.father.father.state.currentCombo = this.parent.state.product;
                this.parent.state.isComboSuggested = false;
                this.parent.father.father.insertComboOnCart();
                
            }
        }
        if(this.state.mode == COMBO_MODE.EDIT) {
            this.parent.finalizeEditItem()
        }
    }

    this.nextStep = function () {
        this.state.stackKeys.push(this.state.selectedMutex);
        const selectedMutex = this.state.mutexKeys.shift();
        this.state.selectedMutex = selectedMutex;

        const selectedPromogroup = this.state.imagePromoGroups.find(promoGroup => promoGroup.CDGRUPMUTEX === selectedMutex)

        this.selectPromogroup(selectedPromogroup)

        this.handleImagePromoGroups(selectedPromogroup)
        this.state.view = COMBO_VIEW.GRID_IMAGE
    }

    this.back = function () {
        const {stackKeys} = this.state
        if(!stackKeys.length) {
            if(this.state.mode == "ADD"){
                if(this.parent.state.isComboSuggested == true){
                    this.parent.father.father.state.showCombo = false;
                } else{
                    vm.changePage("PRODUCT_GRID");
                }
            } else if(this.state.mode == "EDIT"){
                vm.changePage("CART");
            }
        } else {
            this.state.mutexKeys.push(this.state.selectedMutex);
            const selectedMutex = this.state.stackKeys.pop();
            this.state.selectedMutex = selectedMutex;
            if(!selectedMutex) {
                this.state.view = COMBO_VIEW.GRID_LIST
            } else {
                const selectedPromogroup = this.state.imagePromoGroups.find(promoGroup => promoGroup.CDGRUPMUTEX === selectedMutex)
                this.selectPromogroup(selectedPromogroup)
                this.handleImagePromoGroups(selectedPromogroup)
            }
        }
    }

    this.nextPromogroup = function (index) {
        const {promoGroups} = this.state
        const orderedPromogroups = promoGroups.sort((a, b) => a.NRORDPROMOGROUP - b.NRORDPROMOGROUP)
        const promoGroup  = orderedPromogroups[index + 1]
        this.selectPromogroup(promoGroup)
    }

    this.previousPromogroup = function (index) {
        const {promoGroups} = this.state
        const orderedPromogroups = promoGroups.sort((a, b) => a.NRORDPROMOGROUP - b.NRORDPROMOGROUP)
        const promoGroup  = orderedPromogroups[index - 1]
        this.selectPromogroup(promoGroup)
    }

    this.selectMainProducts = function (promoGroup) {
        if(promoGroup.mainSelected) {
            const { comboItems } = this.state.product
            const filteredProducts = comboItems.filter(product => product.CDGRUPROMOC === promoGroup.CDGRUPROMOC)
            if(filteredProducts.length) {
                filteredProducts.forEach(product => {
                    this.decreaseItemCount(product, promoGroup)
                })
            }
            promoGroup.mainSelected = false
        } else {
            const { promoProducts } = this.state
            const mainProducts = promoProducts
                .filter(product => promoGroup.CDGRUPROMOC === product.CDGRUPROMOC)
                .filter(product => product.IDPRINCPROD === 'S')
            if(mainProducts.length) {
                mainProducts.forEach((product) => {
                    this.increaseItemCount(product, promoGroup, false)
                })
                promoGroup.mainSelected = true
            }
        }
        this.buildCompositionCombo(promoGroup)

    }

    this.promoGroupHasMainProduct = function (promoGroup) {
        return promoGroup.hasMainProduct
    }

    this.isGridView = function(){
        if(this.parent.state.imagesView === true){
            return true;
        } else{
            return false;
        }
    }

}