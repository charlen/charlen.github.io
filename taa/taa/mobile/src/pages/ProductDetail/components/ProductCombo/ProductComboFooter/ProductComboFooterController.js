function ProductComboFooterController($scope) {
    this.parent = $scope.$parent.Ctrl;
    this.main = this.parent.main

    this.state =  {
        stepNotFinished: false,
        promoGroupsNotFinished: false,
        currentstepNotFinished: false
    }
    
    this.comboNotFinished = function() {
        const {promoGroups, imagePromoGroups} = this.parent.state
        this.state.stepNotFinished = imagePromoGroups.some(promoGroup => {
            if(!promoGroup.isFinished) {
            }
            return !promoGroup.isFinished
        })
        this.state.promoGroupsNotFinished = promoGroups.some(promoGroup => {
            if(!promoGroup.isFinished) {
            }
            return !promoGroup.isFinished
        })
        return this.state.stepNotFinished || this.state.promoGroupsNotFinished
    }
    
    this.enableNextStep = function () {
        const {promoGroups, selectedMutex, imagePromoGroups} = this.parent.state
        if(!selectedMutex) {
            return this.state.promoGroupsNotFinished = promoGroups.some(promoGroup => !promoGroup.isFinished)
        } else {
            this.state.currentstepNotFinished = imagePromoGroups.some(promoGroup => !promoGroup.isFinished && promoGroup.CDGRUPMUTEX === selectedMutex)
            return this.state.currentstepNotFinished
        }

    }

    this.showNext = function() {
        const { mutexKeys } = this.parent.state
        return mutexKeys.length > 0
    }
}