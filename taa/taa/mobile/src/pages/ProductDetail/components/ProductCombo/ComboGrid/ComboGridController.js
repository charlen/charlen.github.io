function ComboGridController($scope) {
    //ref to ProductComboController methods
    this.parent = $scope.$parent.Ctrl
    this.main = $scope.parent
}