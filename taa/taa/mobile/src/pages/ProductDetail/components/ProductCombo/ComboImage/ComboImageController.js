function ComboImageController($scope) {
    //ref to ProductComboController methods
    this.parent = $scope.$parent.Ctrl
    this.main = this.parent.main

    this.filterProducts = function (promoGroup) {
        return function(product) {
            return promoGroup.CDGRUPROMOC === product.CDGRUPROMOC
        }
    }

    this.selectProduct = function (product, promoGroup) {
        if(promoGroup.blocked) {
            return
        }
        this.parent.onClickProduct(product, promoGroup, false)
        if(this.parent.state.selectedMutex) {
            this.parent.handleImagePromoGroups(promoGroup)
        }
    }
}