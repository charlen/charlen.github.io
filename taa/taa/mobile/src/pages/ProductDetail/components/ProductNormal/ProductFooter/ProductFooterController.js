function ProductFooterController($scope) {
    this.parent = $scope.$parent.Ctrl
    this.main = this.parent.main
}