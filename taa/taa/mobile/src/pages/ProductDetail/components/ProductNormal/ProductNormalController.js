function ProductNormalController ($scope, $rootScope, CartService) {

    const vm = $scope.parent;
    this.main = vm;
    this.parent = $scope.$parent.Ctrl;


    this.state = {
        product: null,
        productsSelecteds: [],
        confirmedProducts: []
    }

    this.increaseItemCount = function () {
        this.parent.state.product.QTPRODVEND++;
    }

    this.decreaseItemCount = function () {
        if (this.parent.state.product.QTPRODVEND > 0) {
            if (this.parent.state.product.QTPRODVEND === 1) {
                if(this.parent.state.mode != "EDIT"){
                    this.main.state.nextPage = "PRODUCT_GRID";
                    this.parent.state.showModalRemoverProduto = true;
                }
            } else{
                this.parent.state.product.QTPRODVEND--;
            }
        }
    };

    this.isGridView = function(){
        if(this.parent.state.imagesView === true){
            return true;
        } else{
            return false;
        }
    }


    this.isEmpitySelections = function(){
        if(this.state.productsSelecteds.length === 0){
            return true;
        } else{
            return false;
        }
    };

    this.confirmProducts = function(){
        this.state.confirmedProducts.forEach(product => {
            product.QTPRODVEND = 1;
            CartService.addToCart(product);
        })
        if(this.main.state.grupoSuggestionSelected.length === 1){
            this.main.changePage("CART");
        }
    }

    this.selectObservation = function (observation) {
        this.parent.state.product.OBSERVATIONS.forEach(function (productObservation) {
            if (
                observation.CDGRPOCOR == productObservation.CDGRPOCOR &&
                observation.CDOCORR == productObservation.CDOCORR
            ) {
                productObservation.selected = !productObservation.selected
            }
        });
    };

    this.addItem = function () {
        this.parent.addItem()
    }

    this.finalizeEditItem = function(){
        this.parent.finalizeEditItem();
    }
}