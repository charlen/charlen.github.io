/* eslint-disable no-unreachable */
function CartController(
    $scope,
    CartService,
    ScreenService,
    ComboService,
    $timeout,
    ApplicationContext,
    ProductGridService,
    $rootScope,
) {
    const vm = $scope.parent
    this.parent = vm
    var self = this;
    this.state = {
        products: [],
        payments: [],
        showModalRemoveProduct: false,
        currentProduct: []
    }

    this.setShowModalRemoverProduto = function (option) {
        this.state.showModalRemoverProduto = option;
    }

    this.loadProducts = function () {
        const cart = CartService.getCart()
        this.state.products = cart
        this.loadPayments()
    }

    this.filterObservation = function (observation) {
        return observation.selected === true;
    };

    this.filterIngredient = function (ingredient) {
        return ingredient.QTPRODVEND > 0;
    };

    this.back = function () {
        if (vm.state.orderMethod === "billet") {
            this.cancelOrder();
          } else {
            vm.changePage("PRODUCT_GRID");
            CartService.unBlockCart();
            CartService.setCartItemState('ADD_PRODUCT_STATE');
          }
    }

    this.next = function () {
        vm.changePage('DOCUMENT')
    }

    this.editProduct = function (item) {
        let _product = angular.copy(item);
        this.parent.state.selectedProduct = item;
        this.parent.resetAllSelectedSuggestions()
        vm.changePage('PRODUCT_DETAIL')
        $timeout(() => {
            $rootScope.$broadcast('onLoadProduct', {
                product: _product,
                mode: 'EDIT',
                qtd: _product.QTPRODVEND
            })
        }, 100)
    }

    this.callRemoveProduct =function(item){
        this.state.currentProduct = item;
        this.setShowModalRemoverProduto(true);
    }

    this.removeProduct = function (item) {
        const index = CartService.getCart().indexOf(item);
        CartService.getCart().splice(index, 1);
        if (!CartService.getCart().length) {
            vm.changePage('PRODUCT_GRID')
        }
        this.setShowModalRemoverProduto(false);
    }

    //Payment Methods
    this.cancelOrder = function () {
        ScreenService.confirmMessage(
            "Tem certeza que deseja cancelar a compra? <p>(Todos os itens serão perdidos)<\/p>",
            "CONFIRMATION",
            _confirmCancel
        );
    };

    this.increaseItemCount = function (item) {
        if (ComboService.isComboMode()) {
            const productQtty = item.QTPRODVEND;
            if (productQtty <= ComboService.getRemainingGroupQuantity(item.wizardCartKey)) {
                item.QTPRODVEND++;
            }
        } else {
            item.QTPRODVEND++;
        }
    }

    this.decreaseItemCount = function (item) {
        if (item.QTPRODVEND > 0) {
            if (item.QTPRODVEND === 1) {
                self.callRemoveProduct(item);
            } else {
                item.QTPRODVEND--;
            }
        }
    };

    this.cancelRecharge = function () {
        ScreenService.confirmMessage(
            "Confirma o cancelamento da recarga?",
            "CONFIRMATION",
            _confirmCancel
        );
    };

    const _confirmCancel = function () {
        vm.resetState();
        CartService.clearCart();
        vm.cancelOrder();
    };

    this.showButtonOnMethod = (method) => vm.state.orderMethod === method;

    this.getOrderCode = function () {
        return vm.state.orderCode;
    };

    this.loadPayments = function () {
        ApplicationContext.RecebimentoRepository.findAll()
            .then((payments) => {
                const taaPayments = [];
                payments.filter((payment) => payment.IDMOSTRARECE == "S" &&
                    (payment.IDTIPORECE == "1" || payment.IDTIPORECE == "2" ||
                        (vm.state.orderMethod !== "recharge" && vm.state.consumerSaleParams.hasOwnProperty('CDIDCONSUMID') && (payment.IDTIPORECE == "9" || payment.IDTIPORECE == "A"))))
                    .forEach((payment) => {
                        switch (payment.IDTIPORECE) {
                            case "1":
                                payment.image =
                                    vm.state.currentClient.images.creditCard;
                                break;
                            case "2":
                            case "9":
                                payment.image =
                                    vm.state.currentClient.images.debitCard;
                                break;
                            case "A":
                                payment.image =
                                    vm.state.currentClient.images.consumerCard;
                                break;
                            default:
                                payment.image =
                                    vm.state.currentClient.images.defaultCard;
                                break;
                        }
                        taaPayments.push(payment);
                    });

                this.state.payments = taaPayments;
            });
    };

    this.previousOrder = function () {
        vm.changePage("DOCUMENT");
        CartService.unBlockCart();
        CartService.setCartItemState('ADD_PRODUCT_STATE');
    };

    this.getFinalMessage = function () {
        return vm.state.currentClient.finalMessage;
    };

    this.savePagerCode = function () {
        if ($scope.keyPad.valor.length !== 0) {
            $scope.handleBarcodeRead($scope.keyPad.valor);
        } else {
            ScreenService.showMessage("Enter the pager code to proceed.");
        }
    };

    this.loadTimeOutRedirect = function () {
        $timeout(() => {
            vm.cancelOrder();
            CartService.clearCart();
            ProductGridService.resetBarcodeProduct();
        }, 5000);
    };

    this.getFinalizePurchaseGifUrl = function () {
        return vm.state.currentClient
            ? vm.state.currentClient.images.getCoupon
            : null;
    };

    this.finalizePurshace = function(){
        const orderMethod = vm.state.orderMethod
        if (orderMethod == 'recharge') {
            vm.changePage('PAYMENT_WIDGET')
        } else if (orderMethod == 'kiosk') {
            vm.changePage('DOCUMENT')
        }
    }

    this.packageDisplayNamePrice = function(item){
        const name = `${item.DSBUTTON}`;
        let priceComplete = vm.getProductPrice(item);
        auxPriceComplete = priceComplete.toString().split(".");
        priceComplete = `${auxPriceComplete[0]},${auxPriceComplete[1]}`;
        const exchangeSymbol = 'R$';
        const descriptionPackage = `${name} ${exchangeSymbol} ${priceComplete}`;
        return descriptionPackage;
    } 

    this.packageDisplayPrice = function(item){
        let price = vm.getProductPackagePrice(item).toString();
        let auxPrice = price.split(".");
        price = `${auxPrice[0]},${auxPrice[1]}`;        
        let message = `Embalagem R$ ${vm.getProductPackagePrice(item)}`;
        return message;
    }
}
