function RegisterPasswordController($scope, ScreenService, ApplicationContext) {
    const vm = $scope.parent
    this.state = {
        keys: [1, 2, 3, 4, 5, 6, 7, 8, 9],
        value: ''
    }

    this.clickKey = function (keyValue) {
        if (keyValue == "<") {
            if (!isNaN(this.state.value[this.state.value.length - 1])) {
                this.state.value = this.state.value.slice(0,this.state.value.length - 1);
            } else {
                this.state.value = this.state.value.slice(0,this.state.value.length - 2);
            }
        } else if (keyValue === " ") {
            this.state.value = "";
        }
        this.state.value += keyValue
    }

    this.savePassword = function () {
        if (!this.state.value) {
            ScreenService.showMessage("Gentileza informar o código.");
        } else {
            const params = {
                CDIDCONSUMID: vm.state.cardNumber,
                CDSENHACONS: this.state.value
            };
            ApplicationContext.ConsumerService.saveNewPassword(
                params
            ).then(data => {
                if (!data.dataset.UPDATE_PASSWORD.error) {
                    ScreenService.showMessage(
                        "Senha cadastrada com sucesso. Gentileza informar os dados novamente.",
                        "SUCCESS"
                    ).then(() => {
                        vm.changePage("CONSUMER_PASSWORD");
                    });
                } else {
                    ScreenService.showMessage(
                        "Erro ao cadastrar nova senha."
                    );
                }
            });
        }
    };
}