function DocumentController(
    $scope,
    CartService,
    ScreenService,
    ApplicationContext
) {
    const vm = $scope.parent;
    this.parent = vm;

    console.log( vm );
    this.state = {
        keys: [1, 2, 3, 4, 5, 6, 7, 8, 9],
        value: "",
        documentType: "cpf",
        isMaskedValue: true,
        showModal: false,
        payments: [],
    };

    this.loadPayments = function () {
        ApplicationContext.RecebimentoRepository.findAll().then((payments) => {
            const taaPayments = [];
            payments
                .filter(
                    (payment) =>
                        payment.IDMOSTRARECE == "S" &&
                        (payment.IDTIPORECE == "1" ||
                            payment.IDTIPORECE == "2" ||
                            payment.IDTIPORECE == "4" ||
                            payment.IDTIPORECE == "H" ||
                            (vm.state.orderMethod !== "recharge" &&
                                vm.state.consumerSaleParams.hasOwnProperty(
                                    "CDIDCONSUMID"
                                ) &&
                                (payment.IDTIPORECE == "9" ||
                                    payment.IDTIPORECE == "A")))
                )
                .forEach((payment) => {
                    switch (payment.IDTIPORECE) {
                        case "1":
                            payment.image =
                                vm.state.currentClient.images.creditCard;
                            break;
                        case "2":
                        case "9":
                            payment.image =
                                vm.state.currentClient.images.debitCard;
                            break;
                        case "A":
                            payment.image =
                                vm.state.currentClient.images.consumerCard;
                            break;
                        default:
                            payment.image =
                                vm.state.currentClient.images.defaultCard;
                            break;
                    }
                    taaPayments.push(payment);
                });

            this.state.payments = taaPayments;
        });
    };

    this.clickKey = function (keyValue) {
        if (keyValue == "<") {
            if (!isNaN(this.state.value[this.state.value.length - 1])) {
                this.state.value = this.state.value.slice(
                    0,
                    this.state.value.length - 1
                );
            } else {
                this.state.value = this.state.value.slice(
                    0,
                    this.state.value.length - 2
                );
            }
        } else if (keyValue === " ") {
            this.state.value = "";
        } else {
            let documentType = this.state.documentType;
            if (documentType == "cpf") {
                if (this.state.value.length < 14) {
                    this.state.value += keyValue;
                    this.applyMask("cpf");
                }
            } else {
                if (this.state.value.length < 18) {
                    this.state.value += keyValue;
                    this.applyMask("cnpj");
                }
            }
        }
    };

    this.applyMask = function (maskType) {
        switch (maskType) {
            case "cpf":
                if (
                    this.state.value.length == 3 ||
                    this.state.value.length == 7
                ) {
                    this.state.value += ".";
                }
                if (this.state.value.length == 11) {
                    this.state.value += "-";
                }
                break;
            case "cnpj":
                if (
                    this.state.value.length == 2 ||
                    this.state.value.length == 6
                ) {
                    this.state.value += ".";
                }
                if (this.state.value.length == 10) {
                    this.state.value += "/";
                }
                if (this.state.value.length == 15) {
                    this.state.value += "-";
                }
                break;
        }
    };

    this.cancelOrder = function () {
        ScreenService.confirmMessage(
            "Tem certeza que deseja cancelar a compra? <p>(Todos os itens serão perdidos)</p>",
            "CONFIRMATION",
            function () {
                vm.cancelOrder();
            }
        );
    };

    this.finalizePurchase = function () {
        vm.state.consumerDoc = this.state.value;
        let documentType = this.state.documentType;
        if (documentType == "cpf") {
            if (vm.state.consumerDoc.length < 14) {
                ScreenService.showMessage(
                    "Digite um cpf válido para finalizar a compra"
                );
            } else {
                var cpf = vm.state.consumerDoc;

                if (isValidCpf(cpf)) {
                    vm.state.consumerDoc = "";
                    this.loadPayments();
                    this.setShowModal(true);
                } else {
                    ScreenService.showMessage("CPF inválido");
                }
            }
        } else if (documentType == "cnpj") {
            if (vm.state.consumerDoc.length < 18) {
                ScreenService.showMessage(
                    "Digite um cnpj válido para finalizar a compra"
                );
            } else {
                var cnpj = vm.state.consumerDoc;

                if (isValidCnpj(cnpj)) {
                    vm.state.consumerDoc = "";
                    this.loadPayments();
                    this.setShowModal(true);
                } else {
                    ScreenService.showMessage("CNPJ inválido");
                }
            }
        } else {
            ScreenService.showMessage(
                "Selecione o tipo de documento a ser digitado"
            );
        }
    };

    const isValidCpf = function (cpf) {
        /* CPF validation. */
        cpf = cpf.replace(".", "").replace(".", "").replace("-", "");
        var total;
        var first, second;

        var invalidCpfs = [
            "00000000000",
            "11111111111",
            "22222222222",
            "33333333333",
            "44444444444",
            "55555555555",
            "66666666666",
            "77777777777",
            "88888888888",
            "99999999999",
        ];

        if (invalidCpfs.indexOf(cpf) == -1) {
            total = 0;
            for (let i = 1; i <= 9; i++) {
                total += parseInt(cpf.substring(i - 1, i)) * (11 - i);
            }
            first = (total * 10) % 11;
            if (first == 10 || first == 11) first = 0;

            total = 0;
            for (let i = 1; i <= 10; i++) {
                total += parseInt(cpf.substring(i - 1, i)) * (12 - i);
            }
            second = (total * 10) % 11;

            if (second == 10 || second == 11) second = 0;
            return !(
                first != parseInt(cpf.substring(9, 10)) ||
                second != parseInt(cpf.substring(10, 11))
            );
        } else {
            return false;
        }
    };

    const isValidCnpj = function (cnpj) {
        cnpj = cnpj.replace(/[^\d]+/g, "");

        if (cnpj === "") return false;

        if (cnpj.length != 14) return false;

        var invalidCnpjs = [
            "00000000000000",
            "11111111111111",
            "22222222222222",
            "33333333333333",
            "44444444444444",
            "55555555555555",
            "66666666666666",
            "77777777777777",
            "88888888888888",
            "99999999999999",
        ];

        // Elimina CNPJs invalidos conhecidos
        if (invalidCnpjs.indexOf(cnpj) != -1) {
            return false;
        }

        // Valida DVs
        let tamanho = cnpj.length - 2;
        let numeros = cnpj.substring(0, tamanho);
        let digitos = cnpj.substring(tamanho);
        let soma = 0;
        let pos = tamanho - 7;
        for (let i = tamanho; i >= 1; i--) {
            soma += numeros.charAt(tamanho - i) * pos--;
            if (pos < 2) {
                pos = 9;
            }
        }
        let resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);
        if (resultado != digitos.charAt(0)) {
            return false;
        }

        tamanho = tamanho + 1;
        numeros = cnpj.substring(0, tamanho);
        soma = 0;
        pos = tamanho - 7;
        for (i = tamanho; i >= 1; i--) {
            soma += numeros.charAt(tamanho - i) * pos--;
            if (pos < 2) {
                pos = 9;
            }
        }
        resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);
        if (resultado != digitos.charAt(1)) {
            return false;
        }

        return true;
    };

    this.performSaleWithoutCpf = function () {
        vm.state.consumerDoc = "";
        this.loadPayments();
        this.setShowModal(true);
    };

    this.isBilletMethod = function () {
        return vm.state.orderMethod === "billet";
    };

    this.previousOrder = function () {
        if (vm.state.orderMethod === "billet") {
            this.cancelOrder();
        } else {
            vm.changePage("CART");
            CartService.unBlockCart();
            CartService.setCartItemState("ADD_PRODUCT_STATE");
        }
    };

    this.getdocumentType = function () {
        return this.state.documentType;
    };

    this.verifyDisable = function (docType) {
        if (this.getdocumentType() == docType) {
            return true;
        } else {
            return false;
        }
    };

    this.setDocumentType = function (docType) {
        this.state.documentType = docType;
        this.state.value = "";
    };

    this.keypadOnEnter = function () {
        this.state.value = "";
    };

    this.maskValue = function () {
        return this.state.isMaskedValue;
    };

    this.changeMask = function () {
        this.state.isMaskedValue = !this.state.isMaskedValue;
    };

    this.showModal = function () {
        return this.state.showModal;
    };

    this.setShowModal = function (modal) {
        this.state.showModal = modal;
    };

    this.showQrCode = function() {
        this.setShowModal(false);
        vm.state.paymentAwaitingCard = false;
        vm.state.paymentAwaitingMoney = false;
        vm.state.paymentAwaitingQrCode = true;
    }

    this.closeModalQrCode = function() {
        vm.state.paymentAwaitingCard = false;
        vm.state.paymentAwaitingQrCode = false;
        vm.state.paymentAwaitingMoney = false;
        this.state.showModal = true;
    }
}
