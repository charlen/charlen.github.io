function SelectOrderMethodController(
    $scope,
    CartService,
    ScreenService,
    ApplicationContext,
    ProductDetailService,
    BiometricService
) {
    const vm = $scope.parent
    this.parent = vm;
    this.state = {
        showQRCode: vm.state.currentClient.showQrcode,
        keys: [1, 2, 3, 4, 5, 6, 7, 8, 9],
        families: [],
        showIdentification: false,
        consumerFound: false,
        qrCode: '',
        cdidconsumid: '',
        filial: null,
        products: null,
        listening: false,
        biometry: false,
    }

    this.loadListener = function () {
        document.body.addEventListener("keypress", this.handleQRCodeInput);
    };

    this.getReadQRCodeImageUrl = () => vm.state.currentClient ? vm.state.currentClient.images.qrCode : null;

    this.getRechargeImageUrl = () => vm.state.currentClient ? vm.state.currentClient.images.recharge : null;

    this.getOrderOnTerminalImageUrl = () => vm.state.currentClient ? vm.state.currentClient.images.doOrder : null;

    this.handleConfigScreen = () => {
        ApplicationContext.FiliaisRepo.findOne()
            .then((filial) => {
                this.state.filial = filial.CDFILIAL
            })
        ApplicationContext.RecebimentoRepository.findAll()
            .then((payments) => payments.some((payment) => payment.IDTIPORECE === "9"))
            .then((showIdentification) => {
                showIdentification ? this.initIdentificationListener() : null
            })

        ApplicationContext.QRCodeProductsRepository.findAll()
            .then((products) => {
                this.state.products = products
            });

        ApplicationContext.CaixaRepository.findOne()
            .then(params => {
                params.IDTIPOPROX === '8' ? this.initBiometriclistener() : null
            })
    };


    this.initBiometriclistener = function() {
		Promise.all([
            ApplicationContext.CaixaRepository.findOne(),
            ApplicationContext.AuthRepository.findOne(),
            ApplicationContext.FilialRepository.findOne(),
        ])
		.then((response) => {
			const { DTABERCAIX } = response[0].status
            const { CDLOJA, CDCAIXA, IDTPTEF, CDTERTEF, IDHABCAIXAVENDA, NRCONFTELA } = response[0]
            const { CDOPERADOR } = response[1]
            const {CDFILIAL, NRINSJURFILI, CDCLIENTE} = response[2]
			ScreenService.changeLoadingMessage('Realizando carga do dispositivo biométrico')
			ApplicationContext.ConsumerService.saveBiometryDevice(CDFILIAL, CDCAIXA, CDLOJA)
			.then((response) => {
				if(response.error) {
					ScreenService.restoreDefaultLoadingMessage()
					ScreenService.showMessage(response.error)
				} else {
					this.state.biometry = true
					BiometricService.init()
					.then((response) => {
						this.captureAndIdentify()
					})
					.catch((error) => {
						this.state.biometry = false
						if(error.name === 'AbortError') {
							return null
						} else {
							ScreenService.showMessage(`Não foi possível localizar ou inicializar o leitor biométrico. \n Erro: ${error}`)
						}
					})
					.finally(() => {
						console.log('call terminate')
					})
				}
				ScreenService.restoreDefaultLoadingMessage()
			})
			.catch((error) => {
				console.log(error)
			})
		})
    }
	this.captureCount = 0;
    this.captureAndIdentify = function () {
        BiometricService.captureAndIdentify().
        then((response) => {
            ApplicationContext.ConsumerService.findConsumer(response.id).
            then(response => {
                if (
                    !!response.dataset.consumer.error &&
                    !response.dataset.consumer.errorCode
                ) {
                    ScreenService.showMessage(
                        response.dataset.consumer.message
                    );
                    this.state.cdidconsumid = '';
                } else {
                    document.body.removeEventListener(
                        'keypress',
                        this.identificationHandler
                    );
                    vm.state.consumerSaleParams = { ...response.dataset.consumer };
                    this.state.listening = false
                    this.state.consumerFound = true
                    this.getFamilies()
                }
            })
            .catch(error => {
                this.initBiometriclistener()
                ScreenService.showMessage(error.error)
            });
        })
        .catch((error) => {
            this.state.biometry = false
            if(error.name === 'AbortError') {
                return null
            } else {
				if(this.captureCount < 3) {
					this.captureCount = this.captureCount + 1
					this.captureAndIdentify()
				} else {
					this.captureCount = 0
                	vm.cancelOrder()
                	ScreenService.showMessage(`Erro: ${error}`)
				}
            }
        })
    }

    this.startQrCodeReading = function () {
        this.loadListener();
        vm.state.orderMethod = "qrcode";
        this.state.listening = true
        ScreenService.changeLoadingMessage("Aproxime o QR CODE ao leitor...");
        ScreenService.showLoader();
    };

    this.openMenu = function () {
        Promise.all([
            ApplicationContext.CaixaRepository.findOne(),
            ApplicationContext.AuthRepository.findOne(),
            ApplicationContext.FilialRepository.findOne(),
        ])
        .then(response => {
            const { DTABERCAIX } = response[0].status
            const { CDLOJA, IDTPTEF, CDTERTEF, IDHABCAIXAVENDA, NRCONFTELA } = response[0]
            const { CDOPERADOR } = response[1]
            const {CDFILIAL, NRINSJURFILI, CDCLIENTE} = response[2]
            BiometricService.abort()
            CartService.clearCart();
            vm.state.orderMethod = "kiosk";
            let CDTIPOCONS = null
            if(vm.state.consumerSaleParams) {
                CDTIPOCONS = vm.state.consumerSaleParams.CDTIPOCONS
            }
            ApplicationContext.ProdutoService.fetch(CDFILIAL, CDLOJA, CDCLIENTE, NRCONFTELA, CDTIPOCONS).then((response) => {
                this.goToProductGrid();
            })
        })
    }
	
    this.identificationHandler = () => {
		if (event.defaultPrevented) {
			return;
        }
        const key = event.key || event.keyCode;
        BiometricService.abort()
        if (key === 'Enter' || key === 13 || key === '13') {
            BiometricService.abort();
            ApplicationContext.FilialRepository.findOne().then(filial => {
                const cardCodePosiInicial = filial.NRPOSINICONS;
                const cardCodePosiFinal = filial.NRPOSFINCONS;
                if (cardCodePosiInicial != 0 || cardCodePosiFinal != 0) {
                    this.state.cdidconsumid = this.state.cdidconsumid.substring(cardCodePosiInicial - 1, cardCodePosiFinal);
                }
                this.getConsumer(this.state.cdidconsumid)
            })

        } else {
            ScreenService.changeLoadingMessage('Carregando dados do leitor...');
            this.state.cdidconsumid += event.key;
        }
    }

    this.handleQRCodeInput = () => {
        if (event.defaultPrevented) {
            return
        }
        const key = event.key || event.keyCode;
        BiometricService.abort()
        if (key === "Enter" || key === 13 || key === '13') {
            let qrCode = _formatQRCode(this.state.qrCode);
            CartService.setCartItemState("ADD_PRODUCT_STATE");
            try {
                qrCode = JSON.parse(formatJSONOrder(qrCode));
                if (this.state.filial !== qrCode.FILIAL) {
                    this.state.listening = false
                    this.resetQrCodeRead("QRCode pertence a outra filial.");
                } else {
                    const cartProducts = this.buildCartFromQrCode(qrCode.PRODUCTSDETAILS)
                    if (cartProducts.length > 0) {
                        cartProducts.forEach((product) => {
                            ProductDetailService.setSelectedProduct(product)
                            CartService.addToCart(product);
                        });
                        _setPayment(qrCode)
                        _setConsumer(qrCode)
                        _setComandaVen(qrCode)
                        this.state.listening = false
                        document.body.removeEventListener("keypress", this.handleQRCodeInput);
                        vm.submitPayment()
                    } else {
                        this.state.listening = false
                        this.resetQrCodeRead("QR Code inválido.");
                    }
                }
            } catch (e) {
                console.log(e)
                this.state.listening = false
                this.resetQrCodeRead("QR Code inválido.");
            }
        } else {
            ScreenService.changeLoadingMessage("Carregando dados do leitor...");
            this.state.qrCode += event.key;
        }
    }

    const _setConsumer = function (qrCodeOrder) {
        vm.state.consumerSaleParams = {
            CDCLIENTE: qrCodeOrder.CDCLIENTE,
            CDCONSUMIDOR: qrCodeOrder.CDCONSUMIDOR
        };
    }

    const _setPayment = function (qrCodeOrder) {

        if (qrCodeOrder.RECEBIMENTOS.length > 0) {
            qrCodeOrder.RECEBIMENTOS[0].CDNSUHOSTTEF = qrCodeOrder.CDNSUHOSTTEF;
            vm.state.payment = qrCodeOrder.RECEBIMENTOS[0];

        } else {
            vm.state.payment = {
                CDTIPORECE: "011",
                IDTIPORECE: "1",
                CDNSUHOSTTEF: qrCodeOrder.CDNSUHOSTTEF,
                VALOR: 10
            };
        }
    }

    const _setComandaVen = function (qrCodeOrder) {
        vm.state.qrcodeInfo.NRCOMANDA = qrCodeOrder.NRCOMANDA
        vm.state.qrcodeInfo.NRVENDAREST = qrCodeOrder.NRVENDAREST
    };

    this.resetQrCodeRead = function (message) {
        document.body.removeEventListener("keypress", this.handleQRCodeInput);
        this.state.qrCode = "";
        ScreenService.hideLoader();
        ScreenService.showMessage(message);
    };

    this.buildCartFromQrCode = function (qrCodeProducts) {
        CartService.clearCart();
        let cartProducts = []
        cartProducts = this.fillArrayCart(qrCodeProducts);
        return cartProducts;
    };

    this.fillArrayCart = function (qrCodeProducts) {
        const arrayCart = []
        const menuProducts = [...this.state.products]
        qrCodeProducts.forEach(function (qrProduct) {
            menuProducts.forEach(function (menuProduct) {
                if (menuProduct.CDPRODUTO === qrProduct.CDPRODUTO) {
                    let productObservations = [];
                    const _product = { ...menuProduct };
                    _product.QTPRODCOMVEN = qrProduct.QTPRODCOMVEN || qrProduct.QTPRODVEND;
                    _product.OBSERVACOES = qrProduct.OBSERVACOES || [];
                    _product.VRPRECITEM = qrProduct.PRICE || qrProduct.VRUNITVEND || qrProduct.VRPRECITEM;
                    _product.VRDESITVEND = 0;
                    _product.IDTIPOCOMPPROD = 0;
                    _product.comboItems = [];
                    _product.QRCODE = true;
                    _product.OBSERVACOES.forEach(CDOCORR => {
                        ProductDetailService.getObservations().forEach(observation => {
                            if (
                                observation.CDOCORR == CDOCORR &&
                                observation.IDEXIOBSAPPCONS == 'S'
                            ) {

                                const _observation = angular.copy(observation);
                                productObservations.push(_observation);
                            }
                        });
                    });
                    _product.OBSERVATIONS = productObservations
                    arrayCart.push(_product);
                }
            });
        });
        return arrayCart;
    };

    const _formatQRCode = function (qrcodeString) {
        return qrcodeString
            .replace(/</gi, "{")
            .replace(/>/gi, "}")
            .replace(/\*/gi, '"')
            .replace(/\$/gi, ":")
            .replace(/\(/gi, "[")
            .replace(/\)/gi, "]");
    };

    const formatJSONOrder = function (formattedQrCode) {
        return formattedQrCode
            .replace(/FIL/gi, "FILIAL")
            .replace(/NVR/gi, "NRVENDAREST")
            .replace(/NCD/gi, "NRCOMANDA")
            .replace(/CLIE/gi, "CDCLIENTE")
            .replace(/CONS/gi, "CDCONSUMIDOR")
            .replace(/PRODS/gi, "PRODUCTSDETAILS")
            .replace(/CDP/gi, "CDPRODUTO")
            .replace(/QT/gi, "QTPRODCOMVEN")
            .replace(/VR/gi, "VRPRECITEM")
            .replace(/IMPPROD/gi, "IDIMPPRODUTO")
            .replace(/OBS/gi, "OBSERVACOES")
            .replace(/PROMO/gi, "PROMOPRODS")
            .replace(/REC/gi, "RECEBIMENTOS")
            .replace(/VRPRECEBIMENTOSITEM/gi, "VRPRECITEM")
            .replace(/VRPRECITEMt/gi, "VALOR")
            .replace(/IDTREC/gi, "IDTIPORECE")
            .replace(/CDTREC/gi, "CDTIPORECE")
            .replace(/CDTIPORECEEBIMENTOS/gi, "CDTIPORECE")
            .replace(/IDTIPORECEEBIMENTOS/gi, "IDTIPORECE")
            .replace(/NSU/gi, "CDNSUHOSTTEF")
            .replace(/CDCOCDNSUHOSTTEFMIDOR/gi, "CDCONSUMIDOR")
            .replace(/CDCONSURECEBIMENTOMIDOR/gi, "CDCONSUMIDOR");
    };

    
    this.initIdentificationListener = () => {
        this.state.listening = true
        document.body.addEventListener("keypress", this.identificationHandler);
    }


    this.clickKey = function (keyValue) {
        if (keyValue == "<") {
            if (!isNaN(this.state.cdidconsumid[this.state.cdidconsumid.length - 1])) {
                this.state.cdidconsumid = this.state.cdidconsumid.slice(0, this.state.cdidconsumid.length - 1);
            } else {
                this.state.cdidconsumid = this.state.cdidconsumid.slice(0, this.state.cdidconsumid.length - 2);
            }
        } else if (keyValue === " ") {
            this.state.cdidconsumid = "";
        } else {
            this.state.cdidconsumid += keyValue;
        }
    }

    this.cancelOrder = function () {
        ScreenService.confirmMessage(
            "Tem certeza que deseja cancelar a compra?",
            "CONFIRMATION",
            () => {
				BiometricService.abort()
                document.body.removeEventListener("keypress", this.handleQRCodeInput);
                this.state.listening = false
                ScreenService.hideLoader();
                vm.cancelOrder();
            }
        );
    };

    this.goToProductGrid = function () {
        vm.state.toGo = false;
        vm.changePage("PRODUCT_GRID")
        CartService.unBlockCart();
        CartService.setCartItemState('ADD_PRODUCT_STATE');
    };

    this.getConsumer = () => {
        BiometricService.abort()
        ApplicationContext.ConsumerService.findConsumer(this.state.cdidconsumid).
            then(response => {
                if (
                    !!response.dataset.consumer.error &&
                    !response.dataset.consumer.errorCode
                ) {
                    ScreenService.showMessage(
                        response.dataset.consumer.message
                    );
                    this.state.cdidconsumid = '';

                } else {
                    document.body.removeEventListener(
                        'keypress',
                        this.identificationHandler
                    );
                    vm.state.consumerSaleParams = { ...response.dataset.consumer };
                    this.state.listening = false
                    this.state.consumerFound = true
                    this.getFamilies()
                }
            })
            .catch(error => {
                ScreenService.showMessage(error.error)
            });
    }

    this.getFamilies = function () {
        ApplicationContext.ConsumerService.getConsumerFamilies(
            vm.state.consumerSaleParams
        ).then((response) => {
            this.state.families = response.dataset.ConsumerSaldoCons
			ApplicationContext.ConsumerFamiliesRepository.save(
				response.dataset.ConsumerSaldoCons
			)
        })
    }

    this.openRecharge = function () {
        vm.state.orderMethod = "recharge";
        vm.changePage("PAYMENT_WIDGET");
    };
}