function FamilyPaymentController($scope, ScreenService, CartService, ApplicationContext) {

    const vm = $scope.parent

    this.state = {
        selectedFamily: null,
        totalValue: 0,
        values: ['1,00', '5,00', '10,00', '20,00', '50,00', '100,00'],
        families: []
    }

    this.selectFamily = function(family) {
        this.state.selectedFamily = family;
        $scope.$apply()
    }

    this.addValue = function (value) {
        let totalValue = parseFloat(this.state.selectedFamily.toAdd);
        totalValue = totalValue + parseFloat(value);
        this.state.selectedFamily.toAdd = _toMoney(totalValue);
        this.getTotalValue();
    };

    const _toMoney = function _toMoney(value) {
        return `${value},00`;
    };

    this.initializeValues = function () {
        const promises = [];
        promises.push(ApplicationContext.FamiliesRepository.findAll());
        promises.push(ApplicationContext.ConsumerFamiliesRepository.findAll());
        Promise.all(promises).then(promises => {
            promises[0].forEach(function(family){
                const VRSALDCONFAM = promises[1].find(function(familyConsumer){
                    return familyConsumer.CDFAMILISALD === family.CDFAMILISALD;
                })
                family.valueConsumer = VRSALDCONFAM ? parseFloat(VRSALDCONFAM.VRSALDCONFAM).toFixed('2')  : '0';
                family.toAdd = 0;
            })
            this.state.families = promises[0];
            this.selectFamily(this.state.families[0]);
            this.getTotalValue();
        });
    };

    this.resetValue = function(family, event) {
        event.stopPropagation();
        family.toAdd = '0';
        this.getTotalValue();
    }

    this.cancelOrder = function(){
        ScreenService.confirmMessage('Gostaria de cancelar a recarga?', 'CONFIRMATION', function() {
            vm.resetState();
            CartService.clearCart();
            vm.cancelOrder();
        });

    }

    this.getTotalValue = function () {
        const totalValue = this.state.families.reduce(function(a, b)  {
            return a + parseFloat(b.toAdd)
        }, 0);
        this.state.totalValue = _toMoney(totalValue);
    };

    this.makeRecharge = function(){
        if(parseInt(parseFloat(this.state.totalValue)*100)/100 <= 0) {
            ScreenService.showMessage('Gentileza informar o valor da recarga.')
        } else {
            vm.state.totalRecharge = parseInt(parseFloat(this.state.totalValue)*100)/100;
            vm.state.familiesToRecharge = this.state.families;
            vm.changePage('ORDER_DETAIL');
        }
    }
}