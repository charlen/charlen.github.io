function WaitScreenController(
    $scope,
    CartService,
    ComboService,
    ApplicationContext,
    ScreenService,
    templateManager,
    $rootScope,
    $interval
) {
    const vm = $scope.parent
    let language;
    let imageIndex = 0
    let stopInterval = null
    this.validatorCounter = 1;
    this.clientName = (name) => vm.state.currentClient.name === name
    this.loadTAAParams = () => {
        if (Array.isArray(vm.state.currentClient.images.intro)) {
            stopInterval = $interval(function() {
                imageIndex++
                if (imageIndex > vm.state.currentClient.images.intro.length - 1) {
                    imageIndex = 0
                }
            }, 10000, false)
        }
        _preventRightClick()
        $rootScope.$broadcast('resetAccessibility')
        CartService.clearCart();
        ComboService.clearWizardCart();
    };

    const _preventRightClick = function() {
        document.addEventListener(
            'contextmenu',
            function(e) {
                e.preventDefault();
            },
            false
        );
    }

    this.prepareTAA = function() {
        Promise.all([
            ApplicationContext.CaixaRepository.findOne(),
            ApplicationContext.AuthRepository.findOne(),
            ApplicationContext.FilialRepository.findOne(),
        ])
        .then(response => {
            const { DTABERCAIX } = response[0].status
            const { CDLOJA, IDTPTEF, CDTERTEF, IDHABCAIXAVENDA, NRCONFTELA } = response[0]
            const { CDOPERADOR } = response[1]
            const {CDFILIAL, NRINSJURFILI, CDCLIENTE} = response[2]
            ApplicationContext.RegisterController.validateRegisterOpening(
                DTABERCAIX,
                CDOPERADOR,
                CDOPERADOR
            );
            // prepareMenu(cardapio)
            const { simulateTef } = vm.state.simulationParams
            if (simulateTef || IDTPTEF !== "2") {
                handleRoute(CDFILIAL, CDLOJA, CDCLIENTE, NRCONFTELA, IDHABCAIXAVENDA)
            } else {
                if (vm.state.capptaInstance) {
                    handleRoute(CDFILIAL, CDLOJA, CDCLIENTE, NRCONFTELA, IDHABCAIXAVENDA)
                } else {
                    ScreenService.showLoader();
                    ScreenService.changeLoadingMessage(
                        "Verificando status da integração Cappta..."
                    );
                    ApplicationContext.CapptaService.getCapptaInstance(CDTERTEF, NRINSJURFILI)
                        .then(cappta => {
                            ScreenService.hideLoader();
                            vm.state.capptaInstance = cappta;
                            handleRoute(CDFILIAL, CDLOJA, CDCLIENTE, NRCONFTELA, IDHABCAIXAVENDA)
                        })
                        .catch(err => {
                            ScreenService.hideLoader();
                            ScreenService.showMessage(err);
                        });
                }
            }
        });

    };

    const handleRoute = function(CDFILIAL, CDLOJA, CDCLIENTE, NRCONFTELA, IDHABCAIXAVENDA) {
        ApplicationContext.ProdutoService.fetch(CDFILIAL, CDLOJA, CDCLIENTE, NRCONFTELA).then((response) => {
            if (stopInterval) {
                $interval.cancel(stopInterval)
            }
            vm.handleRoute(IDHABCAIXAVENDA);
        })
    }

    this.openOperatorValidation = function(event) {
        event.stopPropagation();
        ScreenService.changeLoadingMessage('Aguarde...');
        if (this.validatorCounter < 3) {
            this.validatorCounter++;
        } else {
            const widget = templateManager.container.getWidget(
                'validateOperatorWidget'
            );
            ApplicationContext.AuthRepository.findOne().then(operator => {
                widget.getField("NMOPERADOR").value(operator.NMOPERADOR);
                widget.getField("CDOPERADOR").value(operator.CDOPERADOR);
                widget.activate();
                ScreenService.openSwipe(widget);
            });
            this.validatorCounter = 1;
        }
    };

    this.loadSystemLanguage = () => {
        fetch('./config.json')
            .then(data => data.json())
            .then((jsonData) => {
                language = jsonData.lang;
                this._handleFlagsStyle();
            });
    };

    this.changeLanguage = selectedLanguage => {
        language = selectedLanguage;
        this._handleFlagsStyle();
        this.prepareTAA();
    };

    this._handleFlagsStyle = function() {
        $('.language-flag').removeClass('selected-flag');

        var brazilFlag = $('.brasil');
        var usaFlag = $('.usa');
        var spainFlag = $('.spain');

        brazilFlag.css('opacity', '0.5');
        usaFlag.css('opacity', '0.5');
        spainFlag.css('opacity', '0.5');

        switch (language) {
            case 'pt_br':
                brazilFlag.toggleClass('selected-flag');
                brazilFlag.css('opacity', '1');
                break;
            case 'en_us':
                usaFlag.toggleClass('selected-flag');
                usaFlag.css('opacity', '1');
                break;
            case 'es':
                spainFlag.toggleClass('selected-flag');
                spainFlag.css('opacity', '1');
                break;
        }

        window.lang = language;
        ScreenService.setLanguage(language);
    };

    this.openDashboard = function() {
        ScreenService.openWindow('dashboard');
    };

    this.showLangButtons = () => {
        return vm.state.currentClient.showLangButtons;
    };

    this.getWaitScreenSource = function() {
        return vm.state.currentClient ?
            Array.isArray(vm.state.currentClient.images.intro) ? vm.state.currentClient.images.intro[imageIndex] : vm.state.currentClient.images.intro :
            null;
    };

    this.isApresentationVideo = function() {
        return vm.state.currentClient.isVideo;
    };

}