function ConsumerPasswordController(
    $scope,
    CartService,
    ScreenService,
    ApplicationContext,
    BiometricService
) {
    const vm = $scope.parent;
    this.parent = vm;
    this.state = {
        randomValues: null,
        cardNumber: '',
        showPasswordPad: true,
        filial: null,
        password: [],
        fakePassword: '',
        consumerData: {},
        biometry: false
    };

    this.init = function() {
        ApplicationContext.AuthRepository.findOne()
            .then(params => {
                params.parametros.IDTIPOPROX === '8' ? this.initBiometriclistener() : null
            })
        this.preparePasswordKeys()
    }

    this.preparePasswordKeys = function() {
        ApplicationContext.FiliaisRepo.findOne().then(filial => {
            this.state.consumerData = vm.state.consumerSaleParams
            this.state.filial = filial.CDFILIAL;
            this.state.showPasswordPad = true;
            const arrNumber = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
            const arrayValues = [...Array(5)].map(
                elem =>
                    (elem = [...Array(2)].map(_ => {
                        let rndNumber =
                            arrNumber[Math.floor(Math.random() * arrNumber.length)];
                        arrNumber.splice(
                            arrNumber.findIndex(ele => ele === rndNumber),
                            1
                        );
                        return rndNumber;
                    }))
            );
            this.state.randomValues = arrayValues;
        })
    };

    this.keyClick = function(keyValue) {
        BiometricService.abort();
        if (keyValue === ' ') {
            this.state.fakePassword = '';
            this.state.password = [];
        } else {
            this.state.fakePassword += 'x';
            this.state.password.push(keyValue);
        }
    };

    this.getPayment = function() {
        return vm.state.payment;
    };

    const _backToPayments = () => {
        BiometricService.abort()
        ScreenService.hideLoader();
        vm.changePage('ORDER_DETAIL');
    };

    this.performTransaction = () => {
        if (!this.state.password.length) {
            ScreenService.showMessage('Por gentileza, informar a senha.');
        } else {
            const params = {
                CDIDCONSUMID: this.state.consumerData.CDIDCONSUMID,
                CDSENHACONSMD5: this.state.password,
                CDFILIAL: this.state.filial
            };
            const methodTAA = vm.state.orderMethod;
            if (methodTAA === 'recharge') {
                ScreenService.changeLoadingMessage('Validando informações.');
                _validateConsumer(params).then(response => {
                    if (
                        response.dataset.ValidateConsumer.error === true &&
                        !response.dataset.ValidateConsumer.errorCode
                    ) {
                        ScreenService.showMessage(
                            response.dataset.ValidateConsumer.message
                        );
                    } else if (
                        !!response.dataset.ValidateConsumer.error &&
                        !!response.dataset.ValidateConsumer.errorCode
                    ) {
                        ScreenService.showMessage(
                            'Cartão sem senha cadastrada. Cadastre a nova senha.'
                        ).then(function() {
                            ScreenService.hideLoader();
                            vm.changePage('REGISTER_PASSWORD');
                        });
                    } else {
                        ApplicationContext.ConsumerToRechargeRepository.save(
                            vm.state.consumerSaleParams
                        );
                        ApplicationContext.ConsumerService.getConsumerFamilies(
                            vm.state.consumerSaleParams
                        ).then(function(response) {
                            ApplicationContext.ConsumerFamiliesRepository.save(
                                response.dataset.ConsumerSaldoCons
                            ).then(function() {
                                vm.changePage('PAYMENT_WIDGET');
                            }); 
                        });
                    }
                });
            } else {
                ScreenService.changeLoadingMessage('Validando informações.');
                _validateConsumer(params)
                    .then(response => {
                        if (
                            response.dataset.ValidateConsumer.error === true &&
                            !response.dataset.ValidateConsumer.errorCode
                        ) {
                            ScreenService.showMessage(
                                response.dataset.ValidateConsumer.message
                            );
                            return;
                        } else if (
                            !!response.dataset.ValidateConsumer.error &&
                            !!response.dataset.ValidateConsumer.errorCode
                        ) {
                            ScreenService.showMessage(
                                'Cartão sem senha cadastrada. Cadastre a nova senha.'
                            ).then(function() {
                                ScreenService.hideLoader();
                                vm.changePage('REGISTER_PASSWORD');
                            });
                        } else {
                            ApplicationContext.AuthRepository.findAll().then(dados => {
                                if(dados[0].parametros.IDIMPOPCNF == true){
                                    ScreenService.confirmMessage(
                                    'Deseja imprimir sua nota fiscal?',
                                    'CONFIRMATION',
                                    () => {
                                        vm.state.saleParams.imprimirNota = true;
                                        vm.submitPayment();

                                    },
                                    () => {
                                        vm.state.saleParams.imprimirNota = false;
                                        vm.submitPayment();
                                        }
                                    );
                                } else{
                                    vm.state.saleParams.imprimirNota = true;
                                    vm.submitPayment();
                                }
                            });
                        }
                    })
                    .catch(error => {
                        ScreenService.showMessage(error.data.error);
                    });
            }
        }
    };

    this.cancelTransaction = function() {
        
        document.body.removeEventListener('keypress', this.handleInput);
        const orderMethod = vm.state.orderMethod;
        if (orderMethod == 'kiosk') {
            _backToPayments();
        }

        if (orderMethod == 'recharge') {
            _cancelRecharge();
        }

        if (orderMethod == 'billet') {
            _backToPayments();
        }
    };

    const _cancelRecharge = function() {
        ScreenService.confirmMessage(
            'Confirma o cancelamento da recarga?',
            'CONFIRMATION',
            function() {
                // BiometricService.abort()
                vm.cancelOrder();
            }
        );
    };

    const _validateConsumer = params => {
        ScreenService.changeLoadingMessage('Validando informações.');
        return ApplicationContext.ConsumerService.validateConsumer(params).then(
            response => response
        );
    };

    this.getNumberSeparator = function(value) {
        switch (localStorage.language) {
            case '"pt_br"':
                return value.join().replace(',', ' ou ');
            case '"en_us"':
                return value.join().replace(',', ' or ');
            case '"es"':
                return value.join().replace(',', ' o ');
            default:
                return value.join().replace(',', ' ou ');
        }
    };

    this.initBiometriclistener = function() {
		this.state.biometry = true
        BiometricService.init()
        .then((response) => {
            this.captureAndIdentify()
        })
        .catch((error) => {
            this.state.biometry = false
            if(error.name === 'AbortError') {
                return null
            } else {
                ScreenService.showMessage(`Não foi possível localizar ou inicializar o leitor biométrico. \n Erro: ${error}`)
            }
        })
        .finally(() => {
            console.log('call terminate')
        })
        
    }

    this.captureAndIdentify = () => {
		const stored = vm.state.consumerSaleParams.CDIDCONSUMID
		BiometricService.validate(stored)
		.then((response) => {
			const methodTAA = vm.state.orderMethod;
			if(methodTAA === 'recharge') {
				ApplicationContext.ConsumerToRechargeRepository.save(
					vm.state.consumerSaleParams
				);
				ApplicationContext.ConsumerService.getConsumerFamilies(
					vm.state.consumerSaleParams
				).then(function(response) {
					ApplicationContext.ConsumerFamiliesRepository.save(
						response.dataset.ConsumerSaldoCons
					).then(function() {
						vm.changePage('PAYMENT_WIDGET');
					}); 
				});
			} else {
				ApplicationContext.AuthRepository.findAll().then(dados => {
					if(dados[0].parametros.IDIMPOPCNF == true){
						ScreenService.confirmMessage(
						'Deseja imprimir sua nota fiscal?',
						'CONFIRMATION',
						() => {
							vm.state.saleParams.imprimirNota = true;
							vm.submitPayment();

						},
						() => {
							vm.state.saleParams.imprimirNota = false;
							vm.submitPayment();
							}
						);
					} else{
						vm.state.saleParams.imprimirNota = true;
						vm.submitPayment();
					}
				});
			}
		})
		.catch(error => {
			if(error.name === 'AbortError') {
				return null
			} else {
				this.captureAndIdentify()
				ScreenService.showMessage(`Erro: ${error}`)
			}
		})
        
    }

}