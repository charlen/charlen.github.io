<?php
namespace Util;
class MSDEQuery {
    public function getArray() {
        return self::QUERY_MAPPING;
    }

    const QUERY_MAPPING = array(
        'GET_REGISTER_OPENING_DATE'             => self::GET_REGISTER_OPENING_DATE,
        'SQL_GET_VENDA_BY_NRNOTAFISCALCE'       => self::SQL_GET_VENDA_BY_NRNOTAFISCALCE,
        'SQL_GET_MOVCAIXA_BY_NRSEQVENDA'        => self::SQL_GET_MOVCAIXA_BY_NRSEQVENDA,
        'SQL_INSERE_ITEM_COMANDA_VEN'        => self::SQL_INSERE_ITEM_COMANDA_VEN,
    );

    const GET_REGISTER_OPENING_DATE = "
        SELECT DTABERCAIX
        FROM TURCAIXA
        WHERE CDFILIAL = :CDFILIAL
            AND CDCAIXA  = :CDCAIXA
            AND DTFECHCAIX IS NULL
    ";

    const SQL_GET_MOVCAIXA_BY_NRSEQVENDA = "
        SELECT T.IDTIPORECE, M.*
        FROM MOVCAIXA M, TIPORECE T
        WHERE M.NRSEQVENDA = :NRSEQVENDA
            AND M.CDFILIAL = :CDFILIAL
            AND M.CDCAIXA = :CDCAIXA
            AND M.NRORG = :NRORG
            AND M.CDTIPORECE = T.CDTIPORECE
    ";

    const SQL_GET_VENDA_BY_NRNOTAFISCALCE = "
        SELECT NRSEQVENDA, CDCAIXA
          FROM VENDA
         WHERE CDFILIAL = :CDFILIAL
           AND CDCAIXA = :CDCAIXA
           AND DTABERTUR = :DTABERTUR
           AND NRNOTAFISCALCE = :NRNOTAFISCALCE
           AND IDSITUVENDA = 'O'
    ";

    const SQL_INSERE_ITEM_COMANDA_VEN = "
        INSERT
          INTO ITCOMANDAVEN
               (CDFILIAL,
               NRVENDAREST,
               NRCOMANDA,
               NRPRODCOMVEN,
               CDPRODUTO,
               QTPRODCOMVEN,
               DTHRINCOMVEN,
               VRPRECCOMVEN,
               TXPRODCOMVEN,
               IDSTPRCOMVEN,
               VRDESCCOMVEN,
               NRLUGARMESA,
               CDCAIXACOLETOR)
        VALUES (:CDFILIAL,
        :NRVENDAREST,
        :NRCOMANDA,
        :NRPRODCOMVEN,
        :CDPRODUTO,
        :QTPRODCOMVEN,
        :DTHRINCOMVEN,
        :VRPRECCOMVEN,
        :TXPRODCOMVEN,
        :IDSTPRCOMVEN,
        :VRDESCCOMVEN,
        :NRLUGARMESA,
        :CDCAIXACOLETOR)
    ";
}
