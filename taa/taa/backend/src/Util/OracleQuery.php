<?php

namespace Util;

class OracleQuery {

public function getArray() {
return self::QUERY_MAPPING;
}

const QUERY_MAPPING = array(
);


}