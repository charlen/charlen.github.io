<?php
namespace Helpers;

use Zeedhi\Framework\Session\Session;

class Environment {

	protected $session;

	const USER_INFO = 'USERINFO';

	public function __construct(Session $session) {
		$this->session = $session;
	}

	public function startSession($userInfo = null) {
		$this->session->start();
		$this->setUserInfo($userInfo);
	}

	public function setUserInfo($userInfo) {
		if(isset($userInfo)) {
			$this->session->set(self::USER_INFO, json_encode($userInfo));            
		}
	}

	public function getUserSessionParameter($parameterName) {
		$userParameters = $this->getUserInfo();
		return $userParameters[$parameterName];
	}

	public function hasUserSessionParameter($parameterName) {
	   return $this->getUserSessionParameter($parameterName) !== NULL;
	}

	public function getUserInfo() {
		return json_decode($this->session->get(self::USER_INFO), true);
	}

	public function endSession(){
		$this->session->get(self::USER_INFO); //it should be removed when issue 99032 be solved
		return $this->session->destroy();
	}
}