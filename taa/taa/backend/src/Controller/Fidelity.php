<?php

namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class Fidelity {

    protected $entityManager;
	protected $fidelityAPI;

 	public function __construct(
        \Doctrine\ORM\EntityManager $entityManager,
        \Odhen\API\Service\Fidelidade $fidelityAPI) {

        $this->entityManager = $entityManager;
		$this->fidelityAPI = $fidelityAPI;
	}

    public function validateCard(Request\Filter $request, Response $response) {
        try {
        	$params = $request->getFilterCriteria()->getConditions();
        	$CDIDCONSUMID = $params[0]['value'];

        	$fidelityValidation = $this->fidelityAPI->validaFidelidade($CDIDCONSUMID);

        	$response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('FidelityCardRepo', $fidelityValidation));
        } catch (\Exception $e) {
            $response->addMessage(new Message($e->getMessage()));
        }
    }

}