<?php
namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class Auth {

  const CAIXA_TERMINAL = 'TAA';
  const CAIXA_COMANDA = 'APC';
  const TIPO_NFCE = 'FNC';
  const TIPO_SAT = 'SAT';
  protected $loginAPI;
  protected $paramsTAAService;
  protected $tefAPI;
  protected $caixaAPI;

  public function __construct(
    \Odhen\API\Remote\TEF\TEF $tefAPI,
    \Odhen\API\Service\Login $loginAPI,
    \Service\ParamsTAA $paramsTAAService,
    \Odhen\API\Service\Caixa $caixaAPI
    )
  {
    $this->tefAPI = $tefAPI;
    $this->loginAPI = $loginAPI;
    $this->caixaAPI = $caixaAPI;
    $this->paramsTAAService = $paramsTAAService;
  }

  private function validaTipoEmissao($CDFILIAL, $CDCAIXA)
  {
    $tipoEmissao = $this->paramsTAAService->buscaTipoEmissao($CDFILIAL, $CDCAIXA);
    if ($tipoEmissao != self::TIPO_SAT && $tipoEmissao != self::TIPO_NFCE) {
      throw new \Exception('Tipo emissão do caixa deve ser SAT ou NFC-e.', 404);
    }
  }

  public function auth(Request\Filter $request, Response $response)
  {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL = $params[0]['value'];
      $CDCAIXA = $params[1]['value'];
      $CDOPERADOR = $params[2]['value'];
      $TYPED_CDSENHOPER = $params[3]['value'];
      $simulatePrinter = $params[4]['value'];
      $simulateSaleValidation = $params[5]['value'];
      $simulateTef = $params[6]['value'];

      $this->validaTipoEmissao($CDFILIAL, $CDCAIXA);

      if (!$simulatePrinter || !$simulateSaleValidation) {
        $this->validaEstadoFiscal($CDFILIAL, $CDCAIXA);
      }
      if (!$simulateTef) {
        $this->validaDadosTEF($CDFILIAL, $CDCAIXA);
      }
      $operador = $this->loginAPI->validaLoginCaixa($CDFILIAL, $CDCAIXA, $CDOPERADOR, $TYPED_CDSENHOPER);
      $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('auth', $operador));
    } catch (\Exception $e) {
      $response->setError(new Error($e->getMessage(), $e->getCode()));
      $response->addMessage(new Message($e->getMessage(), Message::TYPE_ERROR));
    }
  }

  private function validaEstadoFiscal($CDFILIAL, $CDCAIXA)
  {
    $result = $this->caixaAPI->checaEstadoFiscal($CDFILIAL, $CDCAIXA, '1');
    if ($result['error'] == true) {
      throw new \Exception($result['message'], 500);
    }
  }

  private function validaDadosTEF($CDFILIAL, $CDCAIXA)
  {
    $tefConfigurationResponse = $this->tefAPI->validaParametrosTef($CDFILIAL, $CDCAIXA);
    if (!!$tefConfigurationResponse['error']) {
      throw new \Exception($tefConfigurationResponse['message'], 404);
    }
    return $tefConfigurationResponse;
  }
}
