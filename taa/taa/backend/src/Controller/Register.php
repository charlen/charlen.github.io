<?php

namespace Controller;
use \Zeedhi\Framework\DataSource\DataSet;
use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class Register
{

  protected $caixaAPI;
  protected $paramsTAAService;
  protected $impressaoUtilAPI;
  protected $utilAPI;
  protected $satRequest;
  protected $controllerParamsTAA;
  protected $parametrosAPI;

  public function __construct(
    \Odhen\API\Service\Caixa $caixaAPI,
    \Service\ParamsTAA $paramsTAAService,
    \Odhen\API\Lib\ImpressaoUtil $impressaoUtilAPI,
    \Odhen\API\Remote\SAT\SAT $satRequest,
    \Odhen\API\Util\Util $utilAPI,
    \Controller\ParamsTAA $controllerParamsTAA,
    \Odhen\API\Service\Parametros $parametrosAPI
  ) {

    $this->caixaAPI = $caixaAPI;
    $this->paramsTAAService = $paramsTAAService;
    $this->impressaoUtilAPI = $impressaoUtilAPI;
    $this->satRequest = $satRequest;
    $this->utilAPI = $utilAPI;
    $this->controllerParamsTAA = $controllerParamsTAA;
    $this->parametrosAPI = $parametrosAPI;
  }

  const TIPO_NFCE = 'FNC';
  const TIPO_SAT = 'SAT';

  public function openRegister(Request\Filter $request, Response $response)
  {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL = $params[0]['value'];
      $CDCAIXA = $params[1]['value'];
      $CDOPERADOR = $params[2]['value'];
      $NRORG = $params[3]['value'];

      // Default values for open register
      $IDMONGO = "";
      $IDATUTURCAIXA = 'I';
      $VRMOVIVEND = '0';
      $DTABERCAIX = new \DateTime();
      $DTMOVTURCAIX = new \DateTime();
      $result = $this->caixaAPI->abreCaixa(
        $CDFILIAL,
        $DTABERCAIX,
        $CDCAIXA,
        $NRORG,
        $CDOPERADOR,
        $DTMOVTURCAIX,
        $VRMOVIVEND,
        $IDMONGO,
        $IDATUTURCAIXA,
        false,
        'TAA',
        false
      );
      if ($result['error'] == false) {
        $caixa = $this->caixaAPI->fetchCaixa($CDFILIAL, $CDCAIXA);
        $status = $this->caixaAPI->getEstadoCaixa($CDFILIAL, $CDCAIXA, $NRORG);
        $caixa['status'] = $status;
        $response->addDataSet(new DataSet('caixa', $caixa));
      } else {
        $response->addDataSet(new DataSet('caixa', $result));       
        $response->addMessage(new Message($result['message']));  
      }
      
    } catch (\Exception $e) {
      $response->addMessage(new Message($e->getMessage()));
    }
  }

  public function closeRegister(Request\Filter $request, Response $response)
  {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL = $params[0]['value'];
      $CDCAIXA = $params[1]['value'];
      $CDOPERADOR = $params[2]['value'];
      $NRCONFTELA = $params[3]['value'];
      $PRINTREPORT = $params[4]['value'];
      $NRORG = $params[5]['value'];
      $DTFECHCAIX = new \DateTime();
      $CLOSEPOSSIMPLE = "S";

      $DTABERCAIX = $this->caixaAPI->getUltimaAberturaCaixa($CDFILIAL, $CDCAIXA);
      $TIPORECE = $this->caixaAPI->buscaTiporeceSangriaAutomatica($CDFILIAL, $CDCAIXA, $DTABERCAIX);

      $result = $this->caixaAPI->fechaCaixa(
        $CLOSEPOSSIMPLE,
        $DTABERCAIX,
        $DTFECHCAIX,
        $CDFILIAL,
        $CDCAIXA,
        $NRORG,
        $CDOPERADOR,
        $NRCONFTELA,
        $TIPORECE, // usado para sangria na api
        $PRINTREPORT,
        'TAA',
        false
      );

      if ($result['error'] == false) {
        $caixa = $this->caixaAPI->fetchCaixa($CDFILIAL, $CDCAIXA);
        $status = $this->caixaAPI->getEstadoCaixa($CDFILIAL, $CDCAIXA, $NRORG);
        $caixa['status'] = $status;
        $response->addDataSet(new DataSet('caixa', $caixa));
      } else {
        $response->addDataSet(new DataSet('caixa', $result));       
        $response->addMessage(new Message($result['message']));  
      }
    } catch (\Exception $e) {
      $response->addMessage(new Message($e->getMessage()));
    }
  }

  public function prepareTAA(Request\Filter $request, Response $response)
  {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL               = $params[0]['value'];
      $CDCAIXA                = $params[1]['value'];
      $CDLOJA                 = $params[2]['value'];
      $NRCONFTELA             = $params[3]['value'];
      $NRORG                  = $params[4]['value'];
      $registerStatus = $this->caixaAPI->getEstadoCaixa($CDFILIAL, $CDCAIXA, $NRORG);
      if ($registerStatus['estado'] == 'aberto') {
        $dataOpening = $this->caixaAPI->getUltimaAberturaCaixa($CDFILIAL, $CDCAIXA);
        $result = array(
          'error' => false,
          'DTABERCAIX' => $dataOpening->format('d/m/Y H:i:s')
        );
      } else {
        $result = array(
          'error' => true,
          'message' => 'O caixa não foi aberto. Operação inválida.'
        );
      }
      if ($result['error'] == false) {
        $this->parametrosAPI->getFileServer();
        $CDCLIENTE = $this->parametrosAPI->buscaClientePadrao($CDFILIAL);
        $tabelaPadrao = $this->parametrosAPI->buscaTabelaPadrao($CDFILIAL, $CDCLIENTE, $CDLOJA, array());
        if ($tabelaPadrao['error'] == false) {
          $precosIndexadosPorProduto = $tabelaPadrao['precosIndexadosPorProduto'];
          $observacoesIndexadasPorProduto = $this->parametrosAPI->montaObservacoes($CDFILIAL, $CDLOJA);
          $cardapio = $this->parametrosAPI->montaCardapio($CDFILIAL, $NRCONFTELA, $CDLOJA, $CDCLIENTE, $precosIndexadosPorProduto, $observacoesIndexadasPorProduto);
          $smartPromoProducts = $this->parametrosAPI->montaPromocoes($CDFILIAL, $NRCONFTELA, $CDLOJA, $precosIndexadosPorProduto, $observacoesIndexadasPorProduto);
          if ($cardapio['error'] == false) {
            $cardapio = $this->controllerParamsTAA->buildCardapioForTAA($cardapio['cardapio'], $smartPromoProducts);
            $produtosSugeridos = $this->parametrosAPI->montaSugestaoVenda($CDFILIAL, $NRCONFTELA, $cardapio['codProdutos']);
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('ProdutosSugeridosRepository', $produtosSugeridos));
            // $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('CardapioRepository', $cardapio));
          }
        } else {
          $result = $tabelaPadrao;
        }
      }
      $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('PrepareTAARepository', $result));
    } catch (\Exception $e) {
      $response->addMessage(new Message($e->getMessage()));
    }
  }

  public function printClosingReport(Request\Filter $request, Response $response)
  {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $DTABERCAIX = $params[0]['value'];
      $CDFILIAL = $params[1]['value'];
      $CDCAIXA = $params[2]['value'];
      $CDOPERADOR = $params[3]['value'];
      $NRORG = '1';

      $result = $this->caixaAPI->imprimeRelatorioFechamento($CDFILIAL, $DTABERCAIX, $CDCAIXA, $CDOPERADOR, $NRORG);
      $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('PrintClosingReportRepository', $result));
    } catch (\Exception $e) {
      $response->addMessage(new Message($e->getMessage()));
    }
  }
  private function validateSATParams($printarParams)
  {
    $result = array(
      'error' => false
    );

    if (empty($printarParams['CDATIVASAT'])) {
      $result = array(
        'error' => true,
        'message' => 'CDATIVASAT não parametrizado.'
      );
    } elseif (empty($printarParams['DSSATHOST'])) {
      $result = array(
        'error' => true,
        'message' => 'DSSATHOST não parametrizado.'
      );
    } elseif (empty($printarParams['DSPRINTHOST'])) {
      $result = array(
        'error' => true,
        'message' => 'DSPRINTHOST não parametrizado.'
      );
    }

    return $result;
  }

  private function validateSat($CDATIVASAT, $CDSAT)
  {

    $result = $this->satRequest->setSatType($CDSAT);
    $result = $this->satRequest->consultarSAT();

    if ($result['error'] == false) {
      $result = $this->satRequest->consultarStatusOperacional($CDATIVASAT);
    }

    return $result;
  }
}
