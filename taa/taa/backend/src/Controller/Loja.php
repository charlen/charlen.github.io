<?php
namespace Controller; 
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource\DataSet;
use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
class Loja {
  protected $lojaAPI;
  public function __construct(\Odhen\API\Service\Loja $lojaAPI)
  {
    $this->lojaAPI = $lojaAPI;
  }

  public function fetchLoja(Request\Filter $request, Response $response) {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL = $params[0]['value'];
      $CDLOJA = $params[1]['value'];
      $loja = $this->lojaAPI->fetchLoja($CDFILIAL, $CDLOJA);
      $response->addDataSet(new DataSet('loja', $loja));
    } catch(\Exception $e) {
      $response->setError(new Error($e->getMessage(), $e->getCode()));
      $response->addMessage(new Message($e->getMessage(), Message::TYPE_ERROR));
    }
  }
}