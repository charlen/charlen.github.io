<?php

namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class ImagesManager
{
    protected $parametersService;

    public function __construct(
        \Zeedhi\Framework\DependencyInjection\InstanceManager $instanceManager,
        \Service\ParamsTAA $paramsTAAService
    ) {
        $this->instanceManager = $instanceManager;
        $this->imagePath        = $this->instanceManager->getParameter('IMG_PATH');
        $this->parametersService = $paramsTAAService;
    }
    public function GetImageFromUrl($host, $output_filename)
    {
        
        if (strpos($host, "https") == false) {
            $host = str_replace("http://", "https://", $host);
        }
        $ch = curl_init($host);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // <-- don't forget this

        $raw = curl_exec($ch);
        curl_close($ch);
        if (file_exists($output_filename)) {
        }
        $fp = file_put_contents($output_filename, $raw);
    }

    public function downloadImages(Request\Row $request, Response $response)
    {
        try {
            $params = $request->getRow();
            $NRCONFTELA = $params['NRCONFTELA'];
            $ForceDownload = $params['FORCEDOWNLOAD'];
            $allImages = $this->parametersService->getImages($NRCONFTELA);
            if ($ForceDownload == true || !is_dir($this->imagePath)) {
                try {
                    if (is_dir($this->imagePath) == false) {
                        mkdir($this->imagePath, 777, true);
                    }
                    if ($allImages[0]['FILESERVERURL'] == null && $allImages != NULL) {
                        $urlPrefix = "http://midia.teknisa.com/files/";
                    } else {
                        $urlPrefix = $allImages[0]['FILESERVERURL'];
                    }
                    foreach ($allImages as $value) {
                        if ($value['DSENDEIMG'] != NULL) {
                            $link = $urlPrefix . $value['DSENDEIMG'];
                            $fileNamePrepare = explode("/", $value['DSENDEIMG']);
                            $fileName = $fileNamePrepare[sizeof($fileNamePrepare) - 1];
                            $filePath = $this->imagePath.'/'.$fileName;
                            if($fileName != null){
                                $this->GetImageFromUrl($link, $filePath);
                                $ForceDownload = false;
                            }             
                        }
                    }
                    $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('folderExists', array(
                        'success' => false
                    )));
                } catch (\Exception $e) {
                    $response->setError(new Error($e->getMessage() . 'Erro na criação da pasta', 500));
                }
            } else if ($ForceDownload == false) {
                $response->addMessage(new Message('callQuestion'));
                $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('folderExists', array(
                    'success' => true
                )));
            }
        } catch (\Exception $e) {
            $response->setError(new Error($e->getMessage() . 'Erro ao realizar rotina', 500));
            $response->addMessage(new Message($e->getMessage()));
        }
    }
}
