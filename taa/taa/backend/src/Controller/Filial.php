<?php
namespace Controller; 
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource\DataSet;
use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
class Filial {
  protected $filialAPI;
  public function __construct(\Odhen\API\Service\Filial $filialAPI)
  {
    $this->filialAPI = $filialAPI;
  }

  public function fetchFilial(Request\Filter $request, Response $response) {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL = $params[0]['value'];
      $filial = $this->filialAPI->fetchFilial($CDFILIAL);
      $response->addDataSet(new DataSet('filial', $filial));
    } catch(\Exception $e) {
      $response->setError(new Error($e->getMessage(), $e->getCode()));
      $response->addMessage(new Message($e->getMessage(), Message::TYPE_ERROR));
    }
  }
}