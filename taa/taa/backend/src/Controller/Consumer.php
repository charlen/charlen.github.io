<?php

namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class Consumer {

    protected $entityManager;
    protected $caixaAPI;
    protected $consumerAPI;
    protected $utilAPI;
    protected $impressaoUtil;
    protected $vendaValAPI;
    protected $paramsTAA;
 	public function __construct(
        \Doctrine\ORM\EntityManager $entityManager,
        \Odhen\API\Service\Caixa $caixaAPI,
        \Odhen\API\Service\Consumidor $consumerAPI,
        \Odhen\API\Util\Util $utilAPI,
        \Odhen\API\Lib\ImpressaoUtil $impressaoUtil,
        \Service\ParamsTAA $paramsTAA,
        \Odhen\API\Service\VendaValidacao $vendaValAPI) {
        $this->entityManager = $entityManager;
        $this->caixaAPI = $caixaAPI;
		    $this->consumerAPI = $consumerAPI;
        $this->utilAPI = $utilAPI;
        $this->impressaoUtil = $impressaoUtil;
        $this->paramsTAA = $paramsTAA;
        $this->vendaValAPI = $vendaValAPI;
    }

    public function saveBiometryDevice(Request\Row $request, Response $response) {
        try {
            $CDFILIAL = $request->getRow()['CDFILIAL'];
            $CDCAIXA = $request->getRow()['CDCAIXA'];
            $CDLOJA = $request->getRow()['CDLOJA'];
            $result = $this->consumerAPI->saveBiometryDevice($CDFILIAL, $CDCAIXA, $CDLOJA);
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('getConsumerToCancelRecharge', $result));
        } catch (\Exception $e) {
            $response->setError(new \Zeedhi\Framework\DTO\Response\Error($e->getMessage(), $e->getCode()));
        }
    }

    public function getConsumerToCancelRecharge(Request\Row $request, Response $response) {
        try {
            $consumerParams = $request->getRow();
            $consumerData = $this->consumerAPI->getCDIDCONSUMID($consumerParams);
            if($consumerData['error']) {
                $responseArray = array(
                    'error' => true,
                    'message' => 'Consumidor não encontrado'
                );
            } else {
                $consumer = array_shift($consumerData['consumer']);
                unset($consumer['CDSENHACONS']);
                unset($consumer['CDSENHACONSMD5']);
                $responseArray = array(
                    'error' => false,
                    'consumer' => $consumer
                );
            }
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('getConsumerToCancelRecharge', $responseArray));
        } catch(\Exception $e) {

        }
    }

    public function findConsumer(Request\Row $request, Response $response) {
      try {
        $consumerParams = $request->getRow();
        $biometry = $consumerParams['biometry'];
        if($biometry) {
          $consumer = $this->consumerAPI->getCDIDCONSUMIDBiometry($consumerParams);
        } else {
          $consumer = $this->consumerAPI->getCDIDCONSUMID($consumerParams);
        }
        if(!$consumer['CDSENHACONS']) {
          throw new \Exception('Usuário sem senha cadastrada. Gentileza comparecer ao caixa.');
        }
        unset($consumer['CDSENHACONS']);
        unset($consumer['CDSENHACONSMD5']);
        $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('consumer', $consumer));
      } catch (\Exception $e) {
        $consumer = array (
          'message' => $e->getMessage()
        );
        $response->setError(new \Zeedhi\Framework\DTO\Response\Error($e->getMessage(), $e->getCode()));
      }
    }

    public function validateConsumer(Request\Row $request, Response $response) {
        try {
            $consumerParams = $request->getRow();

            $consumerValidation = $this->consumerAPI->getCDIDCONSUMID($consumerParams);
            if(!$consumerValidation['CDSENHACONS']) {
              throw new \Exception('Usuário sem senha cadastrada. Gentileza comparecer ao caixa.');
            }
            $arrayValues = json_decode($consumerParams['CDSENHACONSMD5'], true);
            $ARRAYsenha = array();
            $valuesLength = count($arrayValues);
            $arrayWithZeroes = [];
            for($i = $valuesLength; $i > 0; $i--) {
                array_push($arrayWithZeroes, 0);
            }
            $this->doTheFuckingShit($arrayWithZeroes, $valuesLength - 1, $valuesLength, $ARRAYsenha, $arrayValues);
            $validate = $this->consumerAPI->decryptDelphi($consumerValidation['CDSENHACONS']);
            foreach($ARRAYsenha as $senha){
                if($validate == $senha) {
                    $consumer = array(
                        'error' => false,
                        'consumer' => $consumerValidation
                    );
                    break;
                } else {
                    $consumer = array (
                        'error' => true,
                        'message' => 'Senha inválida.'
                    );
                }
            }
        	$response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('ValidateConsumer', $consumer));
        } catch (\Exception $e) {
            $consumer = array (
                'error' => true,
                'message' => $e->getMessage()
            );
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('ValidateConsumer', $consumer));
        }
    }

    private function doTheFuckingShit(&$arrayWithZeroes, $index, $valuesLength, &$ARRAYsenha, $arrayValues) {
        $senha = '';
        for($i = 0; $i < $valuesLength; $i++) {
            $aux = array_values($arrayValues[$i]);
            $senha .= array_values($arrayValues[$i])[$arrayWithZeroes[$i]];
        }
        array_push($ARRAYsenha, $senha);
        do {
            if($arrayWithZeroes[$index] == 1) {
                $arrayWithZeroes[$index] = 0;
                $this->doTheFuckingShit($arrayWithZeroes, ($index - 1), $valuesLength, $ARRAYsenha, $arrayValues);
            } else {
                $arrayWithZeroes[$index] = 1;
                $senha = '';
                for($i = 0; $i < $valuesLength; $i++) {
                    $aux = array_values($arrayValues[$i]);
                    $senha .= array_values($arrayValues[$i])[$arrayWithZeroes[$i]];
                }
                array_push($ARRAYsenha, $senha);
            }
            $sum = array_sum($arrayWithZeroes);
            $index = ($valuesLength - 1);
        } while ($valuesLength != $sum);
    }

    public function getConsumerSaldoCons(Request\Row $request, Response $response) {
        try {
            $params = $request->getRow();
             $consumerSaldoCons = $this->consumerAPI->getSaldocons($params['CDCLIENTE'],$params['CDCONSUMIDOR']);
             $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('ConsumerSaldoCons', $consumerSaldoCons));
        } catch(\Exception $e) {
            throw $e;
        }
    }

    public function doRechargeFamily(Request\Row $request, Response $response) {
        try {
            $params = $request->getRow();
            $filialData = json_decode($params['filial'], true);
            $paymentData = json_decode($params['paymentData'], true);
            $consumer = json_decode($params['consumer'], true);
            $families = json_decode($params['families'], true);
            $dadosTransacao = json_decode($params['dataTransaction'], true);
            $nonZeroValues = array();
            $this->entityManager->getConnection()->beginTransaction();
            foreach ($families as $chargeValue){
                if (floatval(str_replace(',', '.', $chargeValue['toAdd'])) > 0){
                    $chargeValue['toAdd'] = floatval(str_replace(',', '.', $chargeValue['toAdd']));
                    array_push($nonZeroValues, $chargeValue);
                }
            }
            $families = $nonZeroValues;
            $resultCredit = array();
            $dadosTransacao['IDTIPORECE'] = $this->paramsTAA->getIdtiporece($dadosTransacao['CDTIPORECE'], $filialData['NRORG']);
            $TIPORECE = $this->buildPayment($dadosTransacao, $families, $paymentData['DSBUTTON']);
            $date = new \DateTime('NOW');
            $NRSEQMOVEXT = 1;
            foreach($families as $family) {
                $NRDEPOSICONS = $date->format('ymdHi');
                $result = $this->caixaAPI->insereMovimentacao($TIPORECE[0], 0, $filialData['CDFILIAL'], $filialData['CDCAIXA'], $filialData['CDOPERADOR'], $filialData['NRORG']);
                $returnCredita = $this->consumerAPI->creditaSaldo($consumer['CDCLIENTE'], $consumer['CDCONSUMIDOR'], $family['CDFAMILISALD'], $NRSEQMOVEXT++, $TIPORECE[0]['CDTIPORECE'], $filialData['CDFILIAL'], $filialData['CDCAIXA'], $family['toAdd'], $NRDEPOSICONS, $result['NRSEQUMOVI'], $result['DTABERCAIX'], 'TOTEM - RECARGA CAIXA '.$filialData['CDCAIXA']);
                $returnCredita['NRDEPOSICONS'] = $NRDEPOSICONS;
                $returnCredita['VRSALDCONFAM'] = $family['toAdd'];
                $returnCredita['CDFAMILISALD'] = $family['CDFAMILISALD'];
                array_push($resultCredit, $returnCredita);
            }
            $this->entityManager->getConnection()->commit();
            $statusprint = $this->impressaoUtil->printPersonalCreditVoucher($filialData['CDFILIAL'], $filialData['CDCAIXA'], $resultCredit, $TIPORECE, 0);
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('statusRecharge', $statusprint));
        } catch (\Exception $e) {
            if ($this->entityManager->getConnection()->isTransactionActive()) {
                $this->entityManager->getConnection()->rollBack();
            }
            throw $e;
        }
    }

    private function buildPayment($transactionData, $families, $DSBUTTON){
        $paymentArray = array();
        foreach ($families as $family) {
            $payment = array(
                'CDTIPORECE'      => $transactionData['CDTIPORECE'],
                'VRMOVIVEND' 	  => $family['toAdd'],
                'CDFAMILISALD' 	  => $family['CDFAMILISALD'],
                'DSBUTTON' 	      => $DSBUTTON,
                'IDTIPORECE' 	  => $transactionData['IDTIPORECE']
            );
            array_push($paymentArray, $payment);
        }
        return $paymentArray;

    }

    public function cancelPersonalCredit(Request\Row $request, Response $response){
        try {
            $params = $request->getRow();
            $depositos = $this->caixaAPI->buscaNumeroDeposito($params['CDCLIENTE'], $params['CDCONSUMIDOR'], $params['NRDEPOSICONS'], $params['NRSEQMOVCAIXA']);
            if (empty($depositos)){
                $response->addMessage(new Message("Operação bloqueada. Número do depósito não encontrado para o consumidor informado."));
            } else {
                $deposito = $depositos[0];
                // Verifica se o depósito já foi cancelado.
                $NRDEPOSICONS = $this->vendaValAPI->verificaCancelamento($deposito['CDCLIENTE'], $deposito['CDCONSUMIDOR'], $deposito['CDFAMILISALD'], $deposito['NRDEPOSICONS'], $deposito['NRSEQMOVCAIXA']);
                if (!empty($NRDEPOSICONS)) throw new \Exception("Operação bloqueada. O número do depósito informado já foi cancelado. Favor verificar.");

                // Verifica se o depósito foi realizado dentro da abertura atual do caixa.
                $estadoCaixa = $this->caixaAPI->getEstadoCaixa($params['CDFILIAL'], $params['CDCAIXA']);
                if ($deposito['DTABERCAIX'] != $estadoCaixa['DTABERCAIX']){
                    throw new \Exception("Cancelamento de crédito não permitido. Este crédito foi efetuado em outra abertura.");
                }
                $this->entityManager->getConnection()->beginTransaction();

                $cancelDetails = $this->consumerAPI->cancelaSaldo($deposito['CDCLIENTE'], $deposito['CDCONSUMIDOR'], $deposito['CDFAMILISALD'], $deposito['CDTIPORECE'], $deposito['CDFILIAL'], $deposito['CDCAIXA'], $deposito['VRMOVEXTCONS'], $deposito['NRDEPOSICONS'], $deposito['NRSEQMOVCAIXA'], $deposito['DTABERCAIX'], $params['NRORG']);
                $this->caixaAPI->cancelaMovimentacao($deposito['CDFILIAL'], $deposito['CDCAIXA'], $deposito['DTABERCAIX'], $deposito['NRSEQMOVCAIXA']);

                $this->entityManager->getConnection()->commit();

                $printerResult = $this->impressaoService->printCancelCreditVoucher($deposito['CDFILIAL'], $deposito['CDCAIXA'], $deposito['NRDEPOSICONS'], $cancelDetails, $deposito['VRMOVEXTCONS'], $deposito['NMTIPORECE']);

                $message = 'Cancelamento efetuado com sucesso.';
                if ($printerResult['error']){
                    $message .= '<br>Não possível imprimir o comprovante.<br><br>' . $printerResult['message'];
                    $cancelDetails['dadosImpressao'] = null;
                }
                else {
                    $cancelDetails['dadosImpressao'] = $printerResult['message'];
                }

                $response->addMessage(new Message($message));
                $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('CancelCreditRepository', $cancelDetails));
            }
        } catch (\Exception $e){
            if ($this->entityManager->getConnection()->isTransactionActive()) {
                $this->entityManager->getConnection()->rollBack();
            }
            $arrayReturn = array(
                'error' => true,
                'message' => $e->getMessage()
            );
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('CancelCreditRepository', $arrayReturn));
        }
    }

    public function getDeposiconsData(Request\Row $request, Response $response) {
        try {
            $params = $request->getRow();
            $NRDEPOSICONS = $params['NRDEPOSICONS'];
            $CDFILIAL = $params['CDFILIAL'];
            $depositos = $this->caixaAPI->buscaNumeroDeposito($params['CDCLIENTE'], $params['CDCONSUMIDOR'], $params['NRDEPOSICONS'], null);
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('DEPOSICONSDATA', $DEPOSICONSDATA));
        } catch(\Exception $e) {
            $arrayReturn = array(
                'error' => true,
                'message' => $e->getMessage()
            );
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('DEPOSICONSDATA', $arrayReturn));
        }
    }

    public function saveNewPassword(Request\Row $request, Response $response) {
        try {
            $params = $request->getRow();
            $CDIDCONSUMID = $params['CDIDCONSUMID'];
            $CDSENHACONS = $params['CDSENHACONS'];
            $NEWCDSENHACONS = $this->consumerAPI->encryptDelphi($CDSENHACONS);
            $this->consumerAPI->saveCDSENHACONS($CDIDCONSUMID, $NEWCDSENHACONS);
            $arrayReturn = array(
                'error' => false
            );
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('UPDATE_PASSWORD', $arrayReturn));
        } catch(\Exception $e) {
            $arrayReturn = array(
                'error' => true,
                'message' => $e->getMessage()
            );
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('UPDATE_PASSWORD', $arrayReturn));
        }

    }
}
