<?php

namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class TEF {

    protected $entityManager;
    protected $tefAPI;
    protected $tefServiceAPI;
	protected $precoAPI;
    protected $utilAPI;
    protected $paramsTAAService;
    protected $com;

 	public function __construct(
        \Doctrine\ORM\EntityManager $entityManager,
        \Odhen\API\Remote\TEF\TEF $tefAPI,
        \Odhen\API\Service\TEF $tefServiceAPI,
        \Odhen\API\Service\Preco $precoAPI,
        \Odhen\API\Util\Util $utilAPI) {

        $this->entityManager = $entityManager;
		$this->tefAPI = $tefAPI;
		$this->tefServiceAPI = $tefServiceAPI;
		$this->precoAPI = $precoAPI;
        $this->utilAPI = $utilAPI;
	}

    public function performTransaction(Request\Row $request, Response $response) {
        try {
            $row = $request->getRow();
            $totalSale = self::formatTotalSale($row['totalSale']);
            $tefResponse = self::performTefIntegration($row, $totalSale);

        	$response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('TEFTransactionRepo', $tefResponse));
        } catch (\Exception $e) {
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('TEFTransactionRepo', array(
                'error' => true,
                'finishedTransaction' => true,
                'message' => utf8_decode($e->getMessage())
            )));
        }
    }

    private function performTefIntegration($row, $totalSale) {
        try {
            $tefResponse = array('error' => false);
            if ($row['simulateTef']) {
                $tefResponse = self::getSimulationTefData();
            } else {
                if (!$row['isContinuation']) {
                    $tefResponse = $this->tefAPI->configuraTransacaoTef($row['CDFILIAL'], $row['CDCAIXA']);
                    if ($tefResponse['error'] == false) {
                        $tefResponse = $this->tefAPI->iniciaTransacaoTef($row['IDTIPORECE'], $totalSale, $row['CDOPERADOR']);
                        if ($tefResponse['error']) {
                            $tefResponse['finishedTransaction'] = true;
                        }
                    } else {
                        $tefResponse['finishedTransaction'] = true;
                    }
                }

                if (!$tefResponse['error']) {
                    $tefResponse = $this->tefAPI->continuaTransacaoTef($totalSale, $row['IDTIPORECE'], $row['CDTIPORECE'], null, null, $row['CDFILIAL'], $row['CDCAIXA']);
                    if ($tefResponse['error'] == false) {
                        if($tefResponse['finishedTransaction']) {
                            $CDNSUHOSTTEF = $tefResponse['CDNSUHOSTTEF'];
                            $comprovanteTef = $tefResponse['COMPROVANTETEF'];
                            $CDTIPORECE = $tefResponse['CDTIPORECE'];
                            // $tefResponse = $this->tefAPI->finalizaTransacao($com);
                            if ($tefResponse['error'] == false) {
                                $IDSENHACUP = self::getIdCouponPassword($row['CDFILIAL'], $row['CDLOJA'], $row['CDCAIXA']);
                                $tefResponse['finishedTransaction'] = true;
                                $tefResponse['message'] = 'Transação completa com sucesso.';
                                $tefResponse['dados'] = array(
                                    'CDNSUHOSTTEF' => trim($CDNSUHOSTTEF),
                                    'CDTIPORECE' => $CDTIPORECE,
                                    'comprovanteTef' => $comprovanteTef,
                                    'IDSENHACUP' => $IDSENHACUP['IDSENHACUP']
                                );
                            }
                        }
                    }
                }
            }
        	return $tefResponse;
        } catch (\Exception $e) {
            return array(
                'error' => true,
                'finishedTransaction' => true,
                'message' => utf8_decode($e->getMessage())
            );
        }
    }

    private function formatTotalSale($totalSale) {
    	$totalSale = (string) $totalSale;
    	if (strpos($totalSale, '.') == false && strpos($totalSale, ',') == false) {
    		$totalSale .= ',00';
        } else if(strpos($totalSale, ',') === strlen($totalSale) - 1 ) {
            $totalSale = str_pad($totalSale, strlen($totalSale) + 2, '0', STR_PAD_RIGHT);
        } else if(strpos($totalSale, '.') == true) {
            $totalSale = number_format($totalSale, 2);
            $totalSale = str_replace('.', ',', $totalSale);
        }
    	return $totalSale;
    }

    public function getReceCapptaTransaction(Request\Row $request, Response $response) {
        try {
            $row = $request->getRow();
            $cardBrandCode = $row['cardBrandCode'];
            $administrativeCode   = $row['administrativeCode'];
            $CDTIPORECE = self::getTransactionType($cardBrandCode);
            $capptaTransactionData['dados'] = array(
                'CDNSUHOSTTEF'=> $administrativeCode,
                'CDTIPORECE'=> $CDTIPORECE,
                'IDSENHACUP'=> 'S'
            );
        	$response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('CapptaTransaction', $capptaTransactionData));
        } catch (\Exception $e) {
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('CapptaTransaction', array(
                'error' => true,
                'finishedTransaction' => true,
                'message' => utf8_decode($e->getMessage())
            )));
        }
    }

    // @toDo: Remove this and send this method do a service
    private function getIdCouponPassword($CDFILIAL, $CDLOJA, $CDCAIXA) {
        $params = array(
            'CDFILIAL' => $CDFILIAL,
            'CDCAIXA' => $CDCAIXA,
            'CDLOJA' => $CDLOJA
        );

        return $this->entityManager->getConnection()->fetchAssoc(self::GET_ID_COUPOM_PASSWORD, $params);
    }

    const GET_ID_COUPOM_PASSWORD = "
        SELECT IDSENHACUP
        FROM CAIXA
        WHERE CDFILIAL = :CDFILIAL
            AND CDLOJA = :CDLOJA
            AND CDCAIXA = :CDCAIXA
    ";

    private function getTransactionType($cardBrandCode) {
        $params = array(
            'CDBANCARTCR' => $cardBrandCode
        );
        $CDTIPORECE = $this->entityManager->getConnection()->fetchAssoc(self::GET_TRANSACTION_TYPE, $params);
        return empty($CDTIPORECE) ? '008' : $CDTIPORECE;
    }

    const GET_TRANSACTION_TYPE = "
        SELECT CDTIPORECE
          FROM TIPORECE
         WHERE CDBANCARTCR = :CDBANCARTCR
    ";

    public function performCancellation(Request\Row $request, Response $response) {
        try {
            $row = $request->getRow();
            if(!$row['isContinuation']) {
                $tefResponse = $this->tefAPI->configuraTransacaoTef($row['CDFILIAL'], $row['CDCAIXA']);
                if($tefResponse['error']) {
                    throw new \Exception($tefResponse['message']);
                }
            }
            if(!$row['isContinuation']) {
                $tefResponse = $this->tefAPI->iniciaCancelamentoTef($row['TYPECANCELLATION'], self::formatTotalSale($row['VALORVENDA']), $row['CDOPERADOR']);
                if($tefResponse['error']) {
                    throw new \Exception($tefResponse['message']);
                } else {
                    $row['isContinuation'] = true;
                }
            }

            if($row['isContinuation']) {
                $tefResponse = $this->tefAPI->continuaTransacaoTef(self::formatTotalSale($row['VALORVENDA']), $row['TYPECANCELLATION'], null, str_replace("/", "", $row['DTVENDA']),  $row['DOCTEF'], $row['CDFILIAL'], $row['CDCAIXA']);
                if($tefResponse['error']) {
                    throw new \Exception($tefResponse['message']);
                }
            }

            if(!$tefResponse['error'] && $tefResponse['finishedTransaction']) {
                    $CDNSUHOSTTEF = $tefResponse['CDNSUHOSTTEF'];
                    $comprovanteTef = $tefResponse['COMPROVANTETEF'];
                    $CDTIPORECE = $tefResponse['CDTIPORECE'];
                    if ($tefResponse['error'] == false) {
                        $tefResponse['finishedTransaction'] = true;
                        $tefResponse['message'] = 'Transação completa com sucesso.';
                        $tefResponse['dados'] = array(
                            'comprovanteTef' => $comprovanteTef,
                        );
                    }
                $arrTiporece = array(
                    array(
                        'STLPRIVIA' => $tefResponse['COMPROVANTETEF'] ? $tefResponse['COMPROVANTETEF'] : 'SIMULAÇÃO TEF'
                    )
                );
                // $respostaImpressaoTEF = $this->tefServiceAPI->imprimeCupomTEF($arrTiporece, $row['CDFILIAL'], $row['CDCAIXA']);
            }
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('TEFCancellationRepo', $tefResponse));

        } catch (\Exception $e) {
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('TEFCancellationRepo', array(
                'error' => true,
                'finishedTransaction' => true,
                'message' => $e->getMessage()
            )));
        }
    }
}
