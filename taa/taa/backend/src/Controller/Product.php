<?php
namespace Controller;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource\DataSet;
use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
class Product {
  protected $precoAPI;
  protected $produtoAPI;
  protected $observacaoAPI;
  protected $instanceManager;
  public function __construct(\Odhen\API\Service\Preco $precoAPI,
    \Odhen\API\Service\Produto $produtoAPI,
    \Odhen\API\Service\Observacao $observacaoAPI,
    \Zeedhi\Framework\DependencyInjection\InstanceManager $instanceManager)
  {
    $this->precoAPI = $precoAPI;
    $this->produtoAPI = $produtoAPI;
    $this->observacaoAPI = $observacaoAPI;
    $this->instanceManager = $instanceManager;
    $this->imagePath        = $this->instanceManager->getParameter('IMG_PATH');
  }

  public function fetchProducts(Request\Filter $request, Response $response) {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL = $params[0]['value'];
      $CDCLIENTE = $params[1]['value'];
      $CDLOJA = $params[2]['value'];
      $NRCONFTELA = $params[3]['value'];
      $CDTIPOCONS = $params[4]['value'];

      $priceTable = $this->precoAPI->buscaTabelaPadrao($CDFILIAL, $CDCLIENTE, $CDLOJA);
      $observations = $this->observacaoAPI->fetchObservations($CDFILIAL, $CDLOJA, $NRCONFTELA);
      $menuGroups = $this->produtoAPI->fetchGroups($priceTable['CDFILIAL'], $NRCONFTELA);
      $sugestionProducts= [];
      $SUGGESTIONS = array(
        "IDTPBUTTON" => "2",
        "IDTPBUTONAUX" => "0",
        "NRBUTTON" => "00",
        "NRBUTTONAUX" => "0",
        "DSBUTTON" => "SUGESTÕES",
        "CDIDENTBUTON" => null,
        "NRCOLORTEXT" => "16777215.000",
        "NRCOLORBACK" => "8421631.000",
        "NRPGCONFTELA" => "1",
        "NRPGCONFTAUX" => "0",
        "DSMESSAGEBUT" => null,
        "DSIMAGEMBUT" => null,
        "DSENDEIMG" => "./../../../IMAGES/5d122980b3131.png",
        "DSBUTTONINGLES" => "SUGGESTIONS",
        "DSBUTTONESPANH" => "SUGGESTIONS"
      );
      array_unshift($menuGroups, $SUGGESTIONS);



      $menuSubgroups = $this->produtoAPI->fetchSubgroups($priceTable['CDFILIAL'], $NRCONFTELA);
      $products = $this->produtoAPI->fetchProducts($priceTable, $NRCONFTELA, $CDLOJA);
      $promoGroups = $this->produtoAPI->fetchPromoGroups($priceTable, $NRCONFTELA, $CDLOJA);
      $localPromoGroups = $this->produtoAPI->fetchLocalPromoGroups($priceTable, $NRCONFTELA, $CDLOJA);
      $prices = $this->precoAPI->fetchPrecos($priceTable, $CDLOJA, $NRCONFTELA, $CDTIPOCONS);
      $promoProducts = $this->produtoAPI->fetchPromoProducts($priceTable, $NRCONFTELA, $CDLOJA);

      $mostSoldProducts = $this->produtoAPI->fetchMostSoldProducts(300); // Pode ser passado o número de dias a ser considerado a partir da data atual
      $productsCds = array();
      foreach($products as $product){
        //Lista de codigos para buscar sugestão
        $productsCds[] = $product['CDPRODUTO'];

        // Verificar se esse produto faz parte do sugeridos, se for, separa para incluir ele no grupo sugeridos
        if($this->isMostSold($mostSoldProducts, $product)){
          $myProduct = $product;
          $myProduct['NRBUTTON'] = '00';

          $myProduct['NRBUTTONAUX'] = '00';
          $sugestionProducts[$product['CDPRODUTO']] = $myProduct; //Desse modo evito um foreach explicito para ordenar
        }
      }

      //var_dump($sugestionProducts);

      //Inserindo os ítens ordenados no grupo
      foreach($mostSoldProducts as $product){
        if(isset($sugestionProducts[$product['cdproduto']])){ // Evita erro caso o produto esteja desabilitado
          $sugestionProducts[$product['cdproduto']]['IDTPBUTONAUX'] = '2';
          array_push($products, $sugestionProducts[$product['cdproduto']]);          
        }
      }

      foreach ($prices as &$price) {
        if($price['IDPERVALORPR'] == 'V' && $price['IDDESCACREPR'] == 'D') {
          $price['VRPRECITEM'] = $price['VRPRECITEM'] - $price['DIFF_PRICE'];
        }

        if($price['IDPERVALORPR'] == 'V' && $price['IDDESCACREPR'] == 'A') {
          $price['VRPRECITEM'] = $price['VRPRECITEM'] + $price['DIFF_PRICE'];
        }

        if($price['IDPERVALORPR'] == 'P' && $price['IDDESCACREPR'] == 'D') {
          $price['VRPRECITEM'] = $price['VRPRECITEM'] - ($price['VRPRECITEM'] * $price['DIFF_PRICE']) / 100;
        }

        if($price['IDPERVALORPR'] == 'P' && $price['IDDESCACREPR'] == 'A') {
          $price['VRPRECITEM'] = $price['VRPRECITEM'] + ($price['VRPRECITEM'] * $price['DIFF_PRICE']) / 100;
        }
      }

      foreach($observations as &$product) {
        if($product['IDCONTROLAOBS'] === 'A') {
          $product['QTPRODVEND'] = 0;
          $keyPrice = array_search($product['CDPRODUTO'], array_column($prices, 'CDPRODUTO'));
          if($keyPrice) {
            $product['PRICE'] = $prices[$keyPrice];
          }
        }
      }

      foreach($products as &$product){
        $product['embalagem'] = Array();
        $product['embalagem']['price'] = 3.25;
        $product['embalagem']['items'] = Array();

        array_push($product['embalagem']['items'],  Array(
            "NMPRODUTO" => "CANUDO",
            "CDPRODUTO" => "3000000000125",
            "TOPAY" => false,
            "PRICE" => 0
         ));

        array_push($product['embalagem']['items'],Array(
              "NMPRODUTO" => "PACOTE M",
              "CDPRODUTO" => "3000000000126",
              "TOPAY" => true,
              "PRICE" => 3.25
         ));
      }



      foreach($menuGroups as &$product) {
        $fileNamePrepare = explode("/", $product['DSENDEIMG']);
        $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
        if($fileName == null){
          $product['DSENDEIMG'] = null;
        } else {
          $product['DSENDEIMG'] = $this->imagePath . "/" . $fileName;
        }       
      }

      foreach($products as &$product) {
        $result = array_values(array_filter($observations, function($observation) use($product) {
          return $observation['PARENT'] == $product['CDPRODUTO'];
        }));
        $product['OBSERVATIONS'] = $result;
      }

      foreach($menuSubgroups as &$product) {
        $fileNamePrepare = explode("/", $product['DSENDEIMG']);
        $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
        
      }



      foreach($products as &$product) {
        $product['IDTIPOCOMPPROD'] === '3' ? $product['PRODUCT_TYPE'] = 'CP' : $product['PRODUCT_TYPE'] = 'N';
        $keyPrice = array_search($product['CDPRODUTO'], array_column($prices, 'CDPRODUTO'));
        $product['PRICE'] = $prices[$keyPrice];
        $product['QTPRODVEND'] = 0;
        $fileNamePrepare = explode("/", $product['DSENDEIMG']);
        $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
        if($fileName == null){
          $product['DSENDEIMG'] = null;
        } else {
          $product['DSENDEIMG'] = $this->imagePath . "/" . $fileName;
        }
      }



      foreach($menuSubgroups as &$product) {
        $fileNamePrepare = explode("/", $product['DSENDEIMG']);
        $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
        if($fileName == null){
          $product['DSENDEIMG'] = null;
        } else {
          $product['DSENDEIMG'] = $this->imagePath . "/" . $fileName;
        }
      }

      foreach($promoProducts as &$product) {
        $product['PRODUCT_TYPE'] = 'CC';
        $product['QTPRODVEND'] = 0;
        $keyPrice = array_search($product['CDPRODUTO'], array_column($prices, 'CDPRODUTO'));
        $product['PRICE'] = $prices[$keyPrice];
        $fileNamePrepare = explode("/", $product['DSENDEIMG']);
        $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
        if($fileName == null){
          $product['DSENDEIMG'] = null;
        } else {
          $product['DSENDEIMG'] = $this->imagePath . "/" . $fileName;
        }
      }

      //Tratamento das sugestões
      $productSuggestions = $this->produtoAPI->fetchProductsSuggestions($CDFILIAL, $NRCONFTELA, $productsCds);

      foreach($products as $product){
        foreach($productSuggestions as &$suggestion){
          if($product['CDPRODUTO'] == $suggestion['CDSUGESTAOITEM']){
            $suggestion['produto'] = $product;
          }
        }
      }

      foreach($menuGroups as $menuGroup) {
        foreach($productSuggestions as &$suggestion){
          if($menuGroup['NRPGCONFTELA'].$menuGroup['NRBUTTON']  == $suggestion['CDSUGESTAOITEM']){
            $suggestion['grupo'] = $menuGroup;
          }
        }
      }

      $suggestionsMap = $this->orderSuggestions($productSuggestions);

      foreach($products as &$product){
        if(isset($suggestionsMap[$product['CDPRODUTO']])){
          $product['suggestions'] = $suggestionsMap[$product['CDPRODUTO']];
        }
      }

      $dataset = array(
      'products' => $products,
      'groups' => $menuGroups,
      'subGroups' => $menuSubgroups,
      'promoProducts' => $promoProducts,
      'priceTable' => $priceTable,
      'prices' => $prices,
      'observations' => $observations,
      'promoGroups' => $promoGroups,
      'localPromoGroups' => $localPromoGroups,
      'observations' => $observations,
      'mostSoldProducts' => $mostSoldProducts,
      'suggestionsMap' => $suggestionsMap
      );
      $response->addDataSet(new DataSet('produto', $dataset));
    } catch (\Exception $e) {
      $response->setError(new Error($e->getMessage(), $e->getCode()));
      $response->addMessage(new Message($e->getMessage(), Message::TYPE_ERROR));
    }
  }

  private function orderSuggestions($sugestions){
    $suggestionsProductType = [];

      foreach( $sugestions as $sugestion){
         if(!isset($suggestionsProductType[$sugestion['CDPRODUTO']])){
            $suggestionsProductType[$sugestion['CDPRODUTO']] = [];
         }

        //Sugestão de produto
         if( $sugestion['IDSUGESTAOTIPO'] == 1){
            if(!isset($suggestionsProductType[$sugestion['CDPRODUTO']]["produto"])){
              $suggestionsProductType[$sugestion['CDPRODUTO']]["produto"] = [];
            }
            array_push($suggestionsProductType[$sugestion['CDPRODUTO']]["produto"], $sugestion);
         }

         //Sugestão de grupo
         if( $sugestion['IDSUGESTAOTIPO'] == 2){
          if(!isset($suggestionsProductType[$sugestion['CDPRODUTO']]["grupo"])){
            $suggestionsProductType[$sugestion['CDPRODUTO']]["grupo"] = [];
          }
          array_push($suggestionsProductType[$sugestion['CDPRODUTO']]["grupo"], $sugestion);
         }

         //Sugestão de tamanho
         if( $sugestion['IDSUGESTAOTIPO'] == 3){
          if(!isset($suggestionsProductType[$sugestion['CDPRODUTO']]["tamanho"])){
            $suggestionsProductType[$sugestion['CDPRODUTO']]["tamanho"] = [];
          }
          array_push($suggestionsProductType[$sugestion['CDPRODUTO']]["tamanho"], $sugestion);
         }

         //Sugestão de sabor
         if( $sugestion['IDSUGESTAOTIPO'] == 4){
          if(!isset($suggestionsProductType[$sugestion['CDPRODUTO']]["sabor"])){
            $suggestionsProductType[$sugestion['CDPRODUTO']]["sabor"] = [];
          }
          array_push($suggestionsProductType[$sugestion['CDPRODUTO']]["sabor"], $sugestion);
         }


         //Sugestão de combo
         if( $sugestion['IDSUGESTAOTIPO'] == 5){
          if(!isset($suggestionsProductType[$sugestion['CDPRODUTO']]["combo"])){
            $suggestionsProductType[$sugestion['CDPRODUTO']]["combo"] = [];
          }
          array_push($suggestionsProductType[$sugestion['CDPRODUTO']]["combo"], $sugestion);
         }
      }
      return $suggestionsProductType;
  }

  private function isMostSold($mostSoldProducts, $candidate){
     $is = false;
     foreach( $mostSoldProducts as $product){
       if( isset($candidate['CDPRODUTO']) && $product['cdproduto'] == $candidate['CDPRODUTO']){
         $is = true;
         continue;
       }
     }
     return $is;
  }
}
