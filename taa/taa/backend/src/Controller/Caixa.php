<?php
namespace Controller; 
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource\DataSet;
use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
class Caixa {
  protected $caixaAPI;
  public function __construct(\Odhen\API\Service\Caixa $caixaAPI)
  {
    $this->caixaAPI = $caixaAPI;
  }

  public function fetchCaixa(Request\Filter $request, Response $response) {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL = $params[0]['value'];
      $CDCAIXA = $params[1]['value'];
      $NRORG = $params[2]['value'];
      $caixa = $this->caixaAPI->fetchCaixa($CDFILIAL, $CDCAIXA);
      $status = $this->caixaAPI->getEstadoCaixa($CDFILIAL, $CDCAIXA, $NRORG);
      $dataOpening = $this->caixaAPI->getUltimaAberturaCaixa($CDFILIAL, $CDCAIXA);
      $caixa['status'] = $status;
      if($dataOpening) {
        $status['DTABERCAIX'] = $dataOpening->format('d/m/Y H:i:s');
      }
      $response->addDataSet(new DataSet('caixa', $caixa));
    } catch(\Exception $e) {
      $response->setError(new Error($e->getMessage(), $e->getCode()));
      $response->addMessage(new Message($e->getMessage(), Message::TYPE_ERROR));
    }
  }
}