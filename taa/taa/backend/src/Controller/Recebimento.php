<?php
namespace Controller; 
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;
use Zeedhi\Framework\DataSource\DataSet;
use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
class Recebimento {
  protected $recebimentoAPI;
  public function __construct(\Odhen\API\Service\Recebimento $recebimentoAPI)
  {
    $this->recebimentoAPI = $recebimentoAPI;
  }

  public function fetchReceipts(Request\Filter $request, Response $response) {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL = $params[0]['value'];
      $CDCAIXA = $params[1]['value'];
      $receipts = $this->recebimentoAPI->fetchReceipts($CDFILIAL, $CDCAIXA);
      $response->addDataSet(new DataSet('recebimento', $receipts));
    } catch(\Exception $e) {
      $response->setError(new Error($e->getMessage(), $e->getCode()));
      $response->addMessage(new Message($e->getMessage(), Message::TYPE_ERROR));
    }
  }
}