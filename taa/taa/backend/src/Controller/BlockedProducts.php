<?php

namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class  BlockedProducts {
    protected $paramsTAAService;

    public function __construct(\Service\ParamsTAA $paramsTAAService) {
        $this->paramsTAAService = $paramsTAAService;
    }

    public function getBlockedProducts(Request\Filter $request, Response $response) {
        try {

            $params = $request->getFilterCriteria()->getConditions();
            $CDFILIAL = $params[0]['value'];
            $CDLOJA = $params[1]['value'];

            $blockedProducts = $this->paramsTAAService->getBlockedProducts($CDFILIAL, $CDLOJA);
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('BlockedProductsRepository', $blockedProducts));
        } catch (\Exception $e) {
            $response->addMessage(new Message($e->getMessage()));
        }

        return $response;
    }

    public function handleBlockProduct(Request\Filter $request, Response $response) {
        try {
            $params = $request->getFilterCriteria()->getConditions();
            $hasToBlock = $params[0]['value'];
            $CDFILIAL = $params[1]['value'];
            $CDLOJA = $params[2]['value'];
            $CDOPERADOR = $params[3]['value'];
            $CDPRODUTO = $params[4]['value'];

            $blockProduct = $this->paramsTAAService->handleBlockProduct($hasToBlock, $CDFILIAL, $CDLOJA, $CDOPERADOR,  $CDPRODUTO);
            $blockedProducts = $this->paramsTAAService->getBlockedProducts($CDFILIAL, $CDLOJA);

            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('BlockProductsRepository', array('error' => false)));
            $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('BlockedProductsRepository', $blockedProducts));
        } catch (\Exception $e) {
            $response->addMessage(new Message($e->getMessage()));
        }
    }
}


