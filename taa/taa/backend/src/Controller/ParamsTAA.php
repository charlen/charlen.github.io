<?php

namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class ParamsTAA
{

  protected $parametrosAPI;
  protected $operadorAPI;
  protected $paramsTAAService;
  protected $caixaAPI;
  protected $loginAPI;
  protected $instanceManager;

  public function __construct(
    \Odhen\API\Service\Parametros $parametrosAPI,
    \Odhen\API\Service\Login $loginAPI,
    \Odhen\API\Service\Operador $operadorAPI,
    \Service\ParamsTAA $paramsTAAService,
    \Odhen\API\Service\Caixa $caixaAPI,
    \Zeedhi\Framework\DependencyInjection\InstanceManager $instanceManager
  ) {

    $this->parametrosAPI = $parametrosAPI;
    $this->operadorAPI = $operadorAPI;
    $this->paramsTAAService = $paramsTAAService;
    $this->caixaAPI = $caixaAPI;
    $this->loginAPI = $loginAPI;
    $this->instanceManager = $instanceManager;
    $this->imagePath        = $this->instanceManager->getParameter('IMG_PATH');
  }

  public function buildCardapioForTAA($cardapioAPI, $smartPromoProducts)
  {
    $grupos = array();
    $subGrupos = array();
    $produtos = array();
    $codProdutos = array();

    foreach($smartPromoProducts as &$promoProduct) {
      foreach($promoProduct as &$grupromoc){
        //imagem do grupo no index DSENDEIMGGRUPROMOC
        $fileNamePrepare = explode("/", $grupromoc['grupo']['DSENDEIMGGRUPROMOC']);
        $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
        $filePath = $this->imagePath . "/" . $fileName;
        $grupromoc['grupo']['DSENDEIMGGRUPROMOC'] = is_null($grupromoc['grupo']['DSENDEIMGGRUPROMOC']) ? null : $filePath;
        foreach($grupromoc['produtos'] as &$produto) {
          $fileNamePrepare = explode("/", $produto[20]);
          $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
          $filePath = $this->imagePath . "/" . $fileName;
          $produto[20] = is_null($produto[20]) ? null : $filePath;
        }
      }
    }
    foreach ($cardapioAPI as $grupoAtual) {
      if (!empty($grupoAtual['grupo'])) {
        // Montando grupos
        $fileNamePrepare = explode("/", $grupoAtual['grupo']['DSENDEIMG']);
        $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
        $filePath = $this->imagePath . "/" . $fileName;
        $grupo = array(
          "CDGRUPO"  => $grupoAtual['grupo']['CODIGO'],
          "NMGRUPO"  => $grupoAtual['grupo']['DESC'],
          "NMGRUPOINGLES"  => $grupoAtual['grupo']['DESCING'],
          "NMGRUPOESPANH"  => $grupoAtual['grupo']['DESCESP'],
          "IMGGRUPO" => is_null($grupoAtual['grupo']['DSENDEIMG']) ? null : $filePath,
          "NRBUTTON" => $grupoAtual['grupo']['NRBUTTON']
        );
        array_push($grupos, $grupo);

        if (!empty($grupoAtual['subgrupos'])) {
          foreach ($grupoAtual['subgrupos'] as $subGrupoAtual) {
            $fileNamePrepare = explode("/", $subGrupoAtual['subgrupo']['DSENDEIMG']);
            $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
            $filePath = $this->imagePath . "/" . $fileName;
            $subGrupo = array(
              "CDGRUPO"   => $grupoAtual['grupo']['CODIGO'],
              "CDSUBGRUPO" => $grupoAtual['grupo']['CODIGO'] . $subGrupoAtual['subgrupo']['CODIGO'],
              "NMSUBGRUPO" => $subGrupoAtual['subgrupo']['DESC'],
              "IMGSUBGRUPO" => is_null($subGrupoAtual['subgrupo']['DSENDEIMG']) ? null : $filePath,

            );
            array_push($subGrupos, $subGrupo);

            foreach ($subGrupoAtual['produtos'] as $produtoSubGrupoAtual) {

              if ($produtoSubGrupoAtual['IDTIPOCOMPPROD'] != '3') {
                // Produtos comuns
                $fileNamePrepare = explode("/", $produtoSubGrupoAtual['DSENDEIMG']);
                $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
                $filePath = $this->imagePath . "/" . $fileName;
                if (floatval($produtoSubGrupoAtual['VRPRECITEM']) > 0)
                {
                  $produtoSubGrupoAtual = array(
                    "CDGRUPO"          => $grupoAtual['grupo']['CODIGO'],
                    "CDSUBGRUPO"       => $grupoAtual['grupo']['CODIGO'] . $subGrupoAtual['subgrupo']['CODIGO'],
                    "CDPRODUTO"        => $produtoSubGrupoAtual['CDPRODUTO'],
                    "NMPRODUTO"        => $produtoSubGrupoAtual['NMPRODUTO'],
                    "NMPRODINGLES"     => $produtoSubGrupoAtual['NMPRODUTOINGLES'],
                    "NMPRODESPANH"     => $produtoSubGrupoAtual['NMPRODUTOESPANH'],
                    "DSPRODVENDA"      => $produtoSubGrupoAtual['DSPRODVENDA'],
                    "DSADICPROD"       => $produtoSubGrupoAtual['DSADICPROD'],
                    "VRPRECITEM"       => $produtoSubGrupoAtual['VRPRECITEM'],
                    "IMGPRODUTO"       => is_null($produtoSubGrupoAtual['DSENDEIMG']) ? null : $filePath,
                    "IDTIPOCOMPPROD"   => $produtoSubGrupoAtual['IDTIPOCOMPPROD'],
                    "IDIMPPRODUTO"     => $produtoSubGrupoAtual['IDIMPPRODUTO'],
                    "OBSERVACOES"      => $produtoSubGrupoAtual['OBSERVACOES'],
                    "CDBARPRODUTO"     => $produtoSubGrupoAtual['CDBARPRODUTO'],
                    "VRDESITVEND"      => 0,
                    "comboItems"       => array(),
                    "VRPRECITEMCL"     => $produtoSubGrupoAtual['VRPRECITEMCL'],
                  );
                  array_push($codProdutos, $produtoSubGrupoAtual['CDPRODUTO']);
                  array_push($produtos, $produtoSubGrupoAtual);
                }
              } else {
                // Combo
                $fileNamePrepare = explode("/", $produtoSubGrupoAtual['DSENDEIMG']);
                $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
                $filePath = $this->imagePath . "/" . $fileName;
                if (floatval($produtoSubGrupoAtual['VRPRECITEM']) > 0) {
                  $gruposFiltrados = self::filterProductsWithoutPrice($produtoSubGrupoAtual['GRUPOS']);
                  $produtoSubGrupoAtual = array(
                    "CDGRUPO"          => $grupoAtual['grupo']['CODIGO'],
                    "CDSUBGRUPO"       => $grupoAtual['grupo']['CODIGO'] . $subGrupoAtual['subgrupo']['CODIGO'],
                    "CDPRODUTO"        => $produtoSubGrupoAtual['CDPRODUTO'],
                    "NMPRODUTO"        => $produtoSubGrupoAtual['NMPRODUTO'],
                    "NMPRODINGLES"     => $produtoSubGrupoAtual['NMPRODUTOINGLES'],
                    "NMPRODESPANH"     => $produtoSubGrupoAtual['NMPRODUTOESPANH'],
                    "DSPRODVENDA"      => $produtoSubGrupoAtual['DSPRODVENDA'],
                    "DSADICPROD"       => $produtoSubGrupoAtual['DSADICPROD'],
                    "VRPRECITEM"       => $produtoSubGrupoAtual['VRPRECITEM'],
                    "IMGPRODUTO"       => is_null($produtoSubGrupoAtual['DSENDEIMG']) ? null : $filePath,
                    "IDTIPOCOMPPROD"   => $produtoSubGrupoAtual['IDTIPOCOMPPROD'],
                    "GRUPOS"           => $gruposFiltrados,
                    "IDIMPPRODUTO"     => $produtoSubGrupoAtual['IDIMPPRODUTO'],
                    "VRDESITVEND"      => 0,
                    "comboItems"       => array(),
                    "VRPRECITEMCL"     => $produtoSubGrupoAtual['VRPRECITEMCL']
                  );
                  array_push($codProdutos, $produtoSubGrupoAtual['CDPRODUTO']);
                  array_push($produtos, $produtoSubGrupoAtual);
                }
              }
            }
          }
        }

        foreach ($grupoAtual['produtos'] as $produto) {
          $fileNamePrepare = explode("/", $produto['DSENDEIMG']);
          $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
          $filePath = $this->imagePath . "/" . $fileName;
          if ($produto['IDTIPOCOMPPROD'] != '3' && floatval($produto['VRPRECITEM']) > 0) {
            $produto = array(
              "CDGRUPO"           => $grupoAtual['grupo']['CODIGO'],
              "CDSUBGRUPO"        => $grupoAtual['grupo']['CODIGO'],
              "CDPRODUTO"         => $produto['CDPRODUTO'],
              "NMPRODUTO"         => $produto['NMPRODUTO'],
              "NMPRODINGLES"      => $produto['NMPRODUTOINGLES'],
              "NMPRODESPANH"      => $produto['NMPRODUTOESPANH'],
              "DSPRODVENDA"       => $produto['DSPRODVENDA'],
              "DSADICPROD"        => $produto['DSADICPROD'],
              "VRPRECITEM"        => $produto['VRPRECITEM'],
              "IMGPRODUTO"        => is_null($produto['DSENDEIMG']) ? null : $filePath,
              "IDTIPOCOMPPROD"    => $produto['IDTIPOCOMPPROD'],
              "IDIMPPRODUTO"      => $produto['IDIMPPRODUTO'],
              "OBSERVACOES"       => $produto['OBSERVACOES'],
              "CDBARPRODUTO"      => $produto['CDBARPRODUTO'],
              "VRDESITVEND"       => 0,
              "comboItems"        => array(),
              "CDBARPRODUTO"      => $produto['CDBARPRODUTO'],
              "VRPRECITEMCL"     => $produto['VRPRECITEMCL'],
              "IDPRODBLOCK"      => $produto['IDPRODBLOQ'] === 'S' ? 'Bloqueado' : 'Desbloqueado',
              "IDPRODBLOCKBOOL"  => $produto['IDPRODBLOQ'] === 'S' ? true : false
            );
            array_push($codProdutos, $produto['CDPRODUTO']);
            array_push($produtos, $produto);
          } else {

            // Combo
            //aqui
            if (floatval($produto['VRPRECITEM']) > 0) {
              $gruposFiltrados = self::filterProductsWithoutPrice($produto['GRUPOS']);
              $produto = array(
                "CDGRUPO"         => $grupoAtual['grupo']['CODIGO'],
                "CDSUBGRUPO"      => $grupoAtual['grupo']['CODIGO'],
                "CDPRODUTO"       => $produto['CDPRODUTO'],
                "NMPRODUTO"       => $produto['NMPRODUTO'],
                "NMPRODINGLES"     => $produto['NMPRODUTOINGLES'],
                "NMPRODESPANH"     => $produto['NMPRODUTOESPANH'],
                "DSPRODVENDA"     => $produto['DSPRODVENDA'],
                "DSADICPROD"      => $produto['DSADICPROD'],
                "VRPRECITEM"      => $produto['VRPRECITEM'],
                "IMGPRODUTO"      => is_null($produto['DSENDEIMG']) ? null : $filePath,
                "IDTIPOCOMPPROD"  => $produto['IDTIPOCOMPPROD'],
                "GRUPOS"          => array_key_exists($produto['CDPRODUTO'], $smartPromoProducts) ? $smartPromoProducts[$produto['CDPRODUTO']] : null,
                "IDIMPPRODUTO"    => $produto['IDIMPPRODUTO'],
                "VRDESITVEND"     => 0,
                "comboItems"      => array(),
                "VRPRECITEMCL"     => $produto['VRPRECITEMCL'],
                "IDPRODBLOQ"     => $produto['IDPRODBLOQ']
              );
              array_push($codProdutos, $produto['CDPRODUTO']);
              array_push($produtos, $produto);
            }
          }
        }
      }
    }

    return array(
      "grupos" => $grupos,
      "listaSubGrupos" => $subGrupos,
      "listaProdutos" => $produtos,
      "codProdutos" => $codProdutos
    );
  }

  private function filterProductsWithoutImp($produto)
  {
    return (isset($produto['CDIMPOSTO']) &&
      isset($produto['VRPEALIMPFIS']) &&
      isset($produto['CDCSTICMS']) &&
      isset($produto['CDCSTPISCOF']) &&
      isset($produto['CDCFOPPFIS']) &&
      isset($produto['VRALIQPIS']) &&
      isset($produto['VRALIQCOFINS']));
  }

  private function filterProductsWithoutPrice($grupos)
  {

    $gruposTratados = array();
    foreach ($grupos as $grupoAtual) {
      $CDGRUPROMOC = $grupoAtual['grupo']['CDGRUPROMOC'];
      $gruposTratados[$CDGRUPROMOC] = $grupoAtual;
      $gruposTratados[$CDGRUPROMOC]['produtos'] = array();
      foreach ($grupoAtual['produtos'] as $produtoAtual) {
        if ($produtoAtual['VRPRECITEM'] > 0) {
          $fileNamePrepare = explode("/", $produtoAtual['DSENDEIMGPROMO']);
          $fileName = $fileNamePrepare[sizeof($fileNamePrepare)-1];
          $produtoAtual['DSENDEIMGPROMO'] = is_null($produtoAtual['DSENDEIMGPROMO']) ? null : $produtoAtual['DSENDEIMGPROMO'];
          $gruposTratados[$CDGRUPROMOC]['produtos'][$produtoAtual['CDPRODUTO']] = $produtoAtual;
        }
      }
    }
    return $gruposTratados;
  }

  private function handleObservationImages($observations)
  {
    foreach ($observations as &$observation) {
      if (empty($observation['DSENDEIMGOCORR'])) {
        $observation['DSENDEIMGOCORR'] = 'images\noimage.png';
      }
    }
    return $observations;
  }

  public function getFiliais(Request\Filter $request, Response $response)
  {
    try {
      $filiais = $this->paramsTAAService->getFiliais();
      $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('FiliaisRepo', $filiais));
    } catch (\Exception $e) {
      $response->setError(new Error($e->getMessage(), 500));
    }

  }

  public function getRegisters(Request\Filter $request, Response $response)
  {
    $params = $request->getFilterCriteria()->getConditions();
    $CDFILIAL = $params[0]['value'];
    $registers = $this->paramsTAAService->getRegisters($CDFILIAL);

    $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('RegistersRepo', $registers));
  }

  public function loadOperators(Request\Filter $request, Response $response)
  {
    $params = $request->getFilterCriteria()->getConditions();
    $CDFILIAL = $params[0]['value'];

    $sellers = $this->paramsTAAService->loadOperators($CDFILIAL);

    $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('OperatorsRepo', $sellers));
  }
  public function validateOperatorPass(Request\Filter $request, Response $response)
  {
    try {
      $params = $request->getFilterCriteria()->getConditions();
      $CDFILIAL   = $params[0]['value'];
      $CDOPERADOR = $params[1]['value'];
      $SENHADIG   = $params[2]['value'];

      $validation = $this->loginAPI->validaOperador($CDOPERADOR, $CDFILIAL, $SENHADIG);

      $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('ValidateOperatorPassRepo', $validation));
    } catch (\Exception $e) {
      $response->addMessage(new Message($e->getMessage()));
    }
  }

  public function loadBilletData(Request\Row $request, Response $response)
  {
    try {
      $params = $request->getRow();
      $CDFILIAL   = $params['CDFILIAL'];
      $DSCOMANDA = $params['DSCOMANDA'];

      $DSCOMANDA_DATA = $this->paramsTAAService->getComandaData($CDFILIAL, $DSCOMANDA);

      if (!$DSCOMANDA_DATA) {
        throw new \Exception('Nenhuma comanda encontrada.');
      }

      $comandaProducts = $this->paramsTAAService->getComandaProducts($CDFILIAL, $DSCOMANDA_DATA['NRCOMANDA']);

      if (!$comandaProducts) {
        throw new \Exception('Nenhuma produto encontrado na comanda.');
      }

      $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('BilletData', $DSCOMANDA_DATA));
      $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('Products', $comandaProducts));
    } catch (\Exception $e) {
      $response->setError(new Error($e->getMessage(), 404));
    }
  }
  public function auth(Request\Row $request, Response $response) {
    try {
      $params = $request->getRow();
      $operator = $this->paramsTAAService->loginAutenticatorService($params['operator'], $params['password']);
      if(!$operator){
        throw new \Exception("Credenciais inválidas.", 404);
      }
      $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('operador', array('cdoperador'=> $operator)));
    } catch (\Exception $e){
			$response->setError(new Error($e->getMessage(), 500));
    }
  }
}
