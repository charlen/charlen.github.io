<?php

namespace Controller;

use Zeedhi\Framework\DTO\Response\Message;
use Zeedhi\Framework\DTO\Response\Error;
use Zeedhi\Framework\DTO\Response;
use Zeedhi\Framework\DTO\Request;

class Order
{
  protected $entityManager;
  protected $vendaAPI;
  protected $utilAPI;
  protected $impressaoPedidoAPI;
  protected $precoAPI;
  protected $tefAPI;
  protected $paramsTAA;
  protected $impressaoUtil;
  protected $comandaAPI;
  protected $consumidorAPI;
  protected $caixaAPI;
  protected $cashApi;

  public function __construct(
    \Doctrine\ORM\EntityManager $entityManager,
    \Odhen\API\Service\Venda $vendaAPI,
    \Odhen\API\Util\util $utilAPI,
    \Odhen\API\Service\ImpressaoPedido $impressaoPedidoAPI,
    \Odhen\API\Service\Preco $precoAPI,
    \Odhen\API\Service\TEF $tefAPI,
    \Service\ParamsTAA $paramsTAA,
    \Odhen\API\Lib\ImpressaoUtil $impressaoUtil,
    \Odhen\API\Remote\TEF\TEF $tefRemoteAPI,
    \Odhen\API\Service\Comanda $comandaAPI,
    \Odhen\API\Service\Consumidor $consumidorAPI,
    \Odhen\API\Service\Caixa $caixaAPI,
    \Odhen\API\Service\CashCupom $cashApi
  ) {

    $this->entityManager = $entityManager;
    $this->vendaAPI = $vendaAPI;
    $this->utilAPI = $utilAPI;
    $this->impressaoPedidoAPI = $impressaoPedidoAPI;
    $this->precoAPI  = $precoAPI;
    $this->tefAPI = $tefAPI;
    $this->paramsTAA = $paramsTAA;
    $this->impressaoUtil = $impressaoUtil;
    $this->tefRemoteAPI = $tefRemoteAPI;
    $this->comandaAPI = $comandaAPI;
    $this->consumidorAPI = $consumidorAPI;
    $this->caixaAPI = $caixaAPI;
    $this->habilitaLog = true;
    $this->cashApi = $cashApi;
  }

  public function performSale(Request\Row $request, Response $response)
  {
    try {
      $params = $request->getRow();
      $simulation = json_decode($params['simulation'], true);
      $simulateOrder = $simulation['simulateOrder'];
      if ($simulateOrder) {
        $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('PerformSaleRepository', array('orderCode' => '00001')));
      } else {
        $filial = json_decode($params['filial'], true);
        $loja = json_decode($params['loja'], true);
        $caixa = json_decode($params['caixa'], true);
        $products = json_decode($params['products'], true);
        $payment = json_decode($params['payment'], true);
        $simulation = json_decode($params['simulation'], true);
        $consumer = json_decode($params['consumer'], true);
        $operator = json_decode($params['operator'], true);
        $orderInfo = json_decode($params['orderInfo'], true);
        $tableInfo = json_decode($params['tableInfo'], true);
        $qrcodeInfo = json_decode($params['qrcodeInfo'], true);

        $NRORG = $filial['NRORG'];
        $CDFILIAL = $filial['CDFILIAL'];
        $CDLOJA = $caixa['CDLOJA'];
        $CDCAIXA = $caixa['CDCAIXA'];
        $NRMESAPADRAO = $loja['NRMESAPADRAO'];
        $CDVENDEDOR = null;
        $CDOPERADOR = $operator['CDOPERADOR'];
        $DTABERCAIX = $this->caixaAPI->convertToDateDB($this->paramsTAA->getRegisterOpeningDate($CDFILIAL, $CDCAIXA)['DTABERCAIX']);
        $DTVENDA = new \DateTime();

        $NRCOMANDA = null;
        $NRVENDAREST = null;

        $CDNSUHOSTTEF = isset($payment['CDNSUHOSTTEF']) ? $payment['CDNSUHOSTTEF'] : null;
        $CDCLIENTE = isset($consumer['CDCLIENTE']) ? $consumer['CDCLIENTE'] : null;
        $CDCONSUMIDOR = isset($consumer['CDCONSUMIDOR']) ? $consumer['CDCONSUMIDOR'] : null;
        $NRINSCRCONS = isset($consumer['consumerDoc']) ? $consumer['consumerDoc'] : '';

        /* Sale Params */

        $simulatePrinter        = $simulation['simulatePrinter'];
        $simulateSaleValidation = $simulation['simulateSaleValidation'];

        $ITEMVENDA = self::handleProducts($CDFILIAL, $CDLOJA, $products, $CDVENDEDOR);
        $connection = $this->entityManager->getConnection();

        $simulatePrinterOriginal = $simulatePrinter;
        $imprimirNota = isset($orderInfo['imprimirNota']) ? $orderInfo['imprimirNota'] : false;
        if (!$simulatePrinter && $imprimirNota == false) {
          $simulatePrinter = true;
        }
        $resultNSU = array();
        $orderMethod = $orderInfo['orderMethod'];
        if ($orderMethod == 'qrcode'){
          $simulatePrinter = $simulatePrinterOriginal;
          $NRCOMANDA = isset($qrcodeInfo['NRCOMANDA']) ? $qrcodeInfo['NRCOMANDA'] : null;
          $NRVENDAREST = isset($qrcodeInfo['NRVENDAREST']) ? $qrcodeInfo['NRVENDAREST'] : null;
          if(!empty($NRCOMANDA) && !empty($NRVENDAREST)) {
            $validateQRCODE = self::validateReadQRCODE($CDFILIAL, $CDCAIXA, $NRCOMANDA, $NRVENDAREST);
            if ($validateQRCODE['error'] === true) {
              $resultNSU['error'] = true;
              $resultNSU['message'] = $validateQRCODE['message'];
            } else {
              $resultNSU['error'] = false;
              $resultNSU['CDNSUHOSTTEF'] = $CDNSUHOSTTEF;
            }
          } else {
            $message = 'Qrcode sem dados de venda.';
            $response->setError(new Error($message, 500));
            $response->addMessage(new Message($message));
          }
        } else {
          $resultNSU['error'] = false;
          $resultNSU['CDNSUHOSTTEF'] = $CDNSUHOSTTEF;
        }
        if ($resultNSU['error'] == false) {
          $TOTALVENDA = self::getTotalSale($ITEMVENDA['handledProducts']);
          $payment['CDNSUHOSTTEF'] = $resultNSU['CDNSUHOSTTEF'];
          $payment['VRMOVIVEND'] = $TOTALVENDA;
          $payment['NRCARTBANCO'] = '';
          if ($ITEMVENDA['error'] == false) {
            $ITEMVENDA = $ITEMVENDA['handledProducts'];
            $NMCONSVEND = null;
            if (!empty($NRINSCRCONS)) {
              $NRINSCRCONS = $this->utilAPI->removeMask($NRINSCRCONS);
            }
            $CDSENHAPED = self::generateCDSENHAPED($CDFILIAL, $NRORG);
            $VRTROCOVEND = array();
            $EMAIL = null;
            $VRDESCVENDA = 0;
            $CDCONTADOR = 'PEDIDOVENDA' . $CDFILIAL . $CDCAIXA;
            $NRSEQVENDA = $this->utilAPI->geraCodigo($connection, $CDCONTADOR, 1, 1, 10);
            $resultVenda = array('error' => true);
            if ($orderMethod == 'billet') {
              $NRCOMANDA = isset($tableInfo['NRCOMANDA']) ? $tableInfo['NRCOMANDA'] : null;
              $NRVENDAREST = isset($tableInfo['NRVENDAREST']) ? $tableInfo['NRVENDAREST'] : null;
              foreach ($tableInfo as $k => $mesa) {
                unset($tableInfo[$k]['products']);
                $tableInfo[$k]['DTHRMESAFECH'] = new \DateTime();
              }
              $mesaToDelete = $tableInfo;
              if (count($tableInfo) > 1) {
                $tableInfo = $this->newComanda($connection, $CDFILIAL, $CDLOJA, $NRMESAPADRAO, $CDVENDEDOR, $CDOPERADOR, $NRORG, $ITEMVENDA, $CDCAIXA);
              }
              $resultVenda = $this->vendaAPI->vendaMesa(
                $NRORG,
                $CDFILIAL,
                $CDLOJA,
                $CDCAIXA,
                $CDVENDEDOR,
                $CDOPERADOR,
                $DTABERCAIX,
                $DTVENDA,
                $TOTALVENDA,
                array($payment),
                $NMCONSVEND,
                $NRINSCRCONS,
                $CDSENHAPED,
                $VRTROCOVEND,
                $EMAIL,
                $VRDESCVENDA,
                $CDCLIENTE,
                $CDCONSUMIDOR,
                $simulatePrinter,
                $simulateSaleValidation,
                $tableInfo,
                self::formatPositions($tableInfo),
                'BAL_AUT',
                null,
                null
              );
              if ($resultVenda['error'] == false && count($mesaToDelete) > 1) {
                foreach ($mesaToDelete as $mesa) {
                  $this->comandaAPI->apagaTabelasProduto($CDFILIAL, $mesa, 'T');
                  $this->comandaAPI->apagaTabelasComanda($CDFILIAL, $mesa);
                }
              }
            }
            if (!$tableInfo || $orderMethod === 'qrcode' || $orderMethod === 'kiosk') {
              $resultVenda = $this->vendaAPI->venda(
                $NRORG,
                $CDFILIAL,
                $CDLOJA,
                $CDCAIXA,
                $CDVENDEDOR,
                $CDOPERADOR,
                $DTABERCAIX,
                $DTVENDA,
                $TOTALVENDA,
                $ITEMVENDA,
                array($payment),
                $NMCONSVEND,
                $NRINSCRCONS,
                $NRSEQVENDA,
                $VRTROCOVEND,
                $EMAIL,
                $VRDESCVENDA,
                $CDCLIENTE,
                $CDCONSUMIDOR,
                $simulatePrinter,
                $simulateSaleValidation,
                'BAL_AUT',
                $CDSENHAPED,
                $NRCOMANDA,
                $NRVENDAREST
              );
            }
            $resultVenda['orderCode'] = $CDSENHAPED;
            if ($resultVenda['error'] == false) {
              $this->tefRemoteAPI->finalizaTransacao('1');
              $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('PerformSaleRepository', $resultVenda));
              if ($simulatePrinterOriginal) {
                $respostaImpressaoTEF = array('error' => false);
              } else {
                if(isset($payment['comprovanteTef'])) {
                  $comprovanteTef = $payment['comprovanteTef'];
                  $arrTiporece = array();
                  $arrTiporece[0] = array(
                      'STLPRIVIA' => $comprovanteTef
                    );
                  if ($orderMethod == 'qrcode') {
                    $arrTiporece[0] = array(
                      'STLPRIVIA' => ''
                    );
                  }
                  $respostaImpressaoTEF = $this->tefAPI->imprimeCupomTEF($arrTiporece, $filial['CDFILIAL'], $caixa['CDCAIXA'], $filial['NRORG'], $NRSEQVENDA);
                  if ($respostaImpressaoTEF['error'] == true) {
                    $response->addMessage(new Message($respostaImpressaoTEF['message']));
                  }
                }
              }
              if ($simulatePrinterOriginal) {
                $respostaImpressao = array('error' => false);
              } else {
                $ITEMVENDA = self::prepareProductsForPrinter($ITEMVENDA);
                $respostaImpressao = $this->impressaoPedidoAPI->imprimePedido(
                  $CDFILIAL,
                  $CDLOJA,
                  $ITEMVENDA,
                  $CDVENDEDOR,
                  null,
                  null,
                  $CDSENHAPED,
                  'B',
                  false,
                  true,
                  true
                );
              }
              if ($respostaImpressao['error'] == true) {
                $response->addMessage(new Message('Houve um problema no envio do seu pedido. Procure um atendente mais próximo. Erro: ' . $respostaImpressao['message']));
              }
            } else {
              $this->tefRemoteAPI->finalizaTransacao('0');
              $response->setError(new Error($resultVenda['message'], 500));
              $response->addMessage(new Message($resultVenda['message']));
            }
          } else {
            $this->tefRemoteAPI->finalizaTransacao('0');
            $response->setError(new Error($ITEMVENDA['message'], 500));
            $response->addMessage(new Message($ITEMVENDA['message']));
          }
        } else {
          $response->setError(new Error($resultNSU['message'], 500));
          $response->addMessage(new Message($resultNSU['message']));
        }
      }
    } catch (\Exception $e) {
      $this->tefRemoteAPI->finalizaTransacao('0');
      $response->setError(new Error($e->getMessage(), 500));
      $response->addMessage(new Message($e->getMessage()));
    }
  }

  private function newComanda($connection, $CDFILIAL, $CDLOJA, $NRMESAPADRAO, $CDVENDEDOR, $CDOPERADOR, $NRORG, $ITEMVENDA, $CDCAIXA)
  {
    $NRVENDAREST = $this->utilAPI->geraCodigo($connection, 'VENDAREST' . $CDFILIAL, 1, 1, 10);
    $this->newVendarest($CDFILIAL, $CDLOJA, $NRVENDAREST, $NRMESAPADRAO, $CDVENDEDOR, $CDOPERADOR, $NRORG);
    $NRCOMANDAVEN = $this->utilAPI->geraCodigo($connection, 'COMANDAVEN' . $CDFILIAL, 1, 1, 10);
    $this->newComandaVen($CDFILIAL, $NRVENDAREST, $NRCOMANDAVEN, $CDLOJA);
    $this->insereProdutos($connection, $ITEMVENDA, $NRVENDAREST, $NRCOMANDAVEN, $CDFILIAL, $CDCAIXA);
    return array(array(
      'NRVENDAREST' => $NRVENDAREST,
      'NRCOMANDA' => $NRCOMANDAVEN,
      'NRPESMESAVEN' => '1',
      'NRMESA' => $NRMESAPADRAO,
      'NRLUGARMESA' => '01',
      'DSCOMANDA' => $NRCOMANDAVEN,
      'DTHRMESAFECH' => new \DateTime()
    ));
  }

  private function insereProdutos($connection, $ITEMVENDA, $NRVENDAREST, $NRCOMANDAVEN, $CDFILIAL, $CDCAIXA)
  {
    foreach ($ITEMVENDA as $item) {
      $NRPRODCOMVEN = $this->utilAPI->geraCodigo($connection, 'ITCOMANDAVEN' . $CDFILIAL . $NRCOMANDAVEN, 1, 1, 6);
      $params = array(
        'CDFILIAL' => $CDFILIAL,
        'NRVENDAREST' => $NRVENDAREST,
        'NRCOMANDA' => $NRCOMANDAVEN,
        'NRPRODCOMVEN' => $NRPRODCOMVEN,
        'CDPRODUTO' => $item['CDPRODUTO'],
        'QTPRODCOMVEN' => $item['QTPRODVEND'],
        'DTHRINCOMVEN' => new \DateTime(),
        'VRPRECCOMVEN' => $item['VRUNITVEND'],
        'TXPRODCOMVEN' => '',
        'IDSTPRCOMVEN' => '4',
        'VRDESCCOMVEN' => '0',
        'NRLUGARMESA' => '01',
        'CDCAIXACOLETOR' => $CDCAIXA
      );
      $this->entityManager->getConnection()->executeQuery("SQL_INSERE_ITEM_COMANDA_VEN", $params);
    }
  }

  private function newVendarest($CDFILIAL, $CDLOJA, $NRVENDAREST, $NRMESAPADRAO, $CDVENDEDOR, $CDOPERADOR, $NRORG)
  {
    $params = array(
      'CDFILIAL' => $CDFILIAL,
      'NRVENDAREST' => $NRVENDAREST,
      'CDLOJA' => $CDLOJA,
      'NRMESA' => $NRMESAPADRAO,
      'CDVENDEDOR' => $CDVENDEDOR,
      'CDOPERADOR' => $CDOPERADOR,
      'NRPESMESAVEN' => '1',
      'CDCLIENTE' => null,
      'CDCONSUMIDOR' => null,
      'NRPOSICAOMESA' => '1',
      'NRORG' => $NRORG
    );
    $this->entityManager->getConnection()->executeQuery("SQL_INSERE_VENDAREST", $params);
  }

  private function newComandaVen($CDFILIAL, $NRVENDAREST, $NRCOMANDAVEN, $CDLOJA)
  {
    $params = array(
      'CDFILIAL'        =>  $CDFILIAL,
      'NRVENDAREST'      =>  $NRVENDAREST,
      'NRCOMANDA'        =>  $NRCOMANDAVEN,
      'CDLOJA'        =>  $CDLOJA,
      'DSCOMANDA'        =>  'TAA_' . $NRCOMANDAVEN,
      'IDSTCOMANDA'      =>  '1',
      'VRACRCOMANDA'      =>  0,
      'IDORGCMDVENDA'     =>  'BAL_AUT',
      'DSCONSUMIDOR'      =>  null
    );
    $this->entityManager->getConnection()->executeQuery("SQL_ABRE_COMANDA", $params);
  }
  private function formatPositions($mesas)
  {
    return array_map(function ($mesa) {
      return str_pad($mesa['NRLUGARMESA'], 2, '0', STR_PAD_LEFT);
    }, $mesas);
  }

  private function validateReadQRCODE($CDFILIAL, $CDCAIXA, $NRCOMANDA, $NRVENDAREST)
  {
    $result = array();
    $validateQRCODE = $this->paramsTAA->validateReadQRCODE($CDFILIAL, $CDCAIXA, $NRCOMANDA, $NRVENDAREST);
    if ($validateQRCODE['COUNTVENDA'] > 0) {
      $result['error'] = true;
      $result['message'] = 'O QRCode informado já consta em nosso sistema.';
    } else {
      $result['error'] = false;
    }
    return $result;
  }

  public function removeAcentos($texto)
  {
    $table = array(
      'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a',
      'é' => 'e', 'ê' => 'e', 'í' => 'i', 'ó' => 'o', 'ô' => 'o',
      'õ' => 'o', 'ú' => 'u', 'ü' => 'u', 'ç' => 'c', 'Á' => 'A',
      'À' => 'A', 'Ã' => 'A', 'Â' => 'A', 'É' => 'E', 'Ê' => 'E',
      'Í' => 'I', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ú' => 'U',
      'Ü' => 'U', 'Ç' => 'C_'
    );
    return preg_replace("[^a-zA-Z0-9_]", "", strtr($texto, $table));
  }

  private function prepareProductsForPrinter($ITEMVENDA)
  {

    $products = array();
    $ordemimp = 1;
    foreach ($ITEMVENDA as $currentProduct) {
      $currentProduct['ORDEMIMP'] = $ordemimp;
      $currentProduct['IDIMPPROMOCAO'] = 'N';
      $currentProduct['NMPRODPROMOCAO'] = '-';
      $currentProduct['TXPRODCOMVEN'] = empty($currentProduct['TXPRODCOMVEN']) ? null : $currentProduct['TXPRODCOMVEN'];
      $currentProduct['ATRASOPROD'] = null;
      $currentProduct['NRLUGARMESA'] = '1';
      if (!empty($currentProduct['observations'])) {
        $currentProduct['TXPRODCOMVEN'] = '-> ';
        foreach ($currentProduct['observations'] as $currentObs) {
          $currentProduct['TXPRODCOMVEN'] .= $currentObs['DSOCORR'] . ' ';
        }
      }
      array_push($products, $currentProduct);
      if (!empty($currentProduct['itensCombo'])) {
        $ordemimpchild = 0.01;
        foreach ($currentProduct['itensCombo'] as $comboItem) {
          $comboItem['ORDEMIMP'] = $ordemimp + $ordemimpchild;
          $comboItem['IDIMPPROMOCAO'] = 'N';
          $comboItem['NMPRODPROMOCAO'] = '-';
          $comboItem['ATRASOPROD'] = null;
          $comboItem['IDTIPOCOMPPROD'] = '1';
          $comboItem['NRLUGARMESA'] = '1';
          if (empty($comboItem['QTPRODVEND'])) {
            $comboItem['QTPRODCOMVEN'] = 1;
          } else {
            $comboItem['QTPRODCOMVEN'] = $comboItem['QTPRODVEND'];
          }
          if (empty($comboItem['TXPRODCOMVEN'])) {
            $comboItem['TXPRODCOMVEN'] = null;
          }
          if (!empty($comboItem['observations'])) {
            $comboItem['TXPRODCOMVEN'] = '-> ';
            foreach ($comboItem['observations'] as $comboItemObservation) {
              $comboItem['TXPRODCOMVEN'] .= $comboItemObservation['DSOCORR'] . ' ';
            }
          }
          array_push($products, $comboItem);
          $ordemimpchild += 0.01;
        }
      }
      $ordemimp++;
    }
    return $products;
  }

  // It also calculate the descount
  private function handleProducts($CDFILIAL, $CDLOJA, $products, $CDVENDEDOR)
  {
    $handledProducts = array();
    $result = array('error' => false);
    foreach ($products as $product) {
      $newProduct = array();
      $product['QTPRODCOMVEN'] = empty($product['QTPRODCOMVEN']) ? 1 : $product['QTPRODCOMVEN'];
      $product['NMPRODUTO'] = $this->removeAcentos($product['DSBUTTON']);

        $newProduct['DSOBSITEMVENDA'] = "";
        foreach ($product['OBSERVATIONS'] as $observation) {
          $newProduct['DSOBSITEMVENDA'] = $newProduct['DSOBSITEMVENDA'] . $observation['DSOCORR'] . ': ';
        }
        $newProduct['DSOBSPEDDIGITA'] = null;
        $newProduct['CDPRODUTO'] = $product['CDPRODUTO'];
        $newProduct['NMPRODUTO'] = $product['NMPRODUTO'];
        $newProduct['QTPRODVEND'] = $product['QTPRODCOMVEN'];
        $newProduct['QTPRODCOMVEN'] = $product['QTPRODCOMVEN'];
        $newProduct['VRUNITVEND'] = $product['PRICE']['VRPRECITEM'];
        $newProduct['VRDESITVEND'] = isset($product['VRDESITVEND']) ? $product['VRDESITVEND'] : 0;
        $newProduct['VRACRITVEND'] = isset($product['VRACRITVEND']) ? $product['VRACRITVEND'] : 0;
        $newProduct['IDSITUITEM'] = 'A';
        $newProduct['IDTIPOITEM'] = null;
        $newProduct['DSOBSDESCIT'] = null;
        $newProduct['CDGRPOCORDESCIT'] = null;
        $newProduct['IDORIGEMVENDA'] = '';
        $newProduct['OBSERVACOES'] = $product['OBSERVATIONS'];
        $newProduct['IDTIPOCOMPPROD'] = $product['IDTIPOCOMPPROD'];
        $newProduct['IDIMPPRODUTO'] = $product['IDIMPPRODUTO'];
        $newProduct['VRUNITVENDCL'] = $product['PRICE']['VRPRECITEMCL'];
        $newProduct['CDPRODPROMOCAO'] = null;
        $newProduct['REALSUBSIDY'] = 0;
        $newProduct['CDVENDEDOR'] = $CDVENDEDOR;
        $comboItems = array();
        if(isset($product['comboItems'])) {
          foreach ($product['comboItems'] as $currentComboItem) {
            if (empty($currentComboItem['VRDESITVEND'])) {
              $currentComboItem['VRDESITVEND'] = 0;
            }
            if (empty($currentComboItem['VRACRITVEND'])) {
              $currentComboItem['VRACRITVEND'] = 0;
            }
            $newItem = array();
            $newItem['DSOBSITEMVENDA'] = "";
            foreach ($product['OBSERVATIONS'] as $observation) {
              $newItem['DSOBSITEMVENDA'] = $newItem['DSOBSITEMVENDA'] . ', ' . $observation['DSOCORR'];
            }
            $newItem['DSOBSPEDDIGITA'] = null;
            $newItem['CDPRODUTO'] = $currentComboItem['CDPRODUTO'];
            $newItem['NMPRODUTO'] = $currentComboItem['NMPRODUTO'];
            $newItem['QTPRODVEND'] = $currentComboItem['QTPRODVEND'] * $product['QTPRODVEND'];
            $newItem['QTPRODCOMVEN'] = $currentComboItem['QTPRODVEND'] * $product['QTPRODVEND'];
            $newItem['VRUNITVEND'] = $currentComboItem['PRICE']['VRPRECITEM'] + $currentComboItem['VRACRITVEND'] - $currentComboItem['VRDESITVEND'];
            $newItem['VRDESITVEND'] = 0;
            $newItem['VRACRITVEND'] = 0;
            $newItem['IDSITUITEM'] = 'A';
            $newItem['IDTIPOITEM'] = null;
            $newItem['DSOBSDESCIT'] = null;
            $newItem['CDGRPOCORDESCIT'] = null;
            $newItem['IDORIGEMVENDA'] = '';
            $newItem['OBSERVACOES'] = $currentComboItem['OBSERVATIONS'];
            $newItem['IDAPLICADESCPR'] = $currentComboItem['IDAPLICADESCPR'];
            // $newItem['IDPERVALORDES'] = $currentComboItem['IDPERVALORDES'];
            $newItem['VRUNITVENDCL'] = 0;
            $newItem['CDVENDEDOR'] = $CDVENDEDOR;
            $newItem['REALSUBSIDY'] = 0;
            $newItem['CDPRODPROMOCAO'] = $product['CDPRODUTO'];
            array_push($comboItems, $newItem);
          }
        }
        $newProduct['itensCombo'] = $comboItems;

        array_push($handledProducts, $newProduct);
    }

    if ($result['error'] == false) {
      $result['handledProducts'] = $handledProducts;
    }
    return $result;
  }

  private function getTotalSale($products)
  {
    $totalSale = 0;
    foreach ($products as $product) {
      if (isset($product['QRCODE'])) {
        $totalSale += $product['VRUNITVEND'] * $product['QTPRODVEND'];
      } elseif ($product['IDTIPOCOMPPROD'] == '3') {
        if ($product['IDIMPPRODUTO'] == '2') {
          foreach ($product['itensCombo'] as $currentItem) {
            foreach ($currentItem['OBSERVACOES'] as $observation) {
              if ($observation['IDCONTROLAOBS'] == 'A') {
                $totalSale += ($observation['VRUNITVEND'] * $observation['QTPRODVEND']) * $currentItem['QTPRODVEND'];
              }
            }
            $totalSale += ($currentItem['VRUNITVEND'] * $currentItem['QTPRODVEND']);
          }
        } else {
          $totalSale += $product['VRUNITVEND'] * $product['QTPRODCOMVEN'];
          foreach ($product['itensCombo'] as $currentItem) {
            foreach ($currentItem['OBSERVACOES'] as $observation) {
              if ($observation['IDCONTROLAOBS'] == 'A') {
                $totalSale += ($observation['VRUNITVEND'] * $observation['QTPRODVEND']) * $currentItem['QTPRODVEND'];
              }
            }
          }
        }
      } else {
        foreach ($product['OBSERVACOES'] as $observation) {
          if ($observation['IDCONTROLAOBS'] == 'A') {
            $observation['VRUNITVEND'] = $observation['VRPRECITEM'];
            $totalSale += ($observation['VRUNITVEND'] * $observation['QTPRODVEND']) * $product['QTPRODVEND'];
          }
        }
        $totalSale += bcdiv($product['VRUNITVEND'] * $product['QTPRODVEND'], 1, 2);
      }
    }
    return floatval(bcdiv($totalSale, 1, 2));
  }

  private function generateCDSENHAPED($CDFILIAL, $NRORG)
  {
    $connection = $this->entityManager->getConnection();
    $today = date("d/m/Y");
    $CDCONTADOR = 'VENDADIA' . $CDFILIAL . $today;
    return $this->utilAPI->geraCodigo($connection, $CDCONTADOR, $NRORG, 1, 5);
  }

  private function getToGoString($isToGo)
  {
    return $isToGo ? 'PARA VIAGEM' : '';
  }

  public function saleCancel(Request\Row $request, Response $response)
  {
    try {
      $params = $request->getRow();
      $connection = $this->entityManager->getConnection();
      $venda = $this->getVendabyCodigoCupom($params['CDFILIAL'], $params['CDCAIXA'], $params['CODIGOCUPOM']);

      $result = array(
        'error' => true,
        'message' => '',
        'data' => array(
          'dadosImpressao' => array(),
          'dataTEF' => array()
        )
      );
      try {
        if (!empty($venda)) {
          $result['data']['dataTEF'] = self::getTransactions($venda['NRSEQVENDA'], $params['CDFILIAL'], $params['CDCAIXA'], $params['NRORG']);
          $connection->beginTransaction();
          $resultCancel = $this->vendaAPI->cancelaCupom($params['CDFILIAL'], $params['CDCAIXA'], $params['NRORG'], $venda['NRSEQVENDA'], $params['CDOPERADOR'], $params['CDOPERADOR']);
          if (!$resultCancel['error']) {
            $connection->commit();
            $result['error'] = false;
            $result['message'] = 'Venda cancelada com sucesso.';
            // formata mensagem de acordo com os erros do fluxo de cancelamento
            if (isset($resultCancel['mensagemNfce'])) {
              $result['message'] .= ' <br><br> ' . $resultCancel['mensagemNfce'] . '<br><br>';
            } else if (isset($resultCancel['mensagemImpressao'])) {
              $result['message'] .= ' <br><br> ' . $resultCancel['mensagemImpressao'];
            }
            $result['data']['dadosImpressao'] = $resultCancel['dadosImpressao'];
          } else {
            if ($connection != null) {
              $connection->rollback();
            }
            $result = $resultCancel;
          }
        } else {
          $result['message'] = 'Venda para este código de cupom não encontrada ou não relacionada a abertura deste caixa.';
        }
        $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('saleCancel', $result));
      } catch (\Exception $e) {
        if ($connection != null) {
          $connection->rollback();
        }
        $result['message'] = $e->getMessage();
        return $result;
      }
    } catch (\Exception $e) { }
  }

  public function getTransactions($NRSEQVENDA, $CDFILIAL, $CDCAIXA, $NRORG)
  {
    $params = array(
      'NRSEQVENDA' => $NRSEQVENDA,
      'CDFILIAL'    => $CDFILIAL,
      'CDCAIXA'    => $CDCAIXA,
      'NRORG'    => $NRORG
    );

    $recebimentos = $this->entityManager->getConnection()->fetchAll('SQL_GET_MOVCAIXA_BY_NRSEQVENDA', $params);

    return array_filter($recebimentos, function ($recebimento) {
      return !empty($recebimento['NRCONTROLTEF']);
    });
  }

  public function getVendabyCodigoCupom($CDFILIAL, $CDCAIXA, $NRNOTAFISCALCE)
  {
    $venda = array();

    $DTABERCAIX = $this->paramsTAA->getRegisterOpeningDate($CDFILIAL, $CDCAIXA);
    if (!empty($DTABERCAIX)) {
      $params = array(
        'CDFILIAL' => $CDFILIAL,
        'CDCAIXA' => $CDCAIXA,
        'DTABERTUR' => $this->caixaAPI->convertToDateDB($DTABERCAIX['DTABERCAIX']),
        'NRNOTAFISCALCE' => $NRNOTAFISCALCE
      );
      $type = array(
        'DTABERTUR' => \Doctrine\DBAL\Types\Type::DATETIME
      );

      $venda = $this->entityManager->getConnection()->fetchAssoc('SQL_GET_VENDA_BY_NRNOTAFISCALCE', $params, $type);
    }

    return $venda;
  }

  public function cash(Request\Row $request, Response $response){
    try {
      $params = $request->getRow();
      $dadosContent = $params['dadosContent'];
      $dadosCliente = $params['dadosCliente'];
      $cart = $params['cart'];
      $CDFILIAL = $dadosContent['CDFILIAL'];
      $CDLOJA   = $dadosContent['CDLOJA'];

      $CDCONTADORVENDAREST = 'VENDAREST' . $CDFILIAL;
      $CDCONTADORNRCOMANDA = 'COMANDAVEN' . $CDFILIAL;
      
      $connection =  $this->entityManager->getConnection();

      $NRCOMANDAVEN = $this->utilAPI->geraCodigo($connection, 'COMANDAVEN' . $CDFILIAL, 1, 1, 10);
      $NRVENDAREST = $this->utilAPI->geraCodigo($connection, $CDCONTADORVENDAREST, 1, 1, 10);
      $NRCOMANDA = $this->utilAPI->geraCodigo($connection, $CDCONTADORNRCOMANDA, 1, 1, 10);
      $CDVENDEDOR = null;
      $ITEMVENDA = self::handleProducts($CDFILIAL, $CDLOJA, $cart, $CDVENDEDOR);
      $TOTALVENDA = self::getTotalSale($ITEMVENDA['handledProducts']);
      $VENDAREST = array(
        'CDFILIAL' => $CDFILIAL,
        'NRVENDAREST' => $NRVENDAREST,
        'CDLOJA' => $CDLOJA,
        'NRMESA' => $dadosContent['NRMESAPADRAO'],
        'CDVENDEDOR' => null,
        'DTHRFECHMESA' => null,
        'DTHRABERMESA' => \DateTime::createFromFormat('Y-m-d H:i:s', Date('Y-m-d H:i:s')),
        'CDOPERADOR' => $dadosContent['CDOPERADOR'],
        'NRPESMESAVEN' => '1',
        'CDCLIENTE' => isset($dadosCliente['CDCLIENTE']) ? $dadosCliente['CDCLIENTE'] : null,
        'CDCONSUMIDOR' => isset($dadosCliente['CDCONSUMIDOR']) ? $dadosCliente['CDCONSUMIDOR'] : null,
        'IDPEDIDOPAGO' => 'N'
      );
      $COMANDAVEN = array(
        'CDFILIAL' => $CDFILIAL,
        'NRVENDAREST' => $NRVENDAREST,
        'NRCOMANDA' => $NRCOMANDA,
        'CDLOJA' => $CDLOJA,
        'DSCOMANDA' => $NRVENDAREST, // gerar com o util
        'IDSTCOMANDA' => '1',
        'SGSEXOCON' => 'M',
        'TXMOTIVCANCE'  => '',
        'VRACRCOMANDA' => 0,
        'CDPAIS' => null,
        'SGESTADO' => null,
        'CDMUNICIPIO' => null,
        'NRCEPCONSCOMAND' => null,
        'CDBAIRRO' => null,
        'DSBAIRRO' => null,
        'DSENDECONSCOMAN' => null,
        'DSCOMPLENDCOCOM' => null,
        'DSREFENDCONSCOM' => null,
        'IDORGCMDVENDA' => 'BAL_AUT',
        'IDRETBALLOJA' => 'N',
        'NRCOMANDAEXT' => null,
        'IDSINCAGENDA' => 'S',
        'DTHRAGENDADA' => null,
        'IDIMPCUPEXP' => null,
        'DSCONSUMIDOR' => isset($dadosCliente['DSCONSUMIDOR']) ? $dadosCliente['DSCONSUMIDOR'] : null,
        'VRDESCFID' => null,
        'DSOBSCOMANDA' => null,
        'IDCOMANDAPAGA' => 'N',
        'CDCAMPANHA' => null,
        'VRPONTOBRINDE' => null,
        'VRDESCFIDELIDAD' => null,
        'DSCUPOMPROMO' => null
      );
      $this->entityManager->getConnection()->beginTransaction();
      $this->entityManager->getConnection()->executeQuery('INSERT_VENDAREST', $VENDAREST);
      $this->entityManager->getConnection()->executeQuery('INSERT_COMANDAVEN', $COMANDAVEN);
      foreach ($cart as $x) {
        if (empty($x['comboItems'])) {
          $NRPRODCOMVEN = $this->utilAPI->geraCodigo($connection, 'ITCOMANDAVEN' . $CDFILIAL . $NRCOMANDAVEN, 1, 1, 6);
          $ITCOMANDAVEN = array(
            'CDFILIAL' => $CDFILIAL,
            'NRVENDAREST' => $NRVENDAREST,
            'NRCOMANDA' => $NRCOMANDA,
            'NRPRODCOMVEN' => $NRPRODCOMVEN, // Gerar código - Verifica se existe, se não existir, 00001, se não soma, // ? 
            'CDPRODUTO' => $x['CDPRODUTO'],
            'QTPRODCOMVEN' => $x['QTPRODVEND'], // quantidade do produto,
            'VRPRECCOMVEN' => $x['PRICE']['VRPRECITEM'], // preco do produto,
            'TXPRODCOMVEN' => null, // comentário do produto (observação personalizada * Conferir),
            'IDSTPRCOMVEN' => '3',
            'VRDESCCOMVEN' => '0', // valor do desconto do produto,
            'NRLUGARMESA' => '01',
            'IDPRODIMPFIS' => 'N', // * Conferir,
            'CDLOJA' => $CDLOJA,
            'VRACRCOMVEN' => '0', // Valor do acréscimo do produto,
            'NRSEQPRODCOM' => '', // Gerar código - Verifica se existe, se não existir, 001, se não soma,
            'NRSEQPRODCUP' => null, // Gerar código ,
            'VRPRECCLCOMVEN' => null,
            'CDCAIXACOLETOR' => $dadosContent['CDCAIXA'],
            'CDPRODPROMOCAO' => null, // Verificar se produto é promoção inteligente ou produto combinado para colocar o cdprodpromocao,
            'CDVENDEDOR' => null, // Verificar se produto é promoção inteligente ou produto combinado para colocar o cdprodpromocao,
            'CDSENHAPED' => self::generateCDSENHAPED($CDFILIAL, $dadosContent['NRORG']), //Número da senha do pedido do produto / Função na API,
            'NRATRAPRODCOVE' => null, // Segura do KDS (Verificar se o TAA trata dessa funcionalidade (Y - Segura, N - Normal),
            'IDORIGEMVENDA' => null,
            'NRINSCRCONS' => null
          );
          $itcomandavenBD = $this->entityManager->getConnection()->executeQuery('INSERT_ITCOMANDAVEN', $ITCOMANDAVEN);
        } else {
          foreach ($x['comboItems'] as $comboItem) {
            $NRPRODCOMVEN = $this->utilAPI->geraCodigo($connection, 'ITCOMANDAVEN' . $CDFILIAL . $NRCOMANDAVEN, 1, 1, 6);
            $ITCOMANDAVEN = array(
              'CDFILIAL' => $CDFILIAL,
              'NRVENDAREST' => $NRVENDAREST,
              'NRCOMANDA' => $NRCOMANDA,
              'NRPRODCOMVEN' => $NRPRODCOMVEN, // Gerar código - Verifica se existe, se não existir, 00001, se não soma, // ? 
              'CDPRODUTO' => $comboItem['CDPRODUTO'],
              'QTPRODCOMVEN' => $comboItem['QTPRODVEND'], // quantidade do produto,
              'VRPRECCOMVEN' => $comboItem['PRICE']['VRPRECITEM'], // preco do produto,
              'TXPRODCOMVEN' => null, // comentário do produto (observação personalizada * Conferir),
              'IDSTPRCOMVEN' => '3',
              'VRDESCCOMVEN' => '0', // valor do desconto do produto,
              'NRLUGARMESA' => '01',
              'IDPRODIMPFIS' => 'N', // * Conferir,
              'CDLOJA' => $CDLOJA,
              'VRACRCOMVEN' => '0', // Valor do acréscimo do produto,
              'NRSEQPRODCOM' => '', // Gerar código - Verifica se existe, se não existir, 001, se não soma,
              'NRSEQPRODCUP' => null, // Gerar código ,
              'VRPRECCLCOMVEN' => null,
              'CDCAIXACOLETOR' => $dadosContent['CDCAIXA'],
              'CDPRODPROMOCAO' => $x['CDPRODUTO'], // Verificar se produto é promoção inteligente ou produto combinado para colocar o cdprodpromocao,
              'CDVENDEDOR' => null,
              'CDSENHAPED' => self::generateCDSENHAPED($CDFILIAL, $dadosContent['NRORG']), //Número da senha do pedido do produto / Função na API,
              'NRATRAPRODCOVE' => null, // Segura do KDS (Verificar se o TAA trata dessa funcionalidade (Y - Segura, N - Normal),
              'IDORIGEMVENDA' => null,
              'NRINSCRCONS' => null
            );
            try {
              $itcomandavenBD = $this->entityManager->getConnection()->executeQuery('INSERT_ITCOMANDAVEN', $ITCOMANDAVEN);
              
            } catch (\Exception $e) {
              // self::cancelSale($NRCOMANDA, $NRVENDAREST, $CDFILIAL);
              $response->setError(new Error($e->getMessage(), 500));
              $response->addMessage(new Message($e->getMessage()));
            }
          }
        }
      }
      $CDSENHAPEDAPI = $ITCOMANDAVEN['CDSENHAPED'];
      $respostaImpressaoCredito = $this->cashApi->imprimeCupomDinheiro($VENDAREST, $ITEMVENDA['handledProducts'], $dadosContent, $TOTALVENDA);
      if($respostaImpressaoCredito['error'] == true) {
        $this->entityManager->getConnection()->rollBack();
        $response->addMessage(new Message($respostaImpressaoCredito['message']));
        throw new \Exception($respostaImpressaoCredito['message']);
      } else {
        $this->entityManager->getConnection()->commit();
        $response->addDataSet(new \Zeedhi\Framework\DataSource\DataSet('PerformSaleRepository', array(
          'orderCode' => $CDSENHAPEDAPI)));
      }
    } catch (\Exception $e) {
      $response->setError(new Error($e->getMessage(), 500));
      $response->addMessage(new Message($e->getMessage()));   
    }
  }

}
